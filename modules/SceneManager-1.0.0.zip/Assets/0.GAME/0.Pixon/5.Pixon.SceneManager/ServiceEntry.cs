using System.Collections;
using UnityEngine;

/// <summary>A service the Service scene brings up (ads, analytics, remote config...); GameEntry waits for each one in turn.</summary>
public interface IServiceInitializer
{
    IEnumerator Initialize();
}

/// <summary>Root of the Service scene: initializes every IServiceInitializer under it, then keeps them alive across scenes.</summary>
public class ServiceEntry : MonoBehaviour
{
    public IEnumerator Initialize()
    {
        DontDestroyOnLoad(gameObject);
        foreach (var service in GetComponentsInChildren<IServiceInitializer>(true))
        {
            Bug.Log($"{service.GetType().Name} initializing");
            yield return service.Initialize();
        }
    }
}
