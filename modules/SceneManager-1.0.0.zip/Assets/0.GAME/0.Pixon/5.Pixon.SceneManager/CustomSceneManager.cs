﻿using System;
using System.Collections;
using Pixon.Audio;
using Pixon.Observer;
using UnityEngine;

public class CustomSceneManager : MonoBehaviour
{
    public static CustomSceneManager Instance;
    private Coroutine loadCoroutine;

    private void Awake()
    {
        Instance = this;
        DontDestroyOnLoad(this.gameObject);
    }

    public IEnumerator EnterGameplay()
    {
        EventService.Raise(new LoadingProgressEvent(90, "Loading"));
        yield return LoadSceneAsync(SceneName.GameScene, () =>
        {
            EventService.Raise(new LoadingProgressEvent(100, "Loading Completed!"));
            GameScreens.ShowGameplay?.Invoke();
            GameService.IsLobby = false;
        });
        GameService.AudioManager.PlayMusic(MusicID.BGMusic, true);
    }

    public void EnterLobby()
    {
        CancelCoroutine(loadCoroutine);
        loadCoroutine = StartCoroutine(EnterLobbyRoutine());
    }

    public IEnumerator EnterLobbyRoutine()
    {
        EventService.Raise(new LoadingProgressEvent(90, "Loading"));
        yield return LoadSceneAsync(SceneName.LOBBY, () =>
        {
            EventService.Raise(new LoadingProgressEvent(100, "Loading Completed!"));
            GameScreens.ShowLobby?.Invoke();
            GameService.IsLobby = true;
        });
        GameService.AudioManager.PlayMusic(MusicID.BGMusic, true);
    }

    public void ReloadGameplay()
    {
        CancelCoroutine(loadCoroutine);
        loadCoroutine = StartCoroutine(ReloadGameplayRoutine());
    }

    private IEnumerator ReloadGameplayRoutine()
    {
        yield return EnterGameplay();
    }

    public void LoadScene(string sceneName, Action onComplete)
    {
        EventService.Raise(new LoadingProgressEvent(90, "Loading"));
        CancelCoroutine(loadCoroutine);
        loadCoroutine = StartCoroutine(LoadSceneAsync(sceneName, ()=>
        {
            onComplete?.Invoke();
        }));
    }

    public IEnumerator LoadSceneAsync(string sceneName, Action onComplete)
    {
        yield return new WaitForSeconds(0.25f);
        AsyncOperation asyncLoad = UnityEngine.SceneManagement.SceneManager.LoadSceneAsync(sceneName);
        asyncLoad.allowSceneActivation = false;
        while (asyncLoad.progress < 0.9f)
        {
            yield return new WaitForSeconds(0.5f);
        }
        asyncLoad.allowSceneActivation = true;
        onComplete?.Invoke();
    }

    private void CancelCoroutine(Coroutine coroutine)
    {
        if (coroutine != null)
            StopCoroutine(coroutine);
        coroutine = null;
    }
}
public static class SceneName
{
    public const string SPLASH = "Splash";
    public const string LOBBY = "Lobby";
    public const string ServicesScene = "Services";
    public const string GameScene = "Game";
    public const string AssetScene = "AssetScene";
}
