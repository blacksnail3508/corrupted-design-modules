using System.Collections;
using Pixon.Audio;
using Pixon.Feature;
using Pixon.Observer;
using UnityEngine;

public class GameEntry : MonoBehaviour
{
    private CustomSceneManager sceneManager => CustomSceneManager.Instance;
    [SerializeField] Clock clock;
    [SerializeField] FeatureManager featureManager;
    private void Start()
    {
        DontDestroyOnLoad(gameObject);
        StartCoroutine(Entry());
    }

    private IEnumerator Entry()
    {
        #if !UNITY_EDITOR
        Application.targetFrameRate = 60;
        #endif
        GameService.GameMode = GameMode.Playing;
        yield return clock.Activate();
        
        EventService.Raise(new LoadingProgressEvent(15, "Checking Update..."));
        // yield return updater.StartUpdate();

        // EventService.Raise(new LoadingProgressEvent(25, "Initializing Services"));
        // yield return sceneManager.LoadSceneAsync(SceneName.ServicesScene, null);
        
        EventService.Raise(new LoadingProgressEvent(50, "Loading Features Data"));
        yield return featureManager.LoadFeaturesData();
        yield return featureManager.CheckDayAll(true);
        
        EventService.Raise(new LoadingProgressEvent(60, "Preparing Features"));
        yield return featureManager.StartAllFeature();
        
        EventService.Raise(new LoadingProgressEvent(80, "Loading Assets"));

        if (GameService.DataManager.Level <= GameService.LobbyStartLevel)
        {
            yield return EnterGameplay();
        }
        else
        {
            yield return sceneManager.EnterLobbyRoutine();
        }
    }

    private IEnumerator EnterGameplay()
    {
        yield return sceneManager.EnterGameplay();
    }
}

public class LoadingProgressEvent : GameEvent
{
    public float progress;
    public string message;
    public LoadingProgressEvent(float progress, string message)
    {
        this.progress = progress;
        this.message = message;
    }
}