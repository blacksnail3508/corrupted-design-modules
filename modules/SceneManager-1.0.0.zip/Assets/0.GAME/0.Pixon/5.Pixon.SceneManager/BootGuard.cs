using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Sends a scene played on its own back to Splash, so the managers in GameService exist before it runs.</summary>
[DefaultExecutionOrder(-1000)]
public class BootGuard : MonoBehaviour
{
    private void Awake()
    {
        if (GameService.UIManager != null) return;
        // Index 0 is Splash in the build list.
        SceneManager.LoadScene(0);
    }
}
