using System;
using UnityEngine;

namespace CorruptedDesign.UI
{
    public abstract class UIAnimation : MonoBehaviour
    {
        public abstract void PlayIn(Action onComplete = null);
        public abstract void PlayOut(Action onComplete = null);
    }
}