using CorruptedDesign.Audio;
using Sirenix.OdinInspector;
using UnityEngine;

public class SoundPlayer : MonoBehaviour
{
    [SerializeField] private SoundID soundID;

    [Button]
    public void PlaySound()
    {
        GameService.AudioManager.PlaySound(soundID);
    }
}
