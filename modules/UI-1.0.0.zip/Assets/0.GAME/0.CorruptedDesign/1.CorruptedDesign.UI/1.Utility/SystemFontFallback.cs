using TMPro;
using UnityEngine;

/// <summary>Adds the device's own fonts as TMP fallbacks, for symbols (currency signs) the game font lacks.</summary>
public static class SystemFontFallback
{
    // System font families tried in order; each one covering any probe symbol is kept as a fallback.
    private static readonly string[] Families = { "Roboto", "Noto Sans", "Noto Sans Thai", "Helvetica Neue", "Arial" };
    private const string Probe = "₴₸₾₨฿֏؋৳៛﷼";

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void Install()
    {
        // Editor fonts are the desktop's, not the device's, so the result would mislead.
        if (Application.isEditor) return;

        foreach (var family in Families)
        {
            var asset = TMP_FontAsset.CreateFontAsset(family, "Regular");
            if (asset == null) continue;

            int covered = 0;
            foreach (var symbol in Probe)
                if (asset.HasCharacter(symbol, false, true)) covered++;
            Bug.Log($"[Font] system '{family}' covers {covered}/{Probe.Length} probe symbols");

            if (covered > 0) TMP_Settings.fallbackFontAssets.Add(asset);
            else Discard(asset);
        }
    }

    private static void Discard(TMP_FontAsset asset)
    {
        Object.Destroy(asset.atlasTexture);
        Object.Destroy(asset.material);
        Object.Destroy(asset);
    }
}
