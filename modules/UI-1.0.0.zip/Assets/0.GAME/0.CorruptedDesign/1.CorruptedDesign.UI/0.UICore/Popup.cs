using CorruptedDesign.Audio;

namespace CorruptedDesign.UI
{
    /// <summary>A window stacked on the popup layer, with the open and close sounds.</summary>
    public abstract class Popup : Window
    {
        public override void Show()
        {
            GameService.PlaySound(SoundID.PopupOpen);
            base.Show();
        }

        protected override void OnHidden()
        {
            base.OnHidden();
            GameService.PlaySound(SoundID.PopupClose);
        }
    }
}
