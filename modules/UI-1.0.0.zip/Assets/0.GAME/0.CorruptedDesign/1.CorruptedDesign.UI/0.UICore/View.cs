namespace CorruptedDesign.UI
{
    /// <summary>A full screen on the HUD layer, swapped in and out silently.</summary>
    public abstract class View : Window
    {
    }
}
