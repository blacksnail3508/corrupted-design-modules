using CorruptedDesign.UI;
using System;
using Sirenix.OdinInspector;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace CorruptedDesign.UI
{
    [RequireComponent(typeof(CanvasGroup), typeof(Canvas), typeof(GraphicRaycaster))]
    public abstract class Window : MonoBehaviour
    {
        [SerializeField, FoldoutGroup("BASE WINDOW")] protected UIAnimation uiAnimation;
        [SerializeField] private UnityEvent onShow;
        [SerializeField, ReadOnly] public UITrigger LastTrigger;
        [SerializeField] private bool IsPersistent = false;
        [SerializeField] public bool IsTracking = true;
        
        Action onCloseCallback;
        bool IsHiding = false;
        CanvasGroup canvasGroup;
        CanvasGroup Group => canvasGroup ? canvasGroup : canvasGroup = GetComponent<CanvasGroup>();
        public bool IsShowAnimationDone { get; private set; }
        public float ShowAnimationDoneAt { get; private set; }
        public bool IsClosing => IsHiding;
        public virtual bool IsShowing
        {
            get
            {
                return gameObject.activeSelf;
            }
        }

        public abstract string PopupType { get; }

        private void Awake()
        {
            Initialize();
        }
        /// <summary>
        /// Initializes the Window
        /// </summary>
        /// 
        public virtual void Initialize()
        {
        }
        /// <summary>
        /// Show UI to user/ Set active true to this game object, play show animation
        /// </summary>
        public virtual void Show()
        {
            gameObject.SetActive(true);
            Group.interactable = true;
            Delay.Cancel(this);
            transform.SetAsLastSibling();
            PlayAnim();
            onShow?.Invoke();
        }
        
        void PlayAnim()
        {
            IsShowAnimationDone = false;
            if (uiAnimation == null) CompleteShowAnimation();
            else uiAnimation.PlayIn(CompleteShowAnimation);
        }

        void CompleteShowAnimation()
        {
            IsShowAnimationDone = true;
            ShowAnimationDoneAt = Time.unscaledTime;
            OnAnimationComplete();
        }

        /// <summary>
        /// Call when close upper popup to reveal this UI
        /// </summary>
        public virtual void OnReveal()
        {
            gameObject.SetActive(true);
            Group.interactable = true;
            transform.SetAsLastSibling();
        }
        
        /// <summary>
        /// Called after animation/director complete
        /// </summary>
        public virtual void OnAnimationComplete()
        {
        }

        /// <summary>
        /// Hides the Window
        /// </summary>
        public virtual void Hide(Action onComplete = null)
        {
            if (!this.gameObject.activeSelf) return;
            if (IsHiding) return;
            IsHiding = true;
            // Buttons stay hittable through PlayOut; a spam tap would re-run their handler (double purchase).
            Group.interactable = false;

            if (uiAnimation)
                uiAnimation.PlayOut(() => OnHideCompletely(onComplete));
            else OnHideCompletely(onComplete);

            ResetData();
        }

        private void OnHideCompletely(Action callback = null)
        {
            OnHidden();
            gameObject.SetActive(false);
            IsHiding = false;
            callback?.Invoke();
            
            onCloseCallback?.Invoke();
            onCloseCallback = null;
            
            if (IsPersistent == false) AutoDestroy();
        }

        /// <summary>Called once the hide animation is over, just before the window is deactivated.</summary>
        protected virtual void OnHidden()
        {
        }

        public Window SetOnCloseCallback(Action callback)
        {
            this.onCloseCallback = callback;
            return this;
        }

        public virtual void AutoDestroy()
        {
            Debug.Log($"Auto destroy {this.gameObject.name} after 10s");
            Delay.Cancel(this);
            Delay.Call(15f, () =>
            {
                GameService.UIManager.DestroyPopup(this);
            }, this);
        }

        public void HideImmediate()
        {
            Hide();
        }
        /// <summary>
        /// ResetData for show next time
        /// </summary>
        public virtual void ResetData()
        {
        }
        
        public void AutoHookAnimation(UIAnimation anim)
        {
            this.uiAnimation = anim;
        }
    }
}
public static class WindowExtension
{
    public static T ShowPopup<T>(this MonoBehaviour mono, UITrigger trigger, int level = -1) where T : Popup
    {
        if (GameService.UIManager == null) return null;
        return GameService.UIManager.ShowPopup<T>(trigger, level);
    }
    
    public static T Replace<T>(this MonoBehaviour mono, UITrigger trigger, int level = -1) where T : Popup
    {
        if (level == -1) level = GameService.DataManager.Level;
        if (GameService.UIManager == null) return null;
        return GameService.UIManager.ReplacePopup<T>(level, trigger);
    }
    public static T ShowView<T>(this MonoBehaviour mono) where T : View
    {
        if (GameService.UIManager == null) return null;
        return GameService.UIManager.ShowView<T>();
    }

    public static void ClosePopup<T>(this MonoBehaviour mono) where T : Popup
    {
        if (GameService.UIManager == null) return;
        GameService.UIManager.ClosePopup<T>();
    }
    public static void ClosePopup(this MonoBehaviour mono)
    {
        if (GameService.UIManager == null) return;
        GameService.UIManager.ClosePopup();
    }
    public static void CloseAllPopups(this MonoBehaviour mono)
    {
        if (GameService.UIManager == null) return;
        GameService.UIManager.ClosePopups();
    }
}