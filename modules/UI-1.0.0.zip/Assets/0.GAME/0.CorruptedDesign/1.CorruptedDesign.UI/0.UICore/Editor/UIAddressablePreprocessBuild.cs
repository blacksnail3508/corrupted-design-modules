using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace CorruptedDesign.UI.Editor
{
    public class UIAddressablePreprocessBuild : IPreprocessBuildWithReport
    {
        public int callbackOrder => 0;

        public void OnPreprocessBuild(BuildReport report)
        {
            var settings = AddressableAssetSettingsDefaultObject.Settings;
            if (settings == null)
            {
                Debug.LogWarning("[CorruptedDesign UI] Addressable settings not found — skipping UI address fix.");
                return;
            }

            int fixedCount = 0;
            foreach (var guid in AssetDatabase.FindAssets("t:Prefab"))
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                var prefab  = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (prefab == null) continue;

                var win = prefab.GetComponent<Window>();
                if (win == null) continue;

                var entry = settings.FindAssetEntry(guid);
                if (entry == null) continue;

                string typeName = win.GetType().FullName;
                if (entry.address == typeName) continue;

                entry.SetAddress(typeName);
                fixedCount++;
            }

            if (fixedCount > 0)
            {
                settings.SetDirty(UnityEditor.AddressableAssets.Settings.AddressableAssetSettings.ModificationEvent.EntryModified, null, true);
                AssetDatabase.SaveAssets();
                Debug.Log($"[CorruptedDesign UI] Pre-build: fixed {fixedCount} UI prefab address(es).");
            }
            else
            {
                Debug.Log("[CorruptedDesign UI] Pre-build: all UI addresses are up to date.");
            }
        }
    }
}
