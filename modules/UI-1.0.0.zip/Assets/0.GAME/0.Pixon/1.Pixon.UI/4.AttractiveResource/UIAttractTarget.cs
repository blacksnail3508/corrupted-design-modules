using DG.Tweening;
using UnityEngine;
using UnityEngine.Events;

public class UIAttractTarget : MonoBehaviour
{
    private void OnValidate()
    {
        if(RectTransform == null) RectTransform =  transform as RectTransform;
    }

    public RectTransform RectTransform;
    [SerializeField] private UnityEvent onFirstItemArrived;
    [SerializeField] private ParticleSystem collectVFX;
    private Sequence _pulseSeq;

    public void OnIconReached()
    {
        PlayPulse();
        PlayCollectVFX();
    }

    private void PlayCollectVFX()
    {
        if (!collectVFX) return;
        collectVFX.gameObject.SetActive(true);
        collectVFX.Stop();
        collectVFX.Play();
    }

    public void StopCollectVFX()
    {
        if (!collectVFX) return;
        collectVFX.Stop();
        collectVFX.gameObject.SetActive(false);
    }

    private void PlayPulse()
    {
        // Kill any running pulse sequence before starting a new one
        onFirstItemArrived?.Invoke();
        _pulseSeq?.Kill();

        RectTransform.localScale = Vector3.one;

        _pulseSeq = DOTween.Sequence();
        _pulseSeq.Append(RectTransform.DOScale(1.1f, 0.1f).SetEase(Ease.OutQuad));
        _pulseSeq.Append(RectTransform.DOScale(1f, 0.1f).SetEase(Ease.InQuad));
    }
}
