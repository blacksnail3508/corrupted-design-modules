# UIAttractor System - Setup Guide

Hướng dẫn cài đặt và sử dụng hệ thống **UIAttractor** để tạo hiệu ứng các item (vàng, kim cương, v.v.) bay từ một điểm đến đích trên UI (thường là các icon trên HUD).

## 📋 Tổng Quan

Hệ thống bao gồm các thành phần chính:

1. **[UIAttractor.cs](file:///c:/Projects/tap_farm_away/Assets/GAME/6.UI/UISystem/AttractiveResource/UIAttractor.cs)** - Manager điều khiển việc tạo và pooling các icon.
2. **[UIAttractIcon.cs](file:///c:/Projects/tap_farm_away/Assets/GAME/6.UI/UISystem/AttractiveResource/UIAttractIcon.cs)** - Component cho từng icon bay (đã được tối ưu bằng DOTween).
3. **[UIAttractTarget.cs](file:///c:/Projects/tap_farm_away/Assets/GAME/6.UI/UISystem/AttractiveResource/UIAttractTarget.cs)** - Điểm đích trên UI, hỗ trợ hiệu ứng pulse khi item chạm đích.
4. **UIAttractConfig** - Chứa các thông số cấu hình về thời gian, hiệu ứng (easing), và khoảng cách.

---

## 🚀 Setup Instructions

### Bước 1: Tạo Icon Prefab

1. Tạo một **UI Image** mới.
2. Thêm component **UIAttractIcon**.
3. Kéo chính Image đó vào field **Icon** của component.
4. Kéo Image này vào Project để tạo prefab (ví dụ: `CoinIcon_Prefab`).

### Bước 2: Setup Target (Điểm Đích)

1. Chọn UI Element bạn muốn làm đích đến (ví dụ: Icon vàng trên Header).
2. Thêm component **UIAttractTarget**.
3. (Tùy chọn) Gán các sự kiện vào UnityEvent **On First Item Arrived** nếu muốn kích hoạt logic khác khi item đầu tiên chạm đích.

### Bước 3: Setup Attractor Manager

1. Tạo một GameObject trong Canvas (thường đặt tên là `CoinAttractor`).
2. Thêm component **UIAttractor**.
3. **Cấu hình References:**
   - **Prefab**: Gán prefab đã tạo ở Bước 1.
   - **Appear VFX**: (Tùy chọn) Gán Particle System sẽ xuất hiện tại điểm bắt đầu.
4. **Cấu hình Config:**
   - **Start Point**: Vị trí mặc định bắt đầu (thường gán là vị trí Manager).
   - **Target**: Gán component **UIAttractTarget** đã tạo ở Bước 2.
   - **Sprite**: Hình ảnh icon sẽ bay (vàng, kim cương...).
   - **Config**: Thiết lập size, durations, easing, v.v.

---

## ⚙️ Configuration Options (UIAttractConfig)

| Thông số | Mô tả |
|---------|-------|
| **Size** | Kích thước của icon khi bay. |
| **Appear Duration** | Thời gian icon xuất hiện và "văng" (dash) ra ngoài. |
| **Move Duration** | Thời gian icon bay từ điểm dash đến điểm đích. |
| **Dash Distance** | Khoảng cách icon văng ra ngẫu nhiên trước khi bay về đích. |
| **Appear Ease** | Kiểu chuyển động khi xuất hiện (thường dùng `OutBack`). |
| **Move Ease** | Kiểu chuyển động khi bay về đích (thường dùng `InQuad`). |
| **Interval** | Khoảng cách thời gian giữa mỗi icon khi bay theo chuỗi. |

---

## 💡 Usage Examples

### Gọi hiệu ứng từ Code

```csharp
public UIAttractor coinAttractor;
public Transform spawnPoint; // Ví dụ: vị trí của enemy vừa bị tiêu diệt

public void AddCoins(int amount)
{
    // Gọi hiệu ứng: 10 items bay từ spawnPoint đến target mặc định
    coinAttractor.DoAttract(spawnPoint, coinAttractor.target, 10, () => {
        Debug.Log("Hoàn thành hiệu ứng bay!");
        // Thêm logic cộng tiền tại đây
    });
}
```

### Sử dụng với Default Settings

Nếu bạn đã setup `startPoint` và `target` trong Inspector, bạn chỉ cần gọi:

```csharp
coinAttractor.DoAttract(15); // Bay 15 items sử dụng settings mặc định
```

---

## 🏗️ System Architecture

```mermaid
sequenceDiagram
    participant User as C# Code
    participant Mgr as UIAttractor
    participant Pool as Pool (Queue)
    participant Icon as UIAttractIcon
    participant Target as UIAttractTarget

    User->>Mgr: DoAttract(count)
    loop i < count
        Mgr->>Pool: Get icon
        Pool-->>Mgr: Return Icon
        Mgr->>Icon: Init(sprite, config)
        Mgr->>Icon: DoAttract(start, end)
        Icon->>Icon: Animation sequence (DOTween)
        Icon->>Target: OnIconReached()
        Target->>Target: PlayPulse()
        Icon->>Pool: Return to Pool
    end
    Mgr-->>User: OnComplete Callback
```

---

## ✨ Features

- ✅ **Object Pooling** - Tối ưu hiệu năng, không Instantiate/Destroy liên tục.
- ✅ **Catmull-Rom Path** - Item bay theo đường cong tự nhiên, không bay thẳng.
- ✅ **Randomized Dash** - Các item văng ra hướng ngẫu nhiên tạo cảm giác sống động.
- ✅ **Pulse Animation** - Tạo phản hồi thị giác (feedback) tại điểm đích.
- ✅ **Configurable** - Dễ dàng thay đổi thời gian, kích thước và curve thông qua Inspector.
- ✅ **Callback Support** - Hỗ trợ Action gọi lại sau khi hoàn thành chuỗi hiệu ứng.

---

## 📝 Notes

- **Z-Order**: Đảm bảo các layer UI chứa `UIAttractor` nằm phía trên các thành phần khác để icon không bị che khuất.
- **Particle**: Nếu dùng `AppearVFX`, hãy đảm bảo nó là World Space hoặc Overlay tùy theo Canvas setting.
- **Default Sprite**: Bạn có thể thay đổi `sprite` trên manager để dùng chung một hệ thống cho nhiều loại resource khác nhau.
