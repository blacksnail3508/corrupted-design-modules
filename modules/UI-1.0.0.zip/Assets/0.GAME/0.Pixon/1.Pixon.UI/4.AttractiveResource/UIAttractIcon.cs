using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public class UIAttractIcon : MonoBehaviour
{
    [SerializeField] Image icon;
    private UIAttractor Root;
    private UIAttractConfig config;
    
    public void Init(UIAttractor root, Sprite sprite, UIAttractConfig _config)
    {
        Root = root;
        this.icon.sprite = sprite;
        this.config = _config;
        
        icon.rectTransform.sizeDelta = config.iconSize;
        this.transform.localScale = Vector3.zero;
        icon.enabled = true;//it disable by default to prevent render error
    }
    
    private void ReturnPool()
    {
        this.gameObject.SetActive(false);
        Root.OnIconReturn(this); // Enqueue to pool
    }
    
    public void DoAttract(Transform startPoint, UIAttractTarget endPoint, float delay = 0)
    {
        RectTransform rect = icon.rectTransform;
        icon.enabled = true;

        // Reset state
        rect.localScale = Vector3.zero;
        rect.position = startPoint.position;
        this.gameObject.SetActive(true);
        
        // Random dash direction (UI space)
        Vector2 dashDir = Random.insideUnitCircle.normalized * (config.dashDistance + Random.Range(-30f, 30f));
        Vector3 dashTarget = rect.position + new Vector3(dashDir.x, dashDir.y, 0f);

        // Tween sequence
        Sequence seq = DOTween.Sequence();

        // Optional initial delay before starting animation
        if (delay > 0f)
            seq.AppendInterval(delay);

        // Step 1: Scale from 0 to 1
        seq.Append(rect.DOScale(1f, config.appearDuration).SetEase(config.appearEase));

        // Step 2: Dash outward
        seq.Join(rect.DOMove(dashTarget, config.appearDuration).SetEase(config.appearEase));

        // Step 3: Curve to end point
        float centerScaler = 0.4f;
        Vector3 midPoint = (1-centerScaler)*startPoint.position + endPoint.RectTransform.position * centerScaler;
        Vector3[] pathPoints = new Vector3[]
        {
            dashTarget,
            midPoint,
            endPoint.RectTransform.position
        };

        seq.Append(rect.DOPath(pathPoints, config.moveDuration, PathType.CatmullRom)
            .SetEase(config.moveEase)
            .OnComplete(() =>
            {
                endPoint.OnIconReached();
                ReturnPool();
            }));
    }
}