using System;
using System.Collections.Generic;
using DG.Tweening;
using Sirenix.OdinInspector;
using UnityEngine;
using UnityEngine.Events;

public class UIAttractor : MonoBehaviour
{
    [SerializeField, FoldoutGroup("REFERENCES")] private UIAttractIcon prefab;

    [SerializeField, FoldoutGroup("REFERENCES")] private ParticleSystem AppearVFX;
    Queue<UIAttractIcon> Pool = new Queue<UIAttractIcon>();
    
    [SerializeField, FoldoutGroup("CONFIG")]Transform startPoint;
    [SerializeField, FoldoutGroup("CONFIG")]UIAttractTarget target;
    
    [SerializeField, FoldoutGroup("CONFIG")] Sprite sprite;
    [SerializeField, FoldoutGroup("CONFIG")] UIAttractConfig config;
    [SerializeField] UnityEvent OnBurst;

    private UIAttractIcon GetNewIcon(Sprite overrideSprite = null)
    {
        UIAttractIcon icon;

        if (Pool.Count > 0) icon = Pool.Dequeue();
        else icon = Instantiate(prefab, this.transform);

        icon.Init(this, overrideSprite ? overrideSprite : sprite, config);
        return icon;
    }

    public void DoAttract(Transform _startPoint, UIAttractTarget endPoint, int iconCount, Action OnComplete = null, Sprite overrideSprite = null)
    {
        if (AppearVFX)
        {
            AppearVFX.transform.position = _startPoint.position;
            AppearVFX.Stop();
            AppearVFX.Play();
        }

        OnBurst?.Invoke();

        for (int i = 0; i < iconCount; i++)
        {
            var icon = GetNewIcon(overrideSprite);
            Delay.Call(i*config.interval, () =>
            {
                icon.DoAttract(_startPoint, endPoint);
            });
        }

        float totalTime = config.appearDuration + config.moveDuration + iconCount * config.interval;
        Delay.Call(totalTime*0.66f, () =>
        {
            OnComplete?.Invoke();
            Bug.Log("Complete");
        });
    }

     public void DoAttractFullTime(Transform _startPoint, UIAttractTarget endPoint, int iconCount, Action OnComplete = null, Sprite overrideSprite = null)
    {
        if (AppearVFX)
        {
            AppearVFX.transform.position = _startPoint.position;
            AppearVFX.Stop();
            AppearVFX.Play();
        }

        OnBurst?.Invoke();

        for (int i = 0; i < iconCount; i++)
        {
            var icon = GetNewIcon(overrideSprite);
            Delay.Call(i*config.interval, () =>
            {
                icon.DoAttract(_startPoint, endPoint);
            });
        }

        float totalTime = config.appearDuration + config.moveDuration + iconCount * config.interval;
        Delay.Call(totalTime, () =>
        {
            OnComplete?.Invoke();
            Bug.Log("Complete");
        });
    }

    [Button]
    public void DoAttract(Action OnComplete = null)
    {
        DoAttract(startPoint, target, 10, OnComplete);
    }

    public void DoAttract(int itemCount, Action OnComplete = null)
    {
        DoAttract(startPoint, target, itemCount, OnComplete);
    }

    public void OnIconReturn(UIAttractIcon icon)
    {
        Pool.Enqueue(icon);
    }
}

[Serializable]
public class UIAttractConfig
{
    public Vector2 iconSize;
    public float appearDuration = 0.5f;
    public float moveDuration = 0.5f;
    public float dashDistance = 150f;
    public Ease appearEase = Ease.OutBack;
    public Ease moveEase = Ease.InQuad;
    public float interval = 0.035f;
}
