using DG.Tweening;
using TMPro;
using UnityEngine;

public class PushNotification : MonoBehaviour
{
    [Header("REFERENCES")]
    [SerializeField] RectTransform rectTF;
    [SerializeField] TMP_Text text; 
    
    [Header("CONFIG")]
    [Tooltip("Time to this notification to animate show. If = 0, this will show immidiately")]
    [SerializeField] float showDuration = 0.1f;

    [Tooltip("Time to this notification to stay visible before hide")]
    [SerializeField] float visibleDuration = 2.5f;

    [Tooltip("Time to this notification to animate hide")]
    [SerializeField] float hideDuration = 0.15f;

    [Tooltip("Height of noti")]
    [SerializeField] float height = 100;

    private void OnValidate()
    {
        //auto cache rect transform
        rectTF = GetComponent<RectTransform>();
    }

    public void Init(float showDuration, float visibleDuration, float hideDuration,float height)
    {
        this.showDuration = showDuration;
        this.visibleDuration = visibleDuration;
        this.hideDuration = hideDuration;
        this.height = height;
    }

    public void Show(string message)
    {
        text.text = message;
        this.transform.SetAsLastSibling();

        OnShow();

        Delay.Cancel(this);
        //auto hide after visible time
        Delay.Call(visibleDuration, () =>
        {
            Hide();
        }, this);
    }

    private void OnShow()
    {
        this.gameObject.SetActive(true);

        Vector2 newSize = new Vector2(rectTF.sizeDelta.x, height);
        rectTF.DOKill();
        rectTF.DOSizeDelta(newSize, showDuration);
    }

    private void Hide()
    {
        Vector2 newSize = new Vector2(rectTF.sizeDelta.x, 0);
        rectTF.DOKill();
        rectTF.DOSizeDelta(newSize, hideDuration).OnComplete(() =>
        {
            this.gameObject.SetActive(false);
        }); ;
    }
}
