using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;

public class UIShowSequence : MonoBehaviour
{
    [SerializeField]private float tweenDuration = 0.25f;
    [SerializeField]private float interval = 0.09f;
    [SerializeField]private Ease Ease = Ease.OutBack;
    [SerializeField]private float delay = 0.25f;
    [SerializeField] private List<Transform> ItemOrder = new();
    public void Play()
    {
        for (int i = 0; i < ItemOrder.Count; i++)
        {
            var item =  ItemOrder[i];
            item.transform.localScale = Vector3.zero;
            item.transform.DOScale(Vector3.one, tweenDuration).SetDelay(delay + interval * i).SetEase(Ease);
        }
    }
}
