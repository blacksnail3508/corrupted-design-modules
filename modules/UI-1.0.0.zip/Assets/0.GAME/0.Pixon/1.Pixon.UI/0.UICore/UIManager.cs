using System;
using System.Collections.Generic;
using System.Linq;
using Pixon.Observer;
using UnityEngine.Pool;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;

namespace Pixon.UI
{
    public class UIManager : MonoBehaviour
    {
        [SerializeField] RectTransform LayerHUD;
        [SerializeField] RectTransform LayerPopup;
        [SerializeField] RectTransform LayerToast;
        [SerializeField] RectTransform BlockInteraction;
        [SerializeField] private PushNotificationManager notiManager;

        readonly Dictionary<Type, Window> m_Menu = new Dictionary<Type, Window>();
        readonly Dictionary<Type, Window> m_PopUp = new Dictionary<Type, Window>();
        readonly Dictionary<string, GameObject> m_LoadedPrefabs = new Dictionary<string, GameObject>();
        readonly Dictionary<string, AsyncOperationHandle<GameObject>> m_PrefabHandles = new Dictionary<string, AsyncOperationHandle<GameObject>>();
        public Window m_CurrentView { get; set; }
        readonly Stack<Window> m_History = new Stack<Window>();
        readonly Stack<Window> m_PopupHistory = new Stack<Window>();

        void Awake()
        {
            m_History.Clear();
            m_PopupHistory.Clear();
            GameService.UIManager = this;
            DontDestroyOnLoad(gameObject);
            SetInteractable(true);
            notiManager.Init();
        }

        void OnDestroy()
        {
            foreach (var handle in m_PrefabHandles.Values)
            {
                if (handle.IsValid())
                {
                    Addressables.Release(handle);
                }
            }

            m_LoadedPrefabs.Clear();
            m_PrefabHandles.Clear();

            if (ReferenceEquals(GameService.UIManager, this))
            {
                GameService.UIManager = null;
            }
        }

        public void ClearHistory()
        {
            m_History.Clear();
        }

        public T GetView<T>() where T : Window
        {
            return m_Menu.TryGetValue(typeof(T), out var w) ? w as T : null;
        }

        public T ShowView<T>() where T : Window
        {
            ClosePopups();

            if (m_Menu.TryGetValue(typeof(T), out var existing))
            {
                Show(existing);
                return existing as T;
            }

            var prefab = LoadWindowPrefab(typeof(T));
            if (prefab == null)
                return null;

            var newViewObject = Instantiate(prefab, LayerHUD);
            var newView = newViewObject.GetComponent<T>();
            if (newView == null)
            {
                Bug.Log($"{typeof(T).Name} prefab is missing component {typeof(T).Name}.", "red");
                Destroy(newViewObject);
                return null;
            }

            m_Menu[typeof(T)] = newView;
            Show(newView);
            return newView;
        }

        private Window Show(Window view)
        {
            if (view == null)
                return null;

            ClosePopup();

            if (m_CurrentView == view)
            {
                view.OnReveal();
                return view;
            }

            if (m_CurrentView != null)
            {
                m_History.Push(m_CurrentView);
                m_CurrentView.HideImmediate();
            }

            view.Show();
            m_CurrentView = view;
            return view;
        }

        public void GoBack()
        {
            if (m_History.Count != 0)
            {
                Show(m_History.Pop());
            }
        }

        public T GetPopup<T>() where T : Window
        {
            return m_PopUp.TryGetValue(typeof(T), out var w) ? w as T : null;
        }

        public T ShowPopup<T>(UITrigger trigger, int level = -1) where T : Window
        {
            if (level == -1) level = GameService.DataManager.Level;

            if (m_PopUp.TryGetValue(typeof(T), out var existing))
            {
                var popup = existing as T;
                if (popup.IsShowing)
                {
                    MovePopupToTop(popup);
                    popup.OnReveal();
                }
                else
                {
                    ShowPopupInternal(popup, trigger, level);
                }

                return popup;
            }

            var prefab = LoadWindowPrefab(typeof(T));
            if (prefab == null)
                return null;

            var newViewObject = Instantiate(prefab, LayerPopup);
            var newView = newViewObject.GetComponent<T>();
            if (newView == null)
            {
                Bug.Log($"{typeof(T).Name} prefab is missing component {typeof(T).Name}.", "red");
                Destroy(newViewObject);
                return null;
            }

            m_PopUp[typeof(T)] = newView;
            ShowPopupInternal(newView, trigger, level);
            return newView;
        }

        public T ReplacePopup<T>(int level, UITrigger trigger = UITrigger.Auto, Action onComplete = null) where T : Window
        {
            T result = null;
            if (m_PopupHistory.Count > 0)
            {
                var current = m_PopupHistory.Pop();
                current.Hide(() =>
                {
                    onComplete?.Invoke();
                    result = ShowPopup<T>(trigger, level);
                });
            }
            else
            {
                result = ShowPopup<T>(trigger, level);
            }

            return result;
        }

        public void ClosePopup(Action onComplete = null)
        {
            if (m_PopupHistory.Count == 0)
                return;

            ClosePopupInternal(m_PopupHistory.Pop(), onComplete);
        }

        public void DestroyPopup(Window window)
        {
            m_PopUp.Remove(window.GetType());
            Destroy(window.gameObject);

            var typeName = window.GetType().FullName;
            if (m_PrefabHandles.TryGetValue(typeName, out var handle))
            {
                if (handle.IsValid())
                    Addressables.Release(handle);
                m_PrefabHandles.Remove(typeName);
                m_LoadedPrefabs.Remove(typeName);
            }
        }

        public void ClosePopups()
        {
            foreach (var popup in m_PopupHistory)
            {
                popup.HideImmediate();
            }

            m_PopupHistory.Clear();
        }

        public void ClosePopup<T>(Action onComplete = null) where T : Window
        {
            if (m_PopupHistory.Count == 0)
                return;

            if (m_PopupHistory.Peek() is T popup)
            {
                m_PopupHistory.Pop();
                ClosePopupInternal(popup, onComplete);
            }
        }

        public bool IsAnyPopupShowing()
        {
            foreach (var popup in m_PopUp.Values)
            {
                if (popup.IsShowing) return true;
            }
            return false;
        }

        public bool IsAnyPopupShowingExcept<T>() where T : Window
        {
            foreach (var pair in m_PopUp)
            {
                if (pair.Key == typeof(T)) continue;
                if (pair.Value.IsShowing) return true;
            }
            return false;
        }

        public bool IsAnyPopupShowingExcept(ICollection<Type> ignoredTypes)
        {
            foreach (var pair in m_PopUp)
            {
                if (ignoredTypes != null && ignoredTypes.Contains(pair.Key)) continue;
                if (pair.Value.IsShowing) return true;
            }
            return false;
        }

        public void ShowToast(string message)
        {
            notiManager.PushNewNotification(message);
        }

        public void SetInteractable(bool isInteractable)
        {
            Bug.Log($"SetInteractable {isInteractable}");
            if (BlockInteraction != null)
            {
                BlockInteraction.gameObject.SetActive(!isInteractable);
            }
        }

        void ShowPopupInternal(Window popup, UITrigger trigger, int level)
        {
            m_PopupHistory.Push(popup);
            popup.LastTrigger = trigger;
            if (popup.IsTracking)
            {
                EventService.Raise(new PopupShowEvent(popup.GetType().Name, popup.PopupType, trigger, level));
                AnalyticAdapter.LogPopupShow(popup.GetType().Name, popup.PopupType);
            }

            popup.Show();
        }

        void ClosePopupInternal(Window popup, Action onComplete)
        {
            popup.Hide(() =>
            {
                onComplete?.Invoke();
                RevealTopWindow();
            });
        }

        void RevealTopWindow()
        {
            if (m_PopupHistory.Count > 0)
            {
                m_PopupHistory.Peek()?.OnReveal();
                return;
            }

            m_CurrentView?.OnReveal();
        }

        void MovePopupToTop(Window popup)
        {
            if (m_PopupHistory.Count == 0 || ReferenceEquals(m_PopupHistory.Peek(), popup))
                return;

            var orderedPopups = m_PopupHistory.ToList();
            m_PopupHistory.Clear();

            for (int i = orderedPopups.Count - 1; i >= 0; i--)
            {
                if (ReferenceEquals(orderedPopups[i], popup))
                {
                    orderedPopups.RemoveAt(i);
                    break;
                }
            }

            for (int i = orderedPopups.Count - 1; i >= 0; i--)
            {
                m_PopupHistory.Push(orderedPopups[i]);
            }

            m_PopupHistory.Push(popup);
        }

        // Address convention: each UI prefab must be Addressable with address = Window type FullName.
        // Use Pixon > UI > UI Tools > Fix UI Addresses to auto-set this in the Editor.
        GameObject LoadWindowPrefab(Type requestedType)
        {
            var typeName = requestedType.FullName;

            if (m_LoadedPrefabs.TryGetValue(typeName, out var cachedPrefab))
                return cachedPrefab;

            var handle = Addressables.LoadAssetAsync<GameObject>(typeName);
            handle.WaitForCompletion();

            if (handle.Status != AsyncOperationStatus.Succeeded || handle.Result == null)
            {
                Bug.Log($"Failed to load UI addressable for '{typeName}'. Make sure the prefab is Addressable with address = '{typeName}'.", "red");
                if (handle.IsValid())
                    Addressables.Release(handle);
                return null;
            }

            var window = handle.Result.GetComponent<Window>();
            if (window == null)
            {
                Bug.Log($"Addressable '{handle.Result.name}' does not have a Window component.", "red");
                Addressables.Release(handle);
                return null;
            }

            m_PrefabHandles[typeName] = handle;
            m_LoadedPrefabs[typeName] = handle.Result;
            return handle.Result;
        }
    }

    public enum UITrigger
    {
        Click,
        Auto,
    }

    public class PopupShowEvent : GameEvent
    {
        public string PopupName;
        public string PopupType;
        public UITrigger TriggerType;
        public int Level;

        public PopupShowEvent(string popupName, string popupType, UITrigger triggerType, int level)
        {
            PopupName = popupName;
            PopupType = popupType;
            TriggerType = triggerType;
            Level = level;
        }
    }
}
