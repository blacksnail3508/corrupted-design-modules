using System.Collections.Generic;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEngine;

namespace Pixon.UI.Editor
{
    public class UIToolsWindow : EditorWindow
    {
        // --- GUIContent tooltips ---
        static readonly GUIContent k_FixContent = new GUIContent(
            "Fix UI Addresses",
            "Scan all Addressable prefabs that have a Window component.\n" +
            "Sets each address = Window type FullName so UIManager can find them at runtime.\n" +
            "Run this once after adding or renaming UI prefabs.");

        static readonly GUIContent k_ScanContent = new GUIContent(
            "Scan for Missing",
            "Lists every prefab with a Window component that is NOT registered in Addressables.\n" +
            "Results are printed to the Console with references to the offending prefabs.");

        static readonly GUIContent k_RefreshContent = new GUIContent(
            "Refresh",
            "Re-scan the project for prefabs with a Window component and update the table below.");

        static readonly GUIContent k_LabelContent = new GUIContent(
            "UI Label",
            "Addressable label added to all Window prefabs when running Fix UI Addresses.");

        // --- Column headers ---
        static readonly GUIContent k_ColType    = new GUIContent("Type", "Window script type name");
        static readonly GUIContent k_ColAddr    = new GUIContent("Address", "Current Addressable address.\nShould equal the type FullName for UIManager to find it.");
        static readonly GUIContent k_ColOk      = new GUIContent("OK", "Address matches the type FullName and the prefab is in Addressables.");
        static readonly GUIContent k_ColPrefab  = new GUIContent("Prefab", "Click to ping the prefab in the Project window.");

        // --- State ---
        string _uiLabel = "UI";
        Vector2 _scroll;

        struct WindowEntry
        {
            public string typeName;
            public string address;
            public bool isAddressable;
            public bool addressOk;
            public GameObject prefab;
        }

        List<WindowEntry> _entries;

        // --- Styles (lazy init) ---
        GUIStyle _okStyle;
        GUIStyle _warnStyle;
        GUIStyle _headerStyle;

        [MenuItem("Pixon/UI/UI Tools")]
        static void Open()
        {
            var w = GetWindow<UIToolsWindow>(utility: false, title: "Pixon UI Tools");
            w.minSize = new Vector2(480, 300);
        }

        void OnEnable() => Refresh();

        void OnGUI()
        {
            InitStyles();

            // ── Top bar ──────────────────────────────────────────────────
            EditorGUILayout.Space(6);
            using (new EditorGUILayout.HorizontalScope())
            {
                _uiLabel = EditorGUILayout.TextField(k_LabelContent, _uiLabel, GUILayout.Width(260));
                GUILayout.FlexibleSpace();
                if (GUILayout.Button(k_RefreshContent, GUILayout.Width(80), GUILayout.Height(22)))
                    Refresh();
                if (GUILayout.Button(k_FixContent, GUILayout.Width(120), GUILayout.Height(22)))
                { FixUIAddresses(_uiLabel); Refresh(); }
                if (GUILayout.Button(k_ScanContent, GUILayout.Width(110), GUILayout.Height(22)))
                    ScanForMissing(_uiLabel);
            }

            EditorGUILayout.Space(6);

            if (_entries == null || _entries.Count == 0)
            {
                EditorGUILayout.HelpBox("No Window prefabs found in the project.", MessageType.Info);
                return;
            }

            // ── Column header ─────────────────────────────────────────────
            using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                GUILayout.Label(k_ColOk,    _headerStyle, GUILayout.Width(24));
                GUILayout.Label(k_ColType,  _headerStyle, GUILayout.Width(180));
                GUILayout.Label(k_ColAddr,  _headerStyle, GUILayout.ExpandWidth(true));
                GUILayout.Label(k_ColPrefab,_headerStyle, GUILayout.Width(54));
            }

            // ── Rows ──────────────────────────────────────────────────────
            _scroll = EditorGUILayout.BeginScrollView(_scroll);

            foreach (var e in _entries)
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    // status dot
                    var dotStyle = e.addressOk ? _okStyle : _warnStyle;
                    GUILayout.Label(e.addressOk ? "●" : "●", dotStyle, GUILayout.Width(24));

                    // type name
                    EditorGUILayout.SelectableLabel(e.typeName, GUILayout.Width(180), GUILayout.Height(18));

                    // address (greyed out if not addressable)
                    using (new EditorGUI.DisabledScope(!e.isAddressable))
                    {
                        string addrText = e.isAddressable ? e.address : "(not addressable)";
                        EditorGUILayout.SelectableLabel(addrText, GUILayout.ExpandWidth(true), GUILayout.Height(18));
                    }

                    // ping button
                    using (new EditorGUI.DisabledScope(e.prefab == null))
                    {
                        if (GUILayout.Button(new GUIContent("Select", $"Ping '{e.typeName}' in the Project window."),
                            GUILayout.Width(54), GUILayout.Height(18)))
                        {
                            EditorGUIUtility.PingObject(e.prefab);
                            Selection.activeObject = e.prefab;
                        }
                    }
                }
            }

            EditorGUILayout.EndScrollView();

            // ── Footer count ──────────────────────────────────────────────
            int okCount   = _entries.FindAll(e => e.addressOk).Count;
            int warnCount = _entries.Count - okCount;
            EditorGUILayout.Space(2);
            string summary = warnCount == 0
                ? $"✓ {okCount} / {_entries.Count} Windows registered"
                : $"⚠ {warnCount} issue(s) — {okCount} / {_entries.Count} Windows OK";
            EditorGUILayout.LabelField(summary, EditorStyles.centeredGreyMiniLabel);
            EditorGUILayout.Space(4);
        }

        // ── Scan ──────────────────────────────────────────────────────────

        void Refresh()
        {
            _entries = new List<WindowEntry>();
            var settings = AddressableAssetSettingsDefaultObject.Settings;
            string[] guids = AssetDatabase.FindAssets("t:Prefab");

            foreach (var guid in guids)
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (prefab == null) continue;

                var win = prefab.GetComponent<Window>();
                if (win == null) continue;

                string fullName = win.GetType().FullName;
                var addrEntry   = settings?.FindAssetEntry(guid);
                string address  = addrEntry?.address ?? string.Empty;
                bool addressOk  = addrEntry != null && address == fullName;

                _entries.Add(new WindowEntry
                {
                    typeName     = win.GetType().Name,
                    address      = address,
                    isAddressable= addrEntry != null,
                    addressOk    = addressOk,
                    prefab       = prefab,
                });
            }

            _entries.Sort((a, b) =>
            {
                int cmp = a.addressOk.CompareTo(b.addressOk); // issues first
                return cmp != 0 ? cmp : string.Compare(a.typeName, b.typeName, System.StringComparison.Ordinal);
            });

            Repaint();
        }

        // ── Operations ────────────────────────────────────────────────────

        static void FixUIAddresses(string uiLabel)
        {
            var settings = AddressableAssetSettingsDefaultObject.Settings;
            if (settings == null) { Debug.LogError("[Pixon UI] Addressable settings not found."); return; }

            int fixedCount = 0;
            foreach (var guid in AssetDatabase.FindAssets("t:Prefab"))
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                var prefab  = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (prefab == null) continue;

                var win = prefab.GetComponent<Window>();
                if (win == null) continue;

                var entry = settings.FindAssetEntry(guid);
                if (entry == null) continue;

                string typeName = win.GetType().FullName;
                if (entry.address != typeName) { entry.SetAddress(typeName); fixedCount++; }
                if (!string.IsNullOrEmpty(uiLabel)) entry.SetLabel(uiLabel, true, true);
            }

            settings.SetDirty(UnityEditor.AddressableAssets.Settings.AddressableAssetSettings.ModificationEvent.EntryModified, null, true);
            AssetDatabase.SaveAssets();
            Debug.Log($"[Pixon UI] Fixed {fixedCount} UI prefab address(es).");
        }

        static void ScanForMissing(string uiLabel)
        {
            var settings = AddressableAssetSettingsDefaultObject.Settings;
            if (settings == null) { Debug.LogError("[Pixon UI] Addressable settings not found."); return; }

            int missingCount = 0;
            foreach (var guid in AssetDatabase.FindAssets("t:Prefab"))
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                var prefab  = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (prefab == null) continue;

                var win = prefab.GetComponent<Window>();
                if (win == null) continue;

                var entry = settings.FindAssetEntry(guid);
                if (entry == null)
                {
                    Debug.LogWarning($"[Pixon UI] {win.GetType().Name} at '{path}' is NOT Addressable.", prefab);
                    missingCount++;
                }
                else if (!string.IsNullOrEmpty(uiLabel) && !entry.labels.Contains(uiLabel))
                    Debug.LogWarning($"[Pixon UI] {win.GetType().Name} is missing label '{uiLabel}'.", prefab);
            }

            if (missingCount == 0)
                Debug.Log("[Pixon UI] All Window prefabs are properly registered in Addressables.");
        }

        // ── Style init ────────────────────────────────────────────────────

        void InitStyles()
        {
            if (_okStyle != null) return;

            _okStyle = new GUIStyle(EditorStyles.label)
            {
                normal  = { textColor = new Color(0.25f, 0.85f, 0.35f) },
                alignment = TextAnchor.MiddleCenter,
                fontSize = 14,
            };
            _warnStyle = new GUIStyle(_okStyle)
            {
                normal = { textColor = new Color(1f, 0.6f, 0.1f) }
            };
            _headerStyle = new GUIStyle(EditorStyles.toolbarButton)
            {
                alignment = TextAnchor.MiddleLeft,
                fontStyle = FontStyle.Bold,
            };
        }
    }
}
