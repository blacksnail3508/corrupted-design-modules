using System.Collections.Generic;
using Coffee.UIExtensions;
using UnityEngine;
using UnityEngine.InputSystem;

public class TouchEffect : MonoBehaviour
{
    public UIParticle particlePrefab;
    int poolSize = 20;

    private Queue<UIParticle> pool = new Queue<UIParticle>();

    private void Awake()
    {
        // DontDestroyOnLoad only accepts root objects, and this one sits under a scene root.
        transform.SetParent(null);
        DontDestroyOnLoad(this.gameObject);
    }

    void Start()
    {
        for (int i = 0; i < poolSize; i++)
        {
            UIParticle ptc = Instantiate(particlePrefab, transform);
            ptc.gameObject.SetActive(false);
            pool.Enqueue(ptc);
        }
    }
    
    void Update()
    {
        if (Touchscreen.current != null && Touchscreen.current.primaryTouch.press.wasPressedThisFrame)
        {
            Vector2 touchPos = Touchscreen.current.primaryTouch.position.ReadValue();
            PlayEffect(new Vector3(touchPos.x, touchPos.y, 10f));
        }
        else if (Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame)
        {
            Vector2 mousePos = Mouse.current.position.ReadValue();
            PlayEffect(new Vector3(mousePos.x, mousePos.y, 10f));
        }
    }


    void PlayEffect(Vector3 position)
    {
        if (pool.Count == 0)
        {
            // Bug.Log("Pool exhausted!");
            return;
        }

        var ps = pool.Dequeue();
        ps.transform.position = position;
        ps.gameObject.SetActive(true);
        ps.Play();

        StartCoroutine(RecycleAfterPlay(ps));
    }

    private System.Collections.IEnumerator RecycleAfterPlay(UIParticle ps)
    {
        yield return new WaitForSecondsRealtime(1.5f);
        ps.Stop();
        ps.gameObject.SetActive(false);
        pool.Enqueue(ps);
    }
}
