using System.Collections;
using UnityEngine;
using UnityEngine.Events;

public class LoopConfeti : MonoBehaviour
{
    [SerializeField] float interval = 5f;
    [SerializeField] bool playOnEnable = false;
    [Tooltip("Called once every interval while the loop is running.")]
    [SerializeField] UnityEvent onLoop;
    [Tooltip("Called when the loop is stopped.")]
    [SerializeField] UnityEvent onStop;

    Coroutine loopRoutine;

    public bool IsRunning => loopRoutine != null;

    void OnEnable()
    {
        if (playOnEnable)
            StartLoop();
    }

    void OnDisable()
    {
        StopLoop();
    }

    public void StartLoop()
    {
        if (loopRoutine != null)
            return;

        loopRoutine = StartCoroutine(LoopRoutine());
    }

    public void StopLoop()
    {
        if (loopRoutine == null)
            return;

        StopCoroutine(loopRoutine);
        loopRoutine = null;

        onStop?.Invoke();
    }

    IEnumerator LoopRoutine()
    {
        var wait = new WaitForSeconds(interval);

        while (true)
        {
            onLoop?.Invoke();
            yield return wait;
        }
    }
}
