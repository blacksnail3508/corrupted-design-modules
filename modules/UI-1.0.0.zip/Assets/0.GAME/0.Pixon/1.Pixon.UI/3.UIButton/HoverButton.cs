using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

public class HoverButton : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [SerializeField] GameObject showWhenHoverObject;
    [SerializeField] TMP_Text hoverText;
    [TextArea(5, 10)]
    [SerializeField] string Tooltip = "This is my tooltip!";

    private void Start()
    {
        if (hoverText != null)
            hoverText.text = Tooltip;

        if (showWhenHoverObject != null)
            showWhenHoverObject.SetActive(false);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (showWhenHoverObject != null)
            showWhenHoverObject.SetActive(true);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (showWhenHoverObject != null)
            showWhenHoverObject.SetActive(false);
    }
    
    public void SetText(string text)
    {
        Tooltip = text;
        hoverText.text = text;
    }
}
