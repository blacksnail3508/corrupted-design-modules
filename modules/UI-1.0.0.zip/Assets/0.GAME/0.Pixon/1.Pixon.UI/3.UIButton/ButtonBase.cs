using Pixon.Audio;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Pixon.UI
{
    [RequireComponent(typeof(Button))]
    [RequireComponent(typeof(Animator))]
    public class ButtonBase : MonoBehaviour
    {
        [SerializeField] protected SoundID soundID = SoundID.ButtonOnClick;
        protected Button button;
        protected Animator animator;
        [SerializeField] protected TMP_Text text;
        [SerializeField] ButtonTransitionType transition = ButtonTransitionType.Animation;
        [SerializeField] bool trackClick = true;
        [SerializeField] string trackingName;

        Window window;

        protected virtual void Awake()
        {
            window = GetComponentInParent<Window>(true);
            button = GetComponent<Button>();
            if (transition == ButtonTransitionType.Animation)
            {
                animator = GetComponent<Animator>();

                button.transition = Selectable.Transition.Animation;
                animator.updateMode = AnimatorUpdateMode.UnscaledTime;
            }
            button.onClick.AddListener(OnClick);
        }
        protected virtual void OnDestroy()
        {
            button.onClick.RemoveAllListeners();
        }
        protected virtual void OnClick()
        {
            PlaySound();
        }

        public void TrackClick(string trackingType = "economy")
        {
            return;
            if (!trackClick) return;

            AnalyticAdapter.LogButtonClick(
                string.IsNullOrEmpty(trackingName) ? gameObject.name : trackingName,
                window != null ? window.GetType().Name : null,
                trackingType);
        }
        public void AddListener(UnityAction action)
        {
            if (button == null) button = GetComponent<Button>();
            button.onClick.AddListener(action);
        }
        protected virtual void PlaySound()
        {
            GameService.AudioManager.PlaySound(soundID);
        }

        public void SetInteract(bool isInteract)
        {
            button.interactable = isInteract;
        }

        public virtual void SetText(string str)
        {
            if (text == null) return;
            text.text = str;
        }
        
        public void ClearListener()
        {
            button.onClick.RemoveAllListeners();
            button.onClick.AddListener(OnClick);
        }
    }
}

public enum ButtonTransitionType
{
    None = 0,
    ColorTint = 1,
    Animation = 2,
    SpriteSwap = 3,
}