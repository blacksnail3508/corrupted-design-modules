public interface UIRevealStep
{
    public abstract bool ShouldShow();

    public virtual void Process(ref bool isPause)
    {
        if (ShouldShow() == false) return;
        isPause = true;
        OnShow();
    }

    /// <summary>
    /// Call when it ShouldShow => true.
    /// Must open a popup to continue the process
    /// The process is continue by ClosePopup
    /// </summary>
    public abstract void OnShow();
}
