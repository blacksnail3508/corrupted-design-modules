using System;
using System.Collections.Generic;

[Serializable]
public abstract class UIRevealPipeline
{
    protected int currentIndex = 0;
    protected bool isPaused = false;

    protected List<UIRevealStep> CurrentOrder;

    // Callback invoked once after all steps in the current order complete.
    public Action OnComplete { get; set; }

    // Subclasses decide which list of steps to run on each refresh.
    protected abstract List<UIRevealStep> GetCurrentOrder();

    //refresh and call 1 step
    public virtual void Refresh()
    {
        currentIndex = 0;
        isPaused = false;
        CurrentOrder = GetCurrentOrder();

        Advance();
    }

    public void NextStep()
    {
        // Bug.Log("UIRevealPipeline: Reveal() called. Resuming pipeline.");
        if (!isPaused || CurrentOrder == null) return;

        isPaused = false;
        Advance();
    }

    protected virtual void Advance()
    {
        var targetOrder = CurrentOrder;
        Bug.Log($"AUTO SHOW SEQUENCE: {currentIndex} Advenced!");

        while (!isPaused && currentIndex < targetOrder.Count)
        {
            var step = targetOrder[currentIndex];
            // Bug.Log($"UIRevealPipeline: Evaluating step {step.GetType().Name}.");
            currentIndex++;

            step.Process(ref isPaused);

            if (isPaused)
                Bug.Log($"AUTO SHOW SEQUENCE: Showing UI for {step.GetType().Name}. Pausing pipeline!");
            else
                Bug.Log($"AUTO SHOW SEQUENCE: Skipping {step.GetType().Name}, ShouldShow() returned false.");
        }

        if (currentIndex >= targetOrder.Count && !isPaused)
        {
            Bug.Log("AUTO SHOW SEQUENCE: All steps completed. No more UI to show.");
            OnPipelineComplete();
        }
    }

    // Called once after all steps in the current order have been processed.
    protected virtual void OnPipelineComplete()
    {
        OnComplete?.Invoke();
    }
}

public enum RevealPipelineStepType
{
    AppOpen = 0,
    FirstBackHome = 1, // first time user back to home from gameplay
    SequenceNormal = 2
}
