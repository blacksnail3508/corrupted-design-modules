using DG.Tweening;
using System;
using Sirenix.OdinInspector;
using Spine.Unity;
using UnityEngine;

namespace Pixon.UI
{
    public class UIAnimationZoom : UIAnimation
    {
        [SerializeField] CanvasGroup canvasGroup;
        [SerializeField] RectTransform panel;
        [SerializeField] float Duration = 0.25f;

        [Button]
        private void AutoHook()
        {
            canvasGroup = GetComponent<CanvasGroup>();
            this.GetComponent<Window>().AutoHookAnimation(this);
        }
        
        public override void PlayIn(Action onComplete = null)
        {
            canvasGroup.alpha = 0;
            canvasGroup.DOFade(1, Duration).SetUpdate(true);

            panel.localScale = Vector3.one * 0.25f;
            panel.DOScale(1, Duration)
                .SetEase(Ease.OutBack)
                .SetUpdate(true)
                .OnComplete(() =>
                {
                    onComplete?.Invoke();
                });;
        }

        public override void PlayOut(Action onComplete = null)
        {
            canvasGroup.DOFade(0, Duration).SetUpdate(true);
            panel.DOScale(0, Duration)
                .SetEase(Ease.InBack)
                .SetUpdate(true)
                .OnComplete(() =>
                {
                    onComplete?.Invoke();
                });;
        }
    }
}