using System;
using DG.Tweening;
using Pixon.UI;
using Sirenix.OdinInspector;
using UnityEngine;

[RequireComponent(typeof(CanvasGroup))]
public class UIAnimationFade : UIAnimation
{
    [SerializeField] CanvasGroup canvasGroup;
    [SerializeField] float animationDuration = 0.5f;
    [SerializeField] bool isFadeOut = true;

    public override void PlayIn(Action onComplete = null)
    {
        canvasGroup.alpha = 0;
        canvasGroup.DOFade(1, animationDuration).SetUpdate(true).OnComplete(() =>
        {
            onComplete?.Invoke();
        });
    }

    public override void PlayOut(Action onComplete = null)
    {
        if (isFadeOut)
        {
            canvasGroup.alpha = 1;
            canvasGroup.DOFade(0, animationDuration/2f).SetUpdate(true).OnComplete(() =>
            {
                onComplete?.Invoke();
            });
        }
        else
        {
            canvasGroup.alpha = 0;
            onComplete?.Invoke();
        }
    }
    [Button]
    private void AutoHook()
    {
        canvasGroup = GetComponent<CanvasGroup>();
        this.GetComponent<Window>().AutoHookAnimation(this);
    }
}
