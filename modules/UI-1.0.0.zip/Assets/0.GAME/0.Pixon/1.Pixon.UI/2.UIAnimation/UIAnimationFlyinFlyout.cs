using DG.Tweening;
using System;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Pixon.UI
{
    public class UIAnimationFlyinFlyout : UIAnimation
    {
        [SerializeField] CanvasGroup canvasGroup;
        [SerializeField] RectTransform panel;
        [SerializeField] float Duration = 0.15f;
        [SerializeField] private Ease easeIn;
        [SerializeField] private Ease easeOut;
        [Header("POSITIONS")]
        [Tooltip("Position that panel appear")]
        [SerializeField] Vector2 StartPosition = new Vector2(0,200);
        [Tooltip("Position that panel stay after animation")]
        [SerializeField] Vector2 StayPosition = new Vector2(0,0);
        [Tooltip("Position that panel move to disapear")]
        [SerializeField] Vector2 EndPosition = new Vector2(0, -200);
        public override void PlayIn(Action onComplete = null)
        {
            canvasGroup.alpha = 0;
            canvasGroup.DOFade(1, Duration)
                .SetUpdate(true);

            panel.anchoredPosition = StartPosition;
            panel.DOAnchorPos(StayPosition, Duration)
                .SetEase(easeIn)
                .SetUpdate(true)
                .OnComplete(() =>
            {
                onComplete?.Invoke();
            });
        }

        public override void PlayOut(Action onComplete = null)
        {
            canvasGroup.DOFade(0, Duration)
                .SetUpdate(true);
            panel.DOAnchorPos(EndPosition, Duration)
                .SetEase(easeOut)
                .SetUpdate(true)
                .OnComplete(() =>
            {
                onComplete?.Invoke();
            });
        }
        
        [Button]
        private void AutoHook()
        {
            canvasGroup = GetComponent<CanvasGroup>();
            this.GetComponent<Window>().AutoHookAnimation(this);
        }
    }
}