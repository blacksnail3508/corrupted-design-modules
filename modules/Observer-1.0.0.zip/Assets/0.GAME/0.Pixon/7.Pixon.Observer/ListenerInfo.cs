﻿using System;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Pixon.Observer
{
    [Serializable]
    public struct ListenerInfo : IEquatable<ListenerInfo>
    {
        [HorizontalGroup("Row", Width = 0.3f)] [HideLabel]
        public Component Component;

        [HorizontalGroup("Row", Width = 0.7f)] [DisplayAsString] [HideLabel]
        public string MethodName;

        public ListenerInfo(Component component, string methodName)
        {
            Component = component;
            MethodName = methodName;
        }

        public bool Equals(ListenerInfo other)
        {
            return Equals(Component, other.Component) && MethodName == other.MethodName;
        }

        public override bool Equals(object obj)
        {
            return obj is ListenerInfo other && Equals(other);
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Component, MethodName);
        }
    }
}