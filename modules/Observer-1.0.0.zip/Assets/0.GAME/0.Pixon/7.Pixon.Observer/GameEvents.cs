namespace Pixon.Observer
{
    public class LevelUpEvent : GameEvent { }
}
