using System;
using System.Collections.Generic;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Pixon.Observer
{
    [Serializable]
    public class EventInfo
    {
        [DisplayAsString] public string EventName;
        [SerializeField] private List<ListenerInfo> listeners = new();
        private HashSet<ListenerInfo> listenerSet = new();


        public void AddListener(Component listener, string methodName)
        {
            var info = new ListenerInfo(listener, methodName);
            if (listenerSet.Add(info)) // only adds if not already present
            {
                listeners.Add(info); // keep visible in Inspector
            }
        }

        public void RemoveListener(Component listener, string methodName)
        {
            var info = new ListenerInfo(listener, methodName);
            if (listenerSet.Remove(info))
            {
                listeners.Remove(info);
            }
        }
    
        public EventInfo(string eventName)
        {
            this.EventName = eventName;
        }
    }
}