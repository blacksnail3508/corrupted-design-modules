using UnityEngine;

namespace Pixon.Observer
{
    public class GameEvent
    {
        public virtual void Trigger()
        {
            EventManager.Instance.Raise(this);
        }
    }
}

