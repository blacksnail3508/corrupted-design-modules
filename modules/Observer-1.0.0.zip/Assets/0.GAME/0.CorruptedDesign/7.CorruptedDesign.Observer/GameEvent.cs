using UnityEngine;

namespace CorruptedDesign.Observer
{
    public class GameEvent
    {
        public virtual void Trigger()
        {
            EventManager.Instance.Raise(this);
        }
    }
}

