using UnityEngine;

namespace CorruptedDesign.Observer
{
    public static class EventService
    {
#if UNITY_EDITOR
        private static EventTracer eventTracer;
#endif
    
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void Init()
        {
#if UNITY_EDITOR
            if (eventTracer == null)
            {
                var go = new GameObject("EventTracer");
                Object.DontDestroyOnLoad(go);
                eventTracer = go.AddComponent<EventTracer>();
            }
#endif
        }
    
        public static void AddListener<T>(EventManager.EventDelegate<T> del, Component owner = null) where T : GameEvent
        {
            EventManager.Instance.AddListener<T>(del);
#if UNITY_EDITOR
            eventTracer?.AddListener(del, owner);
#endif
        }

        public static void RemoveListener<T>(EventManager.EventDelegate<T> del, Component owner = null) where T : GameEvent
        {
            EventManager.Instance.RemoveListener<T>(del);
#if UNITY_EDITOR
            eventTracer?.RemoveListener(del, owner);
#endif
        }
    
        public static void Raise(GameEvent e, Component sender = null)
        {
            EventManager.Instance.Raise(e);
        }
    }
}
