namespace CorruptedDesign.Observer
{
    public class LevelUpEvent : GameEvent { }
}
