using System.Collections.Generic;
using UnityEngine;

namespace CorruptedDesign.Observer
{
    public class EventTracer : MonoBehaviour
    {   
        [SerializeField] List<EventInfo> EventBackLog = new ();

        private EventInfo GetEventInfo<T>() where T : GameEvent
        {
            string eventName = typeof(T).Name;
            var result = EventBackLog.Find(x => x.EventName == eventName);
            if (result == null)
            {
                result = new EventInfo(eventName);
                EventBackLog.Add(result);
            }
            return result;
        }
    
        public void AddListener<T>(EventManager.EventDelegate<T> del, Component owner = null) where T : GameEvent
        {
            string methodName = del.Method.Name;
            string declaringType = del.Method.DeclaringType?.FullName;
            Component listener = owner != null ? owner : del.Target as Component;
            var info = GetEventInfo<T>();
            info.AddListener(listener, $"{declaringType}.{methodName}");
        }

        public void RemoveListener<T>(EventManager.EventDelegate<T> del, Component owner = null) where T : GameEvent
        {
            string methodName = del.Method.Name;
            string declaringType = del.Method.DeclaringType?.FullName;
            Component listener = owner != null ? owner : del.Target as Component;
            var info = GetEventInfo<T>();

            info.RemoveListener(listener, $"{declaringType}.{methodName}");
        }
    }
}
