using System;

public static class TimeUtils
{
    public static int SecondsPerMinute = 60;
    public static int SecondsPerHour = SecondsPerMinute * 60;
    public static int MinutesPerDay = 24 * 60;
    public static int SecondsPerDay = MinutesPerDay * 60;
    public static long NowTS => CorruptedDesign.TrustedClock.Now();

    public static bool IsBetween(this long timestamps, long startTS, long endTs)
    {
        if (timestamps >= startTS && timestamps <= endTs) return true;
        return false;
    }

    public static long TotalSecondTo(this long timestamps, long endTS)
    {
        return endTS - timestamps;
    }

    public static long TotalSecondFrom(this long timestamps, long startTS)
    {
        return timestamps - startTS;
    }

    public static long TotalSecondBetween(long startTS, long endTS)
    {
        return endTS - startTS;
    }

    public static TimeSpan ToTimeSpan(this long seconds)
    {
        return TimeSpan.FromSeconds(seconds);
    }

    public static int DayBetween(long fromTS, long toTS)
    {
        var from = DateTimeOffset.FromUnixTimeSeconds(fromTS);
        var to = DateTimeOffset.FromUnixTimeSeconds(toTS);
        return (int)(to - from).TotalDays;
    }

    public static bool IsSameDay(long fromTS, long toTS)
    {
        return DayBetween(fromTS, toTS) == 0;
    }

    public static long ToUnixTimestamp(this DateTime dateTime)
    {
        return (long)dateTime.ToUniversalTime().Subtract(new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
    }

    public static string ToTimeString(this long timestamp)
    {
        if (timestamp == 0) return "Value Null";
        DateTimeOffset dateTimeOffset = DateTimeOffset.FromUnixTimeSeconds(timestamp);
        DateTime dateTime = dateTimeOffset.UtcDateTime;
        return dateTime.ToString("yyyy-MM-dd HH:mm:ss");
    }
}