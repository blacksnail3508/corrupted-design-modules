using System;
using System.Collections.Generic;
using UnityEngine;
using System.Text.RegularExpressions;
using System.Globalization;

public static class StringExtensions
{
    public static string SetColor(this string str, string colorHex)
    {
        return $"<color={colorHex}>{str}</color>";
    }

    public static string SetColor(this string str, Color color)
    {
        return $"<color={color}>{str}</color>";
    }

    public static string DateTimeToString(this DateTime dateTime, DateTimeFormat dateTimeFormat)
    {
        return dateTime.ToString(dateTimeFormat.ToFormat());
    }

    public static bool TryStringToDateTime(this string dateTime, DateTimeFormat dateTimeFormat, out DateTime result)
    {
        //return DateTime.ParseExact(dateTime, dateTimeFormat.ToFormat(), System.Globalization.CultureInfo.InvariantCulture)
        result = DateTime.Now;
        var isParse = DateTime.TryParseExact(dateTime.Trim(), dateTimeFormat.ToFormat(),
            CultureInfo.InvariantCulture, DateTimeStyles.None, out result);
        return isParse;
    }


    public static string ToShortString(this int num)
    {
        if (num >= 1_000_000)
        {
            var value = num / 1_000_000f;
            return value % 1 == 0 ? $"{(int)value}m" : $"{value:0.#}m";
        }
        else if (num >= 100_000)
        {
            var value = num / 1_000f;
            return $"{(int)value}k";
        }
        else if (num >= 10_000)
        {
            var value = num / 1_000f;
            return value % 1 == 0 ? $"{(int)value}k" : $"{value:0.#}k";
        }
        else
        {
            return num.ToString();
        }
    }

    public static string ToExtraShortString(this int num)
    {
        if (num >= 1_000_000)
        {
            var value = num / 1_000_000f;
            return value % 1 == 0 ? $"{(int)value}m" : $"{value:0.#}m";
        }
        else if (num >= 10_000)
        {
            var value = num / 1_000f;
            return value % 1 == 0 ? $"{(int)value}k" : $"{value:0.#}k";
        }
        else
        {
            return num.ToString();
        }
    }

    public static string AddSpacesToCamelCase(this string input)
    {
        return Regex.Replace(input, "(?<!^)([A-Z])", " $1");
    }

    public static string ToTimeString(this int totalSeconds, string defaultStr = "00:00")
    {
        if (totalSeconds <= 0)
            return defaultStr;

        var days = totalSeconds / (3600 * 24);
        var hours = totalSeconds % (3600 * 24) / 3600;
        var minutes = totalSeconds % 3600 / 60;
        var seconds = totalSeconds % 60;

        if (days >= 1)
            return string.Format("{0}d {1:D2}h", days, hours);

        if (hours >= 1)
            return string.Format("{0:D2}h:{1:D2}", hours, minutes);

        return string.Format("{0:D2}m:{1:D2}", minutes, seconds);
    }

    public static string ToFormat(this DateTimeFormat format)
    {
        switch (format)
        {
            case DateTimeFormat.DateOnly:
                return "yyyy-MM-dd";
            case DateTimeFormat.DateAndTime:
                return "yyyy-MM-dd HH:mm:ss";
            default:
                throw new ArgumentOutOfRangeException(nameof(format), format, null);
        }
    }

    public static DateTime FromTimestampStringToDateTime(this string tsStr)
    {
        if (long.TryParse(tsStr, out var timestamp))
        {
            var dto = DateTimeOffset.FromUnixTimeSeconds(timestamp);
            return dto.LocalDateTime;
        }

        return DateTime.Now;
    }

    public static string ToIncreasedPrice(this string input, decimal percent = 0)
    {
        // Bước 1: lấy phần số
        var match = Regex.Match(input, @"(\d[0-9.,]*)");
        if (!match.Success) return input;

        var numberPart = match.Groups[1].Value;

        // Bước 2: lưu vị trí của dấu . và ,
        var separators = new List<(int index, char symbol)>();
        for (var i = 0; i < numberPart.Length; i++)
            if (numberPart[i] == '.' || numberPart[i] == ',')
                separators.Add((i, numberPart[i]));

        // Bỏ dấu ra khỏi chuỗi chính
        var cleanNumber = numberPart.Replace(".", "").Replace(",", "");

        // Bước 3: parse sang số nguyên và nhân với percentage
        if (!long.TryParse(cleanNumber, out var baseValue))
            return input;

        var newValue = (long)Math.Round(baseValue * (1 + percent / 100));

        // Bước 4: thêm lại dấu vào vị trí cũ
        var result = newValue.ToString();

        var insertedDigits = -1 * (separators.Count - 1);
        // Vì sau khi nhân, độ dài có thể thay đổi, ta cần chèn lại dấu theo logic cũ
        // Giả sử chỉ quan tâm đến dấu ngăn cách nghìn (.)
        // Ta sẽ chèn lại từ phải sang trái theo khoảng cách ban đầu
        foreach (var sep in separators)
        {
            var posFromRight = numberPart.Length - sep.index - 1;
            var insertPos = result.Length - posFromRight - insertedDigits;
            if (insertPos > 0 && insertPos < result.Length)
            {
                result = result.Insert(insertPos, sep.symbol.ToString());
                insertedDigits++;
            }
        }

        return result;
    }
}

public enum DateTimeFormat
{
    DateOnly = 0,
    DateAndTime = 1
}