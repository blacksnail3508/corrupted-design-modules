using System;
using System.Collections.Generic;
using UnityEngine;

public static class ExtraUtilities
{
    /// <summary>
    /// Picks a random item from <paramref name="source"/> with probability proportional
    /// to the weight returned by <paramref name="weightSelector"/>.
    /// Items with weight &lt;= 0 are never picked. Returns default(T) if the source is empty
    /// or every weight is &lt;= 0.
    /// </summary>
    public static T WeightedRandom<T>(this IEnumerable<T> source, Func<T, float> weightSelector)
    {
        if (source == null) throw new ArgumentNullException(nameof(source));
        if (weightSelector == null) throw new ArgumentNullException(nameof(weightSelector));

        float totalWeight = 0f;
        foreach (var item in source)
        {
            float weight = weightSelector(item);
            if (weight > 0f) totalWeight += weight;
        }

        if (totalWeight <= 0f) return default;

        float roll = UnityEngine.Random.value * totalWeight;
        T last = default;
        foreach (var item in source)
        {
            float weight = weightSelector(item);
            if (weight <= 0f) continue;
            last = item;
            roll -= weight;
            if (roll < 0f) return item;
        }
        return last;
    }
}
