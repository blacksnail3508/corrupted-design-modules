#include <time.h>

extern "C" long long TrustedClock_BootMilliseconds()
{
    return (long long)(clock_gettime_nsec_np(CLOCK_MONOTONIC_RAW) / 1000000ULL);
}
