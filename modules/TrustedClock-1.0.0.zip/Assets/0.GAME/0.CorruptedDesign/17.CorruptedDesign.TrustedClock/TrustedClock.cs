using System;
using System.Runtime.InteropServices;
using UnityEngine;

namespace CorruptedDesign
{
    public static class TrustedClock
    {
        private const string KEY = "trusted_clock";

        [Serializable]
        public struct State
        {
            public long AnchorTrusted;
            public long AnchorBootMs;
            public long LastTrusted;
            public long BootId;
        }

        private static State state;
        private static bool loaded;

        public static long Now()
        {
            long wallNow = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            long bootMs = BootMilliseconds();
            if (bootMs < 0) return wallNow;

            if (!loaded) Load();
            var next = Step(state, wallNow, bootMs, out long now, BootId());
            bool reanchored = next.AnchorBootMs != state.AnchorBootMs || next.BootId != state.BootId;
            state = next;
            if (reanchored) Save();
            return now;
        }

        public static DateTime UtcNow => DateTimeOffset.FromUnixTimeSeconds(Now()).UtcDateTime;

        public static void Save()
        {
            if (loaded) PlayerPrefs.SetString(KEY, JsonUtility.ToJson(state));
        }

        public static State Step(State s, long wallNow, long bootMs, out long now, long bootId = 0)
        {
            // Uptime alone misses a reboot when the game reopens later in the new boot than the anchor was taken.
            bool rebooted = bootMs < s.AnchorBootMs || (bootId > 0 && bootId != s.BootId);
            if (s.AnchorTrusted == 0 || rebooted)
            {
                if (bootId > 0) s.BootId = bootId;
                s.AnchorTrusted = Math.Max(s.LastTrusted, wallNow);
                s.AnchorBootMs = bootMs;
            }

            now = s.AnchorTrusted + (bootMs - s.AnchorBootMs) / 1000;
            s.LastTrusted = Math.Max(s.LastTrusted, now);
            return s;
        }

        private static void Load()
        {
            loaded = true;
            var json = PlayerPrefs.GetString(KEY, string.Empty);
            if (string.IsNullOrEmpty(json)) return;
            try { state = JsonUtility.FromJson<State>(json); }
            catch { state = default; }
        }

#if UNITY_ANDROID && !UNITY_EDITOR
        private static AndroidJavaClass systemClock;
        private static long? bootId;

        private static long BootMilliseconds()
        {
            systemClock ??= new AndroidJavaClass("android.os.SystemClock");
            return systemClock.CallStatic<long>("elapsedRealtime");
        }

        // Settings.Global.BOOT_COUNT (API 24+); the player cannot move it by changing the date. 0 = unknown.
        private static long BootId()
        {
            if (bootId.HasValue) return bootId.Value;
            try
            {
                using var player = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
                using var activity = player.GetStatic<AndroidJavaObject>("currentActivity");
                using var resolver = activity.Call<AndroidJavaObject>("getContentResolver");
                using var global = new AndroidJavaClass("android.provider.Settings$Global");
                bootId = Math.Max(0, global.CallStatic<int>("getInt", resolver, "boot_count", -1));
            }
            catch (Exception e)
            {
                Debug.LogWarning($"[TrustedClock] boot_count unavailable: {e.Message}");
                bootId = 0;
            }
            return bootId.Value;
        }
#elif UNITY_IOS && !UNITY_EDITOR
        [DllImport("__Internal")]
        private static extern long TrustedClock_BootMilliseconds();

        private static long BootMilliseconds() => TrustedClock_BootMilliseconds();

        // kern.boottime shifts when the date is changed, so iOS keeps the uptime-only reboot check.
        private static long BootId() => 0;
#else
        private static long BootMilliseconds() => -1;
        private static long BootId() => 0;
#endif
    }
}
