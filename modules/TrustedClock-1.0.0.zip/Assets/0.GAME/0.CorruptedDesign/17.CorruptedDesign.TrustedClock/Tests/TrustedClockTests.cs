using NUnit.Framework;
using CorruptedDesign;

public class TrustedClockTests
{
    const long Wall = 1_800_000_000;
    const long Boot = 5_000_000;

    static TrustedClock.State Start(out long now) => TrustedClock.Step(default, Wall, Boot, out now);

    [Test]
    public void FirstRunAnchorsToWallClock()
    {
        Start(out long now);
        Assert.AreEqual(Wall, now);
    }

    [Test]
    public void ForwardingTheDateDoesNotMoveTime()
    {
        var s = Start(out _);
        TrustedClock.Step(s, Wall + 30 * 60, Boot, out long now);
        Assert.AreEqual(Wall, now);
    }

    [Test]
    public void RewindingTheDateDoesNotMoveTime()
    {
        var s = Start(out _);
        TrustedClock.Step(s, Wall - 30 * 60, Boot + 10_000, out long now);
        Assert.AreEqual(Wall + 10, now);
    }

    [Test]
    public void RealElapsedTimeCounts()
    {
        var s = Start(out _);
        TrustedClock.Step(s, Wall + 3600, Boot + 3_600_000, out long now);
        Assert.AreEqual(Wall + 3600, now);
    }

    [Test]
    public void RebootReanchorsToWallClock()
    {
        var s = Start(out _);
        s = TrustedClock.Step(s, Wall + 60, Boot + 60_000, out _);
        TrustedClock.Step(s, Wall + 600, 1_000, out long now);
        Assert.AreEqual(Wall + 600, now);
    }

    [Test]
    public void RebootWithRewoundClockNeverGoesBackInTime()
    {
        var s = Start(out _);
        s = TrustedClock.Step(s, Wall + 60, Boot + 60_000, out _);
        TrustedClock.Step(s, Wall - 86_400, 1_000, out long now);
        Assert.AreEqual(Wall + 60, now);
    }

    [Test]
    public void RebootLaterInUptimeReanchorsWhenBootIdChanges()
    {
        var s = TrustedClock.Step(default, Wall, 300_000, out _, bootId: 7);
        TrustedClock.Step(s, Wall + 8 * 3600, 1_800_000, out long now, bootId: 8);
        Assert.AreEqual(Wall + 8 * 3600, now);
    }

    [Test]
    public void UnknownBootIdKeepsUptimeOnlyCheck()
    {
        var s = TrustedClock.Step(default, Wall, 300_000, out _, bootId: 7);
        TrustedClock.Step(s, Wall + 8 * 3600, 1_800_000, out long now);
        Assert.AreEqual(Wall + 1500, now);
    }
}
