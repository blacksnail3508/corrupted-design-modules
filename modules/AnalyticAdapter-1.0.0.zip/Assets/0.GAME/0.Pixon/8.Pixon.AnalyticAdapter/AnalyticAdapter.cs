using System;
using PixonTemplate;
using UnityEngine;

/// <summary>Contract an analytics backend (Firebase, Lion, GameAnalytics...) implements to receive Pixon events.</summary>
public interface IAnalyticSink
{
    void Event(string name, string detail);
}

/// <summary>Writes every event to the Console. Replace with a real sink once an SDK is added.</summary>
public sealed class LogAnalyticSink : IAnalyticSink
{
    public void Event(string name, string detail) => Debug.Log($"[Analytic] {name} {detail}");
}

/// <summary>Single entry point the game calls for tracking. The template ships with a log-only sink and no SDK.</summary>
public static class AnalyticAdapter
{
    public static IAnalyticSink Sink { get; set; } = new LogAnalyticSink();

    private static void Send(string name, string detail = "") => Sink?.Event(name, detail);

    #region Gameplay
    public static void LogLevelStart() => Send("level_start");
    public static void LogLevelStepRevive(ReviveMethod method) => Send("level_revive", method.ToString());
    public static void LogLevelSoftFail(LoseReason reason) => Send("level_soft_fail", reason.ToString());
    public static void LogLevelWin() => Send("level_win");
    public static void LogLevelAbandoned() => Send("level_abandoned");
    public static void LogLevelLose() => Send("level_lose");
    public static void LogBoosterUse(BoosterType boosterType, int remaining) => Send("booster_use", $"{boosterType} left={remaining}");
    #endregion

    #region UI
    public static void LogPopupShow(string windowTypeName, string popupType = null) => Send("popup_show", $"{windowTypeName} {popupType}");

    public static void LogUIInteraction(string uiName, string uiLocation = null, string uiType = "economy", string uiAction = "click")
    {
        if (string.IsNullOrEmpty(uiName)) return;
        Send("ui_interaction", $"{uiAction} {uiName} @{uiLocation} ({uiType})");
    }

    public static void LogButtonClick(string buttonName, string windowTypeName, string uiType = "economy") =>
        LogUIInteraction(buttonName, windowTypeName, uiType);
    #endregion

    #region Economy
    public static void LogResourceGain(ItemType item, int amount, ResourceReason reason, ResourcePlacement placement, bool toLion = true)
    {
        if (amount <= 0 || !toLion) return;
        Send("resource_gain", $"{item} +{amount} {reason} @{placement}");
    }

    public static void LogResourceSpent(ItemType item, int amount, ResourceReason reason, ResourcePlacement placement)
    {
        if (amount <= 0) return;
        Send("resource_spent", $"{item} -{amount} {reason} @{placement}");
    }
    #endregion

    #region Ads / IAP / UA
    public static void LogInterstitialWatched() => Send("interstitial_watched");
    public static void LogRewardedWatched() => Send("rewarded_watched");
    public static void LogIapPurchase() => Send("iap_purchase");
    public static void LogPurchaseFailed() => Send("purchase_failed");
    public static void LogPurchaseNotVerified() => Send("purchase_not_verified");
    public static void LogPurchaseUnknown() => Send("purchase_unknown");
    public static void LogRetention() => Send("retention");

    public static void LogInAppPurchase(string productId, string transactionId, string placement) =>
        Send("in_app_purchase", $"{productId} tx={transactionId} @{placement}");
    #endregion
}
