using System;
using System.Collections.Generic;
using Pixon.Remote;
using UnityEngine;

public enum AdsPlacement
{
    Win,
    Lose,
    Setting,
    Revive,
    WinDoubleCoin,
    Booster,
    FreeReward,
    BuyHeart,
}

/// <summary>Contract an ad SDK (MAX, Lion, IronSource...) implements for <see cref="AdsProvider"/>.</summary>
public interface IAdNetwork
{
    bool IsInitialized { get; }
    bool IsInterstitialReady { get; }
    bool IsRewardedReady { get; }

    /// <summary>Returns false when no ad can show. <paramref name="onClosed"/> runs when the ad is dismissed.</summary>
    bool TryShowInterstitial(string placement, Action onClosed);

    /// <summary>Returns false when no ad can show. <paramref name="onRewarded"/> runs when the reward is earned, <paramref name="onClosed"/> when the ad is dismissed.</summary>
    bool TryShowRewarded(string placement, Action onRewarded, Action onClosed);

    bool ShowBanner();
    void HideBanner();
}

/// <summary>Default network: every ad "plays" instantly and succeeds, so the whole ad flow can be tested without an SDK.</summary>
public sealed class SimulatedAdNetwork : IAdNetwork
{
    public bool IsInitialized => true;
    public bool IsInterstitialReady => true;
    public bool IsRewardedReady => true;

    public bool TryShowInterstitial(string placement, Action onClosed)
    {
        onClosed?.Invoke();
        return true;
    }

    public bool TryShowRewarded(string placement, Action onRewarded, Action onClosed)
    {
        onRewarded?.Invoke();
        onClosed?.Invoke();
        return true;
    }

    public bool ShowBanner() => true;
    public void HideBanner() { }
}

public static class AdsProvider
{
    private const float RewardGraceTime = 0.35f;

    /// <summary>Swap this for a real network adapter once an ad SDK is added.</summary>
    public static IAdNetwork Network { get; set; } = new SimulatedAdNetwork();

    private static float lastInterstitialTime = float.NegativeInfinity;
    private static float lastRewardedTime = float.NegativeInfinity;

    public static bool IsInitialized => Network.IsInitialized;
    public static bool IsInterstitialReady => Network.IsInterstitialReady;
    public static bool IsRewardedReady => Network.IsRewardedReady;

    public static bool IsInterstitialBlocked => InterstitialBlockRemaining > 0f;

    public static bool SkipAds
    {
        get => Pixon.IAP.ShopService.IsNoAds() || (GameService.DataManager != null && GameService.DataManager.IsSkipAds);
        set
        {
            if (GameService.DataManager == null) return;
            GameService.DataManager.IsSkipAds = value;
        }
    }

    public static float InterstitialBlockRemaining => GetInterstitialBlockRemaining(false);

    public static float GetInterstitialBlockRemaining(bool ignoreRwInterval)
    {
        var config = ConfigCollection.InterConfig.Value;
        float now = Time.realtimeSinceStartup;
        float interval = config.Interval - (now - lastInterstitialTime);
        if (ignoreRwInterval) return Mathf.Max(0f, interval);

        float rwInterval = config.RwInterval - (now - lastRewardedTime);
        return Mathf.Max(0f, Mathf.Max(interval, rwInterval));
    }

    public static bool ShowInterstitial(AdsPlacement placement, Action<bool> onComplete = null,
        Dictionary<string, object> additionalData = null, bool ignoreRwInterval = false)
    {
        var call = new AdCall(PlacementName(placement), onComplete);
        Bug.Log($"[Ads] ShowInterstitial {call.Placement}");

        if (SkipAds)
        {
            Bug.Log($"[Ads] {call.Placement} skipped by cheat");
            call.Complete(false);
            return false;
        }

        float blocked = GetInterstitialBlockRemaining(ignoreRwInterval);
        if (blocked > 0f)
        {
            Bug.Log($"[Ads] {call.Placement} blocked, {blocked:0.#}s remaining");
            call.Complete(false);
            return false;
        }

        // A network may close the ad before TryShowInterstitial returns, so the call counts as shown until it says otherwise.
        call.Shown = true;
        bool shown = Network.TryShowInterstitial(call.Placement, () =>
        {
            if (call.Shown)
            {
                MarkInterstitialShown();
                AnalyticAdapter.LogInterstitialWatched();
            }
            call.Complete(call.Shown);
        });

        call.Shown = shown;
        if (!shown) call.Complete(false);

        return shown;
    }

    public static bool ShowInterstitialFromLevel(AdsPlacement placement, int startLevel,
        Action<bool> onComplete = null, Dictionary<string, object> additionalData = null,
        bool ignoreRwInterval = false)
    {
        if (startLevel < 0 || GameService.DataManager.Level < startLevel)
        {
            onComplete?.Invoke(false);
            return false;
        }

        return ShowInterstitial(placement, onComplete, additionalData, ignoreRwInterval);
    }

    public static bool ShowRewarded(AdsPlacement placement, Action<bool> onComplete = null,
        Dictionary<string, object> additionalData = null, BoosterType? booster = null)
    {
        var call = new AdCall(PlacementName(placement), onComplete);
        Bug.Log($"[Ads] ShowRewarded {call.Placement}");

        if (SkipAds)
        {
            Bug.Log($"[Ads] {call.Placement} skipped by cheat, reward granted");
            Delay.Call(RewardGraceTime, () => call.Complete(true));
            return true;
        }

        call.Shown = true;
        bool shown = Network.TryShowRewarded(call.Placement,
            () =>
            {
                if (!call.Completed) AnalyticAdapter.LogRewardedWatched();
                call.Complete(true);
            },
            () => OnRewardedClosed(call));

        call.Shown = shown;
        if (!shown) call.Complete(false);

        return shown;
    }

    public static bool ShowBanner() => Network.ShowBanner();

    public static void HideBanner() => Network.HideBanner();

    private static void MarkInterstitialShown()
    {
        lastInterstitialTime = Time.realtimeSinceStartup;
        Bug.Log($"[Ads] inter interval {ConfigCollection.InterConfig.Value.Interval}s started");
    }

    private static void MarkRewardedWatched()
    {
        lastRewardedTime = Time.realtimeSinceStartup;
        Bug.Log($"[Ads] inter blocked {ConfigCollection.InterConfig.Value.RwInterval}s after rewarded closed");
    }

    private static void OnRewardedClosed(AdCall call)
    {
        if (call.Shown) MarkRewardedWatched();

        if (call.Completed) return;

        Delay.Call(RewardGraceTime, () => call.Complete(false));
    }

    private static string PlacementName(AdsPlacement placement) => placement switch
    {
        AdsPlacement.WinDoubleCoin => "win_double_coin",
        AdsPlacement.FreeReward => "free_reward",
        AdsPlacement.BuyHeart => "buy_heart",
        _ => $"{placement}".ToLowerInvariant()
    };

    private class AdCall
    {
        public readonly string Placement;
        public bool Shown;
        public bool Completed { get; private set; }

        private readonly Action<bool> onComplete;

        public AdCall(string placement, Action<bool> onComplete)
        {
            Placement = placement;
            this.onComplete = onComplete;
        }

        public void Complete(bool success)
        {
            if (Completed) return;

            Completed = true;
            Bug.Log($"[Ads] {Placement} complete: {success}");
            onComplete?.Invoke(success);
        }
    }
}
