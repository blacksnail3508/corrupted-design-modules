using UnityEngine;

namespace Pixon.Stamina
{
    [CreateAssetMenu(fileName = "StaminaConfig", menuName = "GAME/STAMINA/StaminaConfig")]
    public class StaminaConfig : ScriptableObject
    {
        [Header("CONFIG___________")] public int MaxStamina = 5;

        [Header("TIMES___________")] [Tooltip("Total second to recorver 1 stamina")]
        public int RecoverTime = 600;
    }
}