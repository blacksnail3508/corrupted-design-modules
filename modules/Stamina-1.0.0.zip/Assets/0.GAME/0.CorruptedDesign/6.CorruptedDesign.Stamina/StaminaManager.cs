using System;
using System.Collections;
using CorruptedDesign.Feature;
using CorruptedDesign.Observer;
using Sirenix.OdinInspector;
using UnityEngine;

namespace CorruptedDesign.Stamina
{
    public class StaminaManager : FeatureBase
    {
        public const string STAMINA_KEY = "heart_data";

        #region PROPERTIES

        public static StaminaManager Instance;
        [SerializeField] [InlineEditor] private StaminaConfig config;

        [Header("RUNTIME")] [SerializeField] [ReadOnly]
        private StaminaData data;

        private long recoverStartTime;

        // Until PreloadData has run, `data` is still all-zero and must never be written over the save.
        private bool isLoaded;

        #endregion

        #region MONOBEHAVIOR

        protected void Awake()
        {
            Instance = this;
        }

        private void OnApplicationPause(bool pauseStatus)
        {
            if (!pauseStatus && isLoaded) Reload();
        }

        public override IEnumerator PreloadData()
        {
            yield return null;
            Reload();
            TrySpendPendingUsage();
        }

        public IEnumerator CheckNewDays(bool isNewDay)
        {
            yield return null;
        }

        public override IEnumerator StartFeature()
        {
            yield return null;
            Clock.CallPerSecond += OnSecond;
        }

        private void OnDestroy()
        {
            Clock.CallPerSecond -= OnSecond;
        }

        #endregion

        #region UPDATE

        private void OnSecond()
        {
            long now = NowTimestamp();
            UpdateHeart(now);
            UpdateInfiniteTime(now);
        }

        private void UpdateInfiniteTime(long now)
        {
            if (data.InfiniteEndTime == 0) return;
            data.InfiniteTimeRemaining = (int)(data.InfiniteEndTime - now);
            if (data.InfiniteTimeRemaining <= 0)
                ExpireInfinite();
        }

        private void UpdateHeart(long now)
        {
            if (data.CurrentStamina >= config.MaxStamina) return;

            // A clock that went back (reboot with a rewound date) would otherwise stall the timer past RecoverTime.
            if (now < recoverStartTime) SetRecoverStartTime(now);
            data.TimeUntilNextRecover = config.RecoverTime - (int)(now - recoverStartTime);
            if (data.TimeUntilNextRecover > 0) return;

            data.CurrentStamina++;
            SetRecoverStartTime(now);
            if (data.CurrentStamina >= config.MaxStamina)
                ClearRecoverTime();
            SaveData();
        }

        private void ExpireInfinite()
        {
            data.InfiniteEndTime = 0;
            data.InfiniteTimeRemaining = 0;
            SaveData();
        }

        private void ClearRecoverTime()
        {
            data.TimeUntilNextRecover = 0;
            recoverStartTime = NowTimestamp();
            data.RecoverStartTime = 0;
        }

        private void SetRecoverStartTime(long time)
        {
            recoverStartTime = time;
            data.RecoverStartTime = time;
        }

        #endregion

        #region SAVE/LOAD

        public override void SaveData()
        {
            // FeatureManager.SaveAll() fires on any app pause - the iOS ATT prompt pauses us mid-boot,
            // and saving the not-yet-loaded struct there would wipe the player's hearts to 0.
            if (!isLoaded) return;

            TrustedClock.Save();
            var json = JsonUtility.ToJson(data);
            PlayerPrefs.SetString(STAMINA_KEY, json);
        }

        private void Reload()
        {
            var json = PlayerPrefs.GetString(STAMINA_KEY, string.Empty);
            isLoaded = true;

            if (string.IsNullOrEmpty(json))
            {
                SeedFullStamina();
                return;
            }

            try
            {
                data = JsonUtility.FromJson<StaminaData>(json);
                LoadInfiniteTime();
                LoadRecoverTime();
            }
            catch
            {
                SeedFullStamina();
            }
        }

        /// <summary>First run, or an unreadable save: the player starts on a full heart bar.</summary>
        private void SeedFullStamina()
        {
            data = new StaminaData { CurrentStamina = config.MaxStamina };
            SaveData();
        }

        private void LoadInfiniteTime()
        {
            if (data.InfiniteEndTime == 0) return;
            data.InfiniteTimeRemaining = (int)(data.InfiniteEndTime - NowTimestamp());
            if (data.InfiniteTimeRemaining <= 0)
                ExpireInfinite();
        }

        private void LoadRecoverTime()
        {
            if (data.CurrentStamina >= config.MaxStamina)
            {
                ClearRecoverTime();
                SaveData();
                return;
            }

            // Not full with no clock running is a broken save; start the clock now rather than let
            // UpdateHeart read the missing timestamp as "long overdue" and hand out a free heart.
            if (data.RecoverStartTime == 0)
            {
                SetRecoverStartTime(NowTimestamp());
                data.TimeUntilNextRecover = config.RecoverTime;
                SaveData();
                return;
            }

            recoverStartTime = data.RecoverStartTime;
            // Never negative: a clock that went back must not take hearts away.
            var offlineTime = Mathf.Max(0, (int)(NowTimestamp() - recoverStartTime));
            var recovered = Mathf.Max(0, Mathf.Min(offlineTime / config.RecoverTime, config.MaxStamina - data.CurrentStamina));

            data.CurrentStamina += recovered;
            offlineTime -= recovered * config.RecoverTime;

            if (data.CurrentStamina >= config.MaxStamina)
            {
                ClearRecoverTime();
            }
            else if (offlineTime > 0)
            {
                SetRecoverStartTime(NowTimestamp() - offlineTime);
                data.TimeUntilNextRecover = config.RecoverTime - offlineTime;
            }

            SaveData();
        }

        private void TrySpendPendingUsage()
        {
            if (data.PendingUsage == 0) return;
            data.CurrentStamina = Mathf.Max(data.CurrentStamina - data.PendingUsage, 0);
            data.PendingUsage = 0;
            SaveData();
        }

        #endregion

        #region BASE LOGIC

        [Button]
        private void _SpendStamina(int amount, Action onSuccess = null, Action onFailed = null)
        {
            if (data.InfiniteTimeRemaining > 0)
            {
                ClearPendingStaminaUse();
                onSuccess?.Invoke();
                EventService.Raise(new StaminaChangedEvent());
                return;
            }

            if (data.CurrentStamina >= amount)
            {
                data.CurrentStamina -= amount;
                if (data.TimeUntilNextRecover <= 0) SetRecoverStartTime(NowTimestamp());
                ClearPendingStaminaUse();
                onSuccess?.Invoke();
                EventService.Raise(new StaminaChangedEvent());
            }
            else
            {
                onFailed?.Invoke();
            }
        }

        [Button]
        private void _ClaimStamina(int amount, Action onSuccess = null)
        {
            data.CurrentStamina += amount;
            CapStamina();
            SaveData();
            onSuccess?.Invoke();
            EventService.Raise(new StaminaChangedEvent());
        }

        [Button]
        private void _InfiniteStamina(int minutes)
        {
            var now = NowTimestamp();
            data.InfiniteEndTime = (data.InfiniteEndTime > now ? data.InfiniteEndTime : now) + 60L * minutes;
            data.InfiniteTimeRemaining = (int)(data.InfiniteEndTime - now);
            data.CurrentStamina = config.MaxStamina;
            ClearRecoverTime();
            SaveData();
        }

        private void _SetStamina(int input)
        {
            data.CurrentStamina = input;
            CapStamina();
            if (data.CurrentStamina < config.MaxStamina && data.TimeUntilNextRecover <= 0)
                SetRecoverStartTime(NowTimestamp());
            SaveData();
            EventService.Raise(new StaminaChangedEvent());
        }

        private void CapStamina()
        {
            data.CurrentStamina = Mathf.Min(data.CurrentStamina, config.MaxStamina);
            if (data.CurrentStamina >= config.MaxStamina) ClearRecoverTime();
        }

        private void PendingStaminaUse(int amount = 1)
        {
            if (data.InfiniteTimeRemaining > 0) return;
            data.PendingUsage = Mathf.Max(data.PendingUsage + amount, 0);
            SaveData();
        }

        private void ClearPendingStaminaUse()
        {
            data.PendingUsage = 0;
            SaveData();
        }
        #endregion

        #region STATIC SERVICE
        
        public static int CurrentStamina => Instance.data.CurrentStamina;
        public static int MaxStamina => Instance.config.MaxStamina;
        public static bool IsFull => Instance.data.CurrentStamina >= Instance.config.MaxStamina;
        public static int RecoverTimeRemaining => Instance.data.TimeUntilNextRecover;
        public static int InfiniteTimeRemaining => Instance.data.InfiniteTimeRemaining;

        public static string RecoverTimeRemainingString
        {
            get
            {
                if (CurrentStamina >= Instance.config.MaxStamina) return "FULL";
                return FormatMMSS(RecoverTimeRemaining);
            }
        }

        public static string InfiniteTimeRemainingString
        {
            get
            {
                var hour = InfiniteTimeRemaining / 3600;
                if (hour > 10) return $"{hour}h";
                var minute = InfiniteTimeRemaining % 3600 / 60;
                if (hour > 0) return $"{hour}h:{minute:00}";
                var second = InfiniteTimeRemaining % 60;
                return $"{minute:00}:{second:00}s";
            }
        }

        public static void SpendStamina(int amount, Action onSuccess = null, Action onFailed = null)
        {
            if(Instance == null) return;
            Instance._SpendStamina(amount, onSuccess, onFailed);
        }

        public static bool HaveStamina()
        {
            if (InfiniteTimeRemaining <= 0 && CurrentStamina < 1) return false;
            return true;
        }

        public static void ClaimStamina(int amount, string refillMethod, Action onComplete = null)
        {
            if(Instance == null) return;
            Instance._ClaimStamina(amount, onComplete);
        }

        public static void InfiniteStamina(int minutes)
        {
            if(Instance == null) return;
            Bug.Log($"Infinite stamina +{minutes} min");
            if (minutes <= 0) return;
            Instance._InfiniteStamina(minutes);
        }

        public static void SetStamina(int input)
        {
            if(Instance == null) return;
            Instance._SetStamina(input);
        }

        public static void PendingUseStamina(int amount = 1)
        {
            if (Instance == null) return;
            Instance.PendingStaminaUse(amount);
        }

        public static void ClearPendingUseStamina()
        {
            if (Instance == null) return;
            Instance.ClearPendingStaminaUse();
        }

        #endregion

        #region HELPER

        private static long NowTimestamp() => TrustedClock.Now();

        private static string FormatMMSS(int totalSeconds) =>
            $"{totalSeconds / 60:00}:{totalSeconds % 60:00}";

        #endregion
    }

    [Serializable]
    public struct StaminaData
    {
        public int CurrentStamina;
        public int PendingUsage;

        public long RecoverStartTime;
        public int TimeUntilNextRecover;

        public long InfiniteEndTime;
        public int InfiniteTimeRemaining;
    }
}

public class StaminaChangedEvent : GameEvent
{
    
}
