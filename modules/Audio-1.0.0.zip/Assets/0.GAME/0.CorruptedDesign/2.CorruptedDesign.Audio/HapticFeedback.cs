using UnityEngine;

namespace CorruptedDesign.Audio
{
    public enum HapticTypes
    {
        Selection,
        Success,
        Warning,
        Failure,
        LightImpact,
        MediumImpact,
        HeavyImpact,
        RigidImpact,
        SoftImpact
    }

    /// <summary>Device haptics behind one switch. Plug a native haptic plugin in here; the default only vibrates on strong impacts.</summary>
    public static class HapticFeedback
    {
        public static bool HapticsEnabled { get; set; } = true;

        private static float lastTime = float.NegativeInfinity;

        public static void Generate(HapticTypes type)
        {
            if (!HapticsEnabled) return;
#if UNITY_ANDROID || UNITY_IOS
            if (type == HapticTypes.HeavyImpact || type == HapticTypes.Failure) Handheld.Vibrate();
#endif
        }

        public static void GenerateWithCooldown(HapticTypes type, float cooldown)
        {
            float now = Time.unscaledTime;
            if (now - lastTime < cooldown) return;
            lastTime = now;
            Generate(type);
        }

        public static void Stop() { }
    }
}
