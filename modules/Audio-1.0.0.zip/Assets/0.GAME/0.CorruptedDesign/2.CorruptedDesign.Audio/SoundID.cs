namespace CorruptedDesign.Audio
{
    // Values never change: the AudioLibrary is keyed by them, so renumbering remaps every saved clip.
    public enum SoundID
    {
        None = 0,
        ButtonOnClick = 1,
        CoinCollect = 2,
        CoinAppear = 3,
        PopupOpen = 4,
        PopupClose = 5,

        FireWork = 6,
        Win = 7,
        Lose = 8,
        JarTouch = 9,
        JarCompleted = 10,
        SandPutOnJar = 11,
        ConveyorSand = 12,
        Booster1 = 13,
        Booster2 = 14,
        Booster3 = 15,
        IceBreak = 16,
    }

    // Values never change: the AudioLibrary is keyed by them, so renumbering remaps every saved track.
    public enum MusicID
    {
        None = 0,
        BGMusic = 1,
    }

    public enum AmbientID
    {
        None = 0,
        FarmAmbient = 1
    }
}
