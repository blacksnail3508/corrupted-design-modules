#import <UIKit/UIKit.h>

// Light impact tap for CorruptedDesign.Audio.Haptic.
extern "C" void _CorruptedDesignHapticLight()
{
    static UIImpactFeedbackGenerator *generator = nil;
    if (generator == nil) generator = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
    [generator impactOccurred];
}
