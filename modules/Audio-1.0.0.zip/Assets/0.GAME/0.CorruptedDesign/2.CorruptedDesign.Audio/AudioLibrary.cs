
using System.Collections.Generic;
using CorruptedDesign.Audio;
using Sirenix.OdinInspector;
using UnityEngine;
using UnityEngine.Rendering;

[CreateAssetMenu(fileName = "Audio Library", menuName = "SO/Audio Library")]
public class AudioLibrary : ScriptableObject
{
    /// <summary>One take of a sound, rolled against the entry's other clips by weight.</summary>
    [System.Serializable]
    public class SfxClip
    {
        public AudioClip Clip;

        // Relative odds against the entry's other clips; 0 never plays.
        [Min(0f)] public float Weight = 1f;
    }

    [System.Serializable]
    public struct SfxEntry
    {
        public List<SfxClip> Clips;

        // shortcut: pre-Clips single clip, moved into Clips on load; remove once every AudioLibrary asset is resaved.
        [HideInInspector] public AudioClip Clip;

        public int SoundLayer;

        // Per clip mix level, so a clip can be tamed or boosted without re-exporting the wav.
        [Range(0f, 2f)] public float Volume;

        // Pitch is rolled per play, so a clip fired repeatedly does not sound identical every time.
        [Range(0.1f, 3f)] public float MinPitch;
        [Range(0.1f, 3f)] public float MaxPitch;

        public static SfxEntry Default => new SfxEntry { Clips = new List<SfxClip>(), Volume = 1f, MinPitch = 1f, MaxPitch = 1f };

        /// <summary>A pitch drawn from the entry range, or 1 for entries that never set one.</summary>
        public float RollPitch()
        {
            var min = MinPitch <= 0f ? 1f : MinPitch;
            var max = MaxPitch <= 0f ? 1f : MaxPitch;
            return max <= min ? min : Random.Range(min, max);
        }

        /// <summary>One of the entry's clips picked by weight, or null when none can play.</summary>
        public AudioClip RollClip()
        {
            if (Clips == null) return null;

            float total = 0f;
            foreach (var c in Clips)
                if (c != null && c.Clip && c.Weight > 0f) total += c.Weight;

            float roll = Random.value * total;
            AudioClip picked = null;
            foreach (var c in Clips)
            {
                if (c == null || !c.Clip || c.Weight <= 0f) continue;
                picked = c.Clip;
                if (roll < c.Weight) return c.Clip;
                roll -= c.Weight;
            }

            // Random.value can land on exactly 1, which runs past the last bucket.
            return picked;
        }
    }

    [System.Serializable]
    public struct MusicEntry
    {
        public AudioClip Clip;

        // Per track mix level, so a track can be tamed without re-exporting it.
        [Range(0f, 2f)] public float Volume;

        // Pitch is rolled per play, so a replayed track does not sound identical every time.
        [Range(0.1f, 3f)] public float MinPitch;
        [Range(0.1f, 3f)] public float MaxPitch;

        public static MusicEntry Default => new MusicEntry { Volume = 1f, MinPitch = 1f, MaxPitch = 1f };

        /// <summary>A pitch drawn from the entry range, or 1 for entries that never set one.</summary>
        public float RollPitch()
        {
            var min = MinPitch <= 0f ? 1f : MinPitch;
            var max = MaxPitch <= 0f ? 1f : MaxPitch;
            return max <= min ? min : Random.Range(min, max);
        }
    }

    [SerializeField] private SerializedDictionary<SoundID,SfxEntry> SFXLibrary = new();
    [SerializeField] private SerializedDictionary<MusicID,MusicEntry> MusicEntries = new();
    [SerializeField] private SerializedDictionary<AmbientID,AudioClip> AmbientLibrary = new();

    // shortcut: pre-MusicEntry bare clips, moved into MusicEntries on load; remove once every AudioLibrary asset is resaved.
    // A new field name, since the value type changed and FormerlySerializedAs only covers renames.
    [SerializeField, HideInInspector] private SerializedDictionary<MusicID,AudioClip> MusicLibrary = new();

    private void OnEnable() => MigrateLegacy();

    // Runs in the player too, so a build from a never-resaved asset still plays its clips.
    private void MigrateLegacy()
    {
        var moved = false;
        foreach (var id in new List<SoundID>(SFXLibrary.Keys))
        {
            var entry = SFXLibrary[id];
            if (!entry.Clip || entry.Clips is { Count: > 0 }) continue;

            entry.Clips = new List<SfxClip> { new() { Clip = entry.Clip } };
            entry.Clip = null;
            SFXLibrary[id] = entry;
            moved = true;
        }

        foreach (var pair in MusicLibrary)
        {
            if (MusicEntries.ContainsKey(pair.Key)) continue;

            var entry = MusicEntry.Default;
            entry.Clip = pair.Value;
            MusicEntries.Add(pair.Key, entry);
            moved = true;
        }
        if (MusicLibrary.Count > 0)
        {
            MusicLibrary.Clear();
            moved = true;
        }

#if UNITY_EDITOR
        if (moved) UnityEditor.EditorUtility.SetDirty(this);
#endif
    }

    public bool GetMusic(MusicID musicID, out AudioClip clip, out float volume, out float pitch)
    {
        clip = null;
        volume = 1f;
        pitch = 1f;
        if (!MusicEntries.TryGetValue(musicID, out var entry) || !entry.Clip)
        {
            Bug.Log($"Music {musicID} not found!");
            return false;
        }
        clip = entry.Clip;
        volume = entry.Volume;
        pitch = entry.RollPitch();
        return true;
    }

    public bool GetSfx(SoundID soundID, out AudioClip clip, out int soundLayer, out float volume, out float pitch)
    {
        clip = null;
        soundLayer = 0;
        volume = 1f;
        pitch = 1f;
        if (SFXLibrary.TryGetValue(soundID, out var entry)) clip = entry.RollClip();
        if (!clip)
        {
            Bug.Log($"Sound {soundID} not found!");
            return false;
        }
        soundLayer = entry.SoundLayer;
        volume = entry.Volume;
        pitch = entry.RollPitch();
        return true;
    }

    [Button]
    void InitAudioLibrary()
    {
        foreach (SoundID id in System.Enum.GetValues(typeof(SoundID)))
        {
            if(id ==  SoundID.None) continue;
            if (SFXLibrary.ContainsKey(id) == false)
            {
                SFXLibrary.Add(id, SfxEntry.Default);
                continue;
            }

            // Entries authored before Volume and the pitch range existed deserialize at 0, which would mute or stall them.
            var entry = SFXLibrary[id];
            if (entry.Volume <= 0f) entry.Volume = 1f;
            if (entry.MinPitch <= 0f) entry.MinPitch = 1f;
            if (entry.MaxPitch <= 0f) entry.MaxPitch = 1f;
            SFXLibrary[id] = entry;
        }
        foreach (MusicID id in System.Enum.GetValues(typeof(MusicID)))
        {
            if(id ==  MusicID.None) continue;
            if (MusicEntries.ContainsKey(id) == false)
            {
                MusicEntries.Add(id, MusicEntry.Default);
                continue;
            }

            var entry = MusicEntries[id];
            if (entry.Volume <= 0f) entry.Volume = 1f;
            if (entry.MinPitch <= 0f) entry.MinPitch = 1f;
            if (entry.MaxPitch <= 0f) entry.MaxPitch = 1f;
            MusicEntries[id] = entry;
        }
    }

    public AudioClip GetAmbientClip(AmbientID id)
    {
        if (!AmbientLibrary.ContainsKey(id) || !AmbientLibrary[id])
        {
            Bug.Log($"Sound {id} not found!");
            return null;
        }
        return AmbientLibrary[id];
    }
}
