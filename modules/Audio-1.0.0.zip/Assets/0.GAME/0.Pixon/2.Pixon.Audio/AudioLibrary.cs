
using Pixon.Audio;
using Sirenix.OdinInspector;
using UnityEngine;
using UnityEngine.Rendering;

[CreateAssetMenu(fileName = "Audio Library", menuName = "SO/Audio Library")]
public class AudioLibrary : ScriptableObject
{
    [System.Serializable]
    public struct SfxEntry
    {
        public AudioClip Clip;
        public int SoundLayer;

        // Per clip mix level, so a clip can be tamed or boosted without re-exporting the wav.
        [Range(0f, 2f)] public float Volume;

        // Pitch is rolled per play, so a clip fired repeatedly does not sound identical every time.
        [Range(0.1f, 3f)] public float MinPitch;
        [Range(0.1f, 3f)] public float MaxPitch;

        public static SfxEntry Default => new SfxEntry { Volume = 1f, MinPitch = 1f, MaxPitch = 1f };

        /// <summary>A pitch drawn from the entry range, or 1 for entries that never set one.</summary>
        public float RollPitch()
        {
            var min = MinPitch <= 0f ? 1f : MinPitch;
            var max = MaxPitch <= 0f ? 1f : MaxPitch;
            return max <= min ? min : Random.Range(min, max);
        }
    }

    [SerializeField] private SerializedDictionary<SoundID,SfxEntry> SFXLibrary = new();
    [SerializeField] private SerializedDictionary<MusicID,AudioClip> MusicLibrary = new();
    [SerializeField] private SerializedDictionary<AmbientID,AudioClip> AmbientLibrary = new();

    public AudioClip GetMusicClip(MusicID musicID)
    {
        if (!MusicLibrary.ContainsKey(musicID) || !MusicLibrary[musicID])
        {
            Bug.Log($"Music {musicID} not found!");
            return null;
        }
        return MusicLibrary[musicID];
    }

    public bool GetSfx(SoundID soundID, out AudioClip clip, out int soundLayer, out float volume, out float pitch)
    {
        clip = null;
        soundLayer = 0;
        volume = 1f;
        pitch = 1f;
        if (!SFXLibrary.ContainsKey(soundID) || !SFXLibrary[soundID].Clip)
        {
            Bug.Log($"Sound {soundID} not found!");
            return false;
        }
        var entry = SFXLibrary[soundID];
        clip = entry.Clip;
        soundLayer = entry.SoundLayer;
        volume = entry.Volume;
        pitch = entry.RollPitch();
        return true;
    }

    [Button]
    void InitAudioLibrary()
    {
        foreach (SoundID id in System.Enum.GetValues(typeof(SoundID)))
        {
            if(id ==  SoundID.None) continue;
            if (SFXLibrary.ContainsKey(id) == false)
            {
                SFXLibrary.Add(id, SfxEntry.Default);
                continue;
            }

            // Entries authored before Volume and the pitch range existed deserialize at 0, which would mute or stall them.
            var entry = SFXLibrary[id];
            if (entry.Volume <= 0f) entry.Volume = 1f;
            if (entry.MinPitch <= 0f) entry.MinPitch = 1f;
            if (entry.MaxPitch <= 0f) entry.MaxPitch = 1f;
            SFXLibrary[id] = entry;
        }
        foreach (MusicID id in System.Enum.GetValues(typeof(MusicID)))
        {
            if(id ==  MusicID.None) continue;
            if (MusicLibrary.ContainsKey(id) == false)
            {
                MusicLibrary.Add(id, null);
            }
        }
    }

    public AudioClip GetAmbientClip(AmbientID id)
    {
        if (!AmbientLibrary.ContainsKey(id) || !AmbientLibrary[id])
        {
            Bug.Log($"Sound {id} not found!");
            return null;
        }
        return AmbientLibrary[id];
    }
}
