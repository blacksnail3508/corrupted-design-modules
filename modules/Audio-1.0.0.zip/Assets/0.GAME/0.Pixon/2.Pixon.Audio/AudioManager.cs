using System.Collections;
using System.Collections.Generic;
using Pixon.Data;
using Sirenix.OdinInspector;

using UnityEngine;


namespace Pixon.Audio
{
    public class AudioManager : MonoBehaviour
    {
        [SerializeField, InlineEditor] AudioLibrary audioLibrary;
        [SerializeField] AudioSource m_MusicSource;
        [SerializeField] AudioSource m_AmbientSource;
        [SerializeField] AudioSource m_EffectSource;
        [SerializeField] AudioSource m_LoopSource;
        [SerializeField, Min(0f)] float m_MinSoundInterval = 0.1f;

        [Header("Haptic")]
        [SerializeField] bool m_EnableHaptic = true;
        [SerializeField, Min(0f)] float m_MinHapticInterval = 0.1f;
        [SerializeField] HapticTypes m_PourHaptic = HapticTypes.LightImpact;
        [SerializeField, Min(0.02f)] float m_PourHapticInterval = 0.07f;
        [SerializeField, Min(0.02f)] float m_PourHapticIdleTimeout = 0.15f;
        float[] m_LastSoundPlayTime =  new float[5];

        // One source per overlapping one shot. Pitch lives on the AudioSource rather than on the clip
        // it was handed, so a single shared source re-pitches everything still ringing on it every
        // time the next sound rolls one, entries authored at a flat pitch of 1 included.
        const int MaxSfxVoices = 16;
        readonly List<AudioSource> m_SfxVoices = new();

        // Which voice the next cut comes off, for the board that is loud enough to run the pool dry.
        int m_NextVoice;
        float m_PourHapticKeepAliveUntil;
        Coroutine m_PourHapticRoutine;
        [SerializeField] Vault<AudioSettings> audioSetting = new (PlayerPrefsKey.AUDIO, new AudioSettings());
        public bool EnableMusic
        {
            get => audioSetting.Value.EnableMusic;
            set
            {
                audioSetting.Value.EnableMusic = value;
                m_MusicSource.mute = !value;
                m_AmbientSource.mute = !value;
                SaveAudioSetting();
            }
        }

        public bool EnableSfx
        {
            get => audioSetting.Value.EnableSfx;
            set
            {
                audioSetting.Value.EnableSfx = value;
                m_EffectSource.mute = !value;
                if (m_LoopSource != null) m_LoopSource.mute = !value;

                // The ones already ringing as well, or a mute mid sound would be heard out first.
                for (int i = 0; i < m_SfxVoices.Count; i++)
                    if (m_SfxVoices[i] != null) m_SfxVoices[i].mute = !value;
                SaveAudioSetting();
            }
        }
        public bool EnableVibrate
        {
            get => audioSetting.Value.EnableVibrate;
            set
            {
                audioSetting.Value.EnableVibrate = value;
                HapticFeedback.HapticsEnabled = value;
                if (!value) StopPourHaptic();
                SaveAudioSetting();
            }
        }
        public float MasterVolume
        {
            get => audioSetting.Value.MasterVolume;
            set
            {
                audioSetting.Value.MasterVolume = value;
                AudioListener.volume = value;
                m_AmbientSource.volume = value;
                SaveAudioSetting();
            }
        }

        private void Awake()
        {
            GameService.AudioManager = this;
            DontDestroyOnLoad(this.gameObject);
        }

        void OnEnable()
        {
            EnableMusic = audioSetting.Value.EnableMusic;
            EnableSfx = audioSetting.Value.EnableSfx;
            EnableVibrate = audioSetting.Value.EnableVibrate;
            MasterVolume = audioSetting.Value.MasterVolume;
        }

        void OnDisable()
        {
            StopPourHaptic();
            SaveAudioSetting();
        }
        void _PlayMusic(MusicID id, bool looping = true)
        {
            var clip = audioLibrary.GetMusicClip(id);
            if (!clip) return;

            if (m_MusicSource.isPlaying && m_MusicSource.clip == clip)
                return;

            m_MusicSource.clip = clip;
            m_MusicSource.loop = looping;
            m_MusicSource.Play();
        }

        /// <summary>
        /// Play a music based on its sound ID
        /// </summary>
        /// <param name="id">The ID of the music</param>
        /// <param name="looping">Is music looping?</param>
        public void PlayMusic(MusicID id, bool looping = true)
        {
            try
            {
                _PlayMusic(id, looping);
            }
            catch
            {
                // ignored
            }
        }

        /// <summary>
        /// Stop the current music
        /// </summary>
        public void StopMusic()
        {
            m_MusicSource.Stop();
        }

        void _PlaySound(SoundID soundID)
        {
            if (soundID == SoundID.None) return;
            if (!audioLibrary.GetSfx(soundID, out var clip, out var soundLayer, out var volume, out var pitch)) return;

            if (soundLayer <= 2)
                if (Time.time - m_LastSoundPlayTime[soundLayer] < m_MinSoundInterval) return;

            // PlayOneShot takes no pitch, so the source carries it and a sound keeps the one it was
            // played at only while it has that source to itself.
            AudioSource voice = TakeSfxVoice();
            voice.pitch = pitch;
            voice.mute = !EnableSfx;
            voice.PlayOneShot(clip, volume);
            m_LastSoundPlayTime[soundLayer] = Time.time;
        }

        /// <summary>A source with nothing playing on it, which is what keeps a roll to the sound it was rolled for.</summary>
        AudioSource TakeSfxVoice()
        {
            // The inspector's own source is the first voice, so a board quiet enough to need one plays
            // on exactly what it did before.
            if (m_SfxVoices.Count == 0 && m_EffectSource != null) m_SfxVoices.Add(m_EffectSource);

            for (int i = 0; i < m_SfxVoices.Count; i++)
                if (m_SfxVoices[i] != null && !m_SfxVoices[i].isPlaying) return m_SfxVoices[i];

            if (m_SfxVoices.Count < MaxSfxVoices) return AddSfxVoice();

            // Every voice is busy: one tail has to be cut, and round robin spreads which one that is.
            m_NextVoice = (m_NextVoice + 1) % m_SfxVoices.Count;
            return m_SfxVoices[m_NextVoice];
        }

        /// <summary>Another voice, set up as the copy of the effect source the inspector authored.</summary>
        AudioSource AddSfxVoice()
        {
            AudioSource voice = gameObject.AddComponent<AudioSource>();
            voice.playOnAwake = false;
            voice.loop = false;

            if (m_EffectSource != null)
            {
                // Routing and mix, so a voice grown at run time sits where the authored source does.
                voice.outputAudioMixerGroup = m_EffectSource.outputAudioMixerGroup;
                voice.volume = m_EffectSource.volume;
                voice.spatialBlend = m_EffectSource.spatialBlend;
                voice.priority = m_EffectSource.priority;
                voice.panStereo = m_EffectSource.panStereo;
                voice.reverbZoneMix = m_EffectSource.reverbZoneMix;
                voice.bypassEffects = m_EffectSource.bypassEffects;
                voice.bypassListenerEffects = m_EffectSource.bypassListenerEffects;
                voice.bypassReverbZones = m_EffectSource.bypassReverbZones;
            }

            m_SfxVoices.Add(voice);
            return voice;
        }

        public void PlaySound(SoundID soundID)
        {
            try
            {
                _PlaySound(soundID);
            }
            catch
            {
            }
        }
        void _PlayLoopSound(SoundID soundID)
        {
            if (soundID == SoundID.None) return;
            if (!audioLibrary.GetSfx(soundID, out var clip, out _, out var volume, out var pitch)) return;

            if (m_LoopSource == null)
            {
                m_LoopSource = gameObject.AddComponent<AudioSource>();
                m_LoopSource.playOnAwake = false;
            }

            if (m_LoopSource.isPlaying && m_LoopSource.clip == clip) return;

            m_LoopSource.clip = clip;
            m_LoopSource.loop = true;
            // AudioSource.volume clamps at 1, so a loop cannot be boosted the way a one shot can.
            m_LoopSource.volume = Mathf.Min(volume, 1f);
            m_LoopSource.pitch = pitch;
            m_LoopSource.mute = !EnableSfx;
            m_LoopSource.Play();
        }

        public void PlayLoopSound(SoundID soundID)
        {
            try
            {
                _PlayLoopSound(soundID);
            }
            catch
            {
            }
        }

        public void StopLoopSound()
        {
            if (m_LoopSource != null) m_LoopSource.Stop();
        }

        void _PlayHaptic(HapticTypes type)
        {
            if (!m_EnableHaptic || !EnableVibrate) return;

            HapticFeedback.GenerateWithCooldown(type, m_MinHapticInterval);
        }

        public void PlayHaptic(HapticTypes type)
        {
            try
            {
                _PlayHaptic(type);
            }
            catch
            {
            }
        }

        public bool PourHapticPlaying => m_PourHapticRoutine != null;

        public void StartPourHaptic()
        {
            if (!m_EnableHaptic || !EnableVibrate) return;

            m_PourHapticKeepAliveUntil = Time.unscaledTime + Mathf.Max(0.02f, m_PourHapticIdleTimeout);
            if (m_PourHapticRoutine == null) m_PourHapticRoutine = StartCoroutine(PourHapticLoop());
        }

        public void StopPourHaptic()
        {
            m_PourHapticKeepAliveUntil = 0f;
            if (m_PourHapticRoutine != null)
            {
                StopCoroutine(m_PourHapticRoutine);
                m_PourHapticRoutine = null;
            }
            try { HapticFeedback.Stop(); }
            catch { }
        }

        IEnumerator PourHapticLoop()
        {
            float interval = Mathf.Max(0.02f, m_PourHapticInterval);
            while (Time.unscaledTime < m_PourHapticKeepAliveUntil)
            {
                if (!m_EnableHaptic || !EnableVibrate) break;
                try { HapticFeedback.Generate(m_PourHaptic); }
                catch { }
                yield return new WaitForSecondsRealtime(interval);
            }
            m_PourHapticRoutine = null;
            try { HapticFeedback.Stop(); }
            catch { }
        }

        public void PlayVibrate()
        {
            PlayHaptic(HapticTypes.MediumImpact);
        }

        public void SaveAudioSetting()
        {
            audioSetting.Save(audioSetting.Value);
        }

        void _PlayAmbientSound(AmbientID id, bool looping = true)
        {
            if (m_AmbientSource.isPlaying)
                return;

            var clip = audioLibrary.GetAmbientClip(id);
            if (!clip) return;

            m_AmbientSource.clip = clip;
            m_AmbientSource.loop = looping;
            m_AmbientSource.volume = MasterVolume;
            m_AmbientSource.mute = !EnableMusic;
            m_AmbientSource.Play();
        }

        /// <summary>
        /// Play an ambient sound based on its ID
        /// </summary>
        /// <param name="id">The ID of the ambient sound</param>
        /// <param name="looping">Should the ambient sound loop?</param>
        public void PlayAmbientSound(AmbientID id, bool looping = true)
        {
            _PlayAmbientSound(id, looping);
        }
        public void StopAmbientSound()
        {
            m_AmbientSource.Stop();
        }

    }
}