using System.Runtime.InteropServices;
using UnityEngine;

namespace Pixon.Audio
{
    /// <summary>A short, light buzz on the device, below what Handheld.Vibrate can do.</summary>
    public static class Haptic
    {
#if UNITY_IOS && !UNITY_EDITOR
        [DllImport("__Internal")] static extern void _PixonHapticLight();
#endif

#if UNITY_ANDROID && !UNITY_EDITOR
        static AndroidJavaObject s_Vibrator;
        static int s_SdkInt;
#endif

        public static void Light(int milliseconds)
        {
#if UNITY_IOS && !UNITY_EDITOR
            // Handheld.Vibrate is the full 400ms buzz on iOS; the impact generator is the light tap.
            _PixonHapticLight();
#elif UNITY_ANDROID && !UNITY_EDITOR
            LightAndroid(milliseconds);
#endif
        }

#if UNITY_ANDROID && !UNITY_EDITOR
        static void LightAndroid(long milliseconds)
        {
            if (s_Vibrator == null)
            {
                using var player = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
                using var activity = player.GetStatic<AndroidJavaObject>("currentActivity");
                s_Vibrator = activity.Call<AndroidJavaObject>("getSystemService", "vibrator");

                using var version = new AndroidJavaClass("android.os.Build$VERSION");
                s_SdkInt = version.GetStatic<int>("SDK_INT");
            }

            if (s_Vibrator == null) return;

            if (s_SdkInt >= 26)
            {
                // -1 is VibrationEffect.DEFAULT_AMPLITUDE: the device's own strength, not a full-power buzz.
                using var effects = new AndroidJavaClass("android.os.VibrationEffect");
                using var effect = effects.CallStatic<AndroidJavaObject>("createOneShot", milliseconds, -1);
                s_Vibrator.Call("vibrate", effect);
            }
            else
            {
                s_Vibrator.Call("vibrate", milliseconds);
            }
        }
#endif
    }
}
