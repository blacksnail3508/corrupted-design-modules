namespace Pixon.Audio
{
    public enum SoundID
    {
        None = 0,
        ButtonOnClick = 1,
        CoinCollect = 2,
        CoinAppear = 3,
        PopupOpen = 4,
        PopupClose = 5,

        FireWork,
        Win,
        Lose,
        JarTouch,
        JarCompleted,
        SandPutOnJar,
        ConveyorSand,
        Booster1,
        Booster2,
        Booster3,
        IceBreak,
        
    }

    public enum MusicID
    {
        None = 0,
        BGMusic = 1,
    }

    public enum AmbientID
    {
        None = 0,
        FarmAmbient = 1
    }
}
