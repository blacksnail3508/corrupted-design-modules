using System;
using Newtonsoft.Json;

namespace Pixon.Remote
{
    /// <summary>inter_ad_config: when interstitials start at each spot and how far apart they run.</summary>
    [Serializable]
    public class InterAdConfig
    {
        [JsonProperty("inter_win_start_lv")] public int WinStartLv = 15;
        [JsonProperty("inter_lose_start_lv")] public int LoseStartLv = 16;
        [JsonProperty("inter_setting_start_lv")] public int SettingStartLv = 16;
        [JsonProperty("inter_af_rw_win_start_lv")] public int AfterRewardedStartLv = 99999;
        // Seconds between two interstitials.
        [JsonProperty("inter_interval")] public int Interval = 60;
        // Seconds after a rewarded ad before an interstitial may follow it.
        [JsonProperty("inter_rw_interval")] public int RewardedInterval = 30;
        [JsonProperty("ad_break_show")] public bool AdBreakShow = true;
    }

    /// <summary>banner_ad_config.</summary>
    [Serializable]
    public class BannerAdConfig
    {
        [JsonProperty("banner_start_lv")] public int StartLv = 1;
    }

    /// <summary>aoa_ad_config.</summary>
    [Serializable]
    public class AoaAdConfig
    {
        [JsonProperty("aoa_show_session_start")] public int ShowSessionStart = 99999;
    }

    /// <summary>rw_win_ad_config: the coins of a win and the rewarded multiplier on them; lists run normal, hard, super hard.</summary>
    [Serializable]
    public class RwWinAdConfig
    {
        [JsonProperty("currency_reward_win")] public string CurrencyRewardWin = "40,40,40";
        [JsonProperty("rw_win_start_lv")] public int StartLv = 99999;
        [JsonProperty("rw_win_button_right_side")] public bool ButtonRightSide = true;
        [JsonProperty("rw_win_multiplier_value")] public string MultiplierValue = "2,3,5";

        /// <summary>Coins for winning a level of this level_type ("normal", "hard" or "super hard").</summary>
        public int CoinsFor(string levelType) => RemoteList.At(CurrencyRewardWin, TypeIndex(levelType), 40);

        /// <summary>The rewarded button's multiplier on a win of this level_type.</summary>
        public int MultiplierFor(string levelType) => RemoteList.At(MultiplierValue, TypeIndex(levelType), 2);

        private static int TypeIndex(string levelType) => levelType switch
        {
            "super hard" => 2,
            "hard" => 1,
            _ => 0,
        };
    }

    /// <summary>One booster's group (booster_N_config); keys carry a bst_N_ prefix that the config strips.</summary>
    [Serializable]
    public class BoosterGroupConfig
    {
        [JsonProperty("unlock_lv")] public int UnlockLv = 1;
        // Boosters given free when it unlocks, the forced tutorial one included.
        [JsonProperty("bonus_tut")] public int BonusTut = 1;
        [JsonProperty("rw_start_lv")] public int RwStartLv = 1;
        [JsonProperty("rw_limit_per_level")] public int RwLimitPerLevel = 99999;
        [JsonProperty("rw_limit_per_day")] public int RwLimitPerDay = 99999;
        // Above this many coins the free rewarded booster is hidden.
        [JsonProperty("coin_threshold_lock_rw")] public int CoinThresholdLockRw = 5000;
        [JsonProperty("buy_amount")] public int BuyAmount = 1;
        [JsonProperty("price_x1")] public int PriceX1 = 100;
        [JsonProperty("price_x3")] public int PriceX3 = 300;

        public BoosterGroupConfig() { }

        public BoosterGroupConfig(int unlockLv, int price)
        {
            UnlockLv = unlockLv;
            RwStartLv = unlockLv;
            PriceX1 = price;
            PriceX3 = price * 3;
        }
    }

    /// <summary>add_box_config; the game has no Add Box, so nothing reads it yet.</summary>
    [Serializable]
    public class AddBoxConfig
    {
        [JsonProperty("box_unlock_lv")] public int UnlockLv = 1;
        [JsonProperty("box_rw_start_lv")] public int RwStartLv = 1;
        [JsonProperty("box_rw_limit_per_level")] public int RwLimitPerLevel = 99999;
        [JsonProperty("box_rw_limit_per_day")] public int RwLimitPerDay = 99999;
        [JsonProperty("box_coin_threshold_lock_rw")] public int CoinThresholdLockRw = 5000;
        [JsonProperty("box_price_x1")] public int PriceX1 = 100;
    }

    /// <summary>revive_config: when revives are offered and what they cost, per revive taken in a level.</summary>
    [Serializable]
    public class ReviveConfig
    {
        [JsonProperty("revive_iap_offer_start_lv")] public int IapOfferStartLv = 4;
        [JsonProperty("revive_rw_start_lv")] public int RwStartLv = 1;
        [JsonProperty("revive_rw_limit_per_level")] public int RwLimitPerLevel = 99999;
        [JsonProperty("revive_rw_limit_per_day")] public int RwLimitPerDay = 99999;
        [JsonProperty("revive_coin_threshold_unlock_rw")] public int CoinThresholdUnlockRw = 5000;
        // "200,200,300" prices the first two revives 200 and the third 300; the last price holds after.
        [JsonProperty("revive_price_list")] public string PriceList = "900";

        /// <summary>Coins for the revive after <paramref name="revivesUsed"/> earlier ones in the level.</summary>
        public int PriceAt(int revivesUsed) => RemoteList.At(PriceList, revivesUsed, 900);
    }

    /// <summary>refill_heart_config.</summary>
    [Serializable]
    public class RefillHeartConfig
    {
        // Minutes for one heart to come back.
        [JsonProperty("refill_heart_time")] public int Time = 20;
        [JsonProperty("refill_heart_rw_start_lv")] public int RwStartLv = 1;
        [JsonProperty("refill_heart_rw_limit_per_level")] public int RwLimitPerLevel = 99999;
        [JsonProperty("refill_heart_rw_limit_per_day")] public int RwLimitPerDay = 99999;
        [JsonProperty("refill_heart_coin_threshold_unlock_rw")] public int CoinThresholdUnlockRw = 5000;
    }

    /// <summary>rating_config.</summary>
    [Serializable]
    public class RatingConfig
    {
        // The won level at which the player is first asked.
        [JsonProperty("rating_start_lv")] public int StartLv = 6;
        // Won levels between asks after a refusal.
        [JsonProperty("rating_frequency")] public int Frequency = 10;
    }

    /// <summary>in_app_update_config: iau_active is 0 for none, 1 for flexible, 2 for immediate.</summary>
    [Serializable]
    public class InAppUpdateConfig
    {
        [JsonProperty("iau_active")] public int Active = 0;
        [JsonProperty("iau_ask_count")] public int AskCount = 0;
        [JsonProperty("iau_reask_interval")] public int ReaskInterval = 0;
    }

    /// <summary>Comma separated numbers from the console, read by position.</summary>
    internal static class RemoteList
    {
        // Past the end the last entry holds; an empty or broken list gives the fallback.
        public static int At(string list, int index, int fallback)
        {
            if (string.IsNullOrWhiteSpace(list)) return fallback;

            string[] parts = list.Split(',');
            string part = parts[Math.Clamp(index, 0, parts.Length - 1)];
            return int.TryParse(part.Trim(), out int value) ? value : fallback;
        }
    }
}
