#if PIXON_HAS_FIREBASE_REMOTE_CONFIG
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Firebase.RemoteConfig;

namespace Pixon.Remote
{
    /// <summary>Fetches every <see cref="ConfigCollection"/> key from Firebase Remote Config; compiled only while the Firebase SDK is in the project.</summary>
    public class RemoteFetcherFirebase : RemoteFetcher
    {
        public override async Task<RemoteSnapshot> FetchAsync()
        {
            await FirebaseRemoteConfig.DefaultInstance.FetchAsync(TimeSpan.FromSeconds(0));

            var info = FirebaseRemoteConfig.DefaultInstance.Info;
            switch (info.LastFetchStatus)
            {
                case LastFetchStatus.Success:
                    await FirebaseRemoteConfig.DefaultInstance.ActivateAsync();
                    Bug.Log($"[RemoteFetcherFirebase] Fetch success (fetchTime={info.FetchTime}).");
                    return BuildSnapshot();

                case LastFetchStatus.Failure:
                    var reason = info.LastFetchFailureReason switch
                    {
                        FetchFailureReason.Throttled => $"Throttled until {info.ThrottledEndTime}",
                        _ => "Unknown error",
                    };
                    throw new Exception($"[RemoteFetcherFirebase] Fetch failed: {reason}");

                case LastFetchStatus.Pending:
                    throw new Exception("[RemoteFetcherFirebase] Fetch still pending.");

                default:
                    throw new Exception("[RemoteFetcherFirebase] Fetch unknown status.");
            }
        }

        /// <summary>Raw key/value pairs whose key starts with <paramref name="prefix"/>; feeds <see cref="LevelRemoteFetcher.BundleSource"/>.</summary>
        public static IEnumerable<KeyValuePair<string, string>> ReadByPrefix(string prefix)
        {
            var config = FirebaseRemoteConfig.DefaultInstance;
            return config.GetKeysByPrefix(prefix).Select(key => new KeyValuePair<string, string>(key, config.GetValue(key).StringValue)).ToList();
        }

        private static RemoteSnapshot BuildSnapshot()
        {
            var snapshot = new RemoteSnapshot { FetchedAtTimeStamp = TimeUtils.NowTS };
            foreach (var entry in ConfigCollection.All)
                snapshot.Values[entry.Key] = FirebaseRemoteConfig.DefaultInstance.GetValue(entry.Key).StringValue;
            return snapshot;
        }
    }
}
#endif
