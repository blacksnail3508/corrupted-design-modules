using System;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Pixon.Remote
{
    /// <summary>
    /// S: chỉ lo fetch từ remote và trả về RemoteSnapshot.
    /// O: đổi provider thì kế thừa và override FetchAsync.
    /// Mọi key đều fetch về dạng string — không phân biệt kiểu.
    /// </summary>
    public class RemoteFetcher
    {
        public virtual async Task<RemoteSnapshot> FetchAsync()
        {
            await Task.Delay(300);
            return BuildMockSnapshot();
        }

        private static RemoteSnapshot BuildMockSnapshot()
        {
            var snap = new RemoteSnapshot { FetchedAtTimeStamp = DateTime.UtcNow.ToUnixTimestamp() };
            foreach (var entry in ConfigCollection.All)
            {
                snap.Values[entry.Key] = entry switch
                {
                    IntConfig     e => e.DefaultValue.ToString(),
                    FloatConfig   e => e.DefaultValue.ToString(),
                    BoolConfig    e => e.DefaultValue.ToString().ToLower(),
                    StringConfig  e => e.DefaultValue,
                    IDefaultValue e => JsonConvert.SerializeObject(e.GetDefaultValue()),
                    _               => string.Empty
                };
            }
            return snap;
        }
    }
}