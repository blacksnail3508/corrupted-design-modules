using System.Collections.Generic;
using System.Reflection;
using UnityEngine.Scripting;

namespace Pixon.Remote
{
    /// <summary>
    /// Khai bao toan bo remote config (key - default value) cua game tai day.
    /// Them config moi: chi can them mot dong o day — tu dong duoc phat hien boi ConfigCollection.All.
    /// KHONG can dang ky thu cong o bat cu noi nao khac.
    /// </summary>
    [Preserve]
    public static partial class ConfigCollection
    {
        // ── RESOURCES ──
        public static IntConfig   StarterGoldAmount         = new("currency_available_start", 300);
        public static IntConfig   StarterBoosterAmount      = new("booster_available_start", 0);

        // ── BOOSTER ──
        public static JsonRemoteConfig<BoosterConfigData> Booster1Config
            = new("booster_1_config", new BoosterConfigData { UnlockLv = 11, PriceX1 = 300, PriceX3 = 900});

        public static JsonRemoteConfig<BoosterConfigData> Booster2Config
            = new("booster_2_config", new BoosterConfigData { UnlockLv = 6, PriceX1 = 300, PriceX3 = 900 });

        public static JsonRemoteConfig<BoosterConfigData> Booster3Config
            = new("booster_3_config", new BoosterConfigData { UnlockLv = 18, PriceX1 = 900, PriceX3 = 2700 });

        public static BoolConfig  EnableBoosterTutorial     = new("enable_booster_tutorial", true);

        // ── IN-APP UPDATE ──
        public static IntConfig   InAppUpdateActive         = new("in_app_update_active", 0);
        public static IntConfig   IauAskCount               = new("iau_ask_count", 0);
        public static IntConfig   IauReaskInterval          = new("iau_reask_interval", 0);

        // ── CONNECTION ──
        public static BoolConfig  ConnectionEnable          = new("connection_enable", false);
        public static IntConfig   ConnectionEnableStartLevel = new("connection_enable_start_level", 9);
        
        // ── RATING ──
        public static JsonRemoteConfig<RatingConfigData> RatingConfig = new("rating_config", new RatingConfigData());
        public static IntConfig   HintInterval              = new("hint_interval", 30);

        // ── GAMEPLAY ──
        public static IntConfig   LobbyStartLevel           = new("lobby_start_level", 9);
        public static StringConfig CheatPass                = new("cheat_pass", "pixontop1");
        public static JsonRemoteConfig<HintConfig> HintConfig = new("hint_config", new HintConfig());

        // ── INTERSTITIAL ──
        public static JsonRemoteConfig<InterConfigData> InterConfig = new("inter_ad_config", new InterConfigData());

        // ── REVIVE ──
        public static JsonRemoteConfig<ReviveConfigData> ReviveConfig = new("revive_config", new ReviveConfigData());

        // ── REWARDED WIN ──
        public static JsonRemoteConfig<RwWinAdConfigData> RwWinAdConfig = new("rw_win_ad_config", new RwWinAdConfigData());

        // ── ADS ──
        public static FloatConfig InappProcessedPercent     = new("inapp_processed_percent", 0.7f);
        public static IntConfig   BannerStartShow           = new("banner_start_show", 1);
        public static BoolConfig  AoaEnable                 = new("AOA_enable", false);
        public static IntConfig   AoaStartSession           = new("AOA_start_session", 2);

        // ── AUTO-SHOW OFFERS (level just won, first home visit) ──
        public static IntConfig   StarterPackAutoShowLv     = new("starter_pack_auto_show_lv", 9);
        public static IntConfig   RemoveAdsAutoShowLv       = new("remove_ads_auto_show_lv", 19);

        //Feature

        #region ALL
        /// <summary>
        /// Tim tat ca IRemoteConfig duoc khai bao trong class nay.
        /// Dung reflection de tu dong phat hien — [Preserve] tren class dam bao IL2CPP khong strip fields.
        /// Khi them config moi: chi can them field, khong can cap nhat danh sach nay.
        /// </summary>
        public static readonly IReadOnlyList<IRemoteConfig> All = BuildAll();

        static List<IRemoteConfig> BuildAll()
        {
            var list = new List<IRemoteConfig>();
            foreach (var field in typeof(ConfigCollection).GetFields(BindingFlags.Public | BindingFlags.Static))
            {
                if (field.GetValue(null) is IRemoteConfig config)
                    list.Add(config);
            }
            return list;
        }
        #endregion
    }
}
