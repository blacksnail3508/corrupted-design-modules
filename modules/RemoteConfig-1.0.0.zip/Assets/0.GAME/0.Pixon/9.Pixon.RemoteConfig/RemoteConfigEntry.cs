using System.Globalization;
using Newtonsoft.Json;

namespace Pixon.Remote
{
    public class IntConfig : IRemoteConfig
    {
        public string Key          { get; }
        public int    DefaultValue { get; }
        public int    Value        { get; private set; }

        public IntConfig(string key, int defaultValue = 0)
        {
            Key          = key;
            DefaultValue = defaultValue;
            Value        = defaultValue;
        }

        public void Apply(RemoteSnapshot snapshot)
            => Value = int.TryParse(snapshot.Get(Key), out var v) ? v : DefaultValue;
    }
    
    public class FloatConfig : IRemoteConfig
    {
        public string Key          { get; }
        public float    DefaultValue { get; }
        public float    Value        { get; private set; }

        public FloatConfig(string key, float defaultValue = 0)
        {
            Key          = key;
            DefaultValue = defaultValue;
            Value        = defaultValue;
        }

        public void Apply(RemoteSnapshot snapshot)
            => Value = float.TryParse(snapshot.Get(Key), NumberStyles.Float, CultureInfo.InvariantCulture, out var v) ? v : DefaultValue;
    }

    public class BoolConfig : IRemoteConfig
    {
        public string Key          { get; }
        public bool   DefaultValue { get; }
        public bool   Value        { get; private set; }

        public BoolConfig(string key, bool defaultValue = false)
        {
            Key          = key;
            DefaultValue = defaultValue;
            Value        = defaultValue;
        }

        public void Apply(RemoteSnapshot snapshot)
            => Value = bool.TryParse(snapshot.Get(Key), out var v) ? v : DefaultValue;
    }

    public class StringConfig : IRemoteConfig
    {
        public string Key          { get; }
        public string DefaultValue { get; }
        public string Value        { get; private set; }

        public StringConfig(string key, string defaultValue = "")
        {
            Key          = key;
            DefaultValue = defaultValue;
            Value        = defaultValue;
        }

        public void Apply(RemoteSnapshot snapshot)
        {
            var raw = snapshot.Get(Key);
            Value = string.IsNullOrEmpty(raw) ? DefaultValue : raw;
        }
    }
    
    public class JsonRemoteConfig<T> : IRemoteConfig, IDefaultValue where T : new()
    {
        public string Key          { get; }
        public T      DefaultValue { get; }
        public T      Value        { get; private set; }

        public JsonRemoteConfig(string key, T defaultValue = default)
        {
            Key          = key;
            DefaultValue = defaultValue ?? new T();
            Value        = DefaultValue;
        }

        public object GetDefaultValue() => DefaultValue;

        public void Apply(RemoteSnapshot snapshot)
        {
            var raw = snapshot.Get(Key);
            if (string.IsNullOrEmpty(raw)) { Value = DefaultValue; return; }
            try   { Value = JsonConvert.DeserializeObject<T>(raw); }
            catch { Value = DefaultValue; }
        }
    }
}