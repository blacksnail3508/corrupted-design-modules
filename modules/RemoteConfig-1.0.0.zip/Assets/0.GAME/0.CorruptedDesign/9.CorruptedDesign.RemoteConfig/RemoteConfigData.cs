using System;
using Newtonsoft.Json;
using CorruptedDesignTemplate;

namespace CorruptedDesign.Remote
{
    public class InterConfigData
    {
        [JsonProperty("inter_win_start_lv")]       public int  WinStartLv     = 99999;
        [JsonProperty("inter_lose_start_lv")]      public int  LoseStartLv    = 99999;
        [JsonProperty("inter_setting_start_lv")]   public int  SettingStartLv = 99999;
        [JsonProperty("inter_af_rw_win_start_lv")] public int  AfRwWinStartLv = 99999;
        [JsonProperty("inter_interval")]           public int  Interval       = 99999;
        [JsonProperty("inter_rw_interval")]        public int  RwInterval     = 99999;
        [JsonProperty("ad_break_show")]            public bool AdBreakShow    = false;
    }

    public class RwWinAdConfigData
    {
        [JsonProperty("currency_reward_win")]      public int[]   CurrencyRewardWin = { 30, 30, 30 };
        [JsonProperty("rw_win_start_lv")]          public int     StartLv           = 99999;
        [JsonProperty("rw_win_button_right_side")] public bool    ButtonRightSide   = true;
        [JsonProperty("rw_win_multiplier_value")]  public float[] MultiplierValue   = { 2f, 2f, 2f };

        public int GetReward(Difficulty difficulty) => Pick(CurrencyRewardWin, difficulty, 30);

        public float GetMultiplier(Difficulty difficulty) => Pick(MultiplierValue, difficulty, 2f);

        static T Pick<T>(T[] values, Difficulty difficulty, T fallback)
        {
            int index = (int)difficulty;
            if (values == null || index < 0 || index >= values.Length) return fallback;
            return values[index];
        }
    }

    public class BoosterConfigData
    {
        [JsonProperty("unlock_lv")]              public int UnlockLv            = 11;
        [JsonProperty("bonus_tut")]              public int BonusTut            = 2;
        [JsonProperty("rw_start_lv")]            public int RwStartLv           = 1;
        [JsonProperty("rw_limit_per_level")]     public int RwLimitPerLevel     = 99999;
        [JsonProperty("rw_limit_per_day")]       public int RwLimitPerDay       = 99999;
        [JsonProperty("coin_threshold_lock_rw")] public int CoinThresholdLockRw = 5000;
        [JsonProperty("buy_amount")]             public int BuyAmount           = 1;
        [JsonProperty("price_x1")]               public int PriceX1             = 100;
        [JsonProperty("price_x3")]               public int PriceX3             = 300;

        [JsonIgnore] public int SellAmount => Math.Max(1, BuyAmount);

        [JsonIgnore] public int SellPrice => SellAmount >= 3 ? PriceX3 : PriceX1;
    }

    public class ReviveConfigData
    {
        [JsonProperty("revive_rw_start_lv")]              public int   RwStartLv             = 1;
        [JsonProperty("revive_rw_limit_per_level")]       public int   RwLimitPerLevel       = 99999;
        [JsonProperty("revive_rw_limit_per_day")]         public int   RwLimitPerDay         = 99999;
        [JsonProperty("revive_coin_threshold_unlock_rw")] public int   CoinThresholdUnlockRw = 5000;
        [JsonProperty("revive_price_list")]               public int[] PriceList             = { 900, 900, 900, 900, 900};

        public const int FallbackPrice = 100;

        public int GetPrice(int reviveCountThisLevel)
        {
            if (PriceList == null || PriceList.Length == 0) return FallbackPrice;

            int index = reviveCountThisLevel < 0 ? 0 : reviveCountThisLevel;
            if (index >= PriceList.Length) index = PriceList.Length - 1;
            return PriceList[index];
        }
    }

    public class RatingConfigData
    {
        [JsonProperty("rating_start_lv")]   public int StartLv   = 10;
        [JsonProperty("rating_frequency")]  public int Frequency = 10;
    }

    public class HintConfig
    {
        [JsonProperty("enable")] public bool Enable = true;
        [JsonProperty("level_start")] public int LevelStart = 2;
        [JsonProperty("level_end")] public int LevelEnd = -1;
        [JsonProperty("non_action_time")] public float NonActionTime = 10;
    }
}
