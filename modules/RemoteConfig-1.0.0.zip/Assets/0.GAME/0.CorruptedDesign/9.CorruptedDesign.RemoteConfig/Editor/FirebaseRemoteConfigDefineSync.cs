using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;

namespace CorruptedDesign.Remote.Editor
{
    /// <summary>Keeps CORRUPTED_DESIGN_HAS_FIREBASE_REMOTE_CONFIG defined while the Firebase Remote Config SDK is in the project, so the Firebase fetcher compiles only when it can.</summary>
    public static class FirebaseRemoteConfigDefineSync
    {
        private const string Symbol = "CORRUPTED_DESIGN_HAS_FIREBASE_REMOTE_CONFIG";
        private const string TypeName = "Firebase.RemoteConfig.FirebaseRemoteConfig";

        // If the SDK is deleted while the symbol is set the project cannot compile, and this script with it: remove the symbol by hand in Player Settings.
        [InitializeOnLoadMethod]
        private static void Sync()
        {
            bool hasSdk = AppDomain.CurrentDomain.GetAssemblies().Any(a => a.GetType(TypeName, false) != null);
            var target = UnityEditor.Build.NamedBuildTarget.FromBuildTargetGroup(BuildPipeline.GetBuildTargetGroup(EditorUserBuildSettings.activeBuildTarget));

            var symbols = new List<string>(PlayerSettings.GetScriptingDefineSymbols(target).Split(';', StringSplitOptions.RemoveEmptyEntries));
            if (symbols.Contains(Symbol) == hasSdk) return;

            if (hasSdk) symbols.Add(Symbol);
            else symbols.Remove(Symbol);
            PlayerSettings.SetScriptingDefineSymbols(target, string.Join(";", symbols));
        }
    }
}
