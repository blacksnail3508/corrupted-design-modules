#if CORRUPTED_DESIGN_HAS_FIREBASE_REMOTE_CONFIG
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Firebase;
using Firebase.RemoteConfig;
using UnityEngine;

namespace CorruptedDesign.Remote
{
    /// <summary>Fetches every <see cref="ConfigCollection"/> key from Firebase Remote Config; compiled only while the Firebase SDK is in the project.</summary>
    public class RemoteFetcherFirebase : RemoteFetcher
    {
        // Shared: Firebase throws on a second dependency check started while one is still running.
        private static Task<DependencyStatus> dependencyCheck;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetState() => dependencyCheck = null;

        public override async Task<RemoteSnapshot> FetchAsync()
        {
            // A faulted check is finished too, so a retry starts a new one rather than rethrowing forever.
            if (dependencyCheck == null || dependencyCheck.IsFaulted || dependencyCheck.IsCanceled)
                dependencyCheck = FirebaseApp.CheckAndFixDependenciesAsync();
            var status = await dependencyCheck;
            if (status != DependencyStatus.Available)
            {
                // The check is finished, so dropping it lets the next fetch retry without overlapping it.
                dependencyCheck = null;
                throw new Exception($"[RemoteFetcherFirebase] Firebase dependencies not available: {status}");
            }

            await FirebaseRemoteConfig.DefaultInstance.FetchAsync(TimeSpan.FromSeconds(0));

            var info = FirebaseRemoteConfig.DefaultInstance.Info;
            switch (info.LastFetchStatus)
            {
                case LastFetchStatus.Success:
                    await FirebaseRemoteConfig.DefaultInstance.ActivateAsync();
                    Bug.Log($"[RemoteFetcherFirebase] Fetch success (fetchTime={info.FetchTime}).");
                    return BuildSnapshot();

                case LastFetchStatus.Failure:
                    var reason = info.LastFetchFailureReason switch
                    {
                        FetchFailureReason.Throttled => $"Throttled until {info.ThrottledEndTime}",
                        _ => "Unknown error",
                    };
                    throw new Exception($"[RemoteFetcherFirebase] Fetch failed: {reason}");

                case LastFetchStatus.Pending:
                    throw new Exception("[RemoteFetcherFirebase] Fetch still pending.");

                default:
                    throw new Exception("[RemoteFetcherFirebase] Fetch unknown status.");
            }
        }

        /// <summary>Raw key/value pairs whose key starts with <paramref name="prefix"/>; for prefix-keyed remote data.</summary>
        public static IEnumerable<KeyValuePair<string, string>> ReadByPrefix(string prefix)
        {
            var config = FirebaseRemoteConfig.DefaultInstance;
            return config.GetKeysByPrefix(prefix).Select(key => new KeyValuePair<string, string>(key, config.GetValue(key).StringValue)).ToList();
        }

        private static RemoteSnapshot BuildSnapshot()
        {
            var snapshot = new RemoteSnapshot { FetchedAtTimeStamp = TimeUtils.NowTS };
            foreach (var entry in ConfigCollection.All)
                snapshot.Values[entry.Key] = FirebaseRemoteConfig.DefaultInstance.GetValue(entry.Key).StringValue;
            return snapshot;
        }
    }
}
#endif
