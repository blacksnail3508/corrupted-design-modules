# CorruptedDesign.Remote

Hệ thống quản lý Remote Config cho Unity. Fetch dữ liệu từ Unity Remote Config Service, tự động cache mỗi session, đảm bảo config luôn có giá trị để đọc dù fetch chưa hoàn tất.

---

## Yêu cầu

- Unity 2022.3+
- Package `com.unity.remote-config`
- `Newtonsoft.Json` (via `com.unity.nuget.newtonsoft-json`)
- `CorruptedDesign.Data.Vault<T>` — dùng để persist cache

---

## Cấu trúc

| File | Trách nhiệm |
|---|---|
| `IRemoteConfig.cs` | Contract của một config entry |
| `RemoteSnapshot.cs` | Bản chụp raw string từ remote |
| `RemoteConfigEntry.cs` | `IntConfig`, `BoolConfig`, `JsonConfig<T>` |
| `RC.cs` | Nơi khai báo tất cả config của game |
| `RemoteFetcher.cs` | Gọi Unity Remote Config SDK |
| `RemoteManager.cs` | MonoBehaviour entry point |

---

## Luồng hoạt động

```
Awake (sync)
└─ Vault.Load() → apply cache ngay → entries sẵn sàng đọc

Awake (async, nền)
└─ RemoteFetcher.FetchAsync()
   ├─ Thành công → Vault.Save() → apply đè → OnFetchCompleted
   └─ Thất bại   → giữ nguyên giá trị hiện tại → OnFetchCompleted
```

Truy cập `RC.*` bất kỳ lúc nào đều an toàn:

| Thời điểm | Giá trị trả về | `Source` |
|---|---|---|
| Không có cache, chưa fetch xong | `DefaultValue` | `Default` |
| Có cache, chưa fetch xong | Cached value | `Cache` |
| Sau khi fetch xong | Remote value | `Remote` |

---

## Setup

**1. Đặt `RemoteManager` vào scene đầu tiên**

Tạo một GameObject, attach `RemoteManager`. Component tự gọi `DontDestroyOnLoad`.

**2. Khai báo config trong `RC.cs`**

```csharp
public static class RC
{
    public static readonly IntConfig              MaxLevel    = new("max_level",    defaultValue: 10);
    public static readonly BoolConfig             ShowBanner  = new("show_banner",  defaultValue: false);
    public static readonly JsonConfig<RewardData> DailyReward = new("daily_reward", defaultValue: new RewardData());
}
```

**3. Đăng ký vào `RemoteRegistry.cs`**

```csharp
public static IReadOnlyList<IRemoteConfig> All() => new[]
{
    (IRemoteConfig)RC.MaxLevel,
    (IRemoteConfig)RC.ShowBanner,
    (IRemoteConfig)RC.DailyReward,
};
```

---

## Cách dùng

```csharp
// Đọc ngay — luôn an toàn, trả về cached hoặc default nếu fetch chưa xong
int level = RC.MaxLevel.Value;
bool show = RC.ShowBanner.Value;

// Lắng nghe khi fetch remote xong để apply UI
RemoteManager.OnFetchCompleted += RefreshUI;

// Kiểm tra nguồn dữ liệu hiện tại
Debug.Log(RemoteManager.Instance.Source); // "Default" | "Cache" | "Remote"
```

---

## Thêm config kiểu class (JSON)

Trên **Unity Remote Config dashboard**, tạo key với type `string`, value là JSON:

```json
{"baseCoins": 50, "bonusMultiplier": 1.5, "vipOnly": false}
```

Trong project:

```csharp
// 1. Định nghĩa data class
[Serializable]
public class RewardData
{
    public int   BaseCoins       = 50;
    public float BonusMultiplier = 1f;
    public bool  VipOnly         = false;
}

// 2. Khai báo trong RC.cs
public static readonly JsonConfig<RewardData> DailyReward
    = new("daily_reward", defaultValue: new RewardData());

// 3. Đăng ký trong RemoteRegistry.cs
(IRemoteConfig)RC.DailyReward,

// 4. Đọc trong game
RewardData data = RC.DailyReward.Value;
```

---

## Thêm config mới — checklist

- [ ] Thêm field vào `RC.cs`
- [ ] Thêm entry vào `RemoteRegistry.All()`
- [ ] Tạo key tương ứng trên Unity Remote Config dashboard

---

## Mở rộng fetcher

Để dùng provider khác (Firebase, Addressables...):

```csharp
public class FirebaseFetcher : RemoteFetcher
{
    public override async Task<RemoteSnapshot> FetchAsync()
    {
        // fetch từ Firebase...
        var snap = new RemoteSnapshot { FetchedAt = DateTime.UtcNow };
        snap.Values["max_level"] = "50";
        return snap;
    }
}
```

Inject vào `RemoteManager` bằng cách override field `_fetcher` trong subclass.
