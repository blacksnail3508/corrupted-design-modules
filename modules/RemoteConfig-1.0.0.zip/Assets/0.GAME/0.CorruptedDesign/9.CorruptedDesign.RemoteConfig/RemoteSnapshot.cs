using System;
using System.Collections.Generic;

namespace CorruptedDesign.Remote
{
    /// <summary>
    /// Bản chụp toàn bộ raw value từ remote tại một thời điểm.
    /// Mọi giá trị lưu dưới dạng string — việc parse là trách nhiệm của từng config entry.
    /// </summary>
    [Serializable]
    public class RemoteSnapshot
    {
        public long FetchedAtTimeStamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        public Dictionary<string, string> Values    = new();

        public string Get(string key, string defaultValue = "")
            => Values.TryGetValue(key, out var v) ? v : defaultValue;
    }
}
