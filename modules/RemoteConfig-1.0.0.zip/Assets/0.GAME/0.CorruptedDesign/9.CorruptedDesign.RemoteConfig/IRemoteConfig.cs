namespace CorruptedDesign.Remote
{
    public interface IRemoteConfig
    {
        string Key { get; }
        void Apply(RemoteSnapshot snapshot);
    }

    /// <summary>
    /// Cho phép lấy DefaultValue dưới dạng object mà không cần dynamic hay reflection.
    /// RemoteFetcher dùng để build mock snapshot.
    /// </summary>
    public interface IDefaultValue
    {
        object GetDefaultValue();
    }
}