using System;
using System.Threading.Tasks;
using CorruptedDesign.Data;
using UnityEngine;

namespace CorruptedDesign.Remote
{
    public class RemoteManager : MonoBehaviour
    {
        public static RemoteManager Instance { get; private set; }

        private readonly Vault<RemoteSnapshot> _vault           = new("Remote_Cache");

        public bool IsFetchDone { get; private set; }

        public string Source { get; private set; } = "Default";
        public static event Action OnFetchCompleted;

        /// <summary>Where values come from. The default returns each entry's default value; assign a backend fetcher (Firebase...) before the first scene loads.</summary>
        public static RemoteFetcher Fetcher { get; set; } =
#if CORRUPTED_DESIGN_HAS_FIREBASE_REMOTE_CONFIG
            new RemoteFetcherFirebase();
#else
            new RemoteFetcher();
#endif

        // Set once the backend is ready, so other users can wait on it instead of checking again.
        public static bool IsReady { get; private set; }
        public static event Action OnReady;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetState() => IsReady = false;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void Bootstrap()
        {
            if (Instance != null) return;
            new GameObject(nameof(RemoteManager)).AddComponent<RemoteManager>();
        }

        private void Awake()
        {
            if (Instance != null) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);

            ApplyCacheIfAvailable();
            _ = InitAndFetchAsync();
        }

        private void ApplyCacheIfAvailable()
        {
            var cached = _vault.Value;
            if (cached == null) return;

            foreach (var entry in ConfigCollection.All)
                entry.Apply(cached);

            Source = "Cache";
            Bug.Log($"[Remote] Loaded cache from {cached.FetchedAtTimeStamp}. Entries ready.");
        }

        private async Task InitAndFetchAsync()
        {
            try
            {
                IsReady = true;
                // A listener failing must not cost the remote config its fetch.
                try { OnReady?.Invoke(); }
                catch (Exception listenerEx) { Debug.LogException(listenerEx); }

                var snapshot = await Fetcher.FetchAsync();
                _vault.Value = snapshot;

                foreach (var entry in ConfigCollection.All)
                    entry.Apply(snapshot);

                Source = "Remote";
                Bug.Log("[Remote] Fetch completed. Update entries.");
            }
            catch (Exception ex)
            {
                Bug.LogWarning($"[Remote] Fetch failed: {ex.Message}. Keep current entries ({Source}).");
            }
            finally
            {
                IsFetchDone = true;
                OnFetchCompleted?.Invoke();
            }
        }

#if UNITY_EDITOR
        [ContextMenu("Xoá cache")]
        private void ClearCache() => _vault.Save(null);
#endif
    }
}
