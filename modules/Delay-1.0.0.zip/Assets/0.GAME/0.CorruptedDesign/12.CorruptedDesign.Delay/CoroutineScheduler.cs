using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoroutineScheduler : MonoBehaviour
{
    #region SINGLETON
    private static CoroutineScheduler _instance;
    public static CoroutineScheduler Instance
    {
        get
        {
            if (_instance == null)
            {
                var go = new GameObject("CoroutineScheduler");
                DontDestroyOnLoad(go);
                _instance = go.AddComponent<CoroutineScheduler>();
            }
            return _instance;
        }
    }
    #endregion

    #region DATA STRUCTURES
    private class ScheduledItem
    {
        public Action Callback;
        public object Owner;
        public Coroutine Coroutine;
        public long Uid;

        public void Reset(Action callback, object owner, long uid)
        {
            Callback = callback;
            Owner = owner;
            Coroutine = null;
            Uid = uid;
        }

        public void Clear()
        {
            Callback = null;
            Owner = null;
            Coroutine = null;
            Uid = 0;
        }
    }
    #endregion

    #region FIELDS
    private readonly List<ScheduledItem> _scheduled = new List<ScheduledItem>(32);
    private readonly Queue<ScheduledItem> _pool = new Queue<ScheduledItem>();
    private long _nextUid = 0;
    #endregion

    #region PUBLIC METHODS
    public void Schedule(float delay, Action callback, object owner = null, bool unscaled = false)
    {
        var item = _pool.Count > 0 ? _pool.Dequeue() : new ScheduledItem();
        item.Reset(callback, owner, ++_nextUid);
        
        // Start the coroutine and store the reference
        item.Coroutine = StartCoroutine(WaitAndExecute(delay, item, item.Uid, unscaled));
        
        _scheduled.Add(item);
    }

    public void Cancel(object owner)
    {
        if (owner == null) return;

        for (int i = _scheduled.Count - 1; i >= 0; i--)
        {
            if (_scheduled[i].Owner == owner)
            {
                RemoveAndRecycleAt(i);
            }
        }
    }

    public void Clear()
    {
        // Stop all running coroutines
        foreach (var item in _scheduled)
        {
            if (item.Coroutine != null) StopCoroutine(item.Coroutine);
            item.Clear();
            _pool.Enqueue(item);
        }
        _scheduled.Clear();
    }
    #endregion

    #region PRIVATE METHODS
    private IEnumerator WaitAndExecute(float delay, ScheduledItem item, long uid, bool unscaled)
    {
        if (unscaled) yield return new WaitForSecondsRealtime(delay);
        else yield return new WaitForSeconds(delay);

        // Check if the item has been recycled/reused (Uid mismatch)
        if (item.Uid != uid) yield break;

        try
        {
            item.Callback?.Invoke();
        }
        catch (Exception e)
        {
            Debug.LogException(e);
        }

        // Check again if cancelled during callback
        if (item.Uid != uid) yield break;

        // Remove from list and recycle
        // We check if Remove returns true to ensure we don't recycle twice 
        // (e.g. if Cancel was called during the callback)
        if (_scheduled.Remove(item))
        {
            Recycle(item);
        }
    }

    private void RemoveAndRecycleAt(int index)
    {
        var item = _scheduled[index];
        if (item.Coroutine != null) StopCoroutine(item.Coroutine);
        _scheduled.RemoveAt(index);
        Recycle(item);
    }

    private void Recycle(ScheduledItem item)
    {
        item.Clear();
        _pool.Enqueue(item);
    }
    #endregion
}
