using System;
using System.Collections;
using UnityEngine;

public class Clock : MonoBehaviour
{
    public static Action CallPerSecond;
    WaitForSecondsRealtime second = new WaitForSecondsRealtime(1);
    public IEnumerator Activate()
    {
        yield return null;
        StartCoroutine(RuntimeLoop());
    }
    private IEnumerator RuntimeLoop()
    {
        while (true)
        {
            yield return second;
            CallPerSecond?.Invoke();
        }
    }
    private void OnDestroy()
    {
        StopAllCoroutines();
    }
    
    public static void RemoveAllCallback(object target)
    {
        if (CallPerSecond == null) return;

        foreach (Delegate d in CallPerSecond.GetInvocationList())
        {
            if (d.Target == target)
            {
                CallPerSecond -= (Action)d;
            }
        }
    }

    public void ForceActivate()
    {
        StartCoroutine(Activate());
    }
}