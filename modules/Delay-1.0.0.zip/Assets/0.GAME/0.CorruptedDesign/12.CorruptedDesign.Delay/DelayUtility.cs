using System;
using System.Collections;
using UnityEngine;

public static class DelayUtility
{
    public static Coroutine DelayCall(this MonoBehaviour runner, float delay, Action callback)
    {
        return runner.StartCoroutine(DelayRoutine(delay, callback));
    }

    private static IEnumerator DelayRoutine(float delay, Action callback)
    {
        yield return new WaitForSeconds(delay);
        callback?.Invoke();
    }

    public static void CancelCoroutine(this MonoBehaviour runner, Coroutine coroutine)
    {
        if (coroutine != null) runner.StopCoroutine(coroutine);
    }
}

public static class Delay
{
    public static void Call(float delay, Action callback, object owner = null)
    {
        CoroutineScheduler.Instance.Schedule(delay, callback, owner);
    }

    public static void Call(float delay, object owner, Action callback)
    {
        CoroutineScheduler.Instance.Schedule(delay, callback, owner);
    }

    public static void Call(object owner, float delay, Action callback)
    {
        CoroutineScheduler.Instance.Schedule(delay, callback, owner);
    }

    /// <summary>Schedules on real time, so a paused game (timeScale 0) still runs the callback.</summary>
    public static void CallUnscaled(float delay, Action callback, object owner = null)
    {
        CoroutineScheduler.Instance.Schedule(delay, callback, owner, unscaled: true);
    }

    public static void Cancel(object owner)
    {
        CoroutineScheduler.Instance.Cancel(owner);
    }

    public static void Clear()
    {
        CoroutineScheduler.Instance.Clear();
    }
}

// Extension methods for Action to enable chaining .Delay()
public static class ActionDelayExtensions
{
    /// <summary>
    /// Executes the action after a specified delay
    /// </summary>
    /// <param name="action">The action to execute</param>
    /// <param name="delayTime">Delay in seconds</param>
    /// <param name="owner">Optional owner object for tracking/cancellation</param>
    public static void Delay(this Action action, float delayTime, object owner = null)
    {
        if (action != null)
        {
            CoroutineScheduler.Instance.Schedule(delayTime, action, owner);
        }
    }
}