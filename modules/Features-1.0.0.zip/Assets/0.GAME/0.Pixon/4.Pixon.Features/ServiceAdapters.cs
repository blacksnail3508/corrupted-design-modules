using System;
using Pixon.Observer;
using UnityEngine;

namespace Pixon.Feature
{
    /// <summary>Production adapter over the global <c>Clock</c> singleton.</summary>
    public class ClockServiceAdapter : IClockService
    {
        public event Action OnSecond;

        public long NowTS => TimeUtils.NowTS;

        public ClockServiceAdapter()
        {
            Clock.CallPerSecond += Raise;
        }

        private void Raise() => OnSecond?.Invoke();

        public void Subscribe(object owner, Action callback)
        {
            Clock.CallPerSecond += callback;
        }

        public void Unsubscribe(object owner)
        {
            Clock.RemoveAllCallback(owner);
        }
    }

    /// <summary>Production adapter over <c>GameService.DataManager</c> + <c>EventService</c>.</summary>
    public class LevelSourceAdapter : ILevelSource
    {
        public int CurrentLevel => GameService.DataManager.Level;

        /// <summary>The Component this adapter serves, recorded by the EventTracer so the
        /// LevelUp subscription is attributed to the owning feature instead of the bridge closure.</summary>
        private readonly Component _owner;

        private Action<int> _handler;
        private EventManager.EventDelegate<LevelUpEvent> _bridge;

        public LevelSourceAdapter(Component owner = null)
        {
            _owner = owner;
        }

        public void AddLevelUpListener(Action<int> handler)
        {
            if (handler == null) return;
            if (_handler != null) RemoveLevelUpListener(_handler);

            _handler = handler;
            _bridge = _ => handler(CurrentLevel);
            EventService.AddListener<LevelUpEvent>(_bridge, _owner);
        }

        public void RemoveLevelUpListener(Action<int> handler)
        {
            if (_bridge == null) return;
            EventService.RemoveListener<LevelUpEvent>(_bridge, _owner);
            _bridge = null;
            _handler = null;
        }
    }
}
