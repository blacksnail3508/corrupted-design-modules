using UnityEngine;

namespace Pixon.Feature
{
    [CreateAssetMenu(fileName = "FeatureTimeConfig", menuName = "SO/FeatureTimeConfig")]
    public class TimeBaseConfig : ScriptableObject
    {
        public int UnlockLevel;
        public int DurationInMinutes;
        public int ResetTimeInMinutes;
        public TimeEndType TimeEndType = TimeEndType.Midnight;
    }
}
