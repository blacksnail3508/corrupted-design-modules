using System.Collections;
using UnityEngine;

namespace Pixon.Feature
{
    /// <summary>
    /// Demonstrates every hook and command available in the FeatureBase / IFeatureScheduler contract.
    /// Replace placeholder logic with real game code before shipping.
    /// </summary>
    public class FeatureExample : FeatureBase, IDayRolloverAware
    {
        [Header("Config Overrides (optional — leave 0 to use ScriptableObject values)")]
        [SerializeField] private int overrideUnlockLevel    = 0;
        [SerializeField] private int overrideActiveDuration = 0; // minutes
        [SerializeField] private int overrideResetTime      = 0; // minutes

        // ──────────────────────────────────────────────────────────────
        // PIPELINE  (called by FeatureManager in Load → Check → Start order)
        // ──────────────────────────────────────────────────────────────

        #region 1. PreloadData — deserialize saved state, then initialize scheduler

        public override IEnumerator PreloadData()
        {
            // --- Load persisted data (replace with real deserialization) ---
            var data = LoadSavedData();

            // --- Optional: override config values before Initialize ---
            if (overrideUnlockLevel    > 0) featureScheduler.SetUnlockLevel(overrideUnlockLevel);
            if (overrideActiveDuration > 0) featureScheduler.SetActiveDuration(overrideActiveDuration);
            if (overrideResetTime      > 0) featureScheduler.SetResetTime(overrideResetTime);

            // --- Kick the scheduler (required before any command) ---
            featureScheduler.Initialize(data);

            yield break;
        }

        private FeatureCommonData LoadSavedData()
        {
            // Replace with: return JsonUtility.FromJson<FeatureCommonData>(PlayerPrefs.GetString(SaveKey));
            return new FeatureCommonData();
        }

        #endregion

        #region 2. StartFeature — show UI / register input based on current state

        public override IEnumerator StartFeature()
        {
            switch (Scheduler.State)
            {
                case FeatureState.NotUnlocked:
                    // hide entry point in UI
                    break;

                case FeatureState.Preparation:
                    // show "Start" button
                    break;

                case FeatureState.Progressing:
                    // re-open the active session panel (app was backgrounded mid-session)
                    ShowActivePanel();
                    break;

                case FeatureState.Win:
                case FeatureState.Lose:
                    // show result screen that is still waiting for player ack
                    ShowResultScreen(Scheduler.State);
                    break;

                case FeatureState.CooldownToRestart:
                    // show cooldown timer: Scheduler.CooldownRemaining seconds left
                    ShowCooldownUI(Scheduler.CooldownRemaining);
                    break;
            }

            yield break;
        }

        #endregion

        #region 3. SaveData — persist everything that needs to survive a restart

        public override void SaveData()
        {
            // Persist scheduler state:
            //   PlayerPrefs.SetString(SaveKey, JsonUtility.ToJson(schedulerComponent.CommonData));
            // Persist any feature-local fields here too.
            Debug.Log("[FeatureExample] SaveData");
        }

        #endregion

        #region 4. OnDayRollover — IDayRolloverAware (opt-in; remove interface if not needed)

        public IEnumerator OnDayRollover(bool isNewDay)
        {
            if (isNewDay)
            {
                // Reset daily counters, refresh UI, etc.
                Debug.Log("[FeatureExample] New day — resetting daily progress.");
            }

            yield break;
        }

        #endregion
        
        #region Scheduler event handlers

        protected override void HandleInitialized()
        {
            // Scheduler is ready; safe to read Scheduler.State / TimeRemaining here.
            Debug.Log($"[FeatureExample] Initialized — state: {Scheduler.State}");
        }

        protected override void HandleUnlocked()
        {
            // Feature became available for the first time (level requirement met).
            Debug.Log("[FeatureExample] Unlocked — show entry point in lobby.");
        }

        protected override void HandleEntryStarted()
        {
            // Session just started: timer is running, Scheduler.TimeRemaining counting down.
            Debug.Log($"[FeatureExample] Entry started — duration: {Scheduler.TimeRemaining}s");
            ShowActivePanel();
        }

        protected override void HandleTimeUp()
        {
            // Timer reached zero before the player achieved the goal.
            // Scheduler moved to CooldownToRestart automatically; wait for HandleLoseConfirmed
            // or call ConfirmLose() from the UI.
            Debug.Log("[FeatureExample] Time's up!");
            ShowResultScreen(FeatureState.Lose);
        }

        protected override void HandleWinConfirmed()
        {
            // Player acknowledged the win result; cooldown has begun.
            Debug.Log("[FeatureExample] Win confirmed — cooldown starts.");
            ShowCooldownUI(Scheduler.CooldownRemaining);
        }

        protected override void HandleLoseConfirmed()
        {
            // Player acknowledged the lose result; cooldown has begun.
            Debug.Log("[FeatureExample] Lose confirmed — cooldown starts.");
            ShowCooldownUI(Scheduler.CooldownRemaining);
        }

        protected override void HandleCooldownComplete()
        {
            // Cooldown finished; feature is back to Preparation — show Start button again.
            Debug.Log("[FeatureExample] Cooldown done — ready for next entry.");
        }

        protected override void HandleForceStop()
        {
            // An external system (e.g. admin panel, cheat menu) called ForceStop().
            Debug.Log("[FeatureExample] Force-stopped.");
            ShowResultScreen(FeatureState.Lose);
        }

        #endregion
        
        #region Scheduler commands

        /// <summary>Player pressed the Start button.</summary>
        public void OnUserPressStart()
        {
            if (Scheduler.State != FeatureState.Preparation) return;
            Scheduler.StartEntry();
        }

        /// <summary>Player achieved the win condition inside gameplay.</summary>
        public void OnWinConditionMet()
        {
            if (Scheduler.State != FeatureState.Progressing) return;
            GrantRewards();
            // Put scheduler into Win state so HandleWinConfirmed fires after player acks.
            Scheduler.ConfirmWin();
        }

        /// <summary>Player pressed Give Up or the time-up result screen was dismissed as a loss.</summary>
        public void OnUserConfirmLose()
        {
            Scheduler.ConfirmLose();
            Scheduler.MarkUserSeenChanges();
        }

        /// <summary>Emergency stop from game systems (e.g. session interrupted by an event).</summary>
        public void OnForceQuit()
        {
            Scheduler.ForceStop();
        }

        /// <summary>UI dismissed the notification badge — scheduler can clear the badge flag.</summary>
        public void OnUserDismissedBadge()
        {
            Scheduler.MarkUserSeenChanges();
        }

        /// <summary>Display the remaining active-session time (call from a UI ticker).</summary>
        public string GetTimerDisplay()
        {
            int secs = Scheduler.TimeRemaining;
            return $"{secs / 60:D2}:{secs % 60:D2}";
        }

        /// <summary>Display the cooldown time (call from a UI ticker).</summary>
        public string GetCooldownDisplay()
        {
            int secs = Scheduler.CooldownRemaining;
            return $"{secs / 60:D2}:{secs % 60:D2}";
        }

        #endregion

        private void GrantRewards()
        {
            Debug.Log("[FeatureExample] Rewards granted.");
        }

        private void ShowActivePanel()
        {
            Debug.Log($"[FeatureExample] ShowActivePanel — {GetTimerDisplay()} remaining");
        }

        private void ShowResultScreen(FeatureState outcome)
        {
            Debug.Log($"[FeatureExample] ShowResultScreen — {outcome}");
        }

        private void ShowCooldownUI(int secondsRemaining)
        {
            Debug.Log($"[FeatureExample] ShowCooldownUI — {secondsRemaining}s");
        }
    }
}
