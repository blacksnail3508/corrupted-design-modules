using System;

namespace Pixon.Feature
{
    [Serializable]
    public class FeatureCommonData
    {
        public int Entry = 0;
        public int WinCount = 0;
        public int LoseCount = 0;
        public long StartTimeStamp = 0;
        public long EndTimeStamp = 0;
        public long ResetTimeStamp = 0;
        public FeatureState State = FeatureState.NotUnlocked;
    }

    public enum FeatureState
    {
        NotUnlocked,        // waiting for unlock condition (e.g. level)
        Preparation,        // unlocked, awaiting user to start
        Progressing,        // active session, timer running
        Win,                // session ended in win, awaiting ack
        Lose,               // session ended in lose, awaiting ack
        CooldownToRestart   // ack received, waiting before next entry
    }
}
