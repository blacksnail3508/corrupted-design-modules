using System;
using System.Collections;

namespace CorruptedDesign.Feature
{
    #region SCHEDULER ABSTRACTIONS (DIP)

    /// <summary>Per-second tick source. Replaces direct Clock dependency.</summary>
    public interface IClockService
    {
        event Action OnSecond;
        long NowTS => TimeUtils.NowTS;
        void Subscribe(object owner, Action callback);
        void Unsubscribe(object owner);
    }

    /// <summary>User level provider. Replaces direct GameService dependency.</summary>
    public interface ILevelSource
    {
        int CurrentLevel { get; }
        void AddLevelUpListener(Action<int> handler);
        void RemoveLevelUpListener(Action<int> handler);
    }

    /// <summary>Strategy for computing when an active session ends. OCP-friendly.</summary>
    public interface ITimeEndPolicy
    {
        long ComputeEndTimestamp(long startTS, int durationMinutes);
    }

    #endregion

    #region FEATURE-SIDE INTERFACES (ISP)

    // Split into small, opt-in interfaces. A feature implements only what it needs.

    public interface IFeaturePreloadable
    {
        /// <summary>
        /// Call before every method of the feature
        /// </summary>
        /// <returns></returns>
        IEnumerator PreloadData();
    }

    public interface IDayRolloverAware
    {
        IEnumerator OnDayRollover(bool isNewDay);
    }

    public interface IFeatureStartable
    {
        IEnumerator StartFeature();
    }

    public interface IFeaturePersistable
    {
        void SaveData();
    }

    #endregion

    #region SCHEDULER ↔ FEATURE CONTRACT

    /// <summary>Events the scheduler raises; features subscribe to react with logic.</summary>
    public interface ISchedulerEvents
    {
        event Action OnInitialized;
        event Action OnEntryStarted;
        event Action OnUnlocked;
        event Action OnTimeUp;
        event Action OnCooldownComplete;
        event Action OnForceStop;
        event Action OnWinConfirmed;
        event Action OnLoseConfirmed;
    }

    /// <summary>Commands a feature can issue to its scheduler.</summary>
    public interface ISchedulerCommands
    {
        FeatureState State { get; }
        int TimeRemaining { get; }
        int CooldownRemaining { get; }

        void StartEntry(bool incrementEntry = true);
        void ConfirmWin();
        void ConfirmLose();
        void ForceStop();
        void MarkUserSeenChanges();
    }

    public interface IFeatureScheduler : ISchedulerEvents, ISchedulerCommands { }

    #endregion
}
