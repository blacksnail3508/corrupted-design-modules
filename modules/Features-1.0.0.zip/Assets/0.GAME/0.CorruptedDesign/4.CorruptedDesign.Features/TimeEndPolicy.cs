using System;

namespace CorruptedDesign.Feature
{
    /// <summary>Ends at midnight UTC, `durationMinutes` worth of days from now (min 1 day).</summary>
    public class MidnightTimeEndPolicy : ITimeEndPolicy
    {
        public long ComputeEndTimestamp(long startTS, int durationMinutes)
        {
            var days = Math.Max(1, durationMinutes / TimeUtils.MinutesPerDay);
            return GetMidnightDaysFromNow(days).ToUnixTimestamp();
        }

        public static DateTime GetMidnightDaysFromNow(int days)
            => TrustedClock.UtcNow.AddDays(days).Date;
    }

    /// <summary>Ends exactly `durationMinutes` after start.</summary>
    public class ExactDurationTimeEndPolicy : ITimeEndPolicy
    {
        public long ComputeEndTimestamp(long startTS, int durationMinutes)
            => startTS + durationMinutes * 60L;
    }

    public enum TimeEndType
    {
        Midnight,
        ExactHour
    }

    public static class TimeEndPolicyFactory
    {
        public static ITimeEndPolicy Create(TimeEndType type) => type switch
        {
            TimeEndType.Midnight  => new MidnightTimeEndPolicy(),
            TimeEndType.ExactHour => new ExactDurationTimeEndPolicy(),
            _ => throw new ArgumentOutOfRangeException(nameof(type), type, "Unsupported TimeEndType")
        };
    }
}
