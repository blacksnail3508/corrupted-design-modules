using System;
using Sirenix.OdinInspector;
using UnityEngine;
using UnityEngine.Events;

namespace CorruptedDesign.Feature
{
    /// <summary>
    /// Owns TIMING and STATE for a single feature. Knows nothing about feature business logic.
    ///
    /// Single responsibility: drive the <see cref="FeatureState"/> machine off a clock and
    /// raise events. Features subscribe to those events via <see cref="IFeatureScheduler"/>.
    ///
    /// Dependencies (clock, level source, time-end policy) are abstractions — inject them
    /// via <see cref="Configure"/> in tests; production falls back to default adapters.
    /// </summary>
    public class FeatureScheduler : MonoBehaviour, IFeatureScheduler
    {
        #region CONFIG

        [SerializeField, InlineProperty] private TimeBaseConfig _config;
        public int TotalActiveTime => _config.DurationInMinutes * 60;

        #endregion

        #region INJECTED DEPENDENCIES (DIP)

        private IClockService    _clock;
        private ILevelSource     _levelSource;
        private ITimeEndPolicy   _timeEndPolicy;

        /// <summary>
        /// Optional explicit configuration. If not called before <see cref="Initialize"/>,
        /// defaults are used (production adapters). Call this from tests to inject fakes.
        /// </summary>
        public void Configure(IClockService clock, ILevelSource levelSource, ITimeEndPolicy policy = null)
        {
            _clock         = clock         ?? _clock;
            _levelSource   = levelSource   ?? _levelSource;
            _timeEndPolicy = policy        ?? _timeEndPolicy;
        }

        #endregion

        #region RUNTIME DATA

        [ReadOnly] public FeatureCommonData CommonData;

        [SerializeField, FoldoutGroup("Time Values")] private string startDateTime;
        [SerializeField, FoldoutGroup("Time Values")] private string endDateTime;
        [SerializeField, FoldoutGroup("Time Values")] private string restartDateTime;
        [SerializeField, FoldoutGroup("Time Values")] private int timeRemaining;
        [SerializeField, FoldoutGroup("Time Values")] private int timeResetCooldown;

        private Action<int> _levelUpHandler;
        private bool _levelUpRegistered;
        private bool _tickSubscribed;
        private bool _initialized;

        #endregion

        #region EVENTS (ISchedulerEvents) — C# events + UnityEvent mirrors

        public event Action OnInitialized;
        public event Action OnEntryStarted;
        public event Action OnUnlocked;
        public event Action OnTimeUp;
        public event Action OnCooldownComplete;
        public event Action OnForceStop;
        public event Action OnWinConfirmed;
        public event Action OnLoseConfirmed;

        [SerializeField, FoldoutGroup("Unity Events")] public UnityEvent OnInitializedEvent;
        [SerializeField, FoldoutGroup("Unity Events")] public UnityEvent OnEntryStartedEvent;
        [SerializeField, FoldoutGroup("Unity Events")] public UnityEvent OnUnlockedEvent;
        [SerializeField, FoldoutGroup("Unity Events")] public UnityEvent OnTimeUpEvent;
        [SerializeField, FoldoutGroup("Unity Events")] public UnityEvent OnCooldownCompleteEvent;
        [SerializeField, FoldoutGroup("Unity Events")] public UnityEvent OnForceStopEvent;
        [SerializeField, FoldoutGroup("Unity Events")] public UnityEvent OnWinConfirmedEvent;
        [SerializeField, FoldoutGroup("Unity Events")] public UnityEvent OnLoseConfirmedEvent;
        [SerializeField, FoldoutGroup("Unity Events")] public UnityEvent OnUserSeenChangesEvent;

        #endregion

        #region COMMANDS (ISchedulerCommands)

        public FeatureState State => CommonData?.State ?? FeatureState.NotUnlocked;
        public int TimeRemaining => timeRemaining;
        public int CooldownRemaining => timeResetCooldown;

        /// <summary>
        /// Change to Phase Processing, invoke callbacks, pre-calculate times.
        /// Pass <paramref name="incrementEntry"/> = false to (re)start the current entry
        /// without bumping the entry counter (e.g. a "continue" button from Preparation).
        /// </summary>
        public void StartEntry(bool incrementEntry = true)
        {
            RequireInit();
            _startEntry(incrementEntry);
            Raise(OnEntryStarted, OnEntryStartedEvent);
        }

        public void ConfirmWin()
        {
            RequireInit();
            if (CommonData.State != FeatureState.Win) return;
            CommonData.WinCount++;
            CommonData.ResetTimeStamp = _clock.NowTS + _config.ResetTimeInMinutes * 60L;
            restartDateTime = CommonData.ResetTimeStamp.ToString();
            _changeState(FeatureState.CooldownToRestart);
            Raise(OnWinConfirmed, OnWinConfirmedEvent);
        }

        public void ConfirmLose()
        {
            RequireInit();
            CommonData.LoseCount++;
            CommonData.ResetTimeStamp = _clock.NowTS + _config.ResetTimeInMinutes * 60L;
            restartDateTime = CommonData.ResetTimeStamp.ToString();
            _changeState(FeatureState.CooldownToRestart);
            Raise(OnLoseConfirmed, OnLoseConfirmedEvent);
        }

        public void ForceStop()
        {
            RequireInit();
            _changeState(FeatureState.Lose);
            Raise(OnForceStop, OnForceStopEvent);
        }

        public void MarkUserSeenChanges() => OnUserSeenChangesEvent?.Invoke();

        #endregion

        #region INITIALIZATION

        /// <summary>Must be called once per session, before any commands.</summary>
        public virtual void Initialize(FeatureCommonData commonData)
        {
            _clock         ??= new ClockServiceAdapter();
            _levelSource   ??= new LevelSourceAdapter(this);
            _timeEndPolicy ??= TimeEndPolicyFactory.Create(_config.TimeEndType);

            CommonData = commonData;
            _refreshInspectorTimes();

            // Mark ready BEFORE running transitions: the switch below can synchronously
            // cascade (e.g. expired-offline -> _onFeatureTimeUp -> _onCooldownFinished ->
            // OnCooldownComplete listener -> StartEntry), and those commands call
            // RequireInit(). Setting this last would make that cascade throw.
            _initialized = true;

            switch (commonData.State)
            {
                case FeatureState.NotUnlocked:
                    _registerLevelUpListener();
                    _onLevelUp(GameService.DataManager.Level);
                    break;
                case FeatureState.Progressing:
                    if (_clock.NowTS >= commonData.EndTimeStamp) _onFeatureTimeUp();
                    else _activateTimer();
                    break;

                case FeatureState.CooldownToRestart:
                    if (_clock.NowTS >= commonData.ResetTimeStamp) _onCooldownFinished();
                    else _activateTimer();
                    break;
                case FeatureState.Preparation:
                case FeatureState.Win:
                case FeatureState.Lose:
                    break;
            }

            Raise(OnInitialized, OnInitializedEvent);
        }

        #endregion

        #region UNITY LIFECYCLE

        protected virtual void OnDestroy()
        {
            _deactivateTimer();
            _unregisterLevelUpListener();
        }

        #endregion

        #region RUNTIME CONFIG TWEAKS (mutate the per-instance copy only)

        public void SetUnlockLevel(int level)      => _config.UnlockLevel        = level;
        public void SetResetTime(int minutes)      => _config.ResetTimeInMinutes = minutes;
        public void SetActiveDuration(int minutes) => _config.DurationInMinutes  = minutes;

        public void SetRemainingDuration(int seconds)
        {
            RequireInit();
            CommonData.EndTimeStamp = _clock.NowTS + seconds;
            endDateTime = CommonData.EndTimeStamp.ToString();
        }

        #endregion

        #region FORCE TIME CONTROLS (cheat / QA — drive the whole timeline by hand)

        /// <summary>
        /// Force the active session to expire <paramref name="seconds"/> from now.
        /// If the feature is not yet Progressing it is started first, so this works
        /// from any state. The timer is (re)armed and evaluated immediately, so
        /// <see cref="OnTimeUp"/> fires right away when <paramref name="seconds"/> &lt;= 0.
        /// </summary>
        public void ForceEndIn(int seconds)
        {
            RequireInit();
            if (CommonData.State != FeatureState.Progressing)
                _startEntry(incrementEntry: false);

            CommonData.EndTimeStamp = _clock.NowTS + Math.Max(0, seconds);
            _refreshInspectorTimes();
            _activateTimer();
            _onSecondProgressing();   // re-evaluate now; triggers _onFeatureTimeUp if already expired
        }

        /// <summary>Immediately end the active session and move into cooldown, from any state.</summary>
        public void ForceTimeUpNow() => ForceEndIn(0);

        /// <summary>
        /// Force the cooldown to finish <paramref name="seconds"/> from now (default: now).
        /// Only meaningful while in <see cref="FeatureState.CooldownToRestart"/>.
        /// </summary>
        public void ForceCooldownEndIn(int seconds = 0)
        {
            RequireInit();
            if (CommonData.State != FeatureState.CooldownToRestart) return;
            CommonData.ResetTimeStamp = _clock.NowTS + Math.Max(0, seconds);
            _refreshInspectorTimes();
            _activateTimer();
            _onSecondCooldown();      // re-evaluate now; triggers _onCooldownFinished if already elapsed
        }

        /// <summary>
        /// Restart the whole feature cycle right now: jump straight into a fresh
        /// Progressing entry from any state (unlocking if still locked) and bump the
        /// entry counter. Raises <see cref="OnEntryStarted"/>.
        /// </summary>
        public void ForceRestart()
        {
            RequireInit();
            _unregisterLevelUpListener();

            // Run the same finalize path as a real end-of-event so features can
            // bank/cleanup their data while progress is still intact, before the
            // new entry resets it.
            if (CommonData.State == FeatureState.Progressing)
                Raise(OnTimeUp, OnTimeUpEvent);

            // Bypass the "same state" short-circuit in _changeState so the entry truly restarts.
            CommonData.State = FeatureState.Preparation;
            _startEntry(incrementEntry: true);
            Raise(OnEntryStarted, OnEntryStartedEvent);
        }

        #endregion

        #region STATE MACHINE

        private void _startEntry(bool incrementEntry = true)
        {
            if (incrementEntry) CommonData.Entry++;
            CommonData.StartTimeStamp = _clock.NowTS;
            CommonData.EndTimeStamp   = _timeEndPolicy.ComputeEndTimestamp(
                                            CommonData.StartTimeStamp,
                                            _config.DurationInMinutes);
            CommonData.ResetTimeStamp = CommonData.EndTimeStamp + _config.ResetTimeInMinutes * 60L;

            _refreshInspectorTimes();
            _changeState(FeatureState.Progressing);
        }

        private void _changeState(FeatureState newState)
        {
            if (CommonData.State == newState) return;
            CommonData.State = newState;

            switch (newState)
            {
                case FeatureState.Progressing:
                    _onSecondProgressing();
                    _activateTimer();
                    break;

                case FeatureState.CooldownToRestart:
                    _onSecondCooldown();
                    _activateTimer();
                    break;

                default:
                    _deactivateTimer();
                    timeRemaining = 0;
                    timeResetCooldown = 0;
                    break;
            }
        }

        private void _onSecond()
        {
            switch (CommonData.State)
            {
                case FeatureState.Progressing:       _onSecondProgressing(); break;
                case FeatureState.CooldownToRestart: _onSecondCooldown();    break;
            }
        }

        private void _onSecondProgressing()
        {
            timeRemaining = (int)(CommonData.EndTimeStamp - _clock.NowTS);
            if (timeRemaining <= 0) _onFeatureTimeUp();
        }

        private void _onSecondCooldown()
        {
            timeResetCooldown = (int)(CommonData.ResetTimeStamp - _clock.NowTS);
            if (timeResetCooldown <= 0) _onCooldownFinished();
        }

        private void _onFeatureTimeUp()
        {
            timeRemaining = 0;
            var baseTS = Math.Max(_clock.NowTS, CommonData.EndTimeStamp);
            CommonData.ResetTimeStamp = baseTS + _config.ResetTimeInMinutes * 60L;
            restartDateTime = CommonData.ResetTimeStamp.ToString();
            // Finalize the ended entry BEFORE changing state. With a zero cooldown,
            // _changeState(CooldownToRestart) cascades synchronously into
            // OnCooldownComplete -> new entry -> RefreshData (which wipes progress),
            // so raising OnTimeUp afterwards would let listeners see already-reset data.
            Raise(OnTimeUp, OnTimeUpEvent);
            _changeState(FeatureState.CooldownToRestart);
        }

        private void _onCooldownFinished()
        {
            timeResetCooldown = 0;
            _changeState(FeatureState.Preparation);
            Raise(OnCooldownComplete, OnCooldownCompleteEvent);
        }

        #endregion

        #region LEVEL UP HANDLING

        private void _registerLevelUpListener()
        {
            if (_levelUpRegistered) return;
            _levelUpHandler = _onLevelUp;
            _levelSource.AddLevelUpListener(_levelUpHandler);
            _levelUpRegistered = true;
        }

        private void _unregisterLevelUpListener()
        {
            if (!_levelUpRegistered) return;
            _levelSource.RemoveLevelUpListener(_levelUpHandler);
            _levelUpHandler = null;
            _levelUpRegistered = false;
        }

        private void _onLevelUp(int newLevel)
        {
            if (CommonData.State != FeatureState.NotUnlocked) return;
            if (newLevel < _config.UnlockLevel) return;
            _changeState(FeatureState.Preparation);
            _unregisterLevelUpListener();
            Raise(OnUnlocked, OnUnlockedEvent);
        }

        #endregion

        #region TIMER PLUMBING

        private void _activateTimer()
        {
            if (_tickSubscribed) return;
            _clock.OnSecond += _onSecond;
            _tickSubscribed = true;
        }

        private void _deactivateTimer()
        {
            if (!_tickSubscribed) return;
            _clock.OnSecond -= _onSecond;
            _tickSubscribed = false;
        }

        #endregion

        #region HELPERS

        private void _refreshInspectorTimes()
        {
            startDateTime   = CommonData.StartTimeStamp.ToTimeString();
            endDateTime     = CommonData.EndTimeStamp.ToTimeString();
            restartDateTime = CommonData.ResetTimeStamp.ToTimeString();
        }

        private void RequireInit()
        {
            if (!_initialized)
                throw new InvalidOperationException($"{name}: Initialize() must be called first.");
        }

        private static void Raise(Action evt, UnityEvent unityEvt)
        {
            evt?.Invoke();
            unityEvt?.Invoke();
        }

        #endregion
    }
}
