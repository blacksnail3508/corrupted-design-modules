using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CorruptedDesign.Feature
{
    public class FeatureManager : MonoBehaviour
    {
        [SerializeField] private List<FeatureBase> activateFeatures = new List<FeatureBase>();

        #region PIPELINE: Load → Check → Start

        public IEnumerator LoadFeaturesData()
        {
            if (activateFeatures == null || activateFeatures.Count == 0)
            {
                Bug.Log("No feature activated.");
                yield break;
            }

            foreach (var feature in activateFeatures)
            {
                if (feature == null) continue;
                if (feature is IFeaturePreloadable preloadable)
                {
                    Bug.Log($"{feature.GetType().Name} loaded");
                    yield return preloadable.PreloadData();
                }
            }
        }

        public IEnumerator CheckDayAll(bool isNewDay)
        {
            Bug.Log($"IsNewDay {isNewDay.ToString().SetColor("red")}");

            if (activateFeatures == null || activateFeatures.Count == 0) yield break;

            foreach (var feature in activateFeatures)
            {
                if (feature == null) continue;

                if (feature is IDayRolloverAware dayAware)
                {
                    Bug.Log($"{feature.GetType().Name} checked");
                    yield return dayAware.OnDayRollover(isNewDay);
                }
            }
        }

        public IEnumerator StartAllFeature()
        {
            if (activateFeatures == null) yield break;

            foreach (var feature in activateFeatures)
            {
                if (feature == null) continue;
                if (feature is IFeatureStartable startable)
                {
                    Bug.Report("FEATURE REPORT: ", $"{feature.GetType().Name} started");
                    yield return startable.StartFeature();
                }
            }
        }

        public void SaveAll()
        {
            if (activateFeatures == null) return;
            foreach (var feature in activateFeatures)
            {
                if (feature is IFeaturePersistable persistable)
                    persistable.SaveData();
            }
        }

        private void OnApplicationPause(bool paused) { if (paused) SaveAll(); }
        private void OnApplicationQuit()             => SaveAll();

        #endregion
    }
}
