using System.Collections;
using UnityEngine;

namespace CorruptedDesign.Feature
{
    /// <summary>
    /// Base class for game features. Owns business LOGIC only:
    ///   - what counts as a win/lose
    ///   - what rewards to grant
    ///   - what UI to show
    ///
    /// All TIMING (when the session ends, cooldowns, state transitions) is delegated
    /// to the required <see cref="FeatureScheduler"/> component.
    ///
    /// Subclasses interact with the scheduler through <see cref="IFeatureScheduler"/>
    /// (commands + events) — never poke its internals.
    /// </summary>
    [RequireComponent(typeof(FeatureScheduler))]
    public abstract class FeatureBase : MonoBehaviour,
        IFeaturePreloadable,
        IFeatureStartable,
        IFeaturePersistable
        // NOTE: IDayRolloverAware is opt-in — only implement if the feature cares.
    {
        [SerializeField] protected FeatureScheduler featureScheduler;

        /// <summary>The scheduler abstraction this feature talks to.</summary>
        protected IFeatureScheduler Scheduler => featureScheduler;

        #region Unity lifecycle

        protected virtual void OnEnable()  => SubscribeToScheduler();
        protected virtual void OnDisable() => UnsubscribeFromScheduler();

        #endregion

        #region Pipeline hooks (called by FeatureManager)

        /// <summary>1st: load this feature's persisted state, then initialize the scheduler.</summary>
        public abstract IEnumerator PreloadData();

        /// <summary>3rd: start the feature (show UI, register input, etc.).</summary>
        public abstract IEnumerator StartFeature();

        /// <summary>Persist feature state. Default: no-op. Override if you have data to save.</summary>
        public virtual void SaveData() { }

        #endregion

        #region Scheduler event wiring

        /// <summary>
        /// Subscribes to scheduler events. Subclasses override the protected handlers
        /// (OnEntryStarted, OnTimeUp, etc.) — they don't manage subscriptions themselves.
        /// </summary>
        private void SubscribeToScheduler()
        {
            if (featureScheduler == null) return;

            Scheduler.OnInitialized      += HandleInitialized;
            Scheduler.OnEntryStarted     += HandleEntryStarted;
            Scheduler.OnUnlocked         += HandleUnlocked;
            Scheduler.OnTimeUp           += HandleTimeUp;
            Scheduler.OnCooldownComplete += HandleCooldownComplete;
            Scheduler.OnForceStop        += HandleForceStop;
            Scheduler.OnWinConfirmed     += HandleWinConfirmed;
            Scheduler.OnLoseConfirmed    += HandleLoseConfirmed;
        }

        private void UnsubscribeFromScheduler()
        {
            if (featureScheduler == null) return;

            Scheduler.OnInitialized      -= HandleInitialized;
            Scheduler.OnEntryStarted     -= HandleEntryStarted;
            Scheduler.OnUnlocked         -= HandleUnlocked;
            Scheduler.OnTimeUp           -= HandleTimeUp;
            Scheduler.OnCooldownComplete -= HandleCooldownComplete;
            Scheduler.OnForceStop        -= HandleForceStop;
            Scheduler.OnWinConfirmed     -= HandleWinConfirmed;
            Scheduler.OnLoseConfirmed    -= HandleLoseConfirmed;
        }

        // Default handlers are no-ops; subclasses override only what they care about.
        protected virtual void HandleInitialized()      { }
        protected virtual void HandleEntryStarted()     { }
        protected virtual void HandleUnlocked()         { }
        protected virtual void HandleTimeUp()           { }
        protected virtual void HandleCooldownComplete() { }
        protected virtual void HandleForceStop()        { }
        protected virtual void HandleWinConfirmed()     { }
        protected virtual void HandleLoseConfirmed()    { }

        #endregion
    }
}
