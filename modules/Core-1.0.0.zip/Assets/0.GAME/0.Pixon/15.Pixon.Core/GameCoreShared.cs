using Pixon.Observer;
using PixonTemplate;

/// <summary>Raised when the player turns tester mode on, so tester-only objects can show themselves.</summary>
public class TesterLogin : GameEvent
{
}

/// <summary>The level the player last started, kept so a restart or a revive knows where it came from.</summary>
public class PlaySnapShot
{
    public int Level = 0;
    public int RawLevel = 0;
    public Difficulty Difficulty = Difficulty.Normal;
    public int Attempt = 0;
    public int Loses = 0;

    public void SetNewLevel(int level, int rawLevel, Difficulty difficulty)
    {
        Level = level;
        RawLevel = rawLevel;
        Difficulty = difficulty;
        Attempt = 0;
        Loses = 0;
    }
}
