using Pixon.Audio;
using Pixon.Remote;
using Pixon.Stamina;
using Pixon.UI;
using UnityEngine;

/// <summary>Static access point for the global services of the game. Gameplay modules register themselves here.</summary>
public static class GameService
{
    public static int LobbyStartLevel => ConfigCollection.LobbyStartLevel.Value;

    #region GLOBAL SERVICES
    public static UIManager UIManager { get; set; }
    public static PlayerDataManager DataManager { get; set; }
    public static AudioManager AudioManager { get; set; }
    #endregion

    #region STATE
    public static GameMode GameMode { get; set; } = GameMode.Playing;
    public static bool IsLobby { get; set; }
    public static RectTransform GameplayViewRect { get; set; }

    /// <summary>The running gameplay controller. The game sets this when a level starts.</summary>
    public static IGameController GameController { get; set; }
    #endregion

    #region UI / AUDIO
    public static Window ShowPopup<T>(UITrigger trigger) where T : Window => UIManager.ShowPopup<T>(trigger);

    public static void ClosePopup() => UIManager.ClosePopup();

    public static void ShowToast(string message) => UIManager?.ShowToast(message);

    public static void PlaySound(SoundID soundID) => AudioManager?.PlaySound(soundID);

    public static void PlayLoopSound(SoundID soundID) => AudioManager?.PlayLoopSound(soundID);

    public static void StopLoopSound() => AudioManager?.StopLoopSound();

    public static void PlayHaptic(HapticTypes type) => AudioManager?.PlayHaptic(type);
    #endregion

    #region FLOW
    public static void ForcePlayLevel(int level)
    {
        DataManager.SetLevel(level);
        UIManager.ClosePopups();
        ForceReload();
    }

    public static void ForceReload() => CustomSceneManager.Instance.ReloadGameplay();

    public static void NextLevel()
    {
        DataManager.LevelUp();
        if (DataManager.Level > LobbyStartLevel) GoLobby();
        else ForceReload();
    }

    public static void GoLobby()
    {
        UIManager.ClosePopups();
        CustomSceneManager.Instance.EnterLobby();
    }

    public static bool TryStartLevel()
    {
        if (StaminaManager.Instance != null && !StaminaManager.HaveStamina())
        {
            GameScreens.OpenBuyHeart?.Invoke();
            return false;
        }

        ForceReload();
        return true;
    }

    /// <summary>Sends a player who ran short of coins to the shop: the in-game popup while playing, the shop tab in the lobby.</summary>
    public static void TryEnterShop()
    {
        if (UIManager == null) return;

        if (!IsLobby)
        {
            GameScreens.OpenShopInGame?.Invoke();
            return;
        }

        UIManager.ClosePopups();
        GameScreens.OpenShopInLobby?.Invoke();
    }
    #endregion
}

public interface IGameController
{
    void Pause();
    void Resume();
    void Revive(ReviveMethod method);
}

public enum GameMode
{
    Editing,
    Testing,
    Playing,
    Ended
}
