using Pixon.Remote;

public static class RevivePolicy
{
    public static ReviveConfigData Config
        => ConfigCollection.ReviveConfig.Value ?? ConfigCollection.ReviveConfig.DefaultValue;

    public static int CoinPrice
        => Config.GetPrice(GameService.DataManager != null ? GameService.DataManager.ReviveCountThisLevel : 0);

    public static bool CanAffordCoin()
    {
        var data = GameService.DataManager;
        if (data == null) return false;

        return data.Coin >= CoinPrice;
    }

    public static bool HasAnyReviveOption() => CanAffordCoin() || CanWatchRewarded();

    public static bool CanWatchRewarded()
    {
        var data = GameService.DataManager;
        if (data == null) return false;

        var config = Config;
        if (data.Level < config.RwStartLv) return false;
        if (data.Coin > config.CoinThresholdUnlockRw) return false;
        if (data.ReviveRwCountThisLevel >= config.RwLimitPerLevel) return false;
        if (data.ReviveRwCountToday >= config.RwLimitPerDay) return false;

        return true;
    }

    public static void RegisterRevive(ReviveMethod method)
    {
        GameService.DataManager?.RegisterRevive(method);
    }
}
