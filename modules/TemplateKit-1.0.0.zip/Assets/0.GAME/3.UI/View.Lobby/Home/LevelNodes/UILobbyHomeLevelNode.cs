using PixonTemplate;
using Sirenix.OdinInspector;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UILobbyHomeLevelNode : MonoBehaviour
{
    [SerializeField, FoldoutGroup("SPRITES")] private Sprite green, gray, red, purple;

    [SerializeField, FoldoutGroup("TEXTS")]
    private TMP_Text levelText;
    [SerializeField] private Image icon;
    [SerializeField] private int id;
    private int level;
    public void Init()
    {
        level = GameService.DataManager.Level + id;
        levelText.text = $"{level}";
        Refresh(); //update visual
    }
    
    private void Refresh()
    {
        if (id > 0)
        {
            SetGray();
            return;
        }

        //id == 0
        var difficulty = GameService.DataManager.CurrentLevelData.Difficulty;
        switch (difficulty)
        {
            case Difficulty.Normal: SetGreen(); break;
            case Difficulty.Hard: SetRed(); break;
            case Difficulty.Expert: SetPurple(); break;
        }
    }

    [Button]
    private void SetGray()
    {
        icon.sprite = gray;
    }

    [Button]
    void SetGreen()
    {
        icon.sprite = green;
    }

    [Button]
    void SetPurple()
    {
        icon.sprite = purple;
    }

    [Button]
    void SetRed()
    {
        icon.sprite = red;
    }
}
