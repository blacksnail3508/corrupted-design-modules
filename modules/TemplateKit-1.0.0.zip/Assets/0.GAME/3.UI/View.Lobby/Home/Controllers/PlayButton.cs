using Pixon.UI;

public class PlayButton : ButtonBase
{
    protected override void OnClick()
    {
        base.OnClick();
        GameService.TryStartLevel();
    }

    public void Refresh()
    {
        SetText($"Level {GameService.DataManager.Level}");
    }

    private void Start()
    {
        Refresh();
    }

    private void OnEnable()
    {
        Refresh();
    }
}
