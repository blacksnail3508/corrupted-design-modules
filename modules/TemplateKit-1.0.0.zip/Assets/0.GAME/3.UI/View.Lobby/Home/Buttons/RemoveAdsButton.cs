using Pixon.IAP;
using Pixon.Observer;
using Pixon.UI;
using UnityEngine;

/// <summary>Home button that opens the No Ads Bundle popup and disappears once ads are removed.</summary>
public class RemoveAdsButton : MonoBehaviour
{
    private ButtonBase button;

    private void Awake()
    {
        button = GetComponent<ButtonBase>();
        button.AddListener(OnClick);
    }

    private void OnEnable()
    {
        EventService.AddListener<NoAdsEvent>(OnNoAds);
        RefreshVisibility();
    }

    private void OnDisable() => EventService.RemoveListener<NoAdsEvent>(OnNoAds);

    private void OnNoAds(NoAdsEvent e) => RefreshVisibility();

    private void RefreshVisibility() => gameObject.SetActive(!ShopService.IsNoAds());

    private void OnClick() => this.ShowPopup<UIPopupRemoveAdsVip>(UITrigger.Click);
}
