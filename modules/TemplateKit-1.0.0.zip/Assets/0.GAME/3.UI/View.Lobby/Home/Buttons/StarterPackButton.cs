using Pixon.IAP;
using Pixon.Observer;
using Pixon.UI;
using UnityEngine;

/// <summary>Home button that opens the Starter Pack popup and disappears once the pack has been bought.</summary>
public class StarterPackButton : MonoBehaviour
{
    private ButtonBase button;

    private void Awake()
    {
        button = GetComponent<ButtonBase>();
        button.AddListener(OnClick);
    }

    private void OnEnable()
    {
        EventService.AddListener<PurchaseCompletedEvent>(OnPurchased);
        RefreshVisibility();
    }

    private void OnDisable() => EventService.RemoveListener<PurchaseCompletedEvent>(OnPurchased);

    private void OnPurchased(PurchaseCompletedEvent e) => RefreshVisibility();

    private void RefreshVisibility() => gameObject.SetActive(!ShopService.IsSoldOut(ProductName.StarterPack));

    private void OnClick() => this.ShowPopup<UIPopupStarterPack>(UITrigger.Click);
}
