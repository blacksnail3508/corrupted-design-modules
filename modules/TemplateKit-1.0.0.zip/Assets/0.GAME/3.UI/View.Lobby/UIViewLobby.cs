using System;
using Pixon.Observer;
using Pixon.UI;
using UnityEngine;

public class UIViewLobby : Window
{
    public override string PopupType => "view_core";
    [SerializeField] TabButtonManager tabButtonManager; 
    [SerializeField] UIRevealPipelineLobby screenRevealPipeline;
    [SerializeField] private UILobbyHome homeTab;
    
    public UILobbyHome HomeTab => homeTab;

    private void Start()
    {
        EventService.AddListener<LoadingCompleteEvent>(OnLoadingCompleted);
    }

    private void OnDestroy()
    {
        EventService.RemoveListener<LoadingCompleteEvent>(OnLoadingCompleted);
    }

    private void OnLoadingCompleted(LoadingCompleteEvent e)
    {
        Bug.Log("LoadingCompleteEvent Lobby");
        if(this.IsShowing == false) return;
        homeTab.OnLoadingComplete();
        Delay.Call(0.35f, () =>
        {
            screenRevealPipeline.Refresh();
        });
    }

    public override void Show()
    {
        base.Show();
        // A paused gameplay popup may have left timeScale at 0, which freezes the tab swipe.
        Time.timeScale = 1f;
        tabButtonManager.SetScrollValue(0.5f);
    }

    public override void OnReveal()
    {
        base.OnReveal();
        screenRevealPipeline.NextStep();
    }

    public void SnapToShopTab()
    {
        tabButtonManager.SetScrollValue(0.0f);
    }
}
