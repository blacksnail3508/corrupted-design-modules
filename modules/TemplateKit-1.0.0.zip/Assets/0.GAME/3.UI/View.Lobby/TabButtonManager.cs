using System.Collections;
using DG.Tweening;
using Pixon.Audio;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UI.Extensions;

public class TabButtonManager : MonoBehaviour
{
    [SerializeField] private HorizontalScrollSnap snap;
    [SerializeField] GameObject selector;
    [SerializeField] float AnimateDuration = 0.15f;
    [SerializeField] TabToggle[] toggles;
    [SerializeField] Scrollbar scrollbar;

    private int lastTab = 1;


    public void MoveSelector(int tabIndex)
    {
        foreach (var toggle in toggles) toggle.SetOff();
        var target = toggles[tabIndex];
        target.SetOn();
        selector.transform.DOKill();
        selector.transform.DOMoveX(target.transform.position.x, AnimateDuration);

        if (tabIndex == 0)
        {
            // tracker.TrackIAPShow("null", "home_shop", "shop", "click");
        }
        else
        {
            if (lastTab == 0)
            {
                // tracker.TrackIAPClose("null", "home_shop", "shop", "click");
            }
        }
        
        lastTab = tabIndex;
    }

    float lastslideValue = 0;

    public void OnSlideValueChanged(float slideValue)
    {
        // Bug.Log($"Target slide value: {slideValue}");
        //so fk dirty
        //improve later
        if (lastslideValue >= 0.25 && slideValue < 0.25) MoveSelector(0);
        if (lastslideValue <= 0.25 && slideValue > 0.25) MoveSelector(1);
        if (lastslideValue >= 0.75 && slideValue < 0.75) MoveSelector(1);
        if (lastslideValue <= 0.75 && slideValue > 0.75) MoveSelector(2);
        lastslideValue = slideValue;
    }

    Coroutine scrollCoroutine;
    public void SetScrollValue(float value)
    {
        GameService.AudioManager.PlaySound(SoundID.ButtonOnClick);
        this.CancelCoroutine(scrollCoroutine);
        scrollCoroutine = StartCoroutine(SmoothScroll(value, 0.15f));
    }

    public void SelectShop()
    {
        SetScrollValue(0);
    }

    public void SelectHome()
    {
        SetScrollValue(0.5f);
    }

    public void SelectSetting()
    {
        SetScrollValue(1);
    }
    private IEnumerator SmoothScroll(float target, float duration)
    {
        scrollbar?.DOKill();
        snap.enabled = false;
        
        float start = scrollbar.value;
        float time = 0f;

        while (time < duration)
        {
            // Unscaled: a tutorial/setting popup can leave timeScale at 0 and freeze the tab switch.
            time += Time.unscaledDeltaTime;
            scrollbar.value = Mathf.Lerp(start, target, time / duration);
            yield return null;
        }

        scrollbar.value = target; // ensure exact finish
        snap.ChangePage(ProgressToPage(target));
        snap.enabled = true;
    }

    private int ProgressToPage(float progress)
    {
        if (progress == 0) return 0;
        if (progress == 0.5f) return 1;
        if (progress == 1) return 2;
        return 0;
    }
}
