using System.Collections;
using DG.Tweening;
using Pixon.Observer;
using Pixon.UI;
using Sirenix.OdinInspector;
using TMPro;
using UnityEngine;

public class CoinBox : MonoBehaviour
{
    int currentCoin => GameService.DataManager.Coin;
    [SerializeField] private TMP_Text coinText;
    [SerializeField] private ButtonBase addButton;
    [SerializeField] private TMP_Text addVfx;
    float vfxDuration = 1f;

    private int currentValue = 0;

    private void Awake()
    {
        ChangeText(currentCoin, 0);
        addButton.AddListener(OnAddClick);
        EventService.AddListener<CoinChange>(OnCoinChange);
    }

    private void OnDestroy()
    {
        EventService.RemoveListener<CoinChange>(OnCoinChange);
    }

    private void OnCoinChange(CoinChange e)
    {
        float changeVfxDuration = 0.5f;
        int value = e.ChangeValue;

        if (value > 0)
        {
            addVfx.text = "+" + value;
            addVfx.color = Color.green;
        }
        else if (value < 0)
        {
            addVfx.text = $"{value}";
            addVfx.color = Color.red;
            changeVfxDuration = 0.15f;
        }

        ChangeText(currentCoin, changeVfxDuration);

        addVfx.gameObject.SetActive(true);
        addVfx.DOKill();
        addVfx.rectTransform.localPosition = Vector3.zero;
        addVfx.rectTransform.DOLocalMoveY(25, vfxDuration).SetEase(Ease.Linear)
            .OnComplete(() => { addVfx.gameObject.SetActive(false); });
    }

    public void OnAddClick()
    {
        GameService.TryEnterShop();
    }

    private void ChangeText(int targetValue, float duration)
    {
        if (duration <= 0)
        {
            this.CancelCoroutine(txtCoroutine);
            currentValue = targetValue;
            coinText.text = currentValue.ToString();
            return;
        }

        if (gameObject.activeInHierarchy)
        {
            this.CancelCoroutine(txtCoroutine);
            txtCoroutine = StartCoroutine(IEChangeText(targetValue, duration));
        }
        else
        {
            currentValue = targetValue;
            coinText.text = currentValue.ToString();
        }
    }

    private Coroutine txtCoroutine;

    private IEnumerator IEChangeText(int targetValue, float duration)
    {
        yield return null;
        float t = 0;
        var tempvalue = currentValue;
        while (t < duration)
        {
            tempvalue = (int)Mathf.Lerp(currentValue, targetValue, t);
            coinText.text = tempvalue.ToString();
            t += Time.deltaTime;
            yield return null;
        }

        currentValue = targetValue;
        coinText.text = currentValue.ToString();
    }

    private void OnDisable()
    {
        this.CancelCoroutine(txtCoroutine);
    }

    [Button]
    public void ForceRefresh()
    {
        ChangeText(GameService.DataManager.Coin, 0);
    }

    public void ForceSetValue(int coinValue)
    {
        ChangeText(coinValue, 0);
    }
}