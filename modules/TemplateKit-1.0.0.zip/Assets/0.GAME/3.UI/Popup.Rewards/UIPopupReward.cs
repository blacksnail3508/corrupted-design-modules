using System;
using System.Collections.Generic;
using Pixon.Data;
using Pixon.UI;
using UnityEngine;

public class UIPopupReward : Window
{
    public override string PopupType => "popup_announcement";
    [SerializeField] private DynamicRewardLayout rewardLayout;

    public UIPopupReward SetReward(List<RewardSlot> rewards)
    {
        Bug.Log("a");
        rewardLayout.SetValue(rewards);
        return this;
    }

    public UIPopupReward SetReward(BoosterType boosterType, int boosterGiven)
    {
        List<RewardSlot> listReward = new List<RewardSlot>()
        {
            new RewardSlot(ConvertBooster(boosterType), boosterGiven),
        };
        return SetReward(listReward);
    }

    private ItemType ConvertBooster(BoosterType boosterType)
    {
        switch (boosterType)
        {
            case BoosterType.Booster1: return ItemType.Booster_1;
            case BoosterType.Booster2: return ItemType.Booster_2;
            case BoosterType.Booster3: return ItemType.Booster_3;
        }
        return ItemType.Booster_1;
    }
}
