using Pixon.Observer;
using Pixon.UI;
using PixonTemplate;
using UnityEngine;

public class UIViewGamePlay : Window
{
    public override string PopupType => "view_core";

    public const int HideElementMaxLevel = 4;

    [SerializeField] UIVerticalMovement top, bottom;
    [SerializeField] UIGameplayLevelBox levelBox;
    [SerializeField] CoinBox coinBox;
    [Tooltip("Rect the conveyor is framed inside when a level opens.")]
    [SerializeField] RectTransform viewRect;

    private float EngageElementShowDuration = 0.35f;

    readonly UIRevealPipelineGameplay screenRevealPipeline = new UIRevealPipelineGameplay();
    // False from loading until intro, difficulty mask and content popups are done and the level is playable.
    bool isEngaged;
    // The reveal pipeline can finish under the loading screen when the intro is skipped.
    bool engageOnLoadingComplete;

    public override void Initialize()
    {
        base.Initialize();

        GameService.GameplayViewRect = viewRect;
        screenRevealPipeline.OnComplete = OnRevealComplete;

        EventService.AddListener<LoadingCompleteEvent>(OnLoadingComplete);
        EventService.AddListener<LevelIntroCompleteEvent>(OnLevelIntroComplete);
    }

    private void OnDestroy()
    {
        if (ReferenceEquals(GameService.GameplayViewRect, viewRect)) GameService.GameplayViewRect = null;
        EventService.RemoveListener<LoadingCompleteEvent>(OnLoadingComplete);
        EventService.RemoveListener<LevelIntroCompleteEvent>(OnLevelIntroComplete);
    }

    public override void OnReveal()
    {
        base.OnReveal();
        screenRevealPipeline.NextStep();
    }

    public static bool CanShowElement => GameService.DataManager.Level > HideElementMaxLevel;

    public UIViewGamePlay SetElementVisible(bool isShow, float duration = 0)
    {
        // The level rule wins over engagement: a hidden-by-level HUD stays hidden even once the player is in.
        if (isShow && (!CanShowElement || !isEngaged))
        {
            isShow = false;
            duration = 0;
        }

        if (isShow)
        {
            top.Show(duration);
            bottom.Show(duration);
        }
        else
        {
            top.Hide(duration);
            bottom.Hide(duration);
        }
        return this;
    }

    private void OnLoadingComplete(LoadingCompleteEvent e = null)
    {
        if (!gameObject.activeInHierarchy) return;

        coinBox?.ForceRefresh();

        levelBox.Refresh();

        isEngaged = engageOnLoadingComplete;
        engageOnLoadingComplete = false;
        SetElementVisible(isEngaged, isEngaged ? EngageElementShowDuration : 0);
    }

    /// <summary>Marks the level as playable and slides the HUD in, unless the level still hides it.</summary>
    public void Engage()
    {
        if (isEngaged) return;

        isEngaged = true;
        SetElementVisible(true, EngageElementShowDuration);
    }

    private void OnRevealComplete()
    {
        if (LoadingCanvas.IsShowing)
        {
            engageOnLoadingComplete = true;
            return;
        }

        Engage();
    }

    // The popups wait for the level intro: the starting dash runs and the jars scale up on a clear screen.
    private void OnLevelIntroComplete(LevelIntroCompleteEvent e)
    {
        if (!gameObject.activeInHierarchy) return;

        float totalDelay = ShowDifficultMask();

        Delay.Cancel(this);
        Delay.Call(this, totalDelay, () => screenRevealPipeline.Refresh());
    }

    private float ShowDifficultMask()
    {
        var dif = GameService.DataManager.CurrentLevelData.Difficulty;
        if (!UIPopupDifficultMask.ShouldShow(dif)) return 0;

        var popup = GameService.UIManager.ShowPopup<UIPopupDifficultMask>(UITrigger.Click);
        if (popup == null)
        {
            EventService.Raise(new DifficultMaskClosedEvent());
            return 0;
        }

        return popup.SetDif(dif).ShowDuration;
    }
}
