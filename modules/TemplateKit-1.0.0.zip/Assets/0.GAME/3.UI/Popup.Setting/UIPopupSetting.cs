using System;
using Pixon.Remote;
using Pixon.Stamina;
using Pixon.UI;
using TMPro;
using UnityEngine;

public class UIPopupSetting : Window {
    
    public override string PopupType => "popup_game_setting";

    [SerializeField] private RectTransform panel;
    [SerializeField] private UserDeviceSetting setting;
    [SerializeField] private TMP_Text versionCode;
    [SerializeField] ButtonBase homeBtn, replayBtn;
    
    private void Start()
    { 
        versionCode.text = $"Version: {Application.version}";
        replayBtn.AddListener(OnReplayButton);
        homeBtn?.AddListener(OnHomeButton);
    }

    public override void Show() 
    {
        base.Show();
        setting.Refresh();
        Time.timeScale = 0;
    }
    
    private void OnReplayButton()
    {
        LeaveLevel(() =>
        {
            AnalyticAdapter.LogLevelAbandoned();
            GameService.ClosePopup();
            AdsProvider.ShowInterstitialFromLevel(AdsPlacement.Setting,
                ConfigCollection.InterConfig.Value.SettingStartLv, _ => GameService.ForceReload());
        });
    }

    private void OnHomeButton()
    {
        AnalyticAdapter.LogLevelAbandoned();

        // Going home never asks for a heart: spend one if there is one to spend, then leave regardless.
        if (StaminaManager.Instance != null && StaminaManager.HaveStamina())
            StaminaManager.SpendStamina(1);

        GameService.GoLobby();
    }

    private void LeaveLevel(Action onLeft)
    {
        if (StaminaManager.Instance == null)
        {
            onLeft();
            return;
        }

        if (!StaminaManager.HaveStamina())
        {
            GameService.UIManager.ShowPopup<UIPopupBuyHeart>(UITrigger.Click);
            return;
        }

        StaminaManager.SpendStamina(1, onLeft);
    }

    public override void Hide(Action onComplete = null)
    {
        base.Hide(onComplete);
        Time.timeScale = 1;
    }
}