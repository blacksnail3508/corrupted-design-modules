using System;
using PixonTemplate;
using UnityEngine;
using UnityEngine.Rendering;

[CreateAssetMenu(fileName = "SpriteCollection", menuName = "Game/SpriteCollection")]
public class SpriteCollection : ScriptableObject
{
    [SerializeField] LevelBoxSprites levelBoxSprites;
    [SerializeField] private DifficultMaskConfig HardMask;
    [SerializeField] private DifficultMaskConfig ExpertMask;
    [SerializeField] private BoosterConfig[] boosterConfigs;
    [SerializeField] private SerializedDictionary<LevelContent, ContentConfig> contentConfig = new();

    public BoosterConfig GetBoosterConfig(BoosterType type)
    {
        foreach (var config in boosterConfigs)
            if (config.Type == type) return config;
        return null;
    }

    public Sprite GetLevelBoxSprite(Difficulty difficulty)
    {
        return difficulty switch
        {
            Difficulty.Hard => levelBoxSprites.Hard,
            Difficulty.Expert => levelBoxSprites.Expert,
            _ => levelBoxSprites.Normal
        };
    }

    public DifficultMaskConfig GetDifficultMaskConfig(Difficulty difficulty)
    {
        return difficulty switch
        {
            Difficulty.Hard => HardMask,
            Difficulty.Expert => ExpertMask,
            _ => null
        };
    }

    public ContentConfig GetContentConfig(LevelContent content)
    {
        return contentConfig.TryGetValue(content, out var config) ? config : null;
    }
}

[Serializable]
public class DifficultMaskConfig
{
    public Sprite Border;
    public Sprite Icon;
    public Sprite Bar;
    public Sprite Title;
}

[Serializable]
public class LevelBoxSprites
{
    public Sprite Normal;
    public Sprite Hard;
    public Sprite Expert;
}

[Serializable]
public class BoosterConfig
{
    public BoosterType Type;
    public Sprite Icon;
    [TextArea] public string Description;
    [TextArea] public string BoosterName;
}
[Serializable]
public class ContentConfig
{
    public Sprite Icon;
    public string ContentName;
    public string ContentDescription;
}