using Pixon.Audio;
using Pixon.UI;
using TMPro;
using UnityEngine;

public class UIPopupSoftLose : Window
{
    public override string PopupType => "popup_core";
    [SerializeField] TMP_Text levelText;
    [SerializeField] private ButtonBase reviveCoin;
    [SerializeField] private ButtonBase reviveAds;
    [SerializeField] ButtonBase closeButton;

    [SerializeField] LoseReason loseReason;
    private bool isClosed = false;

    private int reviveCost => RevivePolicy.CoinPrice;

    public override void Initialize()
    {
        base.Initialize();
        reviveCoin.AddListener(OnReviveCoin);
        reviveAds.AddListener(OnReviveAds);
        closeButton.AddListener(OnClickClose);
    }

    private void OnClickClose()
    {
        if (isClosed) return;
        isClosed = true;
        OpenLose();
    }

    public override void Show()
    {
        base.Show();
        isClosed = false;
        if (levelText) levelText.text = $"Level {GameService.DataManager.Level}";
        bool canAffordCoin = RevivePolicy.CanAffordCoin();
        reviveCoin.SetText(reviveCost.ToString());//refresh coin cost
        if (reviveAds) reviveAds.gameObject.SetActive(RevivePolicy.CanWatchRewarded());

        GameService.PlaySound(SoundID.Lose);
    }

    public void ReviveByCoin() => OnReviveCoin();

    private void OnReviveCoin()
    {
        if (GameService.DataManager.TrySpendCoin(reviveCost, ResourceReason.Revive, 
                ResourcePlacement.LosePopup))
        {
            reviveCoin.TrackClick("coin");
            Revive(ReviveMethod.ByCoin);
        }
        else
        {
            GameService.TryEnterShop();
        }
    }

    private void OnReviveAds()
    {
        reviveAds.TrackClick("rv");
        AdsProvider.ShowRewarded(AdsPlacement.Revive, success =>
        {
            if (success)
            {
                Revive(ReviveMethod.ByAds);
                return;
            }

            GameService.UIManager.ShowToast("No ads available!");
        });
    }

    private void Revive(ReviveMethod method)
    {
        this.ClosePopup();
        Delay.Call(0.15f, () =>
        {
            GameService.GameController?.Revive(method);
        });
    }

    void OpenLose()
    {
        AnalyticAdapter.LogLevelLose();
        var popup = this.Replace<UIPopupLose>(UITrigger.Click);
        if (popup != null) popup.SetReason(loseReason);
    }

    public void SetReason(LoseReason reason)
    {
        this.loseReason = reason;
    }
}
