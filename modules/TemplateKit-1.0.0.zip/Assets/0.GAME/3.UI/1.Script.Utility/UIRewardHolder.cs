using Pixon.Data;
using Sirenix.OdinInspector;
using UnityEngine;

public class UIRewardHolder : MonoBehaviour
{
    [SerializeField] [OnValueChanged(nameof(Resize))]
    private float sizeX = 100;

    [SerializeField] [OnValueChanged(nameof(Resize))]
    private float sizeY = 100;

    [SerializeField] [OnValueChanged(nameof(ResizeText))]
    private float textSize = 48;

    [SerializeField] private UIResourceHolder Coin, Booster1, Booster2, Booster3, Heart;

    public void SetData(RewardSlot[] rawData)
    {
        var data = new ResourceBundle();
        data.Add(rawData);
        
        Coin.SetActive(data.Coin > 0);
        Booster1.SetActive(data.Booster1 > 0);
        Booster2.SetActive(data.Booster2 > 0);
        Booster3.SetActive(data.Booster3 > 0);
        Heart.SetActive(data.Heart > 0);

        Coin.SetValue(data.Coin);
        Booster1.SetValue(data.Booster1);
        Booster2.SetValue(data.Booster2);
        Booster3.SetValue(data.Booster3);
        Heart.SetValue(data.Heart);
    }

    private void Resize()
    {
        var size = new Vector2(sizeX, sizeY);
        Coin.Resize(size);
        Booster1.Resize(size);
        Booster2.Resize(size);
        Booster3.Resize(size);
        Heart.Resize(size);
    }

    private void ResizeText()
    {
        Coin.ResizeText(textSize);
        Booster1.ResizeText(textSize);
        Booster2.ResizeText(textSize);
        Booster3.ResizeText(textSize);
        Heart.ResizeText(textSize);
    }
}