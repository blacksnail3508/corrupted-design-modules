using Pixon.Data;
using Pixon.Observer;
using UnityEngine;

public class ActiveOnTester : MonoBehaviour
{
    private void Awake()
    {
        Refresh();
        EventService.AddListener<TesterLogin>(OnTesterLogin);
    }

    private void OnDestroy()
    {
        EventService.RemoveListener<TesterLogin>(OnTesterLogin);
    }

    private void OnTesterLogin(TesterLogin e) { Refresh(); }

    public void Refresh()
    {
        var isTester = GameService.DataManager.IsTester;
        gameObject.SetActive(isTester);
    }
}
