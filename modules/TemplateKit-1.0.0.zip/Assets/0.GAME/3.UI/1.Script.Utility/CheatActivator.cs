using Pixon.Observer;
using Sirenix.OdinInspector;
using UnityEngine;

public class CheatActivator : MonoBehaviour
{
    [Button]
    public void ActivateCheat()
    {
        GameService.DataManager.IsTester = true;
        EventService.Raise(new TesterLogin());
    }
}
