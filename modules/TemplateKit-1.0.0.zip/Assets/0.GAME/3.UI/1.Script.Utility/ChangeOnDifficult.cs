using Pixon.Observer;
using PixonTemplate;
using UnityEngine;
using UnityEngine.UI;

public class ChangeOnDifficult : MonoBehaviour
{
    [SerializeField] Image target;
    [SerializeField] Sprite normal, hard, expert;

    private void Awake()
    {
        EventService.AddListener<LoadingCompleteEvent>(OnLoadingComplete);
        Refresh();
    }

    private void OnDestroy()
    {
        EventService.RemoveListener<LoadingCompleteEvent>(OnLoadingComplete);
    }

    private void OnLoadingComplete(LoadingCompleteEvent e) { Refresh(); }

    public void Refresh()
    {
        if (target == null) return;

        var sprite = GetSprite(GameService.DataManager.CurrentDifficulty);
        if (sprite != null) target.sprite = sprite;
    }

    private Sprite GetSprite(Difficulty difficulty)
    {
        return difficulty switch
        {
            Difficulty.Hard => hard,
            Difficulty.Expert => expert,
            _ => normal
        };
    }
}
