using Pixon.UI;
using UnityEngine;

/// <summary>Connects the Pixon modules to this template's popups and views through <see cref="GameScreens"/>.</summary>
public static class TemplateScreens
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void Bind()
    {
        GameScreens.OpenBuyHeart = () => GameService.UIManager?.ShowPopup<UIPopupBuyHeart>(UITrigger.Click);
        GameScreens.OpenShopInGame = () => GameService.UIManager?.ShowPopup<UIPopupShopInGame>(UITrigger.Click);
        GameScreens.OpenShopInLobby = () => GameService.UIManager?.GetView<UIViewLobby>()?.SnapToShopTab();
        GameScreens.ShowLobby = () => GameService.UIManager?.ShowView<UIViewLobby>();
        GameScreens.ShowGameplay = () => GameService.UIManager?.ShowView<UIViewGamePlay>();
    }
}
