using System;
using System.Collections.Generic;
using Pixon.IAP;
using Pixon.UI;
using Spine.Unity;
using TMPro;
using UnityEngine;

/// <summary>The one-time Starter Pack offer: price and rewards come from ShopConfig, and it closes once bought.</summary>
public class UIPopupStarterPack : Window
{
    public override string PopupType => "popup_purchasing";

    [SerializeField] private ButtonBase buyButton;
    [SerializeField] private TMP_Text nameText;
    [SerializeField] private TMP_Text priceText;
    [SerializeField] private SkeletonGraphic starterPack;
    [SerializeField] private List<UIResourceHolder> resourceSlot = new ();

    private const ProductName Product = ProductName.StarterPack;

    private void Start()
    {
        buyButton.AddListener(TryPurchase);
        Refresh();
    }

    private void TryPurchase()
    {
        buyButton.SetInteract(false);
        ShopService.Buy(Product, LastTrigger.ToString(), success =>
        {
            if (this == null) return;
            buyButton.SetInteract(true);
            if (success) CloseAfterReward();
        });
    }

    private void CloseAfterReward()
    {
        // The reward recap opens on top of this popup, so closing is deferred until it is claimed.
        var reward = GameService.UIManager.GetPopup<UIPopupGrantReward>();
        if (reward != null && reward.gameObject.activeSelf)
            reward.SetOnCloseCallback(() => GameService.UIManager.ClosePopup<UIPopupStarterPack>());
        else
            GameService.UIManager.ClosePopup<UIPopupStarterPack>();
    }

    private void Refresh()
    {
        var data = ShopService.GetProductData(Product);
        if (priceText != null) priceText.text = ShopService.GetPriceString(Product);
        if (nameText != null && !string.IsNullOrEmpty(data.DisplayName)) nameText.text = data.DisplayName;

        foreach (var slot in resourceSlot)
        {
            int amount = 0;
            foreach (var reward in data.Rewards)
                if (reward.type == slot.Resource) amount += reward.amount;
            slot.SetActive(amount > 0);
            if (amount > 0) slot.SetData(slot.Resource, amount);
        }
    }

    public override void Show()
    {
        base.Show();
        // The store price can arrive after Start, so it is read again each time the popup opens.
        Refresh();
        // The prefab may ship without the spine reference.
        if (starterPack == null) return;
        starterPack.PlayAnimation("starter_pack_popup", () => starterPack.PlayAnimation("starter_pack_popup_idle"));
    }
}
