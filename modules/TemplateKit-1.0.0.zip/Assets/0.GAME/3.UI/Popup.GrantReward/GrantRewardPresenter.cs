using System.Collections.Generic;
using Pixon.IAP;
using Pixon.Observer;
using Pixon.UI;
using UnityEngine;

/// <summary>Opens the grant-reward popup after any IAP purchase succeeds.</summary>
public static class GrantRewardPresenter
{
    // The listener is static because ShopService has no UI owner; the event outlives every scene.
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Register() => EventService.AddListener<PurchaseCompletedEvent>(OnPurchaseCompleted);

    private static void OnPurchaseCompleted(PurchaseCompletedEvent e)
    {
        // Rewards were paid by the fulfiller before this event, so the popup is a pure recap.
        var data = e.Product.Data;
        var rewards = new List<IapReward>();
        // No-ads is a flag on the product, not an IapReward, so it is added here for display only.
        if (data.GrantsNoAds) rewards.Add(new IapReward { type = ItemType.RemoveAds, amount = 1 });
        rewards.AddRange(data.Rewards);
        if (rewards.Count == 0 || GameService.UIManager == null) return;

        GameService.UIManager.ShowPopup<UIPopupGrantReward>(UITrigger.Auto)?.SetRewards(rewards);
    }
}
