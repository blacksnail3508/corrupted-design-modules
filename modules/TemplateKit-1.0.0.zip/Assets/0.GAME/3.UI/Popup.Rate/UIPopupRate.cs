using System;
using System.Collections;
#if UNITY_ANDROID
using Google.Play.Review;
#endif
using Pixon.Observer;
using Pixon.Remote;
using Pixon.UI;
using UnityEngine;

/// <summary>Asks the player for a star rating, and sends the happy ones on to the store's review sheet.</summary>
public class UIPopupRate : Window
{
    // Below this many stars the player is thanked here rather than sent to the store.
    private const int StoreReviewStars = 4;

    public override string PopupType => "popup_store_rating";

    [SerializeField] private ButtonBase rateBtn;
    [SerializeField] private GameObject[] stars = new GameObject[5];

    private int selectedStars;

    public override void Initialize()
    {
        base.Initialize();
        rateBtn.AddListener(OnRateClick);
    }

    /// <summary>Asks for a rating after the win of this level when one is due, then runs onContinue.</summary>
    public static void ShowIfDue(int wonLevel, Action onContinue)
    {
        if (!IsDue(wonLevel))
        {
            onContinue?.Invoke();
            return;
        }

        UIPopupRate popup = GameService.UIManager?.ShowPopup<UIPopupRate>(UITrigger.Auto, wonLevel);
        if (popup == null)
        {
            onContinue?.Invoke();
            return;
        }

        // Held until the popup is fully hidden, so the win flow carries on whichever way the popup closes.
        popup.SetOnCloseCallback(onContinue);
    }

    // First at rating_start_lv, then every rating_frequency levels after it (both in rating_config), until the player rates.
    private static bool IsDue(int wonLevel)
    {
        // A GM test run is not the player's win; a real win has already flipped the mode to Ended.
        if (GameService.GameMode == GameMode.Testing || GameService.GameMode == GameMode.Editing) return false;
        if (GameService.DataManager == null || GameService.DataManager.IsRated) return false;

        RatingConfigData config = ConfigCollection.RatingConfig.Value;
        int firstLevel = config.StartLv;
        int frequency = config.Frequency;
        if (wonLevel < firstLevel) return false;

        // Zero or less turns the repeat off, leaving the one ask at the first level.
        if (frequency <= 0) return wonLevel == firstLevel;
        return (wonLevel - firstLevel) % frequency == 0;
    }

    /// <summary>Closes without rating, for the auto play bot.</summary>
    public void Dismiss() => GameService.UIManager?.ClosePopup<UIPopupRate>();

    public override void Show()
    {
        // A closed popup is kept around for a while before it is destroyed, so each opening starts on full marks.
        OnClickStar(stars.Length);
        base.Show();
    }

    /// <summary>Lights the first stars up to this one; the star buttons on the prefab call it.</summary>
    public void OnClickStar(int index)
    {
        selectedStars = index;
        for (int i = 0; i < stars.Length; i++) stars[i].SetActive(i < index);
    }

    private void OnRateClick()
    {
        GameService.DataManager.MarkRated();
        EventService.Raise(new RateEvent());

        if (selectedStars < StoreReviewStars)
            GameService.ShowToast("Your review has helped us to improve the game better \nWishing you a very happy new day");
        else
            RequestStoreReview();

        GameService.UIManager.ClosePopup<UIPopupRate>();
    }

    private static void RequestStoreReview()
    {
#if UNITY_ANDROID
        // Run on the UI manager: closing deactivates this popup, which would stop the flow half way.
        GameService.UIManager?.StartCoroutine(LaunchReview());
#elif UNITY_IOS
        UnityEngine.iOS.Device.RequestStoreReview();
#endif
    }

#if UNITY_ANDROID
    private static IEnumerator LaunchReview()
    {
        var reviewManager = new ReviewManager();

        var requestFlow = reviewManager.RequestReviewFlow();
        yield return requestFlow;
        if (requestFlow.Error != ReviewErrorCode.NoError)
        {
            Bug.LogWarning($"[Rate] Review request failed: {requestFlow.Error}");
            yield break;
        }

        var launchFlow = reviewManager.LaunchReviewFlow(requestFlow.GetResult());
        yield return launchFlow;
        if (launchFlow.Error != ReviewErrorCode.NoError)
            Bug.LogWarning($"[Rate] Review launch failed: {launchFlow.Error}");
    }
#endif
}

public class RateEvent : GameEvent
{
}
