using System.Collections.Generic;
using Pixon.Stamina;
using Pixon.UI;
using TMPro;
using UnityEngine;

public class UIPopupBuyHeart : Window
{
    public override string PopupType => "popup_purchasing";

    private const string RefillByCoin = "coin";
    private const string RefillByAds = "ads";
    private const string HeartCurrencyName = "heart";
    private const string FullHeartMessage = "Heart is already full!";
    private const string AdsFailedMessage = "Video not available, please try again!";

    [SerializeField] private int coinPrice = 500;
    [SerializeField] private TMP_Text timeText;
    [SerializeField] private TMP_Text heartText;
    [SerializeField] private ButtonBase claimByCoin;
    [SerializeField] private ButtonBase claimByAds;

    public int CoinPrice => coinPrice;

    private void Start()
    {
        claimByCoin.SetText(coinPrice.ToString());
        claimByCoin.AddListener(ClaimByCoin);
        claimByAds.AddListener(ClaimByAds);
    }

    private void ClaimByCoin()
    {
        if (StaminaManager.Instance == null) return;

        if (StaminaManager.IsFull)
        {
            GameService.ShowToast(FullHeartMessage);
            return;
        }

        if (!GameService.DataManager.TrySpendCoin(coinPrice, ResourceReason.Exchange, ResourcePlacement.PopupBuyHeart))
        {
            GameService.TryEnterShop();
            return;
        }

        claimByCoin.TrackClick(RefillByCoin);

        int claimAmount = StaminaManager.MaxStamina - StaminaManager.CurrentStamina;
        StaminaManager.ClaimStamina(claimAmount, RefillByCoin);
        this.ClosePopup<UIPopupBuyHeart>();
    }

    private void ClaimByAds()
    {
        if (StaminaManager.Instance == null) return;

        if (StaminaManager.IsFull)
        {
            GameService.ShowToast(FullHeartMessage);
            return;
        }

        claimByAds.TrackClick("rv");

        AdsProvider.ShowRewarded(AdsPlacement.BuyHeart, success =>
        {
            if (!success)
            {
                GameService.ShowToast(AdsFailedMessage);
                return;
            }

            StaminaManager.ClaimStamina(1, RefillByAds);
            this.ClosePopup<UIPopupBuyHeart>();
        });
    }

    private void OnEnable()
    {
        UpdateTime();
        Clock.CallPerSecond += UpdateTime;
    }

    private void OnDisable()
    {
        Clock.CallPerSecond -= UpdateTime;
    }

    private void UpdateTime()
    {
        if (StaminaManager.Instance == null) return;

        timeText.text = StaminaManager.RecoverTimeRemainingString;
        heartText.text = StaminaManager.CurrentStamina.ToString();
    }
}
