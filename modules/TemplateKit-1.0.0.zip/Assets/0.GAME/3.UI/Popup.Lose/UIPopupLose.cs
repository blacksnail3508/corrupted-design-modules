using Pixon.Stamina;
using Pixon.Audio;
using Pixon.Remote;
using UnityEngine;
using Pixon.UI;
using TMPro;

public class UIPopupLose : Window
{
    public override string PopupType => "popup_core";
    [SerializeField] TMP_Text levelText;
    [SerializeField] private ButtonBase retry;
    [SerializeField] ButtonBase closeButton;

    [SerializeField] LoseReason loseReason;
    private bool isClosed = false;
    private bool isRetrying = false;

    public override void Initialize()
    {
        base.Initialize();
        closeButton.AddListener(OnClickClose);
        retry.AddListener(ForceRetry);
    }

    public override void ResetData()
    {
        base.ResetData();
        isRetrying = false;
    }

    private void ForceRetry()
    {
        if (isRetrying) return;
        isRetrying = true;
        AdsProvider.ShowInterstitialFromLevel(AdsPlacement.Lose, ConfigCollection.InterConfig.Value.LoseStartLv,
            _ => GameService.ForceReload());
    }

    private void OnClickClose()
    {
        if (isClosed)return;
        isClosed = true;
        // Pixon.Analytics.LevelTracker.LogLevelEnd(GameService.DataManager.Level, 
        //     LevelResult.Lose, loseReason);
        OpenPopupRetry();
    }

    public override void Show()
    {
        base.Show();
        isClosed = false;
        if(levelText) levelText.text = $"Level {GameService.DataManager.Level}";

        GameService.PlaySound(SoundID.Lose);
    }

    void OpenPopupRetry()
    {
        StaminaManager.SpendStamina(1);
        this.Replace<UIPopupRetry>(UITrigger.Click);
    }

    public void SetReason(LoseReason reason)
    {
        this.loseReason = reason;
    }
}
