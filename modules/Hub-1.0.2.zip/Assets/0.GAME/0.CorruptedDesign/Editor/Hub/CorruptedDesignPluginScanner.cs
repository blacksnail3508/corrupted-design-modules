using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace CorruptedDesign.Hub
{
    public class CorruptedDesignPluginInfo
    {
        public string name;
        public string source;
        public string version;
        public bool present;
    }

    /// <summary>Checks which third-party plugins and Unity packages the project carries, and their versions.</summary>
    public static class CorruptedDesignPluginScanner
    {
        private static readonly (string name, string folder)[] Folders =
        {
            ("Odin Inspector", "Assets/Plugins/Sirenix"),
            ("DOTween", "Assets/Plugins/Demigiant/DOTween"),
            ("DOTween Pro", "Assets/Plugins/Demigiant/DOTweenPro"),
            ("Spine Runtime", "Assets/Spine"),
            ("SRDebugger", "Assets/StompyRobot"),
            ("Advanced FPS Counter", "Assets/AdvancedFPSCounter"),
            ("Lean Touch / CW", "Assets/Plugins/CW"),
            ("EnhancedScroller", "Assets/Plugins/EnhancedScroller v2"),
            ("TextMesh Pro", "Assets/TextMesh Pro"),
        };

        private static readonly (string name, string id)[] Packages =
        {
            ("Addressables", "com.unity.addressables"),
            ("Input System", "com.unity.inputsystem"),
            ("Universal RP", "com.unity.render-pipelines.universal"),
            ("Newtonsoft Json", "com.unity.nuget.newtonsoft-json"),
            ("UniTask", "com.cysharp.unitask"),
            ("Unity Purchasing", "com.unity.purchasing"),
            ("UI Effect", "com.coffee.ui-effect"),
            ("UI Particle", "com.coffee.ui-particle"),
            ("Unity UI", "com.unity.ugui"),
            ("Timeline", "com.unity.timeline"),
        };

        public static IReadOnlyList<CorruptedDesignPluginInfo> Scan(string projectRoot)
        {
            var result = new List<CorruptedDesignPluginInfo>();

            foreach (var (name, folder) in Folders)
            {
                bool present = Directory.Exists(Path.Combine(projectRoot, folder));
                result.Add(new CorruptedDesignPluginInfo { name = name, source = "Assets", version = present ? "installed" : "-", present = present });
            }

            var manifest = ReadManifest(projectRoot);
            foreach (var (name, id) in Packages)
            {
                bool present = manifest.TryGetValue(id, out var version);
                result.Add(new CorruptedDesignPluginInfo { name = name, source = "Package " + id, version = present ? ShortVersion(version) : "-", present = present });
            }

            return result;
        }

        // The manifest maps package ids to strings, which JsonUtility cannot read, so each pair is matched by pattern.
        private static Dictionary<string, string> ReadManifest(string projectRoot)
        {
            var map = new Dictionary<string, string>();
            var path = Path.Combine(projectRoot, "Packages", "manifest.json");
            if (!File.Exists(path)) return map;

            foreach (Match m in Regex.Matches(File.ReadAllText(path), "\"([\\w.\\-]+)\"\\s*:\\s*\"([^\"]*)\""))
                map[m.Groups[1].Value] = m.Groups[2].Value;
            return map;
        }

        private static string ShortVersion(string version)
        {
            int hash = version.LastIndexOf('#');
            return hash >= 0 ? version.Substring(hash + 1) : version;
        }
    }
}
