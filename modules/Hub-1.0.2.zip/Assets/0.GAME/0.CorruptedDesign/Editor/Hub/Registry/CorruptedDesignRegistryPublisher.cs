using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using CorruptedDesign.Registry;
using UnityEditor;
using UnityEngine;

namespace CorruptedDesign.Hub
{
    /// <summary>Packs every module into a versioned zip and writes the catalog.json the Registry window reads; the output folder is what gets pushed to the module repository.</summary>
    public static class CorruptedDesignRegistryPublisher
    {
        public const string HubModulePath = "Editor/Hub";
        public const string KitModulePath = "../3.UI";

        private static readonly DateTimeOffset FixedTime = new(2020, 1, 1, 0, 0, 0, TimeSpan.Zero);

        [MenuItem("CorruptedDesign/Registry Tools/Publish To Folder...")]
        private static void PublishFromMenu()
        {
            var folder = EditorUtility.OpenFolderPanel("Folder to write catalog.json and modules/ into", string.Empty, string.Empty);
            if (string.IsNullOrEmpty(folder)) return;

            try
            {
                var catalog = Publish(Path.GetDirectoryName(Application.dataPath), Path.Combine(Application.dataPath, "0.GAME/0.CorruptedDesign"), folder);
                EditorUtility.DisplayDialog("CorruptedDesign Registry", $"Published {catalog.modules.Length} modules to {folder}.", "OK");
            }
            catch (Exception e)
            {
                EditorUtility.DisplayDialog("CorruptedDesign Registry", e.Message, "OK");
            }
        }

        /// <summary>Batch mode: <c>-executeMethod CorruptedDesign.Hub.CorruptedDesignRegistryPublisher.PublishCli -corrupteddesignOut FOLDER</c>.</summary>
        public static void PublishCli()
        {
            try
            {
                var args = Environment.GetCommandLineArgs();
                int index = Array.IndexOf(args, "-corrupteddesignOut");
                if (index < 0 || index + 1 >= args.Length) throw new InvalidOperationException("-corrupteddesignOut FOLDER is required.");

                var catalog = Publish(Path.GetDirectoryName(Application.dataPath), Path.Combine(Application.dataPath, "0.GAME/0.CorruptedDesign"), args[index + 1]);
                Debug.Log($"[CorruptedDesignRegistry] published {catalog.modules.Length} modules");
                EditorApplication.Exit(0);
            }
            catch (Exception e)
            {
                Debug.LogError("[CorruptedDesignRegistry] " + e.Message);
                EditorApplication.Exit(1);
            }
        }

        /// <summary>Writes <c>modules/ID-VERSION.zip</c> for each module and <c>catalog.json</c> into <paramref name="outFolder"/>; refuses to change a zip whose version was already published.</summary>
        public static RegistryCatalog Publish(string projectRoot, string corrupteddesignRoot, string outFolder)
        {
            var modules = new List<RegistryModule>();
            Directory.CreateDirectory(Path.Combine(outFolder, "modules"));

            foreach (var folder in ModuleFolders(corrupteddesignRoot))
            {
                var manifest = ReadManifest(folder);
                var module = new RegistryModule
                {
                    id = manifest.id,
                    name = string.IsNullOrEmpty(manifest.name) ? manifest.id : manifest.name,
                    version = manifest.version,
                    description = manifest.description,
                    dependencies = manifest.dependencies ?? Array.Empty<string>(),
                    companions = manifest.companions ?? Array.Empty<string>(),
                    requires = manifest.requires ?? Array.Empty<RegistryRequirement>(),
                    packages = manifest.packages ?? Array.Empty<RegistryPackage>(),
                    installPath = Relative(projectRoot, folder),
                    extraPaths = (manifest.paths ?? Array.Empty<string>()).Select(p => "Assets/" + p).ToArray(),
                    zip = $"modules/{manifest.id}-{manifest.version}.zip",
                };

                var bytes = Pack(projectRoot, module);
                module.sha256 = CorruptedDesignInstaller.Sha256(bytes);
                module.size = bytes.Length;

                var zipPath = Path.Combine(outFolder, module.zip);
                if (File.Exists(zipPath) && CorruptedDesignInstaller.Sha256(File.ReadAllBytes(zipPath)) != module.sha256)
                    throw new InvalidOperationException($"{module.id} changed but is still version {module.version}: bump \"version\" in its corrupteddesign.module.json.");

                File.WriteAllBytes(zipPath, bytes);
                modules.Add(module);
            }

            var duplicate = modules.GroupBy(m => m.id).FirstOrDefault(g => g.Count() > 1);
            if (duplicate != null) throw new InvalidOperationException($"Module id '{duplicate.Key}' is used by more than one folder.");

            var catalog = new RegistryCatalog { modules = modules.OrderBy(m => m.id, StringComparer.Ordinal).ToArray() };
            File.WriteAllText(Path.Combine(outFolder, "catalog.json"), JsonUtility.ToJson(catalog, true));
            CopyInstaller(corrupteddesignRoot, outFolder);
            return catalog;
        }

        #region PACKING
        private static IEnumerable<string> ModuleFolders(string corrupteddesignRoot)
        {
            foreach (var dir in Directory.GetDirectories(corrupteddesignRoot).OrderBy(d => d, StringComparer.Ordinal))
                if (Path.GetFileName(dir) != "Editor" && File.Exists(Path.Combine(dir, CorruptedDesignModuleRegistry.ManifestFileName))) yield return dir;

            var hub = Path.Combine(corrupteddesignRoot, HubModulePath);
            if (File.Exists(Path.Combine(hub, CorruptedDesignModuleRegistry.ManifestFileName))) yield return hub;

            var kit = Path.GetFullPath(Path.Combine(corrupteddesignRoot, KitModulePath));
            if (File.Exists(Path.Combine(kit, CorruptedDesignModuleRegistry.ManifestFileName))) yield return kit;
        }

        private static CorruptedDesignModuleManifest ReadManifest(string folder)
        {
            var path = Path.Combine(folder, CorruptedDesignModuleRegistry.ManifestFileName);
            var manifest = JsonUtility.FromJson<CorruptedDesignModuleManifest>(File.ReadAllText(path));
            if (manifest == null || string.IsNullOrEmpty(manifest.id) || string.IsNullOrEmpty(manifest.version))
                throw new InvalidOperationException($"{path} needs an id and a version.");
            return manifest;
        }

        // Fixed timestamps and entry order make the zip identical for identical content, so an unchanged module keeps its hash.
        // Entry names are project-relative (Assets/...), so a module with several folders unpacks to the right places.
        private static byte[] Pack(string projectRoot, RegistryModule module)
        {
            using var stream = new MemoryStream();
            using (var archive = new ZipArchive(stream, ZipArchiveMode.Create, true))
            {
                var files = new List<(string path, string entry)>();
                foreach (var relative in ModulePaths.All(module))
                {
                    var folder = Path.Combine(projectRoot, relative);
                    if (!Directory.Exists(folder)) throw new InvalidOperationException($"{module.id}: folder {relative} does not exist.");

                    files.AddRange(Directory.GetFiles(folder, "*", SearchOption.AllDirectories).Select(f => (path: f, entry: Relative(projectRoot, f))));
                    if (File.Exists(folder + ".meta")) files.Add((folder + ".meta", relative + ".meta"));
                }

                foreach (var file in files.OrderBy(f => f.entry, StringComparer.Ordinal))
                {
                    var entry = archive.CreateEntry(file.entry, System.IO.Compression.CompressionLevel.Optimal);
                    entry.LastWriteTime = FixedTime;
                    using var output = entry.Open();
                    var data = File.ReadAllBytes(file.path);
                    output.Write(data, 0, data.Length);
                }
            }
            return stream.ToArray();
        }

        private static string Relative(string root, string path) =>
            Path.GetFullPath(path).Substring(Path.GetFullPath(root).TrimEnd('\\', '/').Length + 1).Replace('\\', '/');

        // The loose installer is published beside the catalog: it is the one file a new project needs.
        private static void CopyInstaller(string corrupteddesignRoot, string outFolder)
        {
            var source = Path.Combine(corrupteddesignRoot, HubModulePath, "Registry", "CorruptedDesignRegistry.cs");
            if (File.Exists(source)) File.Copy(source, Path.Combine(outFolder, "CorruptedDesignRegistry.cs"), true);
        }
        #endregion
    }
}
