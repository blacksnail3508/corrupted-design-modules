using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace CorruptedDesign.Hub
{
    public class CorruptedDesignAssetTypeInfo
    {
        public Type type;
        public string menuName;
        public string fileName;
        public int existing;
    }

    /// <summary>Finds every ScriptableObject that has <c>[CreateAssetMenu]</c> and creates assets of them from one place.</summary>
    public static class CorruptedDesignAssetCreator
    {
        public static IReadOnlyList<CorruptedDesignAssetTypeInfo> Scan()
        {
            var projectAssemblies = new HashSet<string>(ProjectAssemblies.All().Select(a => a.loaded.GetName().Name));
            var result = new List<CorruptedDesignAssetTypeInfo>();

            foreach (var type in TypeCache.GetTypesDerivedFrom<ScriptableObject>())
            {
                if (type.IsAbstract || !projectAssemblies.Contains(type.Assembly.GetName().Name)) continue;

                var attribute = (CreateAssetMenuAttribute)Attribute.GetCustomAttribute(type, typeof(CreateAssetMenuAttribute), false);
                if (attribute == null) continue;

                result.Add(new CorruptedDesignAssetTypeInfo
                {
                    type = type,
                    menuName = string.IsNullOrEmpty(attribute.menuName) ? type.Name : attribute.menuName,
                    fileName = string.IsNullOrEmpty(attribute.fileName) ? "New " + type.Name : attribute.fileName,
                    existing = AssetDatabase.FindAssets("t:" + type.Name).Length,
                });
            }
            return result.OrderBy(i => i.menuName).ToList();
        }

        /// <summary>Starts the same rename-in-place flow as the Create menu, in the folder currently selected in the Project window.</summary>
        public static void Create(CorruptedDesignAssetTypeInfo info)
        {
            var instance = ScriptableObject.CreateInstance(info.type);
            ProjectWindowUtil.CreateAsset(instance, info.fileName + ".asset");
        }

        public static void PingFirst(CorruptedDesignAssetTypeInfo info)
        {
            var guid = AssetDatabase.FindAssets("t:" + info.type.Name).FirstOrDefault();
            if (guid == null) return;

            var asset = AssetDatabase.LoadMainAssetAtPath(AssetDatabase.GUIDToAssetPath(guid));
            Selection.activeObject = asset;
            EditorGUIUtility.PingObject(asset);
        }
    }
}
