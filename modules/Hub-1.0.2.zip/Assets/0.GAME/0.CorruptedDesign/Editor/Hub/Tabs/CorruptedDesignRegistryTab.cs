using CorruptedDesign.Registry;
using UnityEngine.UIElements;

namespace CorruptedDesign.Hub
{
    /// <summary>Hub tab that installs, updates and removes modules from the catalog.</summary>
    public class CorruptedDesignRegistryTab : ICorruptedDesignHubTab
    {
        public string Title => "Registry";

        public VisualElement Build()
        {
            VisualElement container = null;
            var view = new CorruptedDesignRegistryView(() => container?.MarkDirtyRepaint());
            container = new IMGUIContainer(view.Draw) { style = { flexGrow = 1 } };
            return container;
        }
    }
}
