using UnityEngine;
using UnityEngine.UIElements;

namespace CorruptedDesign.Hub
{
    /// <summary>Which third-party plugins and Unity packages are installed.</summary>
    public class CorruptedDesignPluginsTab : ICorruptedDesignHubTab
    {
        public string Title => "Plugins";

        public VisualElement Build()
        {
            var scroll = new ScrollView();
            foreach (var plugin in CorruptedDesignPluginScanner.Scan(CorruptedDesignHubWindow.ProjectRoot))
            {
                var row = new VisualElement { style = { flexDirection = FlexDirection.Row, marginBottom = 3 } };
                row.Add(new Label(plugin.present ? "OK" : "--") { style = { width = 34, color = plugin.present ? new Color(0.3f, 0.75f, 0.5f) : new Color(0.9f, 0.4f, 0.4f) } });
                row.Add(new Label(plugin.name) { style = { width = 200 } });
                row.Add(new Label(plugin.version) { style = { width = 140 } });
                row.Add(new Label(plugin.source) { style = { opacity = 0.6f } });
                scroll.Add(row);
            }
            return scroll;
        }
    }
}
