using System.Linq;
using UnityEngine.UIElements;

namespace CorruptedDesign.Hub
{
    /// <summary>Every editor tool of the project, grouped by menu, started with one click.</summary>
    public class CorruptedDesignToolsTab : ICorruptedDesignHubTab
    {
        private VisualElement list;
        private bool projectOnly = true;
        private string filter = string.Empty;

        public string Title => "Tools";

        public VisualElement Build()
        {
            var root = new VisualElement { style = { flexGrow = 1 } };

            var bar = new VisualElement { style = { flexDirection = FlexDirection.Row, marginBottom = 6 } };
            var search = new TextField { style = { flexGrow = 1 } };
            search.RegisterValueChangedCallback(e => { filter = e.newValue ?? string.Empty; Fill(); });
            bar.Add(search);
            var toggle = new Toggle("Project tools only") { value = projectOnly };
            toggle.RegisterValueChangedCallback(e => { projectOnly = e.newValue; Fill(); });
            bar.Add(toggle);
            root.Add(bar);

            var scroll = new ScrollView { style = { flexGrow = 1 } };
            list = new VisualElement();
            scroll.Add(list);
            root.Add(scroll);

            Fill();
            return root;
        }

        private void Fill()
        {
            list.Clear();
            var tools = CorruptedDesignToolScanner.Scan()
                .Where(t => (!projectOnly || t.isProject) && t.menuPath.IndexOf(filter, System.StringComparison.OrdinalIgnoreCase) >= 0);

            foreach (var group in tools.GroupBy(t => t.group))
            {
                list.Add(new Label(group.Key) { style = { unityFontStyleAndWeight = UnityEngine.FontStyle.Bold, marginTop = 8, marginBottom = 2 } });
                foreach (var tool in group)
                {
                    var captured = tool;
                    var row = new VisualElement { style = { flexDirection = FlexDirection.Row, alignItems = Align.Center } };
                    row.Add(new Button(() => CorruptedDesignToolScanner.Run(captured)) { text = "Run", style = { width = 56 } });
                    row.Add(new Label(tool.menuPath) { style = { marginLeft = 6 } });
                    row.Add(new Label(tool.owner) { style = { marginLeft = 10, opacity = 0.5f } });
                    list.Add(row);
                }
            }
        }
    }
}
