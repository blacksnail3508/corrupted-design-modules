using System.Linq;
using UnityEngine.UIElements;

namespace CorruptedDesign.Hub
{
    /// <summary>Every ScriptableObject type with a Create menu, with a button to create one or jump to an existing one.</summary>
    public class CorruptedDesignCreateTab : ICorruptedDesignHubTab
    {
        private VisualElement list;
        private string filter = string.Empty;

        public string Title => "Create";

        public VisualElement Build()
        {
            var root = new VisualElement { style = { flexGrow = 1 } };
            root.Add(new Label("New assets are created in the folder selected in the Project window.") { style = { opacity = 0.6f, marginBottom = 6 } });

            var search = new TextField { style = { marginBottom = 6 } };
            search.RegisterValueChangedCallback(e => { filter = e.newValue ?? string.Empty; Fill(); });
            root.Add(search);

            var scroll = new ScrollView { style = { flexGrow = 1 } };
            list = new VisualElement();
            scroll.Add(list);
            root.Add(scroll);

            Fill();
            return root;
        }

        private void Fill()
        {
            list.Clear();
            foreach (var info in CorruptedDesignAssetCreator.Scan().Where(i => i.menuName.IndexOf(filter, System.StringComparison.OrdinalIgnoreCase) >= 0))
            {
                var captured = info;
                var row = new VisualElement { style = { flexDirection = FlexDirection.Row, alignItems = Align.Center } };
                row.Add(new Button(() => CorruptedDesignAssetCreator.Create(captured)) { text = "Create", style = { width = 70 } });
                var ping = new Button(() => CorruptedDesignAssetCreator.PingFirst(captured)) { text = "Find", style = { width = 50 } };
                ping.SetEnabled(info.existing > 0);
                row.Add(ping);
                row.Add(new Label(info.menuName) { style = { marginLeft = 6, width = 260 } });
                row.Add(new Label($"{info.type.Name}  ({info.existing})") { style = { opacity = 0.55f } });
                list.Add(row);
            }
        }
    }
}
