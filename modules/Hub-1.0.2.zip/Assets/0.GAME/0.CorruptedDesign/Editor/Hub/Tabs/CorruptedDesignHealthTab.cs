using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace CorruptedDesign.Hub
{
    /// <summary>Runs the project checks and lists what they found.</summary>
    public class CorruptedDesignHealthTab : ICorruptedDesignHubTab
    {
        public string Title => "Health";

        public VisualElement Build()
        {
            var scroll = new ScrollView();

            var modules = CorruptedDesignHealthChecks.UnresolvedModules(CorruptedDesignModuleRegistry.Scan(CorruptedDesignHubWindow.CorruptedDesignRoot));
            scroll.Add(Section("Modules with problems", modules));

            var missing = CorruptedDesignHealthChecks.FindMissingScripts(CorruptedDesignHubWindow.ProjectRoot, "Assets/0.GAME", "Assets/Scenes");
            scroll.Add(Section("Prefabs and scenes with missing scripts", missing));

            var scenesFolder = Path.Combine(Application.dataPath, "Scenes");
            var expected = Directory.Exists(scenesFolder)
                ? Directory.GetFiles(scenesFolder, "*.unity").Select(p => "Assets/Scenes/" + Path.GetFileName(p))
                : Enumerable.Empty<string>();
            var inBuild = EditorBuildSettings.scenes.Where(s => s.enabled).Select(s => s.path);
            scroll.Add(Section("Scenes missing from Build Settings", CorruptedDesignHealthChecks.ScenesMissingFrom(expected, inBuild)));
            return scroll;
        }

        private static VisualElement Section(string title, IReadOnlyList<string> problems)
        {
            var box = new VisualElement { style = { marginBottom = 12 } };
            bool clean = problems.Count == 0;
            box.Add(new Label($"{(clean ? "OK" : "!!")}   {title} ({problems.Count})")
            {
                style = { unityFontStyleAndWeight = FontStyle.Bold, color = clean ? new Color(0.3f, 0.75f, 0.5f) : new Color(0.9f, 0.4f, 0.4f) },
            });
            foreach (var problem in problems) box.Add(new Label("   " + problem) { style = { opacity = 0.8f } });
            return box;
        }
    }
}
