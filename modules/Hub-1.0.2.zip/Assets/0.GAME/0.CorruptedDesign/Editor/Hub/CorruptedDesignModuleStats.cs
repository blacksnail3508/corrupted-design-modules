using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace CorruptedDesign.Hub
{
    public static class CorruptedDesignModuleStats
    {
        private static readonly Regex PublicType = new(
            @"^\s*public\s+(?:(?:abstract|static|sealed|partial|unsafe)\s+)*(?:class|struct|enum|interface|record)\s+(\w+)",
            RegexOptions.Multiline | RegexOptions.Compiled);

        public static (int files, int lines) Count(string folder)
        {
            if (!Directory.Exists(folder)) return (0, 0);

            int files = 0, lines = 0;
            foreach (var path in Directory.EnumerateFiles(folder, "*.cs", SearchOption.AllDirectories))
            {
                files++;
                lines += File.ReadLines(path).Count();
            }
            return (files, lines);
        }

        public static string[] PublicTypes(string folder, int max = 40)
        {
            if (!Directory.Exists(folder)) return System.Array.Empty<string>();

            var found = new List<string>();
            foreach (var path in Directory.EnumerateFiles(folder, "*.cs", SearchOption.AllDirectories))
            {
                foreach (Match m in PublicType.Matches(File.ReadAllText(path)))
                {
                    found.Add(m.Groups[1].Value);
                    if (found.Count >= max) return found.ToArray();
                }
            }
            return found.ToArray();
        }
    }
}
