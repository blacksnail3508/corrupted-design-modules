using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace CorruptedDesign.Hub
{
    /// <summary>Scans the CorruptedDesign root for modules (one folder each, described by <c>corrupteddesign.module.json</c>). Never throws.</summary>
    public static class CorruptedDesignModuleRegistry
    {
        public const string ManifestFileName = "corrupteddesign.module.json";

        private static readonly string[] IgnoredFolders = { "Editor" };

        public static IReadOnlyList<CorruptedDesignModuleEntry> Scan(string corrupteddesignRootFolder)
        {
            var entries = new List<CorruptedDesignModuleEntry>();
            if (string.IsNullOrEmpty(corrupteddesignRootFolder) || !Directory.Exists(corrupteddesignRootFolder)) return entries;

            foreach (var dir in Directory.GetDirectories(corrupteddesignRootFolder).OrderBy(d => d, StringComparer.OrdinalIgnoreCase))
            {
                if (IgnoredFolders.Contains(Path.GetFileName(dir))) continue;
                entries.Add(ReadEntry(dir));
            }

            ResolveDependencies(entries);
            return entries;
        }

        private static CorruptedDesignModuleEntry ReadEntry(string dir)
        {
            var entry = new CorruptedDesignModuleEntry { folder = dir };
            (entry.fileCount, entry.lineCount) = CorruptedDesignModuleStats.Count(dir);

            var manifestPath = Path.Combine(dir, ManifestFileName);
            if (!File.Exists(manifestPath))
            {
                entry.status = CorruptedDesignModuleStatus.MissingManifest;
                entry.statusDetail = ManifestFileName + " not found";
                return entry;
            }

            try
            {
                var manifest = JsonUtility.FromJson<CorruptedDesignModuleManifest>(File.ReadAllText(manifestPath));
                if (manifest == null || string.IsNullOrEmpty(manifest.id)) throw new FormatException("id is empty");
                manifest.dependencies ??= Array.Empty<string>();
                manifest.namespaces ??= Array.Empty<string>();
                entry.manifest = manifest;
            }
            catch (Exception e)
            {
                entry.status = CorruptedDesignModuleStatus.InvalidManifest;
                entry.statusDetail = e.Message;
            }
            return entry;
        }

        private static void ResolveDependencies(List<CorruptedDesignModuleEntry> entries)
        {
            var valid = entries.Where(e => e.manifest != null).ToList();
            var byId = new Dictionary<string, CorruptedDesignModuleEntry>();
            foreach (var e in valid) byId[e.manifest.id] = e;

            foreach (var e in valid)
            {
                var missing = e.manifest.dependencies.Where(d => !byId.ContainsKey(d)).ToList();
                if (missing.Count == 0) continue;
                e.status = CorruptedDesignModuleStatus.MissingDependency;
                e.statusDetail = "missing: " + string.Join(", ", missing);
            }

            foreach (var e in valid)
            {
                if (e.status != CorruptedDesignModuleStatus.Ok) continue;
                if (!ReachesItself(e, byId)) continue;
                e.status = CorruptedDesignModuleStatus.Cycle;
                e.statusDetail = "dependency cycle";
            }
        }

        private static bool ReachesItself(CorruptedDesignModuleEntry start, Dictionary<string, CorruptedDesignModuleEntry> byId)
        {
            var seen = new HashSet<string>();
            var stack = new Stack<string>(start.manifest.dependencies);
            while (stack.Count > 0)
            {
                var id = stack.Pop();
                if (id == start.manifest.id) return true;
                if (!seen.Add(id) || !byId.TryGetValue(id, out var next)) continue;
                foreach (var d in next.manifest.dependencies) stack.Push(d);
            }
            return false;
        }
    }
}
