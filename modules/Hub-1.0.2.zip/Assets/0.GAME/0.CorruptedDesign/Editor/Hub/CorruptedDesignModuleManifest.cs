using System;
using CorruptedDesign.Registry;

namespace CorruptedDesign.Hub
{
    /// <summary>Contents of a module's <c>corrupteddesign.module.json</c>.</summary>
    [Serializable]
    public class CorruptedDesignModuleManifest
    {
        public string id;
        public string name;
        public string version;
        public string description;
        public string[] dependencies = Array.Empty<string>();
        public string[] namespaces = Array.Empty<string>();
        public string docs;
        public CorruptedDesignDefineInfo[] defines = Array.Empty<CorruptedDesignDefineInfo>();
        public string[] companions = Array.Empty<string>();
        public string[] paths = Array.Empty<string>();
        public RegistryRequirement[] requires = Array.Empty<RegistryRequirement>();
        public RegistryPackage[] packages = Array.Empty<RegistryPackage>();
    }

    /// <summary>One scripting define symbol a module reacts to, and what it changes.</summary>
    [Serializable]
    public class CorruptedDesignDefineInfo
    {
        public string symbol;
        public string effect;
        public string setBy;
    }

    public enum CorruptedDesignModuleStatus
    {
        Ok,
        MissingManifest,
        InvalidManifest,
        MissingDependency,
        Cycle,
    }

    public class CorruptedDesignModuleEntry
    {
        public string folder;
        public CorruptedDesignModuleManifest manifest;
        public CorruptedDesignModuleStatus status;
        public string statusDetail = string.Empty;
        public int fileCount;
        public int lineCount;

        public string DisplayName => manifest != null && !string.IsNullOrEmpty(manifest.name)
            ? manifest.name
            : System.IO.Path.GetFileName(folder);
    }
}
