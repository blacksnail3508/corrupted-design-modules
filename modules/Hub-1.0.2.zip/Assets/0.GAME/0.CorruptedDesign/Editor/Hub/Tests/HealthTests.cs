using System.IO;
using System.Linq;
using NUnit.Framework;

namespace CorruptedDesign.Hub.Tests
{
    public class HealthTests
    {
        private const string KnownGuid = "0123456789abcdef0123456789abcdef";
        private const string GoneGuid = "fedcba9876543210fedcba9876543210";

        private string root;

        [SetUp]
        public void SetUp()
        {
            root = Path.Combine(Path.GetTempPath(), "CorruptedDesignHealthTests_" + System.Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(Path.Combine(root, "Assets"));
            File.WriteAllText(Path.Combine(root, "Assets", "Known.cs.meta"), "fileFormatVersion: 2\nguid: " + KnownGuid + "\n");
        }

        [TearDown]
        public void TearDown()
        {
            if (Directory.Exists(root)) Directory.Delete(root, true);
        }

        private void Prefab(string name, string scriptLine) =>
            File.WriteAllText(Path.Combine(root, "Assets", name), "MonoBehaviour:\n  m_Script: " + scriptLine + "\n");

        [Test]
        public void FindMissingScripts_IgnoresPrefabWithKnownScript()
        {
            Prefab("ok.prefab", "{fileID: 11500000, guid: " + KnownGuid + ", type: 3}");

            Assert.IsEmpty(CorruptedDesignHealthChecks.FindMissingScripts(root, "Assets"));
        }

        [Test]
        public void FindMissingScripts_Detects_DeletedScript_And_UnknownGuid()
        {
            Prefab("deleted.prefab", "{fileID: 0}");
            Prefab("gone.prefab", "{fileID: 11500000, guid: " + GoneGuid + ", type: 3}");

            var found = CorruptedDesignHealthChecks.FindMissingScripts(root, "Assets");

            Assert.AreEqual(2, found.Count);
            Assert.IsTrue(found.Any(f => f.StartsWith("Assets/deleted.prefab")));
            Assert.IsTrue(found.Any(f => f.StartsWith("Assets/gone.prefab")));
        }

        [Test]
        public void FindMissingScripts_IgnoresPrecompiledScripts_AndMissingFolder()
        {
            Prefab("dll.prefab", "{fileID: 12388, guid: 00000000000000e0f000000000000000, type: 0}");

            Assert.IsEmpty(CorruptedDesignHealthChecks.FindMissingScripts(root, "Assets", "Nope"));
        }

        [Test]
        public void ScenesMissingFrom_ReturnsScenesNotInBuild()
        {
            var missing = CorruptedDesignHealthChecks.ScenesMissingFrom(new[] { "A.unity", "B.unity" }, new[] { "A.unity" });

            CollectionAssert.AreEqual(new[] { "B.unity" }, missing);
        }

        [Test]
        public void UnresolvedModules_ListsOnlyNonOk()
        {
            var entries = new[]
            {
                new CorruptedDesignModuleEntry { folder = "A", status = CorruptedDesignModuleStatus.Ok },
                new CorruptedDesignModuleEntry { folder = "B", status = CorruptedDesignModuleStatus.Cycle, statusDetail = "dependency cycle" },
            };

            var list = CorruptedDesignHealthChecks.UnresolvedModules(entries);

            Assert.AreEqual(1, list.Count);
            StringAssert.Contains("Cycle", list[0]);
        }

        [Test]
        public void PluginScanner_ReadsFoldersAndManifest()
        {
            Directory.CreateDirectory(Path.Combine(root, "Assets", "Plugins", "Sirenix"));
            Directory.CreateDirectory(Path.Combine(root, "Packages"));
            File.WriteAllText(Path.Combine(root, "Packages", "manifest.json"),
                "{\"dependencies\":{\"com.unity.addressables\":\"2.9.1\",\"com.cysharp.unitask\":\"https://x.git?path=a#2.5.10\"}}");

            var plugins = CorruptedDesignPluginScanner.Scan(root);

            Assert.IsTrue(plugins.First(p => p.name == "Odin Inspector").present);
            Assert.IsFalse(plugins.First(p => p.name == "Spine Runtime").present);
            Assert.AreEqual("2.9.1", plugins.First(p => p.name == "Addressables").version);
            Assert.AreEqual("2.5.10", plugins.First(p => p.name == "UniTask").version);
            Assert.IsFalse(plugins.First(p => p.name == "Input System").present);
        }

        [Test]
        public void ToolScanner_FindsProjectMenuTools_AndSkipsHubItself()
        {
            var tools = CorruptedDesignToolScanner.Scan();

            Assert.IsTrue(tools.Any(t => t.menuPath == "CorruptedDesign/Vault Editor"));
            Assert.IsFalse(tools.Any(t => t.menuPath == "CorruptedDesign/Hub"));
            Assert.IsTrue(tools.Any(t => !t.isProject), "Menus from precompiled plugin DLLs (DOTween, Odin...) should be listed too");
        }

        [Test]
        public void AssetCreator_FindsCreateAssetMenuTypes()
        {
            var types = CorruptedDesignAssetCreator.Scan();

            Assert.IsTrue(types.Any(t => t.menuName == "SO/Audio Library"));
        }

        [Test]
        public void RealProject_EveryModuleIsOk()
        {
            var entries = CorruptedDesignModuleRegistry.Scan(System.IO.Path.Combine(UnityEngine.Application.dataPath, "0.GAME", "0.CorruptedDesign"));

            Assert.IsNotEmpty(entries);
            Assert.IsEmpty(CorruptedDesignHealthChecks.UnresolvedModules(entries));
        }

        [Test]
        public void RealProject_HasNoMissingScripts()
        {
            var root = System.IO.Path.GetDirectoryName(UnityEngine.Application.dataPath);

            Assert.IsEmpty(CorruptedDesignHealthChecks.FindMissingScripts(root, "Assets/0.GAME", "Assets/Scenes"));
        }
    }
}
