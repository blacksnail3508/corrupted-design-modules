using System.Reflection;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace CorruptedDesign.Hub.Tests
{
    public class HubWindowTests
    {
        private static readonly ICorruptedDesignHubTab[] Tabs =
        {
            new CorruptedDesignModulesTab(),
            new CorruptedDesignPluginsTab(),
            new CorruptedDesignToolsTab(),
            new CorruptedDesignCreateTab(),
            new CorruptedDesignHealthTab(),
        };

        [Test]
        public void EveryTab_BuildsContent_WithoutErrors()
        {
            foreach (var tab in Tabs)
            {
                var content = tab.Build();

                Assert.IsNotNull(content, tab.Title + " returned no content");
                Assert.Greater(content.childCount, 0, tab.Title + " built an empty tab");
            }

            LogAssert.NoUnexpectedReceived();
        }

        [Test]
        public void Window_CreateGUI_BuildsEveryTab_WithoutErrors()
        {
            var window = ScriptableObject.CreateInstance<CorruptedDesignHubWindow>();
            try
            {
                typeof(CorruptedDesignHubWindow).GetMethod("CreateGUI", BindingFlags.NonPublic | BindingFlags.Instance).Invoke(window, null);

                Assert.Greater(window.rootVisualElement.childCount, 0);
                LogAssert.NoUnexpectedReceived();
            }
            finally
            {
                Object.DestroyImmediate(window);
            }
        }
    }
}
