using Pixon.Registry;
using UnityEngine.UIElements;

namespace Pixon.Hub
{
    /// <summary>Hub tab that installs, updates and removes modules from the catalog.</summary>
    public class PixonRegistryTab : IPixonHubTab
    {
        public string Title => "Registry";

        public VisualElement Build()
        {
            VisualElement container = null;
            var view = new PixonRegistryView(() => container?.MarkDirtyRepaint());
            container = new IMGUIContainer(view.Draw) { style = { flexGrow = 1 } };
            return container;
        }
    }
}
