using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace Pixon.Hub
{
    /// <summary>Editor window that lists the Pixon modules, plugins, tools and ScriptableObjects of the project and checks its health.</summary>
    public class PixonHubWindow : EditorWindow
    {
        private readonly List<IPixonHubTab> tabs = new();

        private VisualElement tabBar;
        private VisualElement body;
        private int selected;
        private string pendingTab;

        public static string ProjectRoot => Path.GetDirectoryName(Application.dataPath);

        public static string PixonRoot => Path.Combine(Application.dataPath, "0.GAME", "0.Pixon");

        [MenuItem("Pixon/Hub", priority = 0)]
        public static void Open()
        {
            var window = GetWindow<PixonHubWindow>("Pixon Hub");
            window.minSize = new Vector2(760f, 480f);
        }

        /// <summary>Opens the Hub on the tab with this title, such as <c>"Registry"</c>.</summary>
        public static void OpenTab(string title)
        {
            var window = GetWindow<PixonHubWindow>("Pixon Hub");
            window.minSize = new Vector2(760f, 480f);
            window.ShowTab(title);
        }

        private void ShowTab(string title)
        {
            int index = tabs.FindIndex(tab => tab.Title == title);
            if (index >= 0 && tabBar != null) Show(index);
            else pendingTab = title;
        }

        private void CreateGUI()
        {
            tabs.Clear();
            tabs.Add(new PixonModulesTab());
            tabs.Add(new PixonRegistryTab());
            tabs.Add(new PixonPluginsTab());
            tabs.Add(new PixonToolsTab());
            tabs.Add(new PixonCreateTab());
            tabs.Add(new PixonHealthTab());

            var root = rootVisualElement;
            root.Clear();
            root.style.paddingLeft = root.style.paddingRight = 12;
            root.style.paddingTop = 10;

            root.Add(BuildHeader());
            tabBar = new VisualElement { style = { flexDirection = FlexDirection.Row, marginBottom = 8 } };
            root.Add(tabBar);
            body = new VisualElement { style = { flexGrow = 1 } };
            root.Add(body);

            BuildTabBar();
            if (pendingTab != null) selected = Mathf.Max(0, tabs.FindIndex(tab => tab.Title == pendingTab));
            pendingTab = null;
            Show(selected);
        }

        private VisualElement BuildHeader()
        {
            var header = new VisualElement { style = { flexDirection = FlexDirection.Row, justifyContent = Justify.SpaceBetween, alignItems = Align.Center, marginBottom = 8 } };
            var title = new Label("Pixon Hub") { style = { fontSize = 20, unityFontStyleAndWeight = FontStyle.Bold } };
            header.Add(title);
            header.Add(new Button(() => Show(selected)) { text = "Refresh" });
            return header;
        }

        private void BuildTabBar()
        {
            tabBar.Clear();
            for (int i = 0; i < tabs.Count; i++)
            {
                int index = i;
                var button = new Button(() => Show(index)) { text = tabs[i].Title };
                button.style.minWidth = 90;
                tabBar.Add(button);
            }
        }

        private void Show(int index)
        {
            selected = index;
            for (int i = 0; i < tabBar.childCount; i++)
            {
                if (i == index) tabBar[i].style.backgroundColor = new Color(0.24f, 0.44f, 0.88f);
                else tabBar[i].style.backgroundColor = StyleKeyword.Null;
            }

            body.Clear();
            body.Add(tabs[index].Build());
        }
    }

    /// <summary>One tab of the Hub window; rebuilt every time it is shown so it always reads fresh data.</summary>
    public interface IPixonHubTab
    {
        string Title { get; }

        VisualElement Build();
    }
}
