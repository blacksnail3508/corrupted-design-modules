using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace Pixon.Hub
{
    public class PixonPluginInfo
    {
        public string name;
        public string source;
        public string version;
        public bool present;
    }

    /// <summary>Checks which third-party plugins and Unity packages the project carries, and their versions.</summary>
    public static class PixonPluginScanner
    {
        private static readonly (string name, string folder)[] Folders =
        {
            ("Odin Inspector", "Assets/Plugins/Sirenix"),
            ("DOTween", "Assets/Plugins/Demigiant/DOTween"),
            ("DOTween Pro", "Assets/Plugins/Demigiant/DOTweenPro"),
            ("Spine Runtime", "Assets/Spine"),
            ("SRDebugger", "Assets/StompyRobot"),
            ("Advanced FPS Counter", "Assets/AdvancedFPSCounter"),
            ("Lean Touch / CW", "Assets/Plugins/CW"),
            ("EnhancedScroller", "Assets/Plugins/EnhancedScroller v2"),
            ("TextMesh Pro", "Assets/TextMesh Pro"),
        };

        private static readonly (string name, string id)[] Packages =
        {
            ("Addressables", "com.unity.addressables"),
            ("Input System", "com.unity.inputsystem"),
            ("Universal RP", "com.unity.render-pipelines.universal"),
            ("Newtonsoft Json", "com.unity.nuget.newtonsoft-json"),
            ("UniTask", "com.cysharp.unitask"),
            ("Unity Purchasing", "com.unity.purchasing"),
            ("UI Effect", "com.coffee.ui-effect"),
            ("UI Particle", "com.coffee.ui-particle"),
            ("Unity UI", "com.unity.ugui"),
            ("Timeline", "com.unity.timeline"),
        };

        // Pixon's own UPM packages live on a private git registry, so the template cannot carry them; the Hub lists them as not installed.
        private static readonly (string name, string id, string used)[] PixonPackages =
        {
            ("Pixon Core", "com.pixon.core", "pb, bb v3.0.2"),
            ("Pixon Ads", "com.pixon.ads", "pb, bb v3.0.4"),
            ("Pixon Tracking", "com.pixon.tracking", "pb, bb v3.0.0"),
            ("Pixon UI", "com.pixon.ui", "pb v3.0.0"),
            ("Pixon FSM", "com.pixon.fsm", "pb v3.0.0"),
            ("Pixon In-App Purchase", "com.pixon.iap", "pb v3.0.2"),
            ("Pixon In-App Update", "com.pixon.iau", "pb v3.0.2"),
            ("Pixon Remote Config", "com.pixon.remoteconfig", "pb v3.0.0"),
            ("Pixon Google Sheet Importer", "com.pixon.googlesheet.importer", "pb v3.0.0"),
            ("Pixon Custom JsonConverters", "com.pixon.jsonconverters.custom", "pb v3.0.0"),
        };

        public static IReadOnlyList<PixonPluginInfo> Scan(string projectRoot)
        {
            var result = new List<PixonPluginInfo>();

            foreach (var (name, folder) in Folders)
            {
                bool present = Directory.Exists(Path.Combine(projectRoot, folder));
                result.Add(new PixonPluginInfo { name = name, source = "Assets", version = present ? "installed" : "-", present = present });
            }

            var manifest = ReadManifest(projectRoot);
            foreach (var (name, id) in Packages)
            {
                bool present = manifest.TryGetValue(id, out var version);
                result.Add(new PixonPluginInfo { name = name, source = "Package " + id, version = present ? ShortVersion(version) : "-", present = present });
            }

            foreach (var (name, id, used) in PixonPackages)
            {
                bool present = manifest.TryGetValue(id, out var version);
                result.Add(new PixonPluginInfo
                {
                    name = name,
                    source = present ? "Package " + id : $"{id} (private registry, used in {used})",
                    version = present ? ShortVersion(version) : "not installed",
                    present = present,
                });
            }
            return result;
        }

        // The manifest maps package ids to strings, which JsonUtility cannot read, so each pair is matched by pattern.
        private static Dictionary<string, string> ReadManifest(string projectRoot)
        {
            var map = new Dictionary<string, string>();
            var path = Path.Combine(projectRoot, "Packages", "manifest.json");
            if (!File.Exists(path)) return map;

            foreach (Match m in Regex.Matches(File.ReadAllText(path), "\"([\\w.\\-]+)\"\\s*:\\s*\"([^\"]*)\""))
                map[m.Groups[1].Value] = m.Groups[2].Value;
            return map;
        }

        private static string ShortVersion(string version)
        {
            int hash = version.LastIndexOf('#');
            return hash >= 0 ? version.Substring(hash + 1) : version;
        }
    }
}
