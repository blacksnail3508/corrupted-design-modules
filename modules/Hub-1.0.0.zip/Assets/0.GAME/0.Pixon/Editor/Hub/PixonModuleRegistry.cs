using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace Pixon.Hub
{
    /// <summary>Scans the Pixon root for modules (one folder each, described by <c>pixon.module.json</c>). Never throws.</summary>
    public static class PixonModuleRegistry
    {
        public const string ManifestFileName = "pixon.module.json";

        private static readonly string[] IgnoredFolders = { "Editor" };

        public static IReadOnlyList<PixonModuleEntry> Scan(string pixonRootFolder)
        {
            var entries = new List<PixonModuleEntry>();
            if (string.IsNullOrEmpty(pixonRootFolder) || !Directory.Exists(pixonRootFolder)) return entries;

            foreach (var dir in Directory.GetDirectories(pixonRootFolder).OrderBy(d => d, StringComparer.OrdinalIgnoreCase))
            {
                if (IgnoredFolders.Contains(Path.GetFileName(dir))) continue;
                entries.Add(ReadEntry(dir));
            }

            ResolveDependencies(entries);
            return entries;
        }

        private static PixonModuleEntry ReadEntry(string dir)
        {
            var entry = new PixonModuleEntry { folder = dir };
            (entry.fileCount, entry.lineCount) = PixonModuleStats.Count(dir);

            var manifestPath = Path.Combine(dir, ManifestFileName);
            if (!File.Exists(manifestPath))
            {
                entry.status = PixonModuleStatus.MissingManifest;
                entry.statusDetail = ManifestFileName + " not found";
                return entry;
            }

            try
            {
                var manifest = JsonUtility.FromJson<PixonModuleManifest>(File.ReadAllText(manifestPath));
                if (manifest == null || string.IsNullOrEmpty(manifest.id)) throw new FormatException("id is empty");
                manifest.dependencies ??= Array.Empty<string>();
                manifest.namespaces ??= Array.Empty<string>();
                manifest.origin ??= Array.Empty<string>();
                entry.manifest = manifest;
            }
            catch (Exception e)
            {
                entry.status = PixonModuleStatus.InvalidManifest;
                entry.statusDetail = e.Message;
            }
            return entry;
        }

        private static void ResolveDependencies(List<PixonModuleEntry> entries)
        {
            var valid = entries.Where(e => e.manifest != null).ToList();
            var byId = new Dictionary<string, PixonModuleEntry>();
            foreach (var e in valid) byId[e.manifest.id] = e;

            foreach (var e in valid)
            {
                var missing = e.manifest.dependencies.Where(d => !byId.ContainsKey(d)).ToList();
                if (missing.Count == 0) continue;
                e.status = PixonModuleStatus.MissingDependency;
                e.statusDetail = "missing: " + string.Join(", ", missing);
            }

            foreach (var e in valid)
            {
                if (e.status != PixonModuleStatus.Ok) continue;
                if (!ReachesItself(e, byId)) continue;
                e.status = PixonModuleStatus.Cycle;
                e.statusDetail = "dependency cycle";
            }
        }

        private static bool ReachesItself(PixonModuleEntry start, Dictionary<string, PixonModuleEntry> byId)
        {
            var seen = new HashSet<string>();
            var stack = new Stack<string>(start.manifest.dependencies);
            while (stack.Count > 0)
            {
                var id = stack.Pop();
                if (id == start.manifest.id) return true;
                if (!seen.Add(id) || !byId.TryGetValue(id, out var next)) continue;
                foreach (var d in next.manifest.dependencies) stack.Push(d);
            }
            return false;
        }
    }
}
