using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using NUnit.Framework;
using Pixon.Hub;
using Pixon.Registry;

namespace Pixon.Hub.Tests
{
    public class RegistryInstallerTests
    {
        private string temp;
        private string source;
        private string target;
        private string output;

        [SetUp]
        public void SetUp()
        {
            temp = Path.Combine(Path.GetTempPath(), "PixonRegistryTests_" + Guid.NewGuid().ToString("N"));
            source = Path.Combine(temp, "source");
            target = Path.Combine(temp, "target");
            output = Path.Combine(temp, "out");
            Directory.CreateDirectory(Path.Combine(target, "Assets", "0.GAME", "0.Pixon"));
            Directory.CreateDirectory(Path.Combine(target, "Packages"));
            File.WriteAllText(Path.Combine(target, "Packages", "manifest.json"), "{\n  \"dependencies\": {\n    \"com.unity.ugui\": \"2.0.0\"\n  }\n}");
        }

        [TearDown]
        public void TearDown()
        {
            if (Directory.Exists(temp)) Directory.Delete(temp, true);
        }

        private string PixonRoot => Path.Combine(source, "Assets", "0.GAME", "0.Pixon");

        private void Module(string folder, string id, string version, string code, params string[] dependencies)
        {
            var dir = Path.Combine(PixonRoot, folder);
            Directory.CreateDirectory(dir);
            File.WriteAllText(Path.Combine(dir, "pixon.module.json"), "{\"id\":\"" + id + "\",\"name\":\"" + id + "\",\"version\":\"" + version + "\",\"dependencies\":[" + string.Join(",", dependencies.Select(d => "\"" + d + "\"")) + "]}");
            File.WriteAllText(Path.Combine(dir, id + ".cs"), code);
            File.WriteAllText(dir + ".meta", "guid: " + id);
        }

        private RegistryCatalog Publish() => PixonRegistryPublisher.Publish(source, PixonRoot, output);

        private byte[] Zip(RegistryModule module) => File.ReadAllBytes(Path.Combine(output, module.zip));

        private RegistryModule Find(RegistryCatalog catalog, string id) => catalog.modules.First(m => m.id == id);

        [Test]
        public void Publish_WritesCatalogAndZips_AndRepublishIsStable()
        {
            Module("0.A", "A", "1.0.0", "class A {}");
            Module("1.B", "B", "1.0.0", "class B {}", "A");

            var first = Publish();
            var again = Publish();

            Assert.AreEqual(2, first.modules.Length);
            Assert.AreEqual("Assets/0.GAME/0.Pixon/1.B", Find(first, "B").installPath);
            Assert.AreEqual("modules/A-1.0.0.zip", Find(first, "A").zip);
            Assert.AreEqual(Find(first, "A").sha256, Find(again, "A").sha256);
            Assert.IsTrue(File.Exists(Path.Combine(output, "catalog.json")));
        }

        [Test]
        public void Publish_ChangedContentWithSameVersion_Throws()
        {
            Module("0.A", "A", "1.0.0", "class A {}");
            Publish();
            Module("0.A", "A", "1.0.0", "class A { int x; }");

            var e = Assert.Throws<InvalidOperationException>(() => Publish());
            StringAssert.Contains("bump", e.Message);
        }

        [Test]
        public void Install_WritesFilesAndRecordsThemInTheLock()
        {
            Module("0.A", "A", "1.0.0", "class A {}");
            var a = Find(Publish(), "A");

            PixonInstaller.Install(target, a, Zip(a));

            Assert.IsTrue(File.Exists(Path.Combine(target, "Assets/0.GAME/0.Pixon/0.A/A.cs")));
            Assert.IsTrue(File.Exists(Path.Combine(target, "Assets/0.GAME/0.Pixon/0.A.meta")));
            var installed = PixonInstaller.ReadLock(target).Find("A");
            Assert.AreEqual("1.0.0", installed.version);
            Assert.IsTrue(installed.files.Any(f => f.path == "Assets/0.GAME/0.Pixon/0.A/A.cs"));
            Assert.AreEqual(ModuleState.Installed, PixonInstaller.GetState(target, a, PixonInstaller.ReadLock(target)));
        }

        [Test]
        public void Install_RejectsWrongHash_AndZipSlip()
        {
            Module("0.A", "A", "1.0.0", "class A {}");
            var a = Find(Publish(), "A");

            a.sha256 = "00";
            Assert.Throws<InvalidOperationException>(() => PixonInstaller.Install(target, a, Zip(a)));

            using var stream = new MemoryStream();
            using (var archive = new ZipArchive(stream, ZipArchiveMode.Create, true))
                using (var writer = new StreamWriter(archive.CreateEntry("0.A/../../evil.txt").Open())) writer.Write("x");
            var evil = new RegistryModule { id = "A", version = "1.0.0", installPath = "Assets/0.GAME/0.Pixon/0.A" };
            Assert.Throws<InvalidOperationException>(() => PixonInstaller.Install(target, evil, stream.ToArray()));
            Assert.IsFalse(File.Exists(Path.Combine(target, "Assets", "0.GAME", "evil.txt")));
        }

        [Test]
        public void Install_OverUnmanagedFolder_NeedsReplace_AndKeepsABackup()
        {
            Module("0.A", "A", "1.0.0", "class A {}");
            var a = Find(Publish(), "A");
            var existing = Path.Combine(target, "Assets/0.GAME/0.Pixon/0.A");
            Directory.CreateDirectory(existing);
            File.WriteAllText(Path.Combine(existing, "mine.cs"), "hand copied");

            Assert.AreEqual(ModuleState.Unmanaged, PixonInstaller.GetState(target, a, new InstallLock()));
            Assert.Throws<InvalidOperationException>(() => PixonInstaller.Install(target, a, Zip(a)));

            PixonInstaller.Install(target, a, Zip(a), true);

            Assert.IsFalse(File.Exists(Path.Combine(existing, "mine.cs")));
            Assert.IsTrue(Directory.GetFiles(Path.Combine(target, PixonInstaller.TrashFolder), "mine.cs", SearchOption.AllDirectories).Length == 1);
        }

        [Test]
        public void Adopt_TakesOverAHandCopiedFolder()
        {
            Module("0.A", "A", "1.0.0", "class A {}");
            var a = Find(Publish(), "A");
            var existing = Path.Combine(target, "Assets/0.GAME/0.Pixon/0.A");
            Directory.CreateDirectory(existing);
            File.WriteAllText(Path.Combine(existing, "A.cs"), "class A {}");

            PixonInstaller.Adopt(target, a);

            Assert.AreEqual(ModuleState.Installed, PixonInstaller.GetState(target, a, PixonInstaller.ReadLock(target)));
        }

        [Test]
        public void State_GoesModified_ThenUpdateAvailable_WhenCatalogMovesOn()
        {
            Module("0.A", "A", "1.0.0", "class A {}");
            var v1 = Find(Publish(), "A");
            PixonInstaller.Install(target, v1, Zip(v1));

            File.AppendAllText(Path.Combine(target, "Assets/0.GAME/0.Pixon/0.A/A.cs"), "// edit");
            Assert.AreEqual(ModuleState.Modified, PixonInstaller.GetState(target, v1, PixonInstaller.ReadLock(target)));

            PixonInstaller.Install(target, v1, Zip(v1));
            Module("0.A", "A", "1.1.0", "class A { int y; }");
            var v2 = Find(Publish(), "A");
            Assert.AreEqual(ModuleState.UpdateAvailable, PixonInstaller.GetState(target, v2, PixonInstaller.ReadLock(target)));

            PixonInstaller.Install(target, v2, Zip(v2));
            StringAssert.Contains("int y", File.ReadAllText(Path.Combine(target, "Assets/0.GAME/0.Pixon/0.A/A.cs")));
            Assert.AreEqual("1.1.0", PixonInstaller.ReadLock(target).Find("A").version);
        }

        [Test]
        public void Uninstall_MovesFilesToTrash_ReportsLeftovers_AndBlocksOnDependents()
        {
            Module("0.A", "A", "1.0.0", "class A {}");
            Module("1.B", "B", "1.0.0", "class B {}", "A");
            var catalog = Publish();
            PixonInstaller.Install(target, Find(catalog, "A"), Zip(Find(catalog, "A")));
            PixonInstaller.Install(target, Find(catalog, "B"), Zip(Find(catalog, "B")));

            var blocked = Assert.Throws<InvalidOperationException>(() => PixonInstaller.Uninstall(target, "A"));
            StringAssert.Contains("B", blocked.Message);

            File.WriteAllText(Path.Combine(target, "Assets/0.GAME/0.Pixon/1.B/extra.cs"), "mine");
            var leftover = PixonInstaller.Uninstall(target, "B");

            Assert.AreEqual(1, leftover.Count);
            Assert.IsFalse(File.Exists(Path.Combine(target, "Assets/0.GAME/0.Pixon/1.B/B.cs")));
            Assert.IsNull(PixonInstaller.ReadLock(target).Find("B"));

            Assert.AreEqual(0, PixonInstaller.Uninstall(target, "A").Count);
            Assert.IsFalse(Directory.Exists(Path.Combine(target, "Assets/0.GAME/0.Pixon/0.A")));
        }

        [Test]
        public void Closure_PutsDependenciesFirst_ToleratesCycles_AndReportsMissing()
        {
            var catalog = new RegistryCatalog
            {
                modules = new[]
                {
                    new RegistryModule { id = "UI", dependencies = new[] { "Core" } },
                    new RegistryModule { id = "Core", dependencies = new[] { "UI" } },
                    new RegistryModule { id = "Game", dependencies = new[] { "UI", "Ghost" } },
                },
            };

            var closure = PixonInstaller.Closure(catalog, new[] { "Game" }, out var missing);

            CollectionAssert.AreEquivalent(new[] { "UI", "Core", "Game" }, closure.Select(m => m.id));
            Assert.AreEqual("Game", closure.Last().id);
            CollectionAssert.AreEqual(new[] { "Ghost" }, missing);
        }

        [Test]
        public void EnsurePackages_AddsMissingOnly_AndKeepsTheManifestValid()
        {
            var added = PixonInstaller.EnsurePackages(target, new[]
            {
                new RegistryPackage { id = "com.unity.ugui", version = "9.9.9" },
                new RegistryPackage { id = "com.unity.purchasing", version = "5.3.0" },
                new RegistryPackage { id = "com.unity.purchasing", version = "5.3.0" },
            });

            CollectionAssert.AreEqual(new[] { "com.unity.purchasing" }, added);
            var text = File.ReadAllText(Path.Combine(target, "Packages", "manifest.json"));
            StringAssert.Contains("\"com.unity.ugui\": \"2.0.0\"", text);
            StringAssert.Contains("\"com.unity.purchasing\": \"5.3.0\",", text);
            Assert.AreEqual(1, System.Text.RegularExpressions.Regex.Matches(text, "com.unity.purchasing").Count);
        }

        [Test]
        public void MissingRequirements_UsesTheProbe()
        {
            var module = new RegistryModule { requires = new[] { new RegistryRequirement { name = "Odin", probe = "Sirenix.Nope" }, new RegistryRequirement { name = "System", probe = "System.String" } } };

            var missing = PixonInstaller.MissingRequirements(module, PixonInstaller.TypeExists);

            Assert.AreEqual("Odin", missing.Single().name);
        }

        [Test]
        public void CompareVersions_IsNumericPerPart()
        {
            Assert.Less(PixonInstaller.CompareVersions("1.9.0", "1.10.0"), 0);
            Assert.AreEqual(0, PixonInstaller.CompareVersions("1.0", "1.0.0"));
            Assert.Greater(PixonInstaller.CompareVersions("2.0.0", "1.99.99"), 0);
        }
    }
}
