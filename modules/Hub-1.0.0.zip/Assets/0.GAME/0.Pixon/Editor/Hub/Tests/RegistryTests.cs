using System.Collections.Generic;
using System.IO;
using System.Linq;
using NUnit.Framework;

namespace Pixon.Hub.Tests
{
    public class RegistryTests
    {
        private string root;

        [SetUp]
        public void SetUp()
        {
            root = Path.Combine(Path.GetTempPath(), "PixonHubTests_" + System.Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(root);
        }

        [TearDown]
        public void TearDown()
        {
            if (Directory.Exists(root)) Directory.Delete(root, true);
        }

        private string Module(string folder, string json, params (string file, string content)[] files)
        {
            var dir = Path.Combine(root, folder);
            Directory.CreateDirectory(dir);
            if (json != null) File.WriteAllText(Path.Combine(dir, PixonModuleRegistry.ManifestFileName), json);
            foreach (var f in files) File.WriteAllText(Path.Combine(dir, f.file), f.content);
            return dir;
        }

        private static string Json(string id, params string[] deps) =>
            "{\"id\":\"" + id + "\",\"name\":\"" + id + "\",\"version\":\"1.0.0\",\"dependencies\":[" +
            string.Join(",", deps.Select(d => "\"" + d + "\"")) + "]}";

        private static PixonModuleEntry Get(IReadOnlyList<PixonModuleEntry> list, string folder) =>
            list.First(e => Path.GetFileName(e.folder) == folder);

        [Test]
        public void Scan_ValidModules_AllOk()
        {
            Module("0.A", Json("A"), ("a.cs", "class A {}\nclass A2 {}\n"));
            Module("1.B", Json("B", "A"), ("b.cs", "class B {}\n"));

            var list = PixonModuleRegistry.Scan(root);

            Assert.AreEqual(2, list.Count);
            Assert.IsTrue(list.All(e => e.status == PixonModuleStatus.Ok));
            Assert.AreEqual(1, Get(list, "0.A").fileCount);
            Assert.AreEqual(2, Get(list, "0.A").lineCount);
        }

        [Test]
        public void Scan_FolderWithoutManifest_IsMissingManifest()
        {
            Module("0.A", null, ("a.cs", "class A {}"));

            var list = PixonModuleRegistry.Scan(root);

            Assert.AreEqual(PixonModuleStatus.MissingManifest, list[0].status);
        }

        [Test]
        public void Scan_MalformedJson_IsInvalidManifest_AndOthersStillListed()
        {
            Module("0.A", "{ not json");
            Module("1.B", Json("B"));

            var list = PixonModuleRegistry.Scan(root);

            Assert.AreEqual(2, list.Count);
            Assert.AreEqual(PixonModuleStatus.InvalidManifest, Get(list, "0.A").status);
            Assert.AreEqual(PixonModuleStatus.Ok, Get(list, "1.B").status);
        }

        [Test]
        public void Scan_UnknownDependency_IsMissingDependency()
        {
            Module("0.A", Json("A", "Ghost"));

            var e = PixonModuleRegistry.Scan(root)[0];

            Assert.AreEqual(PixonModuleStatus.MissingDependency, e.status);
            StringAssert.Contains("Ghost", e.statusDetail);
        }

        [Test]
        public void Scan_DependencyCycle_IsCycle_AndTerminates()
        {
            Module("0.A", Json("A", "B"));
            Module("1.B", Json("B", "A"));
            Module("2.C", Json("C"));

            var list = PixonModuleRegistry.Scan(root);

            Assert.AreEqual(PixonModuleStatus.Cycle, Get(list, "0.A").status);
            Assert.AreEqual(PixonModuleStatus.Cycle, Get(list, "1.B").status);
            Assert.AreEqual(PixonModuleStatus.Ok, Get(list, "2.C").status);
        }

        [Test]
        public void Scan_IgnoresEditorFolder_AndMissingRoot()
        {
            Module("Editor", null);
            Module("0.A", Json("A"));

            Assert.AreEqual(1, PixonModuleRegistry.Scan(root).Count);
            Assert.AreEqual(0, PixonModuleRegistry.Scan(Path.Combine(root, "nope")).Count);
        }

        [Test]
        public void Scan_ReadsDefines_AndDefaultsToNone()
        {
            Module("0.A", "{\"id\":\"A\",\"defines\":[{\"symbol\":\"HAS_X\",\"effect\":\"turns X on\",\"setBy\":\"Project\"}]}");
            Module("1.B", Json("B"));

            var list = PixonModuleRegistry.Scan(root);

            var define = Get(list, "0.A").manifest.defines.Single();
            Assert.AreEqual("HAS_X", define.symbol);
            Assert.AreEqual("turns X on", define.effect);
            Assert.AreEqual(0, Get(list, "1.B").manifest.defines.Length);
        }

        [Test]
        public void PublicTypes_ListsPublicDeclarations()
        {
            var dir = Module("0.A", Json("A"), ("a.cs", "public class Foo {}\ninternal class Hidden {}\npublic enum Bar { X }\npublic static class Baz {}\n"));

            var types = PixonModuleStats.PublicTypes(dir);

            CollectionAssert.AreEquivalent(new[] { "Foo", "Bar", "Baz" }, types);
        }
    }
}
