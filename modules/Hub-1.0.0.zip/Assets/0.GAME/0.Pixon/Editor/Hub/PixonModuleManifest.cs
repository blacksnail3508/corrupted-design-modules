using System;
using Pixon.Registry;

namespace Pixon.Hub
{
    /// <summary>Contents of a module's <c>pixon.module.json</c>.</summary>
    [Serializable]
    public class PixonModuleManifest
    {
        public string id;
        public string name;
        public string version;
        public string description;
        public string[] dependencies = Array.Empty<string>();
        public string[] namespaces = Array.Empty<string>();
        public string docs;
        public string[] origin = Array.Empty<string>();
        public PixonDefineInfo[] defines = Array.Empty<PixonDefineInfo>();
        public string[] companions = Array.Empty<string>();
        public string[] paths = Array.Empty<string>();
        public RegistryRequirement[] requires = Array.Empty<RegistryRequirement>();
        public RegistryPackage[] packages = Array.Empty<RegistryPackage>();
    }

    /// <summary>One scripting define symbol a module reacts to, and what it changes.</summary>
    [Serializable]
    public class PixonDefineInfo
    {
        public string symbol;
        public string effect;
        public string setBy;
    }

    public enum PixonModuleStatus
    {
        Ok,
        MissingManifest,
        InvalidManifest,
        MissingDependency,
        Cycle,
    }

    public class PixonModuleEntry
    {
        public string folder;
        public PixonModuleManifest manifest;
        public PixonModuleStatus status;
        public string statusDetail = string.Empty;
        public int fileCount;
        public int lineCount;

        public string DisplayName => manifest != null && !string.IsNullOrEmpty(manifest.name)
            ? manifest.name
            : System.IO.Path.GetFileName(folder);
    }
}
