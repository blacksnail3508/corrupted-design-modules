using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace Pixon.Hub
{
    /// <summary>Project checks the Health tab runs. They read files directly, so they never load or dirty a scene.</summary>
    public static class PixonHealthChecks
    {
        private static readonly Regex ScriptRef = new(@"m_Script: \{fileID: (-?\d+)(?:, guid: ([0-9a-f]{32}))?", RegexOptions.Compiled);
        private static readonly Regex GuidLine = new(@"^guid: ([0-9a-f]{32})", RegexOptions.Multiline | RegexOptions.Compiled);

        /// <summary>Lists prefabs and scenes under <paramref name="assetsFolder"/> that point to a script that no longer exists, as "path (count)".</summary>
        public static IReadOnlyList<string> FindMissingScripts(string projectRoot, params string[] assetsFolders)
        {
            var known = IndexScriptGuids(projectRoot);
            var found = new List<string>();

            foreach (var folder in assetsFolders)
            {
                var full = Path.Combine(projectRoot, folder);
                if (!Directory.Exists(full)) continue;

                foreach (var path in Directory.EnumerateFiles(full, "*.*", SearchOption.AllDirectories).Where(IsYamlAsset))
                {
                    int missing = CountMissing(File.ReadAllText(path), known);
                    if (missing > 0) found.Add($"{Relative(projectRoot, path)} ({missing})");
                }
            }
            return found;
        }

        /// <summary>Returns the scenes of <paramref name="expected"/> that are not listed in <paramref name="inBuild"/>.</summary>
        public static IReadOnlyList<string> ScenesMissingFrom(IEnumerable<string> expected, IEnumerable<string> inBuild)
        {
            var build = new HashSet<string>(inBuild);
            return expected.Where(s => !build.Contains(s)).ToList();
        }

        /// <summary>Returns the modules whose status is not Ok, as "name: status (detail)".</summary>
        public static IReadOnlyList<string> UnresolvedModules(IEnumerable<PixonModuleEntry> entries) =>
            entries.Where(e => e.status != PixonModuleStatus.Ok).Select(e => $"{e.DisplayName}: {e.status} ({e.statusDetail})").ToList();

        private static bool IsYamlAsset(string path) => path.EndsWith(".prefab") || path.EndsWith(".unity");

        private static string Relative(string root, string path) => path.Substring(root.Length).TrimStart('\\', '/').Replace('\\', '/');

        // fileID 0 is a script that was deleted; fileID 11500000 with an unknown guid is a script file that is gone.
        private static int CountMissing(string yaml, HashSet<string> known)
        {
            int missing = 0;
            foreach (Match m in ScriptRef.Matches(yaml))
            {
                var fileId = m.Groups[1].Value;
                if (fileId == "0") missing++;
                else if (fileId == "11500000" && m.Groups[2].Success && !known.Contains(m.Groups[2].Value)) missing++;
            }
            return missing;
        }

        private static HashSet<string> IndexScriptGuids(string projectRoot)
        {
            var guids = new HashSet<string>();
            foreach (var folder in new[] { "Assets", "Packages", Path.Combine("Library", "PackageCache") })
            {
                var full = Path.Combine(projectRoot, folder);
                if (!Directory.Exists(full)) continue;

                foreach (var meta in Directory.EnumerateFiles(full, "*.cs.meta", SearchOption.AllDirectories))
                {
                    var match = GuidLine.Match(File.ReadAllText(meta));
                    if (match.Success) guids.Add(match.Groups[1].Value);
                }
            }
            return guids;
        }
    }
}
