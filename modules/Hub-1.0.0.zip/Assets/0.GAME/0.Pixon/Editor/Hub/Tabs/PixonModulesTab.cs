using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace Pixon.Hub
{
    /// <summary>Module list on the left, details of the selected module on the right.</summary>
    public class PixonModulesTab : IPixonHubTab
    {
        private static readonly Color Ok = new(0.30f, 0.75f, 0.50f);
        private static readonly Color Bad = new(0.90f, 0.40f, 0.40f);

        private IReadOnlyList<PixonModuleEntry> entries;
        private ScrollView detail;

        public string Title => "Modules";

        public VisualElement Build()
        {
            entries = PixonModuleRegistry.Scan(PixonHubWindow.PixonRoot);

            var root = new VisualElement { style = { flexDirection = FlexDirection.Row, flexGrow = 1 } };

            var list = new ListView(entries.ToList(), 28, MakeItem, BindItem)
            {
                selectionType = SelectionType.Single,
                style = { width = 240, flexShrink = 0, marginRight = 10 },
            };
            list.selectionChanged += objects => ShowDetail(objects.OfType<PixonModuleEntry>().FirstOrDefault());
            root.Add(list);

            detail = new ScrollView { style = { flexGrow = 1 } };
            root.Add(detail);

            if (entries.Count > 0) list.SetSelection(0);
            else detail.Add(new Label($"No modules found in {PixonHubWindow.PixonRoot}"));
            return root;
        }

        #region LIST
        private VisualElement MakeItem()
        {
            var row = new VisualElement { style = { flexDirection = FlexDirection.Row, alignItems = Align.Center, paddingLeft = 6 } };
            row.Add(new VisualElement { name = "dot", style = { width = 10, height = 10, marginRight = 8, borderTopLeftRadius = 5, borderTopRightRadius = 5, borderBottomLeftRadius = 5, borderBottomRightRadius = 5 } });
            row.Add(new Label { name = "name" });
            return row;
        }

        private void BindItem(VisualElement row, int index)
        {
            var entry = entries[index];
            row.Q("dot").style.backgroundColor = entry.status == PixonModuleStatus.Ok ? Ok : Bad;
            row.Q<Label>("name").text = entry.DisplayName;
        }
        #endregion

        #region DETAIL
        private void ShowDetail(PixonModuleEntry entry)
        {
            detail.Clear();
            if (entry == null) return;

            detail.Add(new Label(entry.DisplayName) { style = { fontSize = 18, unityFontStyleAndWeight = FontStyle.Bold } });
            var status = new Label(entry.status == PixonModuleStatus.Ok ? "OK" : $"{entry.status}: {entry.statusDetail}");
            status.style.color = entry.status == PixonModuleStatus.Ok ? Ok : Bad;
            status.style.marginBottom = 6;
            detail.Add(status);

            var manifest = entry.manifest;
            if (manifest != null)
            {
                detail.Add(Field("Version", manifest.version));
                detail.Add(Field("Description", manifest.description));
                detail.Add(Field("Origin", string.Join(", ", manifest.origin)));
                detail.Add(Field("Dependencies", manifest.dependencies.Length == 0 ? "none" : string.Join(", ", manifest.dependencies)));
                detail.Add(Field("Namespaces", string.Join(", ", manifest.namespaces)));
                detail.Add(Field("Defines", manifest.defines.Length == 0
                    ? "none"
                    : string.Join(System.Environment.NewLine, manifest.defines.Select(d => $"{d.symbol}  ({d.setBy}): {d.effect}"))));
            }

            detail.Add(Field("Files / lines", $"{entry.fileCount} / {entry.lineCount:N0}"));
            detail.Add(Field("Public types", string.Join(", ", PixonModuleStats.PublicTypes(entry.folder))));

            var buttons = new VisualElement { style = { flexDirection = FlexDirection.Row, marginTop = 10 } };
            buttons.Add(new Button(() => Ping(entry)) { text = "Ping Folder" });
            buttons.Add(new Button(() => EditorUtility.RevealInFinder(entry.folder)) { text = "Show in Explorer" });
            if (manifest != null && !string.IsNullOrEmpty(manifest.docs))
                buttons.Add(new Button(() => OpenDocs(manifest.docs)) { text = "Open Docs" });
            detail.Add(buttons);
        }

        private static VisualElement Field(string name, string value)
        {
            var row = new VisualElement { style = { flexDirection = FlexDirection.Row, marginBottom = 3 } };
            row.Add(new Label(name) { style = { width = 110, flexShrink = 0, opacity = 0.65f } });
            row.Add(new Label(string.IsNullOrEmpty(value) ? "-" : value) { style = { whiteSpace = WhiteSpace.Normal, flexShrink = 1 } });
            return row;
        }

        private static void Ping(PixonModuleEntry entry)
        {
            var relative = "Assets" + entry.folder.Substring(Application.dataPath.Length).Replace('\\', '/');
            var asset = AssetDatabase.LoadAssetAtPath<Object>(relative);
            Selection.activeObject = asset;
            EditorGUIUtility.PingObject(asset);
        }

        private static void OpenDocs(string docs)
        {
            var path = Path.Combine(PixonHubWindow.ProjectRoot, docs);
            if (File.Exists(path)) EditorUtility.OpenWithDefaultApp(path);
            else Debug.LogWarning($"[Hub] Docs not found: {path}");
        }
        #endregion
    }
}
