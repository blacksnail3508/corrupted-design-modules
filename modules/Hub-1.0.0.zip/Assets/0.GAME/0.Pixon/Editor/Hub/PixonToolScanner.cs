using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.Compilation;
using Assembly = System.Reflection.Assembly;

namespace Pixon.Hub
{
    public class PixonToolInfo
    {
        public string menuPath;
        public string group;
        public string owner;
        public bool isProject;
    }

    /// <summary>Finds every <c>[MenuItem]</c> command defined by code in the project's Assets folder, so all tools can be started from the Hub.</summary>
    public static class PixonToolScanner
    {
        private const string ProjectCodeFolder = "Assets/0.GAME";
        private const string HubMenu = "Pixon/Hub";

        // Trailing hotkey text such as " %g" or " #&k" is not part of the path ExecuteMenuItem expects.
        private static readonly Regex Hotkey = new(@"\s[%#&_^][^/]*$", RegexOptions.Compiled);

        public static IReadOnlyList<PixonToolInfo> Scan()
        {
            var tools = new List<PixonToolInfo>();
            foreach (var assembly in ProjectAssemblies.All())
            {
                foreach (var type in SafeTypes(assembly.loaded))
                foreach (var method in type.GetMethods(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic))
                foreach (var attribute in method.GetCustomAttributes<MenuItem>(false))
                {
                    if (attribute.validate) continue;

                    var path = Hotkey.Replace(attribute.menuItem, string.Empty);
                    if (path.StartsWith("CONTEXT/") || path == HubMenu) continue;

                    tools.Add(new PixonToolInfo
                    {
                        menuPath = path,
                        group = path.Contains('/') ? path.Substring(0, path.IndexOf('/')) : path,
                        owner = type.Name,
                        isProject = assembly.source != null && assembly.source.sourceFiles.Any(f => f.StartsWith(ProjectCodeFolder, StringComparison.Ordinal)),
                    });
                }
            }
            return tools.OrderBy(t => t.group).ThenBy(t => t.menuPath).ToList();
        }

        public static void Run(PixonToolInfo tool) => EditorApplication.ExecuteMenuItem(tool.menuPath);

        internal static IEnumerable<Type> SafeTypes(Assembly assembly)
        {
            try { return assembly.GetTypes(); }
            catch (ReflectionTypeLoadException e) { return e.Types.Where(t => t != null); }
        }
    }

    /// <summary>The assemblies that belong to the project: those compiled from Assets sources (with their source info) and precompiled plugin DLLs inside Assets (source is null).</summary>
    internal static class ProjectAssemblies
    {
        public static IEnumerable<(UnityEditor.Compilation.Assembly source, Assembly loaded)> All() => Find(AssembliesType.Editor);

        // Dynamic assemblies have no location and throw when asked for it.
        private static bool IsUnderAssets(Assembly assembly, string assetsFolder)
        {
            try { return assembly.Location.Replace('\\', '/').StartsWith(assetsFolder, StringComparison.OrdinalIgnoreCase); }
            catch (NotSupportedException) { return false; }
        }

        private static IEnumerable<(UnityEditor.Compilation.Assembly source, Assembly loaded)> Find(AssembliesType type)
        {
            // Two loaded assemblies can share a simple name, so the first one wins instead of throwing.
            var loaded = new Dictionary<string, Assembly>(StringComparer.Ordinal);
            foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies()) loaded.TryAdd(assembly.GetName().Name, assembly);

            var fromSource = new HashSet<string>(StringComparer.Ordinal);
            foreach (var source in CompilationPipeline.GetAssemblies(type))
            {
                if (!source.sourceFiles.Any(f => f.StartsWith("Assets/", StringComparison.Ordinal))) continue;
                if (!loaded.TryGetValue(source.name, out var assembly)) continue;

                fromSource.Add(source.name);
                yield return (source, assembly);
            }

            var assets = UnityEngine.Application.dataPath.Replace('\\', '/');
            foreach (var pair in loaded)
                if (!fromSource.Contains(pair.Key) && IsUnderAssets(pair.Value, assets)) yield return (null, pair.Value);
        }
    }
}
