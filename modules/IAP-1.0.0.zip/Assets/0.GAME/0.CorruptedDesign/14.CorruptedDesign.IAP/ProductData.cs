using System.Collections.Generic;

namespace CorruptedDesign.IAP
{
    /// <summary>Authored, immutable definition of one product: ids, type, price fallback and what it pays out.</summary>
    public sealed class ProductData
    {
        public ProductName Name { get; }
        public string ProductId { get; }
        public string GooglePlayId { get; }
        public string IosId { get; }
        public IapProductType Type { get; }
        public double DefaultPrice { get; }
        public bool GrantsNoAds { get; }
        public bool OneTime { get; }
        public string DisplayName { get; }
        public IReadOnlyList<IapReward> Rewards { get; }

        public ProductData(ProductName name, string productId, string googlePlayId, string iosId,
            IapProductType type, double defaultPrice, bool grantsNoAds = false, string displayName = null, bool oneTime = false, params IapReward[] rewards)
        {
            Name = name;
            ProductId = productId;
            GooglePlayId = googlePlayId;
            IosId = iosId;
            Type = type;
            DefaultPrice = defaultPrice;
            GrantsNoAds = grantsNoAds;
            OneTime = oneTime;
            DisplayName = displayName;
            Rewards = rewards;
        }
    }
}
