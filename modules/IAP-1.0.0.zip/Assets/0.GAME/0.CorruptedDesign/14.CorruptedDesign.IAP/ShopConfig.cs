using System.Collections.Generic;

namespace CorruptedDesign.IAP
{
    /// <summary>Single source of truth for the catalogue; to add, edit or remove a product touch only ProductName and this table.</summary>
    public static class ShopConfig
    {
        public const bool DebugLog = false;
        public const bool FetchPurchasedOnInitialized = true;
        public const string PROFILE_KEY = "iap_profile";
        public const string FULFILLED_KEY = "iap_fulfilled";
        public const int MAX_FULFILLED_TRANSACTIONS = 200;

        // displayName is optional: when set, UI cards with a name text show it instead of their authored label.
        // Prices and rewards follow the economy sheet "NEW S3_Config"; store ids are placeholders until the stores are set up.
        public static readonly IReadOnlyDictionary<ProductName, ProductData> Products =
            new Dictionary<ProductName, ProductData>
            {
                [ProductName.RemoveAds] = CreateBundle(ProductName.RemoveAds, "noads",
                    IapProductType.NonConsumable, 9.99,
                    "Remove Ads",grantsNoAds: true),

                [ProductName.StarterPack] = CreateBundle(ProductName.StarterPack, "starter.pack",
                    IapProductType.Consumable, 2.99, "Starter Pack",
                    oneTime: true, rewards: Bundle(2000, 1, 1)),

                [ProductName.NoAdsBundle] = CreateBundle(ProductName.NoAdsBundle, "noads.bundle",
                    IapProductType.NonConsumable, 9.99, "No Ads Bundle",
                    grantsNoAds: true,
                    rewards: Bundle(5000, 1, 1)),

                [ProductName.Bundle1] = CreateBundle(ProductName.Bundle1, "bundle.1", 
                    IapProductType.Consumable, 9.99, displayName: "Small Pack", 
                    rewards: Bundle(5000, 1, 1)),
                [ProductName.Bundle2] = CreateBundle(ProductName.Bundle2, "bundle.2", 
                    IapProductType.Consumable, 19.99, displayName: "Medium Pack", 
                    rewards: Bundle(10000, 3, 3)),
                [ProductName.Bundle3] = CreateBundle(ProductName.Bundle3, "bundle.3", 
                    IapProductType.Consumable, 39.99, displayName: "Big Pack", 
                    rewards: Bundle(25000, 6, 6)),
                [ProductName.Bundle4] = CreateBundle(ProductName.Bundle4, "bundle.4", 
                    IapProductType.Consumable, 79.99, displayName: "Huge Pack", 
                    rewards: Bundle(50000, 18, 18)),
                [ProductName.Bundle5] = CreateBundle(ProductName.Bundle5, "bundle.5", 
                    IapProductType.Consumable, 99.99, displayName: "Mega Pack", 
                    rewards: Bundle(65000, 36, 36)),

                [ProductName.CoinPack1] = CreateBundle(ProductName.CoinPack1, "coin.1", 
                    IapProductType.Consumable, 1.99, 
                    rewards: Coins(1000)),
                [ProductName.CoinPack2] = CreateBundle(ProductName.CoinPack2, "coin.2", 
                    IapProductType.Consumable, 7.99, 
                    rewards: Coins(5000)),
                [ProductName.CoinPack3] = CreateBundle(ProductName.CoinPack3, "coin.3", 
                    IapProductType.Consumable, 14.99, 
                    rewards: Coins(10000)),
                [ProductName.CoinPack4] = CreateBundle(ProductName.CoinPack4, "coin.4", 
                    IapProductType.Consumable, 29.99, 
                    rewards: Coins(25000)),
                [ProductName.CoinPack5] = CreateBundle(ProductName.CoinPack5, "coin.5", 
                    IapProductType.Consumable, 54.99, 
                    rewards: Coins(50000)),
                [ProductName.CoinPack6] = CreateBundle(ProductName.CoinPack6, "coin.6", 
                    IapProductType.Consumable, 99.99, 
                    rewards: Coins(100000)),
            };

        private static ProductData CreateBundle(ProductName name, string id, IapProductType type, double price,
            string displayName = null, bool grantsNoAds = false, bool oneTime = false, params IapReward[] rewards)
        {
            string storeId = "com.corrupteddesign.template." + id;
            return new ProductData(name, id, storeId, storeId, type, price, grantsNoAds, displayName, oneTime, rewards);
        }

        private static IapReward[] Coins(int coins) => new[] { new IapReward { type = ItemType.Coin, amount = coins } };

        /// <summary>Coins, N of each in-level booster and hours of infinite hearts, as the bundle table lays them out.</summary>
        private static IapReward[] Bundle(int coins, int boostersEach, int infiniteHeartHours) => new[]
        {
            new IapReward { type = ItemType.Coin, amount = coins },
            new IapReward { type = ItemType.Booster_1, amount = boostersEach },
            new IapReward { type = ItemType.Booster_2, amount = boostersEach },
            new IapReward { type = ItemType.Booster_3, amount = boostersEach },
            new IapReward { type = ItemType.InfiniteHeart, amount = infiniteHeartHours },
        };
    }
}
