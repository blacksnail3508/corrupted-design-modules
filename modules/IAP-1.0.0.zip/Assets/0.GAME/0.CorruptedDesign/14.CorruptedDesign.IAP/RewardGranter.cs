using System;
using System.Collections.Generic;
using CorruptedDesign.Observer;
using CorruptedDesign.Stamina;
using UnityEngine;

namespace CorruptedDesign.IAP
{
    /// <summary>Pays out product rewards to the game's wallet and hearts.</summary>
    public interface IRewardGranter
    {
        bool CanGrant { get; }
        void Grant(IapReward reward);
    }

    /// <summary>One handler per ItemType; a new reward kind is one more entry, not a new branch.</summary>
    public class RewardGranter : IRewardGranter
    {
        private readonly Dictionary<ItemType, Action<int>> handlers = new()
        {
            [ItemType.Coin] = amount => GameService.DataManager.ClaimCoin(amount, ResourceReason.Purchase, ResourcePlacement.Shop, true),
            [ItemType.Booster_1] = amount => ClaimBooster(BoosterType.Booster1, amount),
            [ItemType.Booster_2] = amount => ClaimBooster(BoosterType.Booster2, amount),
            [ItemType.Booster_3] = amount => ClaimBooster(BoosterType.Booster3, amount),
            [ItemType.Heart] = amount => StaminaManager.ClaimStamina(amount, "iap"),
            [ItemType.InfiniteHeart] = ClaimInfiniteHearts,
        };

        public bool CanGrant => GameService.DataManager != null && StaminaManager.Instance != null;

        public void Grant(IapReward reward)
        {
            if (handlers.TryGetValue(reward.type, out var handler)) handler(reward.amount);
            else Debug.LogWarning($"[IAP] No handler for reward type {reward.type}.");
        }

        // The amount is hours; StaminaManager.InfiniteStamina does not raise the change event, so the heart box is told here.
        private static void ClaimInfiniteHearts(int hours)
        {
            StaminaManager.InfiniteStamina(hours * 60);
            new StaminaChangedEvent().Trigger();
        }

        private static void ClaimBooster(BoosterType type, int amount) =>
            GameService.DataManager.ClaimBooster(type, amount, ResourceReason.Purchase, ResourcePlacement.Shop);
    }
}
