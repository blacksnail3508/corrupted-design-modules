using System;
using UnityEngine;

namespace CorruptedDesign.IAP
{
    public enum IapProductType
    {
        Consumable = 0,
        NonConsumable = 1,
        Subscription = 2
    }

    public enum IAPOperationStatus
    {
        Success,
        Fail,
        // The store refused a re-buy because the player already holds the item.
        AlreadyOwned
    }

    public enum SubscriptionResult
    {
        True,
        False,
        Unsupported
    }

    /// <summary>One grant a product pays out on purchase.</summary>
    [Serializable]
    public struct IapReward
    {
        public ItemType type;
        public int amount;
    }

    /// <summary>Runtime view of a ProductData: the authored definition plus the live state the store reports.</summary>
    public class IapStoreProduct
    {
        public ProductData Data { get; }

        public string productId => Data.ProductId;
        public IapProductType productType => Data.Type;

        [NonSerialized] public string localizedPriceString = "-";
        [NonSerialized] public double price;
        [NonSerialized] public string isoCurrencyCode;
        [NonSerialized] public string receipt;
        [NonSerialized] public string localizedDescription;
        [NonSerialized] public string localizedTitle;
        [NonSerialized] public bool active;
        [NonSerialized] public CorruptedDesignSubscriptionInfo subscriptionInfo;

        public IapStoreProduct(ProductData data) => Data = data;

        public string GetStoreID() => Application.platform switch
        {
            RuntimePlatform.IPhonePlayer => Data.IosId,
            RuntimePlatform.Android => Data.GooglePlayId,
            _ => Data.ProductId,
        };
    }

    /// <summary>Snapshot of a subscription taken the last time the store reported a receipt for it.</summary>
    public class CorruptedDesignSubscriptionInfo
    {
        public string productId;
        public DateTime purchaseDate;
        public DateTime expireDate;
        public DateTime cancelDate;
        public SubscriptionResult isSubscribed = SubscriptionResult.Unsupported;
        public SubscriptionResult isExpired = SubscriptionResult.Unsupported;
        public SubscriptionResult isCancelled = SubscriptionResult.Unsupported;
        public SubscriptionResult isFreeTrial = SubscriptionResult.Unsupported;
        public SubscriptionResult isAutoRenewing = SubscriptionResult.Unsupported;
        public SubscriptionResult isIntroductoryPricePeriod = SubscriptionResult.Unsupported;
        public TimeSpan remainingTime;
        public TimeSpan subscriptionPeriod;
        public TimeSpan freeTrialPeriod;
        public string freeTrialPeriodString;
        public TimeSpan introductoryPricePeriod;
        public string introductoryPrice;
        public long introductoryPricePeriodCycles;
        public string skuDetails;
        public string subscriptionInfoJson;
    }

    /// <summary>Price and ownership cached per store id so the shop has something to show before the store answers.</summary>
    public class IapProductProfile
    {
        public double price;
        public string localizedPriceString;
        public string isoCurrencyCode;
        public string localizedDescription;
        public string localizedTitle;
        public bool active;
    }

    /// <summary>Verdict of a receipt check.</summary>
    public class IapVerification
    {
        public bool success;
        public string error;
    }
}
