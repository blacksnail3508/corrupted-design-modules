using CorruptedDesign.UI;
using UnityEngine;

public class UIPopupLoadingIap : Popup
{
    public override string PopupType =>  "popup_loading";
}
