using CorruptedDesign.UI;
using TMPro;
using UnityEngine;

/// <summary>Tells the player a store purchase did not go through.</summary>
public class UIPopupPurchaseFailed : Popup
{
    public override string PopupType => "popup_purchase_failed";

    [SerializeField] private ButtonBase continueButton;
    [SerializeField] private TMP_Text messageText;

    // The text authored on the prefab, put back whenever the popup is shown without a reason.
    private string defaultMessage;

    private void Start() => continueButton.AddListener(() => this.ClosePopup<UIPopupPurchaseFailed>());

    /// <summary>Shows <paramref name="message"/>, or the prefab's own text when it is null.</summary>
    public UIPopupPurchaseFailed SetMessage(string message)
    {
        defaultMessage ??= messageText.text;
        messageText.text = message ?? defaultMessage;
        return this;
    }
}
