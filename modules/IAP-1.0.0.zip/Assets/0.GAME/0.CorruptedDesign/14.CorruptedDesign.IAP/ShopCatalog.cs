using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

namespace CorruptedDesign.IAP
{
    /// <summary>Builds runtime products from ShopConfig and seeds them from the on-device cache.</summary>
    public class ShopCatalog
    {
        private readonly Dictionary<ProductName, IapStoreProduct> byName = new();
        private readonly Dictionary<string, IapStoreProduct> byAnyId = new();

        /// <summary>Every internal and store id mapped to its product; the controller reads it for restore lookups.</summary>
        public Dictionary<string, IapStoreProduct> ByAnyId => byAnyId;

        public ShopCatalog(IReadOnlyDictionary<ProductName, ProductData> config, InAppPurchaseProfile profile)
        {
            foreach (var pair in config)
            {
                var product = new IapStoreProduct(pair.Value);
                SeedState(product, profile);
                byName[pair.Key] = product;
                TryIndex(pair.Value.ProductId, product);
                TryIndex(pair.Value.GooglePlayId, product);
                TryIndex(pair.Value.IosId, product);
            }
        }

        public bool TryGet(ProductName name, out IapStoreProduct product) => byName.TryGetValue(name, out product);

        private void TryIndex(string id, IapStoreProduct product)
        {
            if (string.IsNullOrEmpty(id)) return;
            if (!byAnyId.TryAdd(id, product))
                Debug.LogWarning($"[IAP] Duplicate product id '{id}' on '{product.Data.Name}'.");
        }

        private static void SeedState(IapStoreProduct product, InAppPurchaseProfile profile)
        {
            if (profile.TryGet(product.GetStoreID(), out var cached))
            {
                product.localizedPriceString = cached.localizedPriceString;
                product.price = cached.price;
                product.isoCurrencyCode = cached.isoCurrencyCode;
                product.localizedDescription = cached.localizedDescription;
                product.localizedTitle = cached.localizedTitle;
                product.active = cached.active;
                return;
            }

            product.price = product.Data.DefaultPrice;
            product.localizedPriceString = product.Data.DefaultPrice.ToString("0.00", CultureInfo.InvariantCulture) + "$";
            product.isoCurrencyCode = "USD";
            product.localizedTitle = product.localizedDescription = product.Data.Name.ToString();
        }
    }
}
