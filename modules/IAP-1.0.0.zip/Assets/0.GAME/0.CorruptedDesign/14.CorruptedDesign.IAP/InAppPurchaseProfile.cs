using System.Collections.Generic;
using CorruptedDesign.Data;

namespace CorruptedDesign.IAP
{
    /// <summary>On-device cache of prices and ownership, keyed by store id so each A/B variant has its own entry.</summary>
    public class InAppPurchaseProfile
    {
        private readonly Vault<Dictionary<string, IapProductProfile>> vault =
            new(ShopConfig.PROFILE_KEY, new Dictionary<string, IapProductProfile>());

        private Dictionary<string, IapProductProfile> Map => vault.Value ??= new Dictionary<string, IapProductProfile>();

        public bool TryGet(string storeId, out IapProductProfile profile)
        {
            profile = null;
            return !string.IsNullOrEmpty(storeId) && Map.TryGetValue(storeId, out profile) && profile != null;
        }

        public void Update(string storeId, IapProductProfile profile)
        {
            if (string.IsNullOrEmpty(storeId)) return;
            Map[storeId] = profile;
        }

        public void Save() => vault.Save(Map);
    }
}
