namespace CorruptedDesign.IAP
{
    /// <summary>Every sellable pack; add a value here and one entry in ShopConfig to ship a new product.</summary>
    public enum ProductName
    {
        RemoveAds,
        StarterPack,
        NoAdsBundle,
        Bundle1,
        Bundle2,
        Bundle3,
        Bundle4,
        Bundle5,
        CoinPack1,
        CoinPack2,
        CoinPack3,
        CoinPack4,
        CoinPack5,
        CoinPack6,
    }
}
