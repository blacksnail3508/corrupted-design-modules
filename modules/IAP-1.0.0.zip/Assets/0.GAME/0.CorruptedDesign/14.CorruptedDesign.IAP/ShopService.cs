using System;
using Cysharp.Threading.Tasks;
using CorruptedDesign.Observer;
using CorruptedDesign.UI;
using UnityEngine;

namespace CorruptedDesign.IAP
{
    /// <summary>Game-facing IAP entry point: boots the store and answers every product, price and ownership query.</summary>
    public static class ShopService
    {
        private static readonly IRewardGranter granter = new RewardGranter();
        private static readonly PurchaseFulfiller fulfiller = CreateFulfiller();

        private static IapController controller;
        private static ShopCatalog catalog;
        private static bool ready;
        private static bool buying;

        private const float PurchaseStartDelaySeconds = 0.25f;
        private const float InitRetrySeconds = 30f;
        private const float RefetchRetrySeconds = 30f;
        // Each refetch re-verifies every owned item, so a validator that stays down is not hammered.
        private const int MaxRefetchAttempts = 5;
        private const string NoInternetMessage = "No internet connection. Please check your connection and try again.";

        private static float nextInitRetryAt;
        private static float nextRefetchAt;
        private static int refetchAttempts;

        private static bool IsOffline => Application.internetReachability == NetworkReachability.NotReachable;

        public static bool IsReady => ready;

        // Interrupted orders are replayed at init and need the wallet and hearts to exist, so boot waits for them.
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void AutoBoot() => BootWhenGameReady().Forget();

        private static async UniTaskVoid BootWhenGameReady()
        {
            await UniTask.WaitUntil(() => granter.CanGrant);
            Initialize();
        }

        public static void Initialize()
        {
            if (controller != null) return;

            var profile = new InAppPurchaseProfile();
            catalog = new ShopCatalog(ShopConfig.Products, profile);
            refetchAttempts = 0;
            nextRefetchAt = Time.realtimeSinceStartup + RefetchRetrySeconds;

            IapTicker.Create(Tick);
            controller = new IapController
            {
                FulfillPurchaseAsync = fulfiller.FulfillAsync,
                OwnershipRestored = fulfiller.RestoreOwnership
            };
            controller.Initialize(profile, catalog.ByAnyId, ShopConfig.FetchPurchasedOnInitialized,
                ShopConfig.DebugLog, success => ready = success);
        }

        private static void Tick()
        {
            if (controller == null) return;

            controller.OnUpdate();
            RetryInitializeWhenOnline();
            RefetchPurchasesWhenOnline();
        }

        private static void RetryInitializeWhenOnline()
        {
            if (!controller.HasFailed || IsOffline || Time.realtimeSinceStartup < nextInitRetryAt) return;

            nextInitRetryAt = Time.realtimeSinceStartup + InitRetrySeconds;
            controller.RetryInitialize();
        }

        private static void RefetchPurchasesWhenOnline()
        {
            if (!controller.NeedsPurchaseRefetch || !controller.IsInitialized || buying || IsOffline) return;
            if (refetchAttempts >= MaxRefetchAttempts || Time.realtimeSinceStartup < nextRefetchAt) return;

            nextRefetchAt = Time.realtimeSinceStartup + RefetchRetrySeconds;
            refetchAttempts++;
            controller.RefetchPurchases();
        }

        public static void Shutdown()
        {
            controller?.Shutdown();
            controller = null;
            ready = false;
            EndBuying();
        }

        public static void Buy(ProductName name, string location, Action<bool> onDone = null)
        {
            // A second tap during the processing window is dropped, not reported as a failed purchase.
            if (buying) return;
            if (IsSoldOut(name))
            {
                onDone?.Invoke(false);
                return;
            }
            // The store never answers offline, which would leave the loading popup up until the purchase timeout.
            if (IsOffline)
            {
                ShowPurchaseFailed(NoInternetMessage);
                onDone?.Invoke(false);
                return;
            }
            if (controller == null || !catalog.TryGet(name, out var product))
            {
                ShowPurchaseFailed();
                onDone?.Invoke(false);
                return;
            }
            // Back online after a failed init: retry now rather than wait out the 30 s timer.
            if (controller.HasFailed) nextInitRetryAt = 0f;

            buying = true;
            GameService.UIManager?.ShowPopup<UIPopupLoadingIap>(UITrigger.Auto);
            // Unscaled so a paused game (timeScale 0) still reaches the store.
            Delay.CallUnscaled(PurchaseStartDelaySeconds, () =>
            {
                if (controller == null)
                {
                    EndBuying();
                    ShowPurchaseFailed();
                    onDone?.Invoke(false);
                    return;
                }
                controller.BuyProduct(product.Data.ProductId, location, (status, message, bought) =>
                {
                    bool success = status == IAPOperationStatus.Success;
#if UNITY_ANDROID
                    // Google Play rejects a re-buy of an owned item; restoring it is what the player actually needs.
                    if (status == IAPOperationStatus.AlreadyOwned && product.Data.Type == IapProductType.NonConsumable && controller != null)
                    {
                        controller.RestorePurchases(null, (_, _) =>
                        {
                            EndBuying();
                            bool owned = IsSoldOut(name);
                            if (!owned) ShowPurchaseFailed();
                            onDone?.Invoke(owned);
                        });
                        return;
                    }
                    // An unconsumed consumable is an interrupted order still owed to the player; the refetch replays and grants it.
                    if (status == IAPOperationStatus.AlreadyOwned && controller != null) controller.RefetchPurchases();
#endif

                    EndBuying();
                    if (success) new PurchaseCompletedEvent { Product = bought }.Trigger();
                    else ShowPurchaseFailed();
                    onDone?.Invoke(success);
                });
            });
        }

        // A null message shows the prefab's own text, so a reused popup never keeps an earlier reason.
        private static void ShowPurchaseFailed(string message = null) =>
            GameService.UIManager?.ShowPopup<UIPopupPurchaseFailed>(UITrigger.Auto)?.SetMessage(message);

        private static void EndBuying()
        {
            buying = false;
            // Anywhere, since a popup opened over it (e.g. a lost-connection notice) would leave it stuck under the stack.
            GameService.UIManager?.ClosePopupAnywhere<UIPopupLoadingIap>();
        }

        public static void RestorePurchases(Action<bool> onDone = null)
        {
            if (controller == null)
            {
                onDone?.Invoke(false);
                return;
            }
            controller.RestorePurchases(null, (success, message) =>
            {
                if (success) new RestorePurchaseSuccessEvent().Trigger();
                onDone?.Invoke(success);
            });
        }

        /// <summary>The authored definition: ids, type and the full reward list.</summary>
        public static ProductData GetProductData(ProductName name) => ShopConfig.Products[name];

        public static string GetPriceString(ProductName name) => TryGet(name, out var p) ? p.localizedPriceString : "-";

        public static double GetPrice(ProductName name) => TryGet(name, out var p) ? p.price : 0d;

        public static string GetCurrencyCode(ProductName name) => TryGet(name, out var p) ? p.isoCurrencyCode : "-";

        public static bool IsActive(ProductName name) => TryGet(name, out var p) && p.active;

        public static bool IsBoughtBefore(ProductName name) => fulfiller.IsBought(name);

        /// <summary>True for a one-time product the player already bought, so it must not be offered or sold again.</summary>
        public static bool IsSoldOut(ProductName name) =>
            (ShopConfig.Products[name].OneTime || ShopConfig.Products[name].Type == IapProductType.NonConsumable) && fulfiller.IsBought(name);

        public static bool IsNoAds() => fulfiller.IsNoAds;

        public static CorruptedDesignSubscriptionInfo GetSubscriptionInfo(ProductName name) =>
            TryGet(name, out var p) ? p.subscriptionInfo : null;

        public static SubscriptionResult IsSubscribed(ProductName name) =>
            GetSubscriptionInfo(name)?.isSubscribed ?? SubscriptionResult.Unsupported;

        public static DateTime GetExpireDate(ProductName name) => GetSubscriptionInfo(name)?.expireDate ?? default;

        public static TimeSpan GetRemainingTime(ProductName name) => GetSubscriptionInfo(name)?.remainingTime ?? default;

        private static bool TryGet(ProductName name, out IapStoreProduct product)
        {
            product = null;
            return catalog != null && catalog.TryGet(name, out product);
        }

        private static PurchaseFulfiller CreateFulfiller()
        {
            var created = new PurchaseFulfiller(granter);
            created.NoAdsGranted += () => new NoAdsEvent().Trigger();
            return created;
        }
    }

    public class PurchaseCompletedEvent : GameEvent
    {
        public IapStoreProduct Product;
    }

    public class RestorePurchaseSuccessEvent : GameEvent { }

    public class NoAdsEvent : GameEvent { }

    /// <summary>Runs the controller watchdog on unscaled time so a paused game still times purchases out.</summary>
    internal class IapTicker : MonoBehaviour
    {
        private Action tick;

        public static void Create(Action tick)
        {
            var go = new GameObject("IapTicker");
            DontDestroyOnLoad(go);
            go.AddComponent<IapTicker>().tick = tick;
        }

        private void Update() => tick?.Invoke();
    }
}
