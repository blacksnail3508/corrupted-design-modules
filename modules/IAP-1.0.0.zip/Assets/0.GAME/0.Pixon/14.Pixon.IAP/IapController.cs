using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using Pixon.Observer;
using UnityEngine;
using UnityEngine.Purchasing;

namespace Pixon.IAP
{
    /// <summary>Drives Unity IAP 5.x: connect, fetch, buy, restore, replay interrupted orders, then confirm.</summary>
    public class IapController
    {
        private const float StoreConnectTimeoutSeconds = 30f;
        private const float StoreFetchTimeoutSeconds = 60f;
        private const float PurchaseTimeoutSeconds = 300f;
        private const float RestoreTimeoutSeconds = 120f;

        public Func<string, IapStoreProduct, UniTask<bool>> FulfillPurchaseAsync { get; set; }

        private readonly IapReceiptValidator validator;
        private readonly Dictionary<string, UniTaskCompletionSource<bool>> pendingWork = new();
        private readonly HashSet<string> interruptedTransactionIds = new();

        private StoreController storeController;
        private StoreConnectionStatus connectionStatus = StoreConnectionStatus.NotConnected;
        private ProductFetchStatus productFetchStatus = ProductFetchStatus.NotFetched;
        private PurchasesFetchStatus purchasesFetchStatus = PurchasesFetchStatus.NotFetched;
        private ModuleStatus moduleStatus = ModuleStatus.NotInitialized;

        private InAppPurchaseProfile profile;
        private Dictionary<string, IapStoreProduct> productsByAnyId;
        private Action<bool> onInitialized;
        private bool fetchPurchasedOnInitialized;
        private bool debug;
        private bool storeEventsAttached;
        private int requestedProductCount;
        private int lifecycle;

        private Action<IAPOperationStatus, string, IapStoreProduct> purchaseCallback;
        private Action<IAPOperationStatus, string, IapStoreProduct> restoredCallback;
        private string purchaseLocation;
        private string activeProductId;
        private string activeTransactionId;
        private int purchaseRequests;
        // 0 means no purchase in flight; a stale id belongs to a request that already ended.
        private int activePurchaseRequest;
        private bool purchaseInProgress;
        private float purchaseDeadline;
        private Action<bool, string> restoreDone;
        private float restoreDeadline;
        private bool restoreAwaitingFetch;

        public IapController(IapReceiptValidator validator = null)
        {
            this.validator = validator ?? new IapReceiptValidator();
        }

        public bool IsInitialized => moduleStatus == ModuleStatus.Initialized;

        private bool HasUsableProducts => productFetchStatus == ProductFetchStatus.Success
                                          || productFetchStatus == ProductFetchStatus.PartialSuccess;

        public void Initialize(InAppPurchaseProfile profile, Dictionary<string, IapStoreProduct> productsByAnyId,
            bool fetchPurchasedOnInitialized, bool debug, Action<bool> onInitialized)
        {
            this.profile = profile;
            this.productsByAnyId = productsByAnyId;
            this.fetchPurchasedOnInitialized = fetchPurchasedOnInitialized;
            this.debug = debug;
            // Assigned before the handshake because the store may report back synchronously.
            this.onInitialized = onInitialized;
            InitializePurchasing();
        }

        public void Shutdown()
        {
            lifecycle++;
            TryCompletePurchase(IAPOperationStatus.Fail, "Purchase service shut down.", null);
            CompleteRestore(false, "Purchase service shut down.");
            foreach (var source in pendingWork.Values) source.TrySetResult(false);
            pendingWork.Clear();
            DetachStoreEvents();
            storeController = null;
            interruptedTransactionIds.Clear();
            activePurchaseRequest = 0;
            connectionStatus = StoreConnectionStatus.NotConnected;
            productFetchStatus = ProductFetchStatus.NotFetched;
            purchasesFetchStatus = PurchasesFetchStatus.NotFetched;
            moduleStatus = ModuleStatus.NotInitialized;
            requestedProductCount = 0;
            FulfillPurchaseAsync = null;
            onInitialized = null;
            purchaseCallback = null;
            restoredCallback = null;
            productsByAnyId = null;
            profile = null;
        }

        /// <summary>Watchdog for a store that never delivers a terminal callback.</summary>
        public void OnUpdate()
        {
            if (purchaseInProgress && Time.realtimeSinceStartup >= purchaseDeadline)
            {
                // The store may still deliver this transaction; mark it replayed so it cannot answer the next request.
                if (!string.IsNullOrEmpty(activeTransactionId)) interruptedTransactionIds.Add(activeTransactionId);
                TryCompletePurchase(IAPOperationStatus.Fail, "Purchase timed out waiting for the store.", null);
            }
            if (restoreDone != null && Time.realtimeSinceStartup >= restoreDeadline)
                CompleteRestore(false, "Restore timed out waiting for the store.");
        }

        #region Initialize
        private async void InitializePurchasing()
        {
            int generation = lifecycle;
            moduleStatus = ModuleStatus.Initializing;
            var status = await ConnectToStore();
            if (generation != lifecycle) return;

            if (status == StoreConnectionStatus.Connected)
            {
                await UniTask.WhenAll(FetchProducts(), FetchPurchases());
                if (generation != lifecycle) return;
                // A failed purchases fetch must not lock buying out; a restore re-runs it.
                moduleStatus = HasUsableProducts ? ModuleStatus.Initialized : ModuleStatus.Failed;
                if (fetchPurchasedOnInitialized && purchasesFetchStatus != PurchasesFetchStatus.Success)
                    IapLog.Warn($"Owned purchases were not fetched ({purchasesFetchStatus}); ownership is served from the cache.");
            }
            else
            {
                moduleStatus = ModuleStatus.Failed;
                IapLog.Error("Store connection failed.");
            }

#if UNITY_EDITOR
            // The editor has no real store; report ready so the shop stays workable.
            moduleStatus = ModuleStatus.Initialized;
#endif
            onInitialized?.Invoke(moduleStatus == ModuleStatus.Initialized);
        }

        // Polls off the scaled clock so a paused game (timeScale 0) still makes progress.
        private static async UniTask<bool> WaitUntilOrTimeout(Func<bool> predicate, float timeoutSeconds)
        {
            float deadline = Time.realtimeSinceStartup + timeoutSeconds;
            while (!predicate())
            {
                if (Time.realtimeSinceStartup >= deadline) return false;
                await UniTask.Yield();
            }
            return true;
        }

        private async UniTask<StoreConnectionStatus> ConnectToStore()
        {
            if (connectionStatus != StoreConnectionStatus.NotConnected) return connectionStatus;

            connectionStatus = StoreConnectionStatus.Connecting;
            try
            {
                storeController = UnityIAPServices.StoreController();
                AttachStoreEvents();
                ObserveStoreConnect(storeController.Connect()).Forget();

                // Connect() stays pending while Unity retries, so the timeout covers the attempt itself.
                if (!await WaitUntilOrTimeout(
                        () => connectionStatus == StoreConnectionStatus.Connected
                              || connectionStatus == StoreConnectionStatus.Disconnected,
                        StoreConnectTimeoutSeconds))
                {
                    connectionStatus = StoreConnectionStatus.Disconnected;
                    IapLog.Error("Timed out waiting for the store connection.");
                }
            }
            catch (Exception ex)
            {
                connectionStatus = StoreConnectionStatus.Disconnected;
                IapLog.Error($"Error connecting to store: {ex.Message}");
            }
            return connectionStatus;
        }

        private async UniTaskVoid ObserveStoreConnect(Task connect)
        {
            int generation = lifecycle;
            try { await connect; }
            catch (Exception ex)
            {
                if (generation != lifecycle) return;
                if (connectionStatus == StoreConnectionStatus.Connecting)
                    connectionStatus = StoreConnectionStatus.Disconnected;
                IapLog.Error($"Error connecting to store: {ex.Message}");
            }
        }

        // The store controller is process-wide, so handlers are attached once and detached on shutdown.
        private void AttachStoreEvents()
        {
            if (storeEventsAttached) return;
            storeEventsAttached = true;
            storeController.OnPurchasePending += OnPurchasePending;
            storeController.OnPurchaseConfirmed += OnPurchaseConfirmed;
            storeController.OnPurchaseDeferred += OnPurchaseDeferred;
            storeController.OnPurchaseFailed += OnPurchaseFailed;
            storeController.OnPurchasesFetched += OnPurchasesFetched;
            storeController.OnPurchasesFetchFailed += OnPurchasesFetchFailed;
            storeController.OnStoreConnected += OnStoreConnected;
            storeController.OnStoreDisconnected += OnStoreDisconnected;
            storeController.OnProductsFetched += OnProductsFetched;
            storeController.OnProductsFetchFailed += OnProductsFetchFailed;
        }

        private void DetachStoreEvents()
        {
            if (!storeEventsAttached || storeController == null) return;
            storeEventsAttached = false;
            storeController.OnPurchasePending -= OnPurchasePending;
            storeController.OnPurchaseConfirmed -= OnPurchaseConfirmed;
            storeController.OnPurchaseDeferred -= OnPurchaseDeferred;
            storeController.OnPurchaseFailed -= OnPurchaseFailed;
            storeController.OnPurchasesFetched -= OnPurchasesFetched;
            storeController.OnPurchasesFetchFailed -= OnPurchasesFetchFailed;
            storeController.OnStoreConnected -= OnStoreConnected;
            storeController.OnStoreDisconnected -= OnStoreDisconnected;
            storeController.OnProductsFetched -= OnProductsFetched;
            storeController.OnProductsFetchFailed -= OnProductsFetchFailed;
        }

        private void OnStoreConnected()
        {
            connectionStatus = StoreConnectionStatus.Connected;
            if (moduleStatus == ModuleStatus.Failed && HasUsableProducts)
                moduleStatus = ModuleStatus.Initialized;
        }

        private void OnStoreDisconnected(StoreConnectionFailureDescription description)
        {
            IapLog.Warn($"Store disconnected: {description.message}");
            connectionStatus = StoreConnectionStatus.Disconnected;
            // Fail closed: a disconnected store cannot complete what is in flight or requested next.
            if (moduleStatus == ModuleStatus.Initialized) moduleStatus = ModuleStatus.Failed;
            TryCompletePurchase(IAPOperationStatus.Fail, "Store disconnected.", null);
            CompleteRestore(false, "Store disconnected.");
        }
        #endregion

        #region Fetch purchases
        private async UniTask FetchPurchases()
        {
            if (!fetchPurchasedOnInitialized || purchasesFetchStatus != PurchasesFetchStatus.NotFetched) return;

            purchasesFetchStatus = PurchasesFetchStatus.Fetching;
            storeController.FetchPurchases();
            if (!await WaitUntilOrTimeout(() => purchasesFetchStatus != PurchasesFetchStatus.Fetching, StoreFetchTimeoutSeconds)
                && purchasesFetchStatus == PurchasesFetchStatus.Fetching)
            {
                purchasesFetchStatus = PurchasesFetchStatus.Failed;
                IapLog.Error("Timed out waiting for the purchases fetch.");
                if (restoreAwaitingFetch) CompleteRestore(false, "Purchase fetch timed out.");
            }
        }

        private async void OnPurchasesFetched(Orders orders)
        {
            int generation = lifecycle;
            try
            {
                // Reconciliation asks "did the store still report this entitlement", not "did it verify",
                // so a transient verification failure never revokes a legitimate purchase.
                var reportedProducts = new HashSet<IapStoreProduct>();
                int unfulfilledReplays = 0;

                if (orders.ConfirmedOrders != null
                    && !await RestoreConfirmedOrders(orders.ConfirmedOrders, reportedProducts, generation))
                    return;

                if (orders.PendingOrders != null)
                {
                    foreach (var order in orders.PendingOrders)
                    {
                        string transactionId = order?.Info?.TransactionID;
                        if (!string.IsNullOrEmpty(transactionId)) interruptedTransactionIds.Add(transactionId);
                    }
                    foreach (var order in orders.PendingOrders)
                    {
                        var product = GetFirstProductInOrder(order);
                        if (product != null && productsByAnyId.TryGetValue(product.definition.id, out var pendingProduct))
                            reportedProducts.Add(pendingProduct);

                        // One order that cannot be fulfilled stays pending without aborting the others.
                        if (!await HandlePendingAsync(order)) unfulfilledReplays++;
                        if (generation != lifecycle) return;
                    }
                }

                if (orders.DeferredOrders != null)
                    foreach (var order in orders.DeferredOrders) OnPurchaseDeferred(order);

                purchasesFetchStatus = PurchasesFetchStatus.Success;
                ReconcileOwnership(reportedProducts);
                profile?.Save();

                if (restoreAwaitingFetch)
                {
                    if (unfulfilledReplays > 0)
                        CompleteRestore(false, $"{unfulfilledReplays} pending purchase(s) could not be fulfilled; they are retried on the next restore.");
                    else CompleteRestore(true, null);
                }
            }
            catch (Exception ex)
            {
                if (generation != lifecycle) return;
                IapLog.Error($"Purchase processing failed: {ex.Message}");
                purchasesFetchStatus = PurchasesFetchStatus.Failed;
                if (restoreAwaitingFetch) CompleteRestore(false, "Purchase processing failed.");
            }
        }

        // A confirmed consumable was already delivered and is never replayed from here.
        private async UniTask<bool> RestoreConfirmedOrders(IReadOnlyList<ConfirmedOrder> confirmedOrders,
            HashSet<IapStoreProduct> reportedProducts, int generation)
        {
            var restores = new List<(Product product, IapStoreProduct storeProduct, string receipt,
                UniTask<IapVerification> verification)>();
            foreach (var order in confirmedOrders)
            {
                var product = GetFirstProductInOrder(order);
                if (product == null) continue;

                if (!productsByAnyId.TryGetValue(product.definition.id, out var storeProduct))
                {
                    IapLog.Warn($"Product not found for purchase: {product.definition.id}");
                    continue;
                }
                reportedProducts.Add(storeProduct);
                CachePriceMetadata(product);
                if (storeProduct.productType == IapProductType.Consumable) continue;

                restores.Add((product, storeProduct, order.Info?.Receipt,
                    validator.VerifyAsync(product, order, "restore")));
            }

            foreach (var (product, storeProduct, receipt, verification) in restores)
            {
                var response = await verification;
                // A verdict that lands after a shutdown must not write store state into the next session.
                if (generation != lifecycle) return false;
                if (response == null || !response.success)
                {
                    NotifyPurchaseRestored(IAPOperationStatus.Fail, storeProduct,
                        response?.error ?? "Restored receipt could not be validated.");
                    continue;
                }

                ApplyEntitlement(storeProduct, product, receipt);
                CacheOwnership(storeProduct);
                NotifyPurchaseRestored(IAPOperationStatus.Success, storeProduct, "Restore Success!");
            }
            return true;
        }

        // A failed or skipped fetch never reconciles, so an offline launch keeps serving the cached ownership.
        private void ReconcileOwnership(HashSet<IapStoreProduct> reportedProducts)
        {
            if (productsByAnyId == null) return;
            var visited = new HashSet<IapStoreProduct>();
            foreach (var product in productsByAnyId.Values)
            {
                if (product == null || !visited.Add(product)) continue;
                if (product.productType == IapProductType.Consumable) continue;
                if (!product.active || reportedProducts.Contains(product)) continue;

                IapLog.Warn($"Entitlement is no longer reported by the store, clearing: {product.productId}");
                product.active = false;
                product.receipt = null;
                product.subscriptionInfo = null;
                CacheOwnership(product);
            }
        }

        private void OnPurchasesFetchFailed(PurchasesFetchFailureDescription failure)
        {
            NotifyPurchaseRestored(IAPOperationStatus.Fail, null, failure.FailureReason.ToString());
            purchasesFetchStatus = PurchasesFetchStatus.Failed;
            if (restoreAwaitingFetch) CompleteRestore(false, "Purchase fetch failed.");
        }

        // Invoked once per restored product, so the callback stays subscribed until the restore completes.
        private void NotifyPurchaseRestored(IAPOperationStatus status, IapStoreProduct product, string message)
        {
            if (status == IAPOperationStatus.Fail) IapLog.Error($"Restore failed: {message}");
            restoredCallback?.Invoke(status, message, product);
        }
        #endregion

        #region Fetch products
        private async UniTask FetchProducts()
        {
            if (productFetchStatus != ProductFetchStatus.NotFetched) return;

            productFetchStatus = ProductFetchStatus.Fetching;
            try
            {
                // productsByAnyId maps several keys onto one product, so request distinct active store ids.
                var requestedStoreIds = new HashSet<string>();
                var definitions = new List<ProductDefinition>();
                foreach (var pair in productsByAnyId)
                {
                    var storeId = pair.Value.GetStoreID();
                    if (string.IsNullOrEmpty(storeId) || !requestedStoreIds.Add(storeId)) continue;
                    definitions.Add(new ProductDefinition(storeId, (ProductType)pair.Value.productType));
                }
                requestedProductCount = definitions.Count;
                storeController.FetchProducts(definitions);
                if (!await WaitUntilOrTimeout(() => productFetchStatus != ProductFetchStatus.Fetching, StoreFetchTimeoutSeconds)
                    && productFetchStatus == ProductFetchStatus.Fetching)
                {
                    productFetchStatus = ProductFetchStatus.Failed;
                    IapLog.Error("Timed out waiting for the products fetch.");
                }
            }
            catch (Exception ex)
            {
                productFetchStatus = ProductFetchStatus.Failed;
                IapLog.Error($"Error fetching products: {ex.Message}");
            }
        }

        private void OnProductsFetched(List<Product> products)
        {
            if (products == null || products.Count == 0)
            {
                IapLog.Error("Store returned no products.");
                SetProductFetchResult(ProductFetchStatus.Failed);
                return;
            }

            foreach (var fetched in products)
                if (productsByAnyId.TryGetValue(fetched.definition.id, out var storeProduct))
                    ApplyStoreMetadata(storeProduct, fetched);
            profile?.Save();
            SetProductFetchResult(products.Count >= requestedProductCount
                ? ProductFetchStatus.Success : ProductFetchStatus.PartialSuccess);
        }

        private void OnProductsFetchFailed(ProductFetchFailed failure)
        {
            IapLog.Error($"Failed to fetch products: {failure.FailureReason}");
            if (failure.FailedFetchProducts == null || failure.FailedFetchProducts.Count == 0)
            {
                SetProductFetchResult(ProductFetchStatus.Failed);
                return;
            }
            SetProductFetchResult(failure.FailedFetchProducts.Count >= requestedProductCount
                ? ProductFetchStatus.Failed : ProductFetchStatus.PartialSuccess);
        }

        // The first verdict for a fetch wins, so a late partial failure cannot downgrade a completed fetch.
        private void SetProductFetchResult(ProductFetchStatus status)
        {
            if (productFetchStatus != ProductFetchStatus.Fetching) return;
            productFetchStatus = status;
        }

        // Only the active SKU may overwrite the live fields the shop shows; every SKU still refreshes its own cache entry.
        private void ApplyStoreMetadata(IapStoreProduct shopProduct, Product product)
        {
            if (product.definition.id == shopProduct.GetStoreID())
            {
                shopProduct.localizedPriceString = product.metadata.localizedPriceString;
                shopProduct.price = decimal.ToDouble(product.metadata.localizedPrice);
                shopProduct.isoCurrencyCode = product.metadata.isoCurrencyCode;
                shopProduct.localizedDescription = product.metadata.localizedDescription;
                shopProduct.localizedTitle = product.metadata.localizedTitle;
            }
            CachePriceMetadata(product);
        }

        // A consumable is never marked owned, so a repeatable pack stays repurchasable.
        private void ApplyEntitlement(IapStoreProduct shopProduct, Product product, string receipt)
        {
            if (!string.IsNullOrEmpty(receipt)) shopProduct.receipt = receipt;
            if (shopProduct.productType == IapProductType.NonConsumable)
            {
                shopProduct.active = true;
            }
            else if (shopProduct.productType == IapProductType.Subscription)
            {
                var snapshot = BuildSubscriptionSnapshot(product);
                if (snapshot != null)
                {
                    shopProduct.subscriptionInfo = snapshot;
                    shopProduct.active = snapshot.isSubscribed == SubscriptionResult.True;
                }
            }
        }

        private void CachePriceMetadata(Product product)
        {
            string storeId = product?.definition?.id;
            if (profile == null || string.IsNullOrEmpty(storeId)) return;
            profile.TryGet(storeId, out var cached);
            profile.Update(storeId, new IapProductProfile
            {
                localizedPriceString = product.metadata.localizedPriceString,
                price = decimal.ToDouble(product.metadata.localizedPrice),
                isoCurrencyCode = product.metadata.isoCurrencyCode,
                localizedDescription = product.metadata.localizedDescription,
                localizedTitle = product.metadata.localizedTitle,
                active = cached != null && cached.active
            });
        }

        // Ownership is written to the active SKU's entry, the one the next boot reads.
        private void CacheOwnership(IapStoreProduct shopProduct)
        {
            string storeId = shopProduct?.GetStoreID();
            if (profile == null || string.IsNullOrEmpty(storeId)) return;
            if (!profile.TryGet(storeId, out var cached))
            {
                cached = new IapProductProfile
                {
                    localizedPriceString = shopProduct.localizedPriceString,
                    price = shopProduct.price,
                    isoCurrencyCode = shopProduct.isoCurrencyCode,
                    localizedDescription = shopProduct.localizedDescription,
                    localizedTitle = shopProduct.localizedTitle
                };
            }
            cached.active = shopProduct.active;
            profile.Update(storeId, cached);
        }
        #endregion

        #region Buy
        public void BuyProduct(string productId, string location,
            Action<IAPOperationStatus, string, IapStoreProduct> onComplete)
        {
            if (purchaseInProgress || restoreDone != null)
            {
                onComplete?.Invoke(IAPOperationStatus.Fail, "Another purchase or restore is in progress.", null);
                return;
            }
            purchaseInProgress = true;
            activePurchaseRequest = ++purchaseRequests;
            purchaseDeadline = Time.realtimeSinceStartup + PurchaseTimeoutSeconds;
            activeProductId = productId;
            activeTransactionId = null;
            purchaseLocation = location;
            purchaseCallback = onComplete;

            if (!IsInitialized)
            {
                TryCompletePurchase(IAPOperationStatus.Fail, "Module not ready.", null);
                return;
            }
            if (!productsByAnyId.TryGetValue(productId, out var product))
            {
                TryCompletePurchase(IAPOperationStatus.Fail, $"Product not found: {productId}", null);
                return;
            }

            activeProductId = product.productId;
            try { storeController.PurchaseProduct(product.GetStoreID()); }
            catch (Exception ex) { TryCompletePurchase(IAPOperationStatus.Fail, $"Error initiating purchase: {ex.Message}", null); }
        }

        private async void OnPurchasePending(PendingOrder pendingOrder)
        {
            await HandlePendingAsync(pendingOrder);
        }

        private async UniTask<bool> HandlePendingAsync(PendingOrder pendingOrder)
        {
            // Captured up front so this order answers the request in flight now, not whichever replaces it.
            int requestId = activePurchaseRequest;
            string transactionId = pendingOrder?.Info?.TransactionID;
            if (string.IsNullOrEmpty(transactionId))
            {
                ReportOutcome(pendingOrder, requestId, AnalyticAdapter.LogPurchaseUnknown);
                CompleteOrderCallback(pendingOrder, requestId, IAPOperationStatus.Fail, "Purchase has no transaction identity; order remains pending.", null);
                return false;
            }
            if (pendingWork.TryGetValue(transactionId, out var existing)) return await existing.Task;

            var source = new UniTaskCompletionSource<bool>();
            pendingWork[transactionId] = source;
            int generation = lifecycle;
            bool completed = false;
            try
            {
                // On iOS a dismissed payment sheet can still raise OnPurchasePending; a paid order always has a receipt.
                if (string.IsNullOrEmpty(pendingOrder.Info.Receipt))
                {
                    CompleteOrderCallback(pendingOrder, requestId, IAPOperationStatus.Fail, "Purchase dismissed without payment.", null);
                    return false;
                }

                bool isValidPurchase = await ProcessPendingOrder(pendingOrder, requestId);
                if (isValidPurchase && generation == lifecycle && storeController != null)
                {
                    try
                    {
                        storeController.ConfirmPurchase(pendingOrder);
                        completed = true;
                    }
                    catch (Exception)
                    {
                        IapLog.Warn("Confirmation failed; the fulfilled transaction remains retryable.");
                    }
                }
                return completed;
            }
            catch (Exception ex)
            {
                IapLog.Error($"Fulfillment failed: {ex.Message}");
                if (generation == lifecycle)
                    CompleteOrderCallback(pendingOrder, requestId, IAPOperationStatus.Fail, "Purchase fulfillment failed; order remains pending.", null);
                return false;
            }
            finally
            {
                source.TrySetResult(completed);
                if (pendingWork.TryGetValue(transactionId, out var current) && current == source) pendingWork.Remove(transactionId);
            }
        }

        private async UniTask<bool> ProcessPendingOrder(PendingOrder pendingOrder, int requestId)
        {
            var product = GetFirstProductInOrder(pendingOrder);
            if (product == null)
            {
                ReportOutcome(pendingOrder, requestId, AnalyticAdapter.LogPurchaseUnknown);
                CompleteOrderCallback(pendingOrder, requestId, IAPOperationStatus.Fail, "Could not find product in pending order.", null);
                return false;
            }
            if (!productsByAnyId.TryGetValue(product.definition.id, out var storeProduct))
            {
                ReportOutcome(pendingOrder, requestId, AnalyticAdapter.LogPurchaseUnknown);
                CompleteOrderCallback(pendingOrder, requestId, IAPOperationStatus.Fail, "Product not found.", null);
                return false;
            }
            return await TryProcessPurchase(pendingOrder, product, storeProduct, requestId);
        }

        private async UniTask<bool> TryProcessPurchase(PendingOrder pendingOrder, Product product,
            IapStoreProduct targetProduct, int requestId)
        {
            int generation = lifecycle;
            bool activeOrder = IsCurrentRequest(requestId) && IsActiveOrder(pendingOrder);
            if (activeOrder) activeTransactionId = pendingOrder.Info.TransactionID;
            string receipt = pendingOrder.Info.Receipt;

            var response = await validator.VerifyAsync(product, pendingOrder, activeOrder ? purchaseLocation : "replay");
            if (generation != lifecycle) return false;
            if (!response.success)
            {
                // Never grant or confirm an unverified purchase; leave it pending so the store can retry.
                if (activeOrder) AnalyticAdapter.LogPurchaseNotVerified();
                if (activeOrder) CompleteOrderCallback(pendingOrder, requestId, IAPOperationStatus.Fail, response.error, targetProduct);
                return false;
            }

            if (FulfillPurchaseAsync == null || !await FulfillPurchaseAsync(pendingOrder.Info.TransactionID, targetProduct))
            {
                CompleteOrderCallback(pendingOrder, requestId, IAPOperationStatus.Fail, "Purchase fulfillment is not durably saved; order remains pending.", targetProduct);
                return false;
            }
            if (generation != lifecycle) return false;

            ApplyEntitlement(targetProduct, product, receipt);
            CacheOwnership(targetProduct);
            profile?.Save();

            if (interruptedTransactionIds.Remove(pendingOrder.Info.TransactionID))
                new InterruptedPurchaseRestoredEvent { Product = targetProduct }.Trigger();

            if (activeOrder) AnalyticAdapter.LogIapPurchase();
            // Replays and restores carry no placement and were logged when first bought.
            if (activeOrder) AnalyticAdapter.LogInAppPurchase(targetProduct?.productId, pendingOrder.Info.TransactionID, purchaseLocation);
            if (activeOrder) CompleteOrderCallback(pendingOrder, requestId, IAPOperationStatus.Success, null, targetProduct);
            return true;
        }

        private void OnPurchaseDeferred(Order order)
        {
            if (!debug) return;
            IapLog.Log($"Purchase deferred for product '{GetFirstProductInOrder(order)?.definition.id ?? "unknown"}'");
        }

        private void OnPurchaseConfirmed(Order order)
        {
            if (order is FailedOrder)
                IapLog.Warn("Confirmation failed; the fulfilled order remains retryable.");
        }

        private void OnPurchaseFailed(FailedOrder failedOrder)
        {
            var product = GetFirstProductInOrder(failedOrder);
            string message = $"Purchase failed - Product: '{product?.definition.id ?? "unknown"}', "
                             + $"Reason: {failedOrder.FailureReason}, Details: {failedOrder.Details}";
            // An unidentifiable failure still has to end the purchase in flight, or every later purchase is rejected.
            if (IsActiveOrder(failedOrder) || (purchaseInProgress && product == null))
            {
                AnalyticAdapter.LogPurchaseFailed();
                TryCompletePurchase(IAPOperationStatus.Fail, message, null);
                return;
            }
            IapLog.Warn(message);
        }

        private static Product GetFirstProductInOrder(Order order) =>
            order?.CartOrdered?.Items()?.FirstOrDefault()?.Product;

        private bool IsCurrentRequest(int requestId) => requestId != 0 && requestId == activePurchaseRequest;

        private bool IsActiveOrder(Order order)
        {
            if (!purchaseInProgress || order == null) return false;
            // An order the store replayed from an earlier session must never consume the current callback.
            if (interruptedTransactionIds.Contains(order.Info?.TransactionID ?? string.Empty)) return false;
            var product = GetFirstProductInOrder(order);
            if (product == null || !productsByAnyId.TryGetValue(product.definition.id, out var mapped)
                || mapped.productId != activeProductId) return false;
            return activeTransactionId == null || activeTransactionId == order.Info.TransactionID;
        }

        private void ReportOutcome(Order order, int requestId, Action report)
        {
            if (IsCurrentRequest(requestId) && IsActiveOrder(order)) report();
        }

        private void CompleteOrderCallback(Order order, int requestId, IAPOperationStatus status, string error, IapStoreProduct product)
        {
            if (IsCurrentRequest(requestId) && IsActiveOrder(order)) TryCompletePurchase(status, error, product);
        }

        private void TryCompletePurchase(IAPOperationStatus status, string error, IapStoreProduct product)
        {
            if (!purchaseInProgress && purchaseCallback == null) return;
            if (status == IAPOperationStatus.Fail)
                IapLog.Error($"Purchase of {product?.GetStoreID() ?? "unknown"} failed: {error}");

            var callback = purchaseCallback;
            purchaseCallback = null;
            purchaseInProgress = false;
            activePurchaseRequest = 0;
            activeProductId = activeTransactionId = purchaseLocation = null;
            try { callback?.Invoke(status, error, product); }
            catch (Exception ex) { IapLog.Warn($"Purchase notification callback failed: {ex.Message}"); }
        }
        #endregion

        #region Restore
        public void RestorePurchases(Action<IAPOperationStatus, string, IapStoreProduct> onProductRestored,
            Action<bool, string> onRestoreDone)
        {
            if (purchaseInProgress || restoreDone != null)
            {
                onRestoreDone?.Invoke(false, "Another purchase or restore is in progress.");
                return;
            }
            if (!IsInitialized)
            {
                onProductRestored?.Invoke(IAPOperationStatus.Fail, "Module not ready.", null);
                onRestoreDone?.Invoke(false, "Module not ready.");
                return;
            }

            restoredCallback = onProductRestored;
            restoreDone = onRestoreDone ?? ((_, _) => { });
            restoreDeadline = Time.realtimeSinceStartup + RestoreTimeoutSeconds;
            int generation = lifecycle;
            try
            {
                storeController.RestoreTransactions((success, message) =>
                {
                    if (generation != lifecycle || restoreDone == null || restoreAwaitingFetch) return;
                    if (!success) { CompleteRestore(false, message); return; }

                    // Google Play's RestoreTransactions callback alone does not fetch orders.
                    restoreAwaitingFetch = true;
                    purchasesFetchStatus = PurchasesFetchStatus.Fetching;
                    try { storeController.FetchPurchases(); }
                    catch (Exception) { CompleteRestore(false, "Purchase fetch failed."); }
                });
            }
            catch (Exception) { CompleteRestore(false, "Store restore request failed."); }
        }

        private void CompleteRestore(bool success, string message)
        {
            var callback = restoreDone;
            restoreDone = null;
            restoreAwaitingFetch = false;
            restoredCallback = null;
            callback?.Invoke(success, message);
        }
        #endregion

        // Unity IAP 5 marks SubscriptionManager obsolete without shipping a replacement for subscription state.
#pragma warning disable CS0618
        private static PixonSubscriptionInfo BuildSubscriptionSnapshot(Product product)
        {
            if (product == null || !product.hasReceipt) return null;
            try
            {
                var info = new SubscriptionManager(product, null).GetSubscriptionInfo();
                if (info == null) return null;
                return new PixonSubscriptionInfo
                {
                    productId = Safe(info.GetProductId, product.definition.id),
                    purchaseDate = Safe(info.GetPurchaseDate, default),
                    expireDate = Safe(info.GetExpireDate, default),
                    cancelDate = Safe(info.GetCancelDate, default),
                    isSubscribed = Safe(() => ToResult(info.IsSubscribed()), SubscriptionResult.Unsupported),
                    isExpired = Safe(() => ToResult(info.IsExpired()), SubscriptionResult.Unsupported),
                    isCancelled = Safe(() => ToResult(info.IsCancelled()), SubscriptionResult.Unsupported),
                    isFreeTrial = Safe(() => ToResult(info.IsFreeTrial()), SubscriptionResult.Unsupported),
                    isAutoRenewing = Safe(() => ToResult(info.IsAutoRenewing()), SubscriptionResult.Unsupported),
                    isIntroductoryPricePeriod = Safe(() => ToResult(info.IsIntroductoryPricePeriod()), SubscriptionResult.Unsupported),
                    remainingTime = Safe(info.GetRemainingTime, default),
                    subscriptionPeriod = Safe(info.GetSubscriptionPeriod, default),
                    freeTrialPeriod = Safe(info.GetFreeTrialPeriod, default),
                    freeTrialPeriodString = Safe(info.GetFreeTrialPeriodString, null),
                    introductoryPricePeriod = Safe(info.GetIntroductoryPricePeriod, default),
                    introductoryPrice = Safe(info.GetIntroductoryPrice, null),
                    introductoryPricePeriodCycles = Safe(info.GetIntroductoryPricePeriodCycles, 0L),
                    skuDetails = Safe(info.GetSkuDetails, null),
                    subscriptionInfoJson = Safe(info.GetSubscriptionInfoJsonString, null),
                };
            }
            catch (Exception ex)
            {
                IapLog.Warn($"Subscription info unavailable for '{product.definition.id}': {ex.Message}");
                return null;
            }
        }
#pragma warning restore CS0618

        // Individual getters throw on stores that do not report the value; a missing field must not lose the rest.
        private static T Safe<T>(Func<T> read, T fallback)
        {
            try { return read(); }
            catch (Exception) { return fallback; }
        }

        private static SubscriptionResult ToResult(Result result) => result switch
        {
            Result.True => SubscriptionResult.True,
            Result.False => SubscriptionResult.False,
            _ => SubscriptionResult.Unsupported,
        };

        private enum ModuleStatus { NotInitialized, Initializing, Initialized, Failed }
        private enum StoreConnectionStatus { NotConnected, Connected, Disconnected, Connecting }
        private enum ProductFetchStatus { NotFetched, Fetching, Failed, PartialSuccess, Success }
        private enum PurchasesFetchStatus { NotFetched, Success, Failed, Fetching }
    }

    /// <summary>Raised after a purchase left pending by an earlier session was replayed and fulfilled.</summary>
    public class InterruptedPurchaseRestoredEvent : GameEvent
    {
        public IapStoreProduct Product;
    }

    internal static class IapLog
    {
        private const string Tag = "[IAP] ";

        public static void Log(string message) => Debug.Log(Tag + message);
        public static void Warn(string message) => Debug.LogWarning(Tag + message);
        public static void Error(string message) => Debug.LogError(Tag + message);
    }
}
