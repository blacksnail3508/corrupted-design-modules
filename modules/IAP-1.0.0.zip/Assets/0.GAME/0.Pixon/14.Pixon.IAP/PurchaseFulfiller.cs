using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Pixon.Data;

namespace Pixon.IAP
{
    /// <summary>Grants a verified purchase exactly once and remembers what the player owns.</summary>
    public class PurchaseFulfiller
    {
        private readonly Vault<Ledger> vault = new(ShopConfig.FULFILLED_KEY, new Ledger());
        private readonly IRewardGranter granter;

        public event Action NoAdsGranted;

        public PurchaseFulfiller(IRewardGranter granter) => this.granter = granter;

        private Ledger Data => vault.Value ??= new Ledger();

        public bool IsNoAds => Data.noAds;

        public bool IsBought(ProductName name) => Data.boughtProducts.Contains(name.ToString());

        // Rewards and the replay marker are saved in one ledger write, so a transaction is never granted twice.
        public UniTask<bool> FulfillAsync(string transactionId, IapStoreProduct product)
        {
            var ledger = Data;
            if (ledger.transactions.Contains(transactionId)) return UniTask.FromResult(true);
            if (!granter.CanGrant) return UniTask.FromResult(false);

            foreach (var reward in product.Data.Rewards) granter.Grant(reward);

            ledger.transactions.Add(transactionId);
            if (ledger.transactions.Count > ShopConfig.MAX_FULFILLED_TRANSACTIONS) ledger.transactions.RemoveAt(0);
            string key = product.Data.Name.ToString();
            if (!ledger.boughtProducts.Contains(key)) ledger.boughtProducts.Add(key);

            bool newNoAds = product.Data.GrantsNoAds && !ledger.noAds;
            if (newNoAds) ledger.noAds = true;
            vault.Save(ledger);

            if (newNoAds) NoAdsGranted?.Invoke();
            return UniTask.FromResult(true);
        }

        [Serializable]
        private class Ledger
        {
            public List<string> transactions = new();
            public List<string> boughtProducts = new();
            public bool noAds;
        }
    }
}
