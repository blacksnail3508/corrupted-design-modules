using System;
using Cysharp.Threading.Tasks;
using Pixon.Observer;
using Pixon.UI;
using UnityEngine;

namespace Pixon.IAP
{
    /// <summary>Game-facing IAP entry point: boots the store and answers every product, price and ownership query.</summary>
    public static class ShopService
    {
        private static readonly IRewardGranter granter = new RewardGranter();
        private static readonly PurchaseFulfiller fulfiller = CreateFulfiller();

        private static IapController controller;
        private static ShopCatalog catalog;
        private static bool ready;
        private static bool buying;

        private const float PurchaseStartDelaySeconds = 0.25f;

        public static bool IsReady => ready;

        // Interrupted orders are replayed at init and need the wallet and hearts to exist, so boot waits for them.
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void AutoBoot() => BootWhenGameReady().Forget();

        private static async UniTaskVoid BootWhenGameReady()
        {
            await UniTask.WaitUntil(() => granter.CanGrant);
            Initialize();
        }

        public static void Initialize()
        {
            if (controller != null) return;

            var profile = new InAppPurchaseProfile();
            catalog = new ShopCatalog(ShopConfig.Products, profile);

            IapTicker.Create(() => controller?.OnUpdate());
            controller = new IapController { FulfillPurchaseAsync = fulfiller.FulfillAsync };
            controller.Initialize(profile, catalog.ByAnyId, ShopConfig.FetchPurchasedOnInitialized,
                ShopConfig.DebugLog, success => ready = success);
        }

        public static void Shutdown()
        {
            controller?.Shutdown();
            controller = null;
            ready = false;
            EndBuying();
        }

        public static void Buy(ProductName name, string location, Action<bool> onDone = null)
        {
            // A second tap during the processing window is dropped, not reported as a failed purchase.
            if (buying) return;
            if (IsSoldOut(name))
            {
                onDone?.Invoke(false);
                return;
            }
            if (controller == null || !catalog.TryGet(name, out var product))
            {
                ShowPurchaseFailed();
                onDone?.Invoke(false);
                return;
            }

            buying = true;
            GameService.UIManager?.ShowPopup<UIPopupLoadingIap>(UITrigger.Auto);
            // Unscaled so a paused game (timeScale 0) still reaches the store.
            Delay.CallUnscaled(PurchaseStartDelaySeconds, () =>
            {
                if (controller == null)
                {
                    EndBuying();
                    ShowPurchaseFailed();
                    onDone?.Invoke(false);
                    return;
                }
                controller.BuyProduct(product.Data.ProductId, location, (status, message, bought) =>
                {
                    EndBuying();
                    bool success = status == IAPOperationStatus.Success;
                    if (success) new PurchaseCompletedEvent { Product = bought }.Trigger();
                    else ShowPurchaseFailed();
                    onDone?.Invoke(success);
                });
            });
        }

        private static void ShowPurchaseFailed() => GameService.UIManager?.ShowPopup<UIPopupPurchaseFailed>(UITrigger.Auto);

        private static void EndBuying()
        {
            buying = false;
            GameService.UIManager?.ClosePopup<UIPopupLoadingIap>();
        }

        public static void RestorePurchases(Action<bool> onDone = null)
        {
            if (controller == null)
            {
                onDone?.Invoke(false);
                return;
            }
            controller.RestorePurchases(null, (success, message) =>
            {
                if (success) new RestorePurchaseSuccessEvent().Trigger();
                onDone?.Invoke(success);
            });
        }

        /// <summary>The authored definition: ids, type and the full reward list.</summary>
        public static ProductData GetProductData(ProductName name) => ShopConfig.Products[name];

        public static string GetPriceString(ProductName name) => TryGet(name, out var p) ? p.localizedPriceString : "-";

        public static double GetPrice(ProductName name) => TryGet(name, out var p) ? p.price : 0d;

        public static string GetCurrencyCode(ProductName name) => TryGet(name, out var p) ? p.isoCurrencyCode : "-";

        public static bool IsActive(ProductName name) => TryGet(name, out var p) && p.active;

        public static bool IsBoughtBefore(ProductName name) => fulfiller.IsBought(name);

        /// <summary>True for a one-time product the player already bought, so it must not be offered or sold again.</summary>
        public static bool IsSoldOut(ProductName name) =>
            (ShopConfig.Products[name].OneTime || ShopConfig.Products[name].Type == IapProductType.NonConsumable) && fulfiller.IsBought(name);

        public static bool IsNoAds() => fulfiller.IsNoAds;

        public static PixonSubscriptionInfo GetSubscriptionInfo(ProductName name) =>
            TryGet(name, out var p) ? p.subscriptionInfo : null;

        public static SubscriptionResult IsSubscribed(ProductName name) =>
            GetSubscriptionInfo(name)?.isSubscribed ?? SubscriptionResult.Unsupported;

        public static DateTime GetExpireDate(ProductName name) => GetSubscriptionInfo(name)?.expireDate ?? default;

        public static TimeSpan GetRemainingTime(ProductName name) => GetSubscriptionInfo(name)?.remainingTime ?? default;

        private static bool TryGet(ProductName name, out IapStoreProduct product)
        {
            product = null;
            return catalog != null && catalog.TryGet(name, out product);
        }

        private static PurchaseFulfiller CreateFulfiller()
        {
            var created = new PurchaseFulfiller(granter);
            created.NoAdsGranted += () => new NoAdsEvent().Trigger();
            return created;
        }
    }

    public class PurchaseCompletedEvent : GameEvent
    {
        public IapStoreProduct Product;
    }

    public class RestorePurchaseSuccessEvent : GameEvent { }

    public class NoAdsEvent : GameEvent { }

    /// <summary>Runs the controller watchdog on unscaled time so a paused game still times purchases out.</summary>
    internal class IapTicker : MonoBehaviour
    {
        private Action tick;

        public static void Create(Action tick)
        {
            var go = new GameObject("IapTicker");
            DontDestroyOnLoad(go);
            go.AddComponent<IapTicker>().tick = tick;
        }

        private void Update() => tick?.Invoke();
    }
}
