using Pixon.UI;
using UnityEngine;

public class UIPopupLoadingIap : Window
{
    public override string PopupType =>  "popup_loading";
}
