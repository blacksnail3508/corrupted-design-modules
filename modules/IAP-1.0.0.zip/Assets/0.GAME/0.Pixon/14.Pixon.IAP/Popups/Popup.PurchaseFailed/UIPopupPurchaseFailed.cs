using Pixon.UI;
using TMPro;
using UnityEngine;

/// <summary>Tells the player a store purchase did not go through.</summary>
public class UIPopupPurchaseFailed : Window
{
    public override string PopupType => "popup_purchase_failed";

    [SerializeField] private ButtonBase continueButton;
    [SerializeField] private TMP_Text messageText;

    private void Start() => continueButton.AddListener(() => this.ClosePopup<UIPopupPurchaseFailed>());

    public UIPopupPurchaseFailed SetMessage(string message)
    {
        messageText.text = message;
        return this;
    }
}
