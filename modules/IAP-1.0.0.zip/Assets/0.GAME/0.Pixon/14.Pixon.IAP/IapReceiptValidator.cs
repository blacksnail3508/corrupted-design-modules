using Cysharp.Threading.Tasks;
using UnityEngine.Purchasing;

namespace Pixon.IAP
{
    /// <summary>Checks a pending order. The default accepts every order; override with a server or store validator for production.</summary>
    public class IapReceiptValidator
    {
        public virtual UniTask<IapVerification> VerifyAsync(Product product, Order order, string purchaseLocation) =>
            UniTask.FromResult(Accepted());

        protected static IapVerification Accepted() => new() { success = true, error = string.Empty };

        protected static IapVerification Rejected(string error) => new() { success = false, error = error };
    }
}
