using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "DefineSymbolsData", menuName = "Define Manager/Define Symbols Data")]
public class DefineSymbolsData : ScriptableObject
{
    public List<string> activeDefines = new List<string>();
}