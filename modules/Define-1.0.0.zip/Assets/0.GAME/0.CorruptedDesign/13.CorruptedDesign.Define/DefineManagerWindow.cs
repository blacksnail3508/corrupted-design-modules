#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.Linq;

public class DefineManagerWindow : EditorWindow
{
    private DefineSymbolsData data;
    private string newDefine = "";
    private Vector2 scrollPos;
    private HashSet<string> tempActiveDefines = new HashSet<string>(); // Local cache
    private bool hasUnsavedChanges = false;

    [MenuItem("Tools/Define Manager")]
    public static void ShowWindow()
    {
        GetWindow<DefineManagerWindow>("Define Manager");
    }

    private void OnEnable()
    {
        LoadOrCreateData();
        RefreshDefinesFromPlayerSettings();
    }

    private void LoadOrCreateData()
    {
        string[] guids = AssetDatabase.FindAssets("t:DefineSymbolsData");
        if (guids.Length > 0)
        {
            data = AssetDatabase.LoadAssetAtPath<DefineSymbolsData>(AssetDatabase.GUIDToAssetPath(guids[0]));
        }
        else
        {
            data = CreateInstance<DefineSymbolsData>();
            AssetDatabase.CreateAsset(data, "Assets/DefineSymbolsData.asset");
            AssetDatabase.SaveAssets();
        }
    }

    private void RefreshDefinesFromPlayerSettings()
    {
        string definesString = PlayerSettings.GetScriptingDefineSymbolsForGroup(EditorUserBuildSettings.selectedBuildTargetGroup);
        var defines = definesString.Split(';').Where(d => !string.IsNullOrEmpty(d)).ToList();

        foreach (var d in defines)
        {
            if (!data.activeDefines.Contains(d))
                data.activeDefines.Add(d);
        }

        tempActiveDefines = new HashSet<string>(defines);
        hasUnsavedChanges = false;
    }

    private void OnGUI()
    {
        if (data == null)
        {
            EditorGUILayout.HelpBox("Define Symbols Data not found.", MessageType.Warning);
            if (GUILayout.Button("Create Data"))
            {
                LoadOrCreateData();
            }
            return;
        }

        EditorGUILayout.LabelField("Scripting Define Symbols", EditorStyles.boldLabel);

        scrollPos = EditorGUILayout.BeginScrollView(scrollPos, GUILayout.Height(250));

        for (int i = 0; i < data.activeDefines.Count; i++)
        {
            EditorGUILayout.BeginHorizontal();

            string define = data.activeDefines[i];
            bool isActive = tempActiveDefines.Contains(define);

            bool newActive = EditorGUILayout.ToggleLeft(define, isActive, GUILayout.Width(200));
            if (newActive != isActive)
            {
                if (newActive)
                    tempActiveDefines.Add(define);
                else
                    tempActiveDefines.Remove(define);

                hasUnsavedChanges = true;
            }

            if (GUILayout.Button("Delete", GUILayout.Width(60)))
            {
                data.activeDefines.RemoveAt(i);
                tempActiveDefines.Remove(define);
                i--;
                hasUnsavedChanges = true;
                continue;
            }

            EditorGUILayout.EndHorizontal();
        }

        EditorGUILayout.EndScrollView();

        EditorGUILayout.Space();
        EditorGUILayout.LabelField("Add New Define", EditorStyles.boldLabel);

        EditorGUILayout.BeginHorizontal();
        newDefine = EditorGUILayout.TextField(newDefine);

        if (GUILayout.Button("Add", GUILayout.Width(60)))
        {
            AddDefine(newDefine);
            newDefine = "";
        }
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.Space();
        if (GUILayout.Button("Refresh from Player Settings"))
        {
            RefreshDefinesFromPlayerSettings();
        }

        GUI.enabled = hasUnsavedChanges;
        if (GUILayout.Button("✅ Apply Changes"))
        {
            ApplyChanges();
        }
        GUI.enabled = true;

        if (GUI.changed)
        {
            EditorUtility.SetDirty(data);
        }
    }

    private void AddDefine(string define)
    {
        if (string.IsNullOrWhiteSpace(define) || data.activeDefines.Contains(define))
            return;

        data.activeDefines.Add(define);
        tempActiveDefines.Add(define);
        hasUnsavedChanges = true;
    }

    private void ApplyChanges()
    {
        string newDefines = string.Join(";", tempActiveDefines);
        PlayerSettings.SetScriptingDefineSymbolsForGroup(EditorUserBuildSettings.selectedBuildTargetGroup, newDefines);

        hasUnsavedChanges = false;
        Debug.Log("Applied defines: " + newDefines);
    }
}
#endif
