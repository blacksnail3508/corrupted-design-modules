// Manages level progression, tracking played levels and loading level data.
// Levels loop within a defined range. Played state is persisted via Vault.

using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Pixon.Data;
using Sirenix.OdinInspector;
using Sirenix.Utilities;
using UnityEngine;
using CC = Pixon.Remote.ConfigCollection;

[Serializable]
public class LevelSystem
{
    public static readonly Vector2Int DefaultLoop = new(21, 100);
    public static Vector2Int Loop { get; private set; } = DefaultLoop;

    [SerializeField] List<int> NewLevels = new();
    [SerializeField] Vault<List<int>> playedLevelVault = new("user_played_level", new List<int>());
    [SerializeField] Vault<int> pinPlayerLevelVault = new("user_loop_pin_level", 0);
    [SerializeField] Vault<int> pinRawLevelVault = new("user_loop_pin_raw", 0);

    readonly LevelRemoteFetcher remoteLevels = new();

    [Button("REFRESH")]
    public void Initialize()
    {
        remoteLevels.Initialize();
        remoteLevels.Synced -= RefreshLoop;
        remoteLevels.Synced += RefreshLoop;
        RefreshLoop();
    }

    private void RefreshLoop()
    {
        Loop = new Vector2Int(DefaultLoop.x, Mathf.Max(DefaultLoop.y, remoteLevels.MaxLevel));
        // Reset lists
        NewLevels = ScanForUnplayedLevels();
    }

    private bool IsAvailable(int level) => level >= 1 && (level <= DefaultLoop.y || remoteLevels.Has(level));

    // Find all unplayed levels
    private List<int> ScanForUnplayedLevels()
    {
        var played = playedLevelVault.Value;
        var result = new List<int>();
        for (int i = 1; i <= Loop.y; i++)
            if (!played.Contains(i) && IsAvailable(i)) result.Add(i);
        return result;
    }

    // Load current level data
    public LevelJson GetLevelJson(int level)
    {
        //check if user level is higher than level pool, reuse level instead
        int loopedLevel = GetLevelLooped(level);

        return GetRemoteLevelData(loopedLevel) ?? GetRawLevelData(loopedLevel, 0);
    }

    // Tester path: bundled levels only, never the remote pack.
    public LevelJson GetBuiltinLevelJson(int level)
    {
        int builtin = level <= DefaultLoop.y ? Mathf.Max(1, level) : LoopClamp(level, Loop.x, DefaultLoop.y);
        return GetRawLevelData(builtin, 0);
    }

    public LevelJson FallbackToDefault(LevelJson failed, Exception error)
    {
        int level = failed.RemoteLevel;
        remoteLevels.Reject(level);
        Debug.LogError($"[LevelRemote] Remote Level_{level} failed to init, falling back to Resources. {error}");
        if (level <= DefaultLoop.y) return GetRawLevelData(level, 0);

        int replacement = PickDefaultReuseLevel(level);
        if (pinRawLevelVault.Value == level) pinRawLevelVault.Save(replacement);
        return GetRawLevelData(replacement, 0);
    }

    private LevelJson GetRemoteLevelData(int level)
    {
        // return null;
        if (!remoteLevels.TryGet(level, out var json)) return null;

        try
        {
            var data = JsonConvert.DeserializeObject<LevelJson>(json);
            if (data == null) throw new Exception("level is empty");

            data.RemoteLevel = level;
            Bug.Log($"Load lv {level} from remote");
            return data;
        }
        catch (Exception e)
        {
            remoteLevels.Reject(level);
            Debug.LogError($"[LevelRemote] Remote Level_{level} is invalid, using Resources. {e.Message}");
            return null;
        }
    }
    
    // Load from default pack
    LevelJson LoadLevelFromDefaultPack(int level)
    {
        string path = $"Levels/Level_{level}";
        var file = Resources.Load<TextAsset>(path);
        if (file == null)
        {
            // The template ships no level files, so a game without them still boots on an empty level.
            Bug.LogWarning($"[LevelSystem] {path} not found, using an empty level.");
            return new LevelJson();
        }

        Bug.Log($"Load lv {level} from file {path}");
        return JsonConvert.DeserializeObject<LevelJson>(file.text);
    }

    // Load level data with fallback
    private LevelJson GetRawLevelData(int level, int levelPack)
    {
        string path = $"Levels_{levelPack}/Level_{level}";
        try
        {
            var file = Resources.Load<TextAsset>(path);
            string json = file?.text;
            if (json.IsNullOrWhitespace()) throw new Exception();
            Bug.Log($"Load lv {level} of pack {levelPack} from file {path}");
            return JsonConvert.DeserializeObject<LevelJson>(json);
        }
        catch
        {
            // Bug.Log($"Level {level} of pack {levelPack} not found! Using default pack = {DefaultPack}");
            return LoadLevelFromDefaultPack(level);
        }
    }

    [Button("GET LEVEL LOOPED")]
    public int GetLevelLooped(int level)
    {
        if (level < 1) level = 1;

        if (level <= DefaultLoop.y) return level;

        if (pinPlayerLevelVault.Value == level && IsAvailable(pinRawLevelVault.Value))
            return pinRawLevelVault.Value;

        int result = level <= Loop.y && IsAvailable(level) ? level : PickReuseLevel(level);
        pinPlayerLevelVault.Save(level);
        pinRawLevelVault.Save(result);
        return result;
    }

    private int PickReuseLevel(int level)
    {
        for (int i = 0; i < NewLevels.Count; i++)
            if (NewLevels[i] >= Loop.x && NewLevels[i] < level && IsAvailable(NewLevels[i])) return NewLevels[i];

        int looped = LoopClamp(level, Loop.x, Loop.y);
        return IsAvailable(looped) ? looped : LoopClamp(level, Loop.x, DefaultLoop.y);
    }

    private int PickDefaultReuseLevel(int level)
    {
        for (int i = 0; i < NewLevels.Count; i++)
            if (NewLevels[i] >= Loop.x && NewLevels[i] <= DefaultLoop.y) return NewLevels[i];
        return LoopClamp(level, Loop.x, DefaultLoop.y);
    }

    private void ClearLoopPin()
    {
        pinPlayerLevelVault.Save(0);
        pinRawLevelVault.Save(0);
    }

    [Button("Mark Play Level")]
    public void MarkLevelAsPlayed(int level)
    {
        var played = playedLevelVault.Value;
        if (level <= Loop.y && !played.Contains(level)) played.Add(level);
        playedLevelVault.Save(played);
        NewLevels.Remove(level);
    }

    [Button("Mark Play Level Range")]
    public void MarkLevelAsPlayed(int from, int to)
    {
        var played = playedLevelVault.Value.ToHashSet();
        int maxLevel = Mathf.Min(to, Loop.y);
        for (int i = from; i <= maxLevel; i++) played.Add(i);
        playedLevelVault.Save(played.ToList());
    }

    [Button("Mark Unplay Level Range")]
    public void MarkLevelAsUnplayed(int from, int to)
    {
        var played = playedLevelVault.Value;
        for (int i = from; i <= to; i++) played.Remove(i);
        playedLevelVault.Save(played);
    }

    public void ClearPlayedLevels()
    {
        var played = playedLevelVault.Value;
        played.Clear();
        playedLevelVault.Save(played);
        ClearLoopPin();
    }

    public void ResetPlayedLevel()
    {
        playedLevelVault.Save(new List<int>());
        ClearLoopPin();
    }

    private int LoopClamp(int x, int loopStart, int loopEnd)
    {
        if (x <= loopEnd && x > 0)
            return x;

        // Wrap around into the range
        int rangeSize = loopEnd - loopStart + 1;
        return loopStart + ((x - loopStart) % rangeSize);
    }
}