using System;
using System.Collections.Generic;

[Serializable]
public class LevelBundle
{
    public string BundleName = "Bundle_0";
    public int BundleID = 0;
    public List<string> LevelData = new List<string>();
}

[Serializable]
public class FetchedLevels
{
    public List<LevelBundle> LevelBundles = new List<LevelBundle>();
}
