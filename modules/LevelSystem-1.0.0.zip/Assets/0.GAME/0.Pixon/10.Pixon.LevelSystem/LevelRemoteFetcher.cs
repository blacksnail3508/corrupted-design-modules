using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Pixon.Data;
using Pixon.Remote;

public class LevelRemoteFetcher
{
    public const string KeyPrefix = "level_bundle_";
    public const int LevelsPerBundle = 10;

    /// <summary>Supplies the raw remote key/value pairs that hold level bundles. Wire the remote backend here; the default has none.</summary>
    public static Func<IEnumerable<KeyValuePair<string, string>>> BundleSource { get; set; } =
#if PIXON_HAS_FIREBASE_REMOTE_CONFIG
        () => RemoteFetcherFirebase.ReadByPrefix(KeyPrefix);
#else
        () => Array.Empty<KeyValuePair<string, string>>();
#endif

    readonly Vault<FetchedLevels> fetchedLevels = new(PlayerPrefsKey.FetchedLevels, new FetchedLevels(), VaultBackend.JsonFile);
    readonly Dictionary<int, string> levels = new();
    readonly HashSet<int> rejected = new();
    bool initialized;

    public int MaxLevel { get; private set; }
    public event Action Synced;

    public void Initialize()
    {
        if (initialized) return;
        initialized = true;

        Rebuild(fetchedLevels.Value);

        RemoteManager.OnFetchCompleted += OnFetchCompleted;
        if (RemoteManager.Instance != null && RemoteManager.Instance.IsFetchDone) OnFetchCompleted();
    }

    public bool TryGet(int rawLevel, out string json)
    {
        json = null;
        return !rejected.Contains(rawLevel) && levels.TryGetValue(rawLevel, out json);
    }

    public bool Has(int rawLevel) => !rejected.Contains(rawLevel) && levels.ContainsKey(rawLevel);

    public void Reject(int rawLevel) => rejected.Add(rawLevel);

    void OnFetchCompleted()
    {
        if (RemoteManager.Instance == null || RemoteManager.Instance.Source != "Remote") return;

        var fetched = ReadFromRemote();
        fetchedLevels.Save(fetched);
        Rebuild(fetched);
        Bug.Log($"[LevelRemote] Synced {fetched.LevelBundles.Count} bundles, {levels.Count} remote levels, max Level_{MaxLevel}.");
        Synced?.Invoke();
    }

    static FetchedLevels ReadFromRemote()
    {
        var result = new FetchedLevels();

        foreach (var pair in BundleSource())
        {
            var key = pair.Key;
            if (!key.StartsWith(KeyPrefix, StringComparison.Ordinal)) continue;

            if (!int.TryParse(key.Substring(KeyPrefix.Length), out int bundleId) || bundleId < 0)
            {
                Bug.LogWarning($"[LevelRemote] Skip key '{key}': no bundle id after '{KeyPrefix}'.");
                continue;
            }

            try
            {
                var bundle = JsonConvert.DeserializeObject<LevelBundle>(pair.Value);
                if (bundle == null) continue;

                if (bundle.BundleID != bundleId)
                    Bug.LogWarning($"[LevelRemote] '{key}' declares BundleID {bundle.BundleID}; using {bundleId} from the key.");
                bundle.BundleID = bundleId;
                result.LevelBundles.Add(bundle);
            }
            catch (Exception e)
            {
                Bug.LogWarning($"[LevelRemote] Skip '{key}': {e.Message}");
            }
        }

        return result;
    }

    void Rebuild(FetchedLevels fetched)
    {
        levels.Clear();
        rejected.Clear();
        MaxLevel = 0;
        if (fetched?.LevelBundles == null) return;

        foreach (var bundle in fetched.LevelBundles)
        {
            if (bundle?.LevelData == null) continue;

            if (bundle.LevelData.Count > LevelsPerBundle)
                Bug.LogWarning($"[LevelRemote] Bundle {bundle.BundleID} has {bundle.LevelData.Count} levels; only the first {LevelsPerBundle} are used.");

            int count = Math.Min(bundle.LevelData.Count, LevelsPerBundle);
            for (int i = 0; i < count; i++)
            {
                var json = bundle.LevelData[i];
                if (string.IsNullOrWhiteSpace(json)) continue;

                int level = bundle.BundleID * LevelsPerBundle + i;
                levels[level] = json;
                MaxLevel = Math.Max(MaxLevel, level);
            }
        }
    }
}
