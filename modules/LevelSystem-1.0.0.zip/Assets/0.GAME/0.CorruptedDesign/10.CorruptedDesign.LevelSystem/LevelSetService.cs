using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using CorruptedDesign.Data;
using CorruptedDesign.LevelSets;
using CorruptedDesign.Remote;
using UnityEngine;
using CC = CorruptedDesign.Remote.ConfigCollection;

/// <summary>Picks the active remote level set from remote config, keeps its manifest and prefetches its levels to disk.</summary>
public sealed class LevelSetService
{
    // Editor only: an http(s) url or a folder that replaces the configured source while testing sets.
    public const string LocalBaseUrlPrefKey = "LevelSet.LocalBaseUrl";
    // One FetchAsync of at most PrefetchBatch levels at a time caps downloads service-wide; a newer window replaces the rest.
    private const int PrefetchBatch = 3;

    private readonly Vault<string> activeVault = new("level_set_active", "");
    private readonly Vault<string> forcedVault = new("level_set_forced", "");
    private readonly HashSet<int> broken = new();
    private readonly Func<string, bool> isValidLevel;

    private LevelSetCache cache;
    private LevelSetLoader loader;
    private bool initialized;
    private List<int> pendingWanted;
    private string pendingSet;
    private bool fetching;
    // Bumped by every decision, so a manifest that lands after a newer decision is ignored.
    private int resolveVersion;
    private string resolving;

    /// <summary>Name of the set being played, or "" for built-in levels only.</summary>
    public string ActiveSet { get; private set; } = "";
    public LevelSetManifest ActiveManifest { get; private set; }
    public int CachedCount => ActiveManifest != null ? cache.CountLevels(ActiveSet) : 0;
    /// <summary>Raised on every set decision and every downloaded level.</summary>
    public event Action Changed;
    // Bumped by set decisions only, so listeners can tell them from the Changed raised for each downloaded level.
    public int SetVersion { get; private set; }
    /// <summary>Set that overrides remote config (QA, or a game without Firebase), or "" when none.</summary>
    public string ForcedSet => LevelSetName.Normalize(forcedVault.Value);

    /// <param name="isValidLevel">Whether a downloaded level text is playable; the game's parser, since the payload format is game-side.</param>
    public LevelSetService(Func<string, bool> isValidLevel) => this.isValidLevel = isValidLevel ?? (text => !string.IsNullOrWhiteSpace(text));

    public void Initialize()
    {
        if (initialized) return;
        initialized = true;

        cache = new LevelSetCache(Path.Combine(Application.persistentDataPath, "level_sets"));
        loader = new LevelSetLoader(CreateDownloader(), cache, isValidLevel,
            logWarning: m => Bug.LogWarning(m), logError: m => Debug.LogError(m));
        loader.LevelCached += OnLevelCached;

        var saved = LevelSetName.Normalize(activeVault.Value);
        // A set whose manifest is gone from disk cannot be played offline; built-in until the fetch decides again.
        if (saved != "" && cache.TryReadManifest(saved, out var manifest))
        {
            ActiveSet = saved;
            ActiveManifest = manifest;
        }
        loader.SetCurrent(ActiveSet);
        Bug.Log($"[LevelSet] Start with {(ActiveSet == "" ? LevelSetName.Builtin : ActiveSet)}");

        RemoteManager.OnFetchCompleted -= OnFetchCompleted;
        RemoteManager.OnFetchCompleted += OnFetchCompleted;
        if (RemoteManager.Instance != null && RemoteManager.Instance.IsFetchDone) OnFetchCompleted();
    }

    /// <summary>Forces a set over remote config and saves it; "" hands the choice back to remote config.</summary>
    public void ForceSet(string set)
    {
        forcedVault.Save(LevelSetName.Normalize(set));
        if (initialized) SafeEvaluate();
    }

    // Membership comes from the manifest, so it never depends on what is downloaded yet.
    public bool HasLevel(int level) => ActiveManifest != null && ActiveManifest.Has(level);

    public bool IsCached(int level) => HasLevel(level) && !broken.Contains(level) && cache.HasLevel(ActiveSet, level);

    /// <summary>Reads a cached set level as raw text, the game parses it.</summary>
    public bool TryRead(int level, out string text)
    {
        text = null;
        return IsCached(level) && cache.TryReadLevel(ActiveSet, level, out text);
    }

    /// <summary>Stops serving a set level for the rest of the session.</summary>
    public void MarkBroken(int level)
    {
        if (level > 0) broken.Add(level);
    }

    // The file is gone, so prefetch downloads it again for the next session; this session keeps built-in.
    public void Discard(int level)
    {
        MarkBroken(level);
        if (ActiveManifest != null) cache.DeleteLevel(ActiveSet, level);
    }

    /// <summary>Downloads the levels of <paramref name="wanted"/> the active set holds, in order, replacing any older window.</summary>
    public void Prefetch(IReadOnlyList<int> wanted)
    {
        if (!initialized || ActiveManifest == null || wanted == null || wanted.Count == 0) return;
        if (Application.internetReachability == NetworkReachability.NotReachable) return;

        var levels = new List<int>(wanted.Count);
        foreach (var level in wanted)
            if (ActiveManifest.Has(level) && !levels.Contains(level)) levels.Add(level);
        if (levels.Count == 0) return;

        pendingWanted = levels;
        pendingSet = ActiveSet;
        if (!fetching) _ = Observe(PumpPrefetch(), "Prefetch");
    }

    private async Task PumpPrefetch()
    {
        fetching = true;
        try
        {
            string set = null;
            var queue = new Queue<int>();
            while (true)
            {
                if (pendingWanted != null)
                {
                    set = pendingSet;
                    queue = new Queue<int>(pendingWanted);
                    pendingWanted = null;
                }
                if (set != ActiveSet || queue.Count == 0) break;

                var batch = new List<int>(PrefetchBatch);
                while (batch.Count < PrefetchBatch && queue.Count > 0)
                {
                    var level = queue.Dequeue();
                    // Skipped here so a batch holds real downloads, not levels the loader would drop at once.
                    if (!cache.HasLevel(set, level) && !loader.IsMissing(set, level)) batch.Add(level);
                }
                // After a network failure the queue waits for the next trigger, unless one already arrived during this batch.
                if (batch.Count > 0 && await loader.FetchAsync(set, batch) && pendingWanted == null) break;
            }
        }
        finally { fetching = false; }
    }

    #region SET DECISION

    private void OnFetchCompleted() => SafeEvaluate();

    private void SafeEvaluate()
    {
        try { Evaluate(); }
        catch (Exception e) { Debug.LogError($"[LevelSet] Choosing the level set failed: {e}"); }
    }

    private void Evaluate()
    {
        string target;
        var forced = ForcedSet;
        if (forced != "") target = forced;
        else if (RemoteManager.Instance != null && RemoteManager.Instance.IsFetchDone && RemoteManager.Instance.Source == "Remote")
            target = LevelSetName.Normalize(CC.LevelSet.Value);
        // A cached or default config is not a decision: keep whatever set was active.
        else return;

        if (target == resolving) return;

        if (target == "")
        {
            resolveVersion++;
            resolving = null;
            if (ActiveSet != "") SwitchToBuiltin("level_set is empty");
            return;
        }

        if (target == ActiveSet)
        {
            RaiseSetChanged();
            // The set is already active from its cached manifest; ask once more so levels added to it since are noticed.
            _ = Observe(Resolve(target, true), "Refresh of " + target);
            return;
        }

        _ = Observe(Resolve(target), "Resolve of " + target);
    }

    private async Task Resolve(string target, bool refresh = false)
    {
        var version = ++resolveVersion;
        resolving = target;
        ResolveStatus status;
        LevelSetManifest manifest;
        try { (status, manifest) = await loader.ResolveAsync(target, refresh); }
        finally { if (version == resolveVersion) resolving = null; }
        if (version != resolveVersion) return;

        switch (status)
        {
            case ResolveStatus.Ready:
                // Same set with a newer manifest: keep the session state (broken levels, pins) and only widen what it holds.
                if (target == ActiveSet)
                {
                    ActiveManifest = manifest;
                    RaiseSetChanged();
                }
                else Switch(target, manifest);
                break;
            case ResolveStatus.NotFound:
                Bug.LogWarning($"[LevelSet] Set {target} not found");
                SwitchToBuiltin("set " + target + " not found");
                break;
            default:
                Bug.LogWarning($"[LevelSet] Set {target} unavailable, keeping {(ActiveSet == "" ? LevelSetName.Builtin : ActiveSet)} until next launch");
                break;
        }
    }

    private void Switch(string set, LevelSetManifest manifest)
    {
        ActiveSet = set;
        ActiveManifest = manifest;
        broken.Clear();
        activeVault.Save(set);
        loader.SetCurrent(set);
        cache.DeleteAllExcept(set);
        Bug.Log($"[LevelSet] Active set {set}: {manifest.LevelCount} levels");
        RaiseSetChanged();
    }

    private void SwitchToBuiltin(string reason)
    {
        ActiveSet = "";
        ActiveManifest = null;
        broken.Clear();
        activeVault.Save("");
        // Makes downloads still in flight for the old set stale, so they are neither written nor announced.
        loader.SetCurrent("");
        cache.DeleteAllExcept("");
        Bug.Log($"[LevelSet] Active set builtin ({reason})");
        RaiseSetChanged();
    }

    #endregion

    private void OnLevelCached(string set, int level)
    {
        // Runs inside the loader's worker: a throw here would end that worker's queue.
        try
        {
            if (set != ActiveSet) return;
            Bug.Log($"[LevelSet] Cached Level_{level} of {set}");
            RaiseChanged();
        }
        catch (Exception e) { Debug.LogError($"[LevelSet] LevelCached handler failed: {e}"); }
    }

    private void RaiseSetChanged()
    {
        SetVersion++;
        RaiseChanged();
    }

    private void RaiseChanged()
    {
        try { Changed?.Invoke(); }
        catch (Exception e) { Debug.LogError($"[LevelSet] Changed handler failed: {e}"); }
    }

    private static async Task Observe(Task task, string what)
    {
        try { await task; }
        catch (Exception e) { Debug.LogError($"[LevelSet] {what} failed: {e}"); }
    }

    #region SOURCE

    private static ILevelSetDownloader CreateDownloader()
    {
#if UNITY_EDITOR
        var local = UnityEditor.EditorPrefs.GetString(LocalBaseUrlPrefKey, "").Trim();
        if (local.StartsWith("http", StringComparison.OrdinalIgnoreCase))
        {
            Bug.LogWarning($"[LevelSet] Editor override: level sets downloaded from {local}");
            return new UnityLevelSetDownloader(local);
        }
        if (local != "")
        {
            var folder = local.StartsWith("file://", StringComparison.OrdinalIgnoreCase) ? new Uri(local).LocalPath : local;
            Bug.LogWarning($"[LevelSet] Editor override: level sets read from {folder}");
            return new LocalFolderDownloader(() => folder);
        }
#endif
        return new ConfiguredDownloader();
    }

    // Chosen per fetch, so a bucket that arrives with this session's remote config is used at once.
    private sealed class ConfiguredDownloader : ILevelSetDownloader
    {
        // shortcut: File IO cannot read StreamingAssets inside an Android apk, so ship sets there for Editor/iOS/desktop only; Android needs the Firebase source.
        private readonly LocalFolderDownloader local = new(() => Path.Combine(Application.streamingAssetsPath, CC.LevelSetFolder.Value));
#if CORRUPTED_DESIGN_HAS_FIREBASE_REMOTE_CONFIG
        // Public-read REST download, no Storage SDK: the Storage rules must allow reads under the sets folder.
        private readonly UnityLevelSetDownloader firebase =
            new(path => UnityLevelSetDownloader.FirebaseUrl(CC.LevelSetBucket.Value.Trim(), CC.LevelSetFolder.Value, path));

        public Task<FetchResult> FetchAsync(string relativePath) =>
            string.IsNullOrWhiteSpace(CC.LevelSetBucket.Value) ? local.FetchAsync(relativePath) : firebase.FetchAsync(relativePath);
#else
        public Task<FetchResult> FetchAsync(string relativePath) => local.FetchAsync(relativePath);
#endif
    }

    #endregion
}
