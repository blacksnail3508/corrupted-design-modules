using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Newtonsoft.Json.Linq;

namespace CorruptedDesign.LevelSets
{
    /// <summary>Validates level set names before they reach a URL or a cache path.</summary>
    public static class LevelSetName
    {
        public const string Builtin = "builtin";

        private static readonly Regex Valid = new("^[A-Za-z0-9_.-]+$");

        /// <summary>The trimmed name, or "" when it is empty or unsafe.</summary>
        public static string Normalize(string raw)
        {
            if (raw == null) return "";
            var name = raw.Trim();
            // A bare ".." would pass the character check but still escape the cache folder.
            if (name == ".." || !Valid.IsMatch(name)) return "";
            return name;
        }
    }

    /// <summary>One published level set: the level numbers it holds as inclusive ranges; every other number stays built-in.</summary>
    // Wire format: {"name":"s1","levels":[[31,60],[200,220]]}
    public sealed class LevelSetManifest
    {
        public string Name;
        public readonly List<(int From, int To)> Ranges = new();

        public static LevelSetManifest Of(string name, params (int From, int To)[] ranges)
        {
            var m = new LevelSetManifest { Name = name };
            m.Ranges.AddRange(ranges);
            return m;
        }

        public bool Has(int level)
        {
            foreach (var r in Ranges)
                if (level >= r.From && level <= r.To) return true;
            return false;
        }

        // Overlapping ranges are counted twice; this only feeds a status text.
        public int LevelCount
        {
            get
            {
                long sum = 0;
                foreach (var r in Ranges) sum += (long)r.To - r.From + 1;
                return (int)Math.Min(sum, int.MaxValue);
            }
        }

        /// <summary>Parses a manifest, refusing one whose name is not <paramref name="expectedName"/> or whose ranges are bad.</summary>
        public static bool TryParse(string json, string expectedName, out LevelSetManifest manifest)
        {
            manifest = null;
            if (string.IsNullOrEmpty(json)) return false;
            try
            {
                var o = JObject.Parse(json);
                var name = (string)o["name"];
                if (name == null || name != expectedName || o["levels"] is not JArray levels || levels.Count == 0) return false;

                var parsed = new LevelSetManifest { Name = name };
                foreach (var item in levels)
                {
                    if (item is not JArray pair || pair.Count != 2) return false;
                    var from = (int?)pair[0];
                    var to = (int?)pair[1];
                    if (from == null || to == null || from.Value < 1 || to.Value < from.Value) return false;
                    parsed.Ranges.Add((from.Value, to.Value));
                }

                manifest = parsed;
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public string ToJson()
        {
            var levels = new JArray();
            foreach (var r in Ranges) levels.Add(new JArray(r.From, r.To));
            return new JObject { ["name"] = Name, ["levels"] = levels }.ToString(Newtonsoft.Json.Formatting.None);
        }
    }
}
