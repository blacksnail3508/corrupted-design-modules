using System;
using System.Collections.Generic;

namespace CorruptedDesign.LevelSets
{
    /// <summary>Predicts the raw levels the next positions will play, to prefetch them.</summary>
    public static class LevelWindow
    {
        /// <summary>The current raw level plus up to <paramref name="size"/> upcoming ones, without repeats.</summary>
        // inSet marks levels beyond count that the set still holds, which are played at their own number.
        public static List<int> Predict(int position, int size, int count, int loopStart, int loopEnd, IReadOnlyList<int> unplayed,
            Func<int, bool> inSet = null)
        {
            var result = new List<int>();
            var seen = new HashSet<int>();
            int next = 0;
            // Past this many positions every raw level that can still appear has been seen, so a huge size cannot spin or overflow.
            long needed = Math.Max(0L, (long)count - position + 1) + (unplayed?.Count ?? 0) + (loopEnd - loopStart + 1);
            long steps = Math.Min(size > 0 ? size : 0L, needed);

            for (long i = 0; i <= steps; i++)
            {
                long p = position + i;
                int raw;
                if (p <= count || (inSet != null && p <= int.MaxValue && inSet((int)p))) raw = (int)p;
                else
                {
                    raw = 0;
                    while (unplayed != null && next < unplayed.Count)
                    {
                        int candidate = unplayed[next++];
                        if (candidate < loopStart || candidate > loopEnd || seen.Contains(candidate)) continue;
                        raw = candidate;
                        break;
                    }
                    if (raw == 0) raw = LoopClamp(p, loopStart, loopEnd);
                }

                if (seen.Add(raw)) result.Add(raw);
            }
            return result;
        }

        private static int LoopClamp(long x, int loopStart, int loopEnd)
        {
            if (x <= loopEnd && x > 0) return (int)x;
            int rangeSize = loopEnd - loopStart + 1;
            return (int)(loopStart + ((x - loopStart) % rangeSize));
        }
    }
}
