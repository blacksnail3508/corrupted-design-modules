using System;

namespace CorruptedDesign.LevelSets
{
    /// <summary>Which content a player level position was served from, so a retry replays the same content.</summary>
    [Serializable]
    public struct ContentPin
    {
        public int Position;
        public string Source;
        public int Level;
    }

    /// <summary>The content picked for one position: a set level or a built-in raw level.</summary>
    public readonly struct LevelPick
    {
        public readonly bool FromSet;
        public readonly int Level;
        public readonly string SourceName;

        public LevelPick(bool fromSet, int level, string sourceName)
        {
            FromSet = fromSet;
            Level = level;
            SourceName = sourceName;
        }
    }

    /// <summary>Picks set or built-in content per position and pins it until the position changes.</summary>
    public sealed class LevelContentPicker
    {
        private ContentPin pin;

        public LevelContentPicker(ContentPin pin) { this.pin = pin; }

        public ContentPin Pin => pin;

        /// <summary>Content for <paramref name="position"/>; a cached set level wins, else built-in <paramref name="raw"/> or a reuse.</summary>
        public LevelPick Pick(int position, int raw, string activeSet, Func<int, bool> isCached, int builtinMax, Func<int> builtinReuse)
        {
            activeSet ??= "";

            if (position > 0 && pin.Position == position)
            {
                if (pin.Source == LevelSetName.Builtin) return new LevelPick(false, pin.Level, LevelSetName.Builtin);
                // A set pin only holds while its set is active and its file is still on disk.
                if (activeSet != "" && pin.Source == activeSet && isCached(pin.Level)) return new LevelPick(true, pin.Level, activeSet);
            }

            LevelPick pick;
            if (activeSet != "" && isCached(raw)) pick = new LevelPick(true, raw, activeSet);
            else if (raw <= builtinMax) pick = new LevelPick(false, raw, LevelSetName.Builtin);
            else pick = new LevelPick(false, builtinReuse(), LevelSetName.Builtin);

            pin = new ContentPin { Position = position, Source = pick.SourceName, Level = pick.Level };
            return pick;
        }

        /// <summary>Repins a position whose set level failed onto a built-in level.</summary>
        public void MarkBroken(int position, int builtinLevel) =>
            pin = new ContentPin { Position = position, Source = LevelSetName.Builtin, Level = builtinLevel };

        public void ClearPin() => pin = default;
    }
}
