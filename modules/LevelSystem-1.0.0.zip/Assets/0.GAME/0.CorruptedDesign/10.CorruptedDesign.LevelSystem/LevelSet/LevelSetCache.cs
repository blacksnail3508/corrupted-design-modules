using System;
using System.IO;

namespace CorruptedDesign.LevelSets
{
    /// <summary>On-disk cache of downloaded level sets: one folder per set holding its manifest and level files.</summary>
    public sealed class LevelSetCache
    {
        private const string ManifestFile = "manifest.json";

        private readonly string root;

        public LevelSetCache(string root) { this.root = root; }

        public bool HasLevel(string set, int level) => File.Exists(LevelPath(set, level));

        public bool TryReadLevel(string set, int level, out string text) => TryReadFile(LevelPath(set, level), out text);

        public void WriteLevel(string set, int level, string text) => WriteAtomic(LevelPath(set, level), text);

        /// <summary>Reads a cached manifest; an unreadable one is deleted so it is downloaded again.</summary>
        public bool TryReadManifest(string set, out LevelSetManifest m)
        {
            m = null;
            var path = ManifestPath(set);
            if (!TryReadFile(path, out var json)) return false;
            if (LevelSetManifest.TryParse(json, set, out m)) return true;

            TryDelete(path);
            return false;
        }

        public void WriteManifest(LevelSetManifest m) => WriteAtomic(ManifestPath(m.Name), m.ToJson());

        public int CountLevels(string set)
        {
            var dir = SetDir(set);
            if (!Directory.Exists(dir)) return 0;

            var count = 0;
            foreach (var file in Directory.GetFiles(dir, "Level_*.json"))
            {
                // The search pattern also matches "Level_5.json.tmp" on some platforms.
                var name = Path.GetFileNameWithoutExtension(file).Substring("Level_".Length);
                if (file.EndsWith(".json", StringComparison.Ordinal) && int.TryParse(name, out _)) count++;
            }
            return count;
        }

        public void DeleteLevel(string set, int level) => TryDelete(LevelPath(set, level));

        /// <summary>Drops every cached set but <paramref name="set"/>.</summary>
        public void DeleteAllExcept(string set)
        {
            if (!Directory.Exists(root)) return;

            foreach (var dir in Directory.GetDirectories(root))
            {
                if (!string.IsNullOrEmpty(set) && Path.GetFileName(dir) == set) continue;
                try { Directory.Delete(dir, true); }
                catch (Exception) { }
            }
        }

        private string SetDir(string set) => Path.Combine(root, set);

        private string LevelPath(string set, int level) => Path.Combine(SetDir(set), "Level_" + level + ".json");

        private string ManifestPath(string set) => Path.Combine(SetDir(set), ManifestFile);

        private static bool TryReadFile(string path, out string text)
        {
            text = null;
            if (!File.Exists(path)) return false;
            try
            {
                text = File.ReadAllText(path);
                if (!string.IsNullOrEmpty(text)) return true;
            }
            catch (Exception) { }

            text = null;
            TryDelete(path);
            return false;
        }

        private static void WriteAtomic(string path, string content)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            var tmp = path + ".tmp";
            File.WriteAllText(tmp, content);
            // File.Move has no overwrite flag on netstandard 2.1.
            if (File.Exists(path)) File.Delete(path);
            File.Move(tmp, path);
        }

        private static void TryDelete(string path)
        {
            try { if (File.Exists(path)) File.Delete(path); }
            catch (Exception) { }
        }
    }
}
