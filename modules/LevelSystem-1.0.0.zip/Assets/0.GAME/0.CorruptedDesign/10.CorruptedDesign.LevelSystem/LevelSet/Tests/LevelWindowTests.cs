using CorruptedDesign.LevelSets;
using NUnit.Framework;

public class LevelWindowTests
{
    [Test]
    public void WithinCount_ReturnsPositions()
    {
        CollectionAssert.AreEqual(new[] { 31, 32, 33, 34 }, LevelWindow.Predict(31, 3, 280, 21, 280, new int[0]));
    }

    [Test]
    public void SizeZeroOrNegative_ReturnsCurrentOnly()
    {
        CollectionAssert.AreEqual(new[] { 31 }, LevelWindow.Predict(31, 0, 280, 21, 280, new int[0]));
        CollectionAssert.AreEqual(new[] { 31 }, LevelWindow.Predict(31, -4, 280, 21, 280, new int[0]));
    }

    [Test]
    public void BeyondCount_UsesUnplayedInOrder()
    {
        CollectionAssert.AreEqual(new[] { 50, 60, 23 }, LevelWindow.Predict(281, 2, 280, 21, 280, new[] { 50, 10, 60 }));
    }

    [Test]
    public void BeyondCount_NoUnplayed_LoopClamps()
    {
        CollectionAssert.AreEqual(new[] { 21, 22, 23 }, LevelWindow.Predict(281, 2, 280, 21, 280, new int[0]));
    }

    [Test]
    public void BeyondCount_NullUnplayed_TreatedAsEmpty()
    {
        CollectionAssert.AreEqual(new[] { 21, 22, 23 }, LevelWindow.Predict(281, 2, 280, 21, 280, null));
    }

    [Test]
    public void CrossesCount_MixesBoth()
    {
        CollectionAssert.AreEqual(new[] { 279, 280, 40, 22 }, LevelWindow.Predict(279, 3, 280, 21, 280, new[] { 40 }));
    }

    [Test]
    public void BeyondCount_InSetLevel_IsPlayedAtItsOwnNumber()
    {
        // Positions 331..349 keep looping; only 350 is a level the set holds.
        var result = LevelWindow.Predict(349, 2, 330, 21, 330, new int[0], level => level == 350);
        CollectionAssert.AreEqual(new[] { 39, 350, 41 }, result);
    }

    [Test]
    public void InSetNull_BehavesAsBefore()
    {
        CollectionAssert.AreEqual(new[] { 21, 22, 23 }, LevelWindow.Predict(281, 2, 280, 21, 280, new int[0], null));
    }

    [Test]
    public void DuplicateRawLevels_AreSkipped()
    {
        var result = LevelWindow.Predict(281, 270, 280, 21, 280, new int[0]);
        Assert.AreEqual(260, result.Count);
        CollectionAssert.AllItemsAreUnique(result);
    }

    [Test]
    public void HugeSize_TerminatesStartsWithCurrentAndIsUnique()
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        var result = LevelWindow.Predict(31, int.MaxValue, 280, 21, 280, new int[0]);
        sw.Stop();
        Assert.Less(sw.ElapsedMilliseconds, 1000);
        Assert.AreEqual(31, result[0]);
        CollectionAssert.AllItemsAreUnique(result);
    }
}
