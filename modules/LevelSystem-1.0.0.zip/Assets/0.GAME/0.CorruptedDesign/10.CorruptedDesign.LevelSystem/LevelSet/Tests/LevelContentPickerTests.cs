using CorruptedDesign.LevelSets;
using Newtonsoft.Json;
using NUnit.Framework;

public class LevelContentPickerTests
{
    static LevelContentPicker Fresh() => new LevelContentPicker(default);

    [Test]
    public void Cached_PicksSet()
    {
        var pick = Fresh().Pick(31, 31, "s1", l => true, 280, () => 5);
        Assert.IsTrue(pick.FromSet);
        Assert.AreEqual("s1", pick.SourceName);
        Assert.AreEqual(31, pick.Level);
    }

    [Test]
    public void NotCached_Within280_PicksBuiltinSameNumber()
    {
        var pick = Fresh().Pick(31, 31, "s1", l => false, 280, () => 5);
        Assert.IsFalse(pick.FromSet);
        Assert.AreEqual(LevelSetName.Builtin, pick.SourceName);
        Assert.AreEqual(31, pick.Level);
    }

    [Test]
    public void NotCached_Beyond280_PicksBuiltinReuse()
    {
        var pick = Fresh().Pick(300, 300, "s1", l => false, 280, () => 77);
        Assert.IsFalse(pick.FromSet);
        Assert.AreEqual(77, pick.Level);
    }

    [Test]
    public void NoActiveSet_PicksBuiltin()
    {
        var pick = Fresh().Pick(31, 31, "", l => true, 280, () => 5);
        Assert.IsFalse(pick.FromSet);
        Assert.AreEqual(31, pick.Level);
        pick = Fresh().Pick(31, 31, null, l => true, 280, () => 5);
        Assert.IsFalse(pick.FromSet);
    }

    [Test]
    public void Retry_AfterFileLands_KeepsBuiltin()
    {
        var picker = Fresh();
        var first = picker.Pick(31, 31, "s1", l => false, 280, () => 5);
        var second = picker.Pick(31, 31, "s1", l => true, 280, () => 5);
        Assert.IsFalse(second.FromSet);
        Assert.AreEqual(first.Level, second.Level);
        Assert.AreEqual(first.SourceName, second.SourceName);
    }

    [Test]
    public void Retry_BuiltinReuse_DoesNotRerollOrCallReuse()
    {
        var picker = Fresh();
        picker.Pick(300, 300, "s1", l => false, 280, () => 77);
        var again = picker.Pick(300, 300, "s1", l => false, 280, () => { Assert.Fail("reuse called"); return 0; });
        Assert.AreEqual(77, again.Level);
    }

    [Test]
    public void NewPosition_Repicks()
    {
        var picker = Fresh();
        picker.Pick(31, 31, "s1", l => false, 280, () => 5);
        var next = picker.Pick(32, 32, "s1", l => true, 280, () => 5);
        Assert.IsTrue(next.FromSet);
        Assert.AreEqual(32, picker.Pin.Position);
    }

    [Test]
    public void PinFromOtherSet_Ignored()
    {
        var picker = new LevelContentPicker(new ContentPin { Position = 31, Source = "old", Level = 31 });
        var pick = picker.Pick(31, 31, "s1", l => true, 280, () => 5);
        Assert.AreEqual("s1", pick.SourceName);
        Assert.IsTrue(pick.FromSet);
    }

    [Test]
    public void SetPin_FileGone_Repicks()
    {
        var picker = new LevelContentPicker(new ContentPin { Position = 31, Source = "s1", Level = 31 });
        var pick = picker.Pick(31, 31, "s1", l => false, 280, () => 5);
        Assert.IsFalse(pick.FromSet);
        Assert.AreEqual(31, pick.Level);
    }

    [Test]
    public void SetPin_StillCached_IsKept()
    {
        var picker = new LevelContentPicker(new ContentPin { Position = 31, Source = "s1", Level = 40 });
        var pick = picker.Pick(31, 31, "s1", l => l == 40, 280, () => 5);
        Assert.IsTrue(pick.FromSet);
        Assert.AreEqual(40, pick.Level);
    }

    [Test]
    public void ClearPin_ThenPick_UsesSet()
    {
        var picker = Fresh();
        picker.Pick(31, 31, "s1", l => false, 280, () => 5);
        picker.ClearPin();
        Assert.AreEqual(0, picker.Pin.Position);
        var pick = picker.Pick(31, 31, "s1", l => true, 280, () => 5);
        Assert.IsTrue(pick.FromSet);
    }

    [Test]
    public void MarkBroken_RepinsToBuiltin()
    {
        var picker = Fresh();
        picker.Pick(31, 31, "s1", l => true, 280, () => 5);
        picker.MarkBroken(31, 12);
        var pick = picker.Pick(31, 31, "s1", l => true, 280, () => 5);
        Assert.IsFalse(pick.FromSet);
        Assert.AreEqual(12, pick.Level);
        Assert.AreEqual(LevelSetName.Builtin, pick.SourceName);
    }

    [Test]
    public void Pin_RoundTripsThroughNewtonsoft()
    {
        var pin = new ContentPin { Position = 31, Source = "s1", Level = 40 };
        var back = JsonConvert.DeserializeObject<ContentPin>(JsonConvert.SerializeObject(pin));
        Assert.AreEqual(31, back.Position);
        Assert.AreEqual("s1", back.Source);
        Assert.AreEqual(40, back.Level);
    }
}
