using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CorruptedDesign.LevelSets
{
    public enum ResolveStatus { Ready, NotFound, Unavailable }

    /// <summary>Resolves set manifests and downloads set levels into the cache, with retries and a parallel cap.</summary>
    public sealed class LevelSetLoader
    {
        private readonly ILevelSetDownloader downloader;
        private readonly LevelSetCache cache;
        private readonly Func<string, bool> isValidLevel;
        private readonly int maxParallel;
        private readonly int maxRetries;
        private readonly Func<int, Task> delay;
        private readonly Action<string> logWarning;
        private readonly Action<string> logError;

        private readonly object gate = new();
        private readonly Dictionary<string, HashSet<int>> missing = new();
        private readonly HashSet<string> inFlight = new();
        // Null until the service picks a set; until then no result counts as stale.
        private volatile string current;

        public event Action<string, int> LevelCached;

        public LevelSetLoader(ILevelSetDownloader downloader, LevelSetCache cache, Func<string, bool> isValidLevel,
            int maxParallel = 3, int maxRetries = 2, Func<int, Task> delay = null,
            Action<string> logWarning = null, Action<string> logError = null)
        {
            this.downloader = downloader;
            this.cache = cache;
            this.isValidLevel = isValidLevel;
            this.maxParallel = Math.Max(1, maxParallel);
            this.maxRetries = Math.Max(0, maxRetries);
            this.delay = delay ?? (attempt => Task.Delay(1000 * attempt));
            // Lambdas, not method groups, so UnityEngine is only touched when a message is actually logged.
            this.logWarning = logWarning ?? (m => UnityEngine.Debug.LogWarning(m));
            this.logError = logError ?? (m => UnityEngine.Debug.LogError(m));
        }

        public void SetCurrent(string set)
        {
            current = set;
        }

        public bool IsMissing(string set, int level)
        {
            lock (gate) return missing.TryGetValue(set, out var levels) && levels.Contains(level);
        }

        // refresh skips the cached manifest, so a level added to a published set is noticed on the next launch.
        public async Task<(ResolveStatus status, LevelSetManifest manifest)> ResolveAsync(string set, bool refresh = false)
        {
            if (!refresh && cache.TryReadManifest(set, out var cached)) return (ResolveStatus.Ready, cached);

            for (var attempt = 0; attempt <= maxRetries; attempt++)
            {
                if (attempt > 0) await delay(attempt);

                var result = await Download(set + "/manifest.json");
                if (result.Status == FetchStatus.Error) continue;
                if (result.Status == FetchStatus.NotFound) return (ResolveStatus.NotFound, null);

                if (!LevelSetManifest.TryParse(result.Text, set, out var manifest))
                {
                    logError("[LevelSet] Invalid manifest for set " + set);
                    return (ResolveStatus.NotFound, null);
                }

                // An unsaved manifest is still usable this session; the next launch downloads it again.
                try { cache.WriteManifest(manifest); }
                catch (Exception e) { logError("[LevelSet] Could not cache manifest for set " + set + ": " + e.Message); }
                return (ResolveStatus.Ready, manifest);
            }

            logWarning("[LevelSet] Manifest for set " + set + " unavailable after " + (maxRetries + 1) + " attempts");
            return (ResolveStatus.Unavailable, null);
        }

        // True when a level ran out of retries on network errors; missing, invalid or stale levels do not count.
        public async Task<bool> FetchAsync(string set, IReadOnlyList<int> wanted)
        {
            var queue = new Queue<int>(wanted);
            var workers = new Task<bool>[Math.Min(maxParallel, Math.Max(1, wanted.Count))];
            for (var i = 0; i < workers.Length; i++) workers[i] = RunWorker(set, queue);
            var failed = await Task.WhenAll(workers);
            return Array.IndexOf(failed, true) >= 0;
        }

        private async Task<bool> RunWorker(string set, Queue<int> queue)
        {
            var failed = false;
            while (!IsStale(set) && TryTakeNext(set, queue, out var level))
            {
                try { failed |= await FetchLevel(set, level); }
                finally { lock (gate) inFlight.Remove(Key(set, level)); }
            }
            return failed;
        }

        private bool TryTakeNext(string set, Queue<int> queue, out int level)
        {
            lock (gate)
            {
                while (queue.Count > 0)
                {
                    level = queue.Dequeue();
                    if (cache.HasLevel(set, level)) continue;
                    if (missing.TryGetValue(set, out var levels) && levels.Contains(level)) continue;
                    // Another overlapping FetchAsync already owns this level.
                    if (!inFlight.Add(Key(set, level))) continue;
                    return true;
                }
            }
            level = 0;
            return false;
        }

        private async Task<bool> FetchLevel(string set, int level)
        {
            var path = set + "/Level_" + level + ".json";
            for (var attempt = 0; attempt <= maxRetries; attempt++)
            {
                if (attempt > 0) await delay(attempt);
                if (IsStale(set)) return false;

                var result = await Download(path);
                if (IsStale(set)) return false;

                if (result.Status == FetchStatus.Error) continue;
                if (result.Status == FetchStatus.NotFound)
                {
                    MarkMissing(set, level);
                    return false;
                }

                if (!IsValid(result.Text))
                {
                    logError("[LevelSet] Invalid level " + level + " in set " + set);
                    MarkMissing(set, level);
                    return false;
                }

                // Left unmarked on failure so a later FetchAsync can try again.
                try { cache.WriteLevel(set, level, result.Text); }
                catch (Exception e)
                {
                    logError("[LevelSet] Could not cache level " + level + " of set " + set + ": " + e.Message);
                    return false;
                }

                LevelCached?.Invoke(set, level);
                return false;
            }

            logWarning("[LevelSet] Level " + level + " of set " + set + " unavailable after " + (maxRetries + 1) + " attempts");
            return true;
        }

        private async Task<FetchResult> Download(string path)
        {
            try { return await downloader.FetchAsync(path); }
            catch (Exception e)
            {
                logWarning("[LevelSet] Download of " + path + " threw: " + e.Message);
                return new FetchResult(FetchStatus.Error, null);
            }
        }

        private bool IsValid(string text)
        {
            try { return isValidLevel(text); }
            catch (Exception) { return false; }
        }

        private void MarkMissing(string set, int level)
        {
            lock (gate)
            {
                if (!missing.TryGetValue(set, out var levels)) missing[set] = levels = new HashSet<int>();
                levels.Add(level);
            }
        }

        private bool IsStale(string set)
        {
            var now = current;
            return now != null && now != set;
        }

        private static string Key(string set, int level) => set + "/" + level;
    }
}
