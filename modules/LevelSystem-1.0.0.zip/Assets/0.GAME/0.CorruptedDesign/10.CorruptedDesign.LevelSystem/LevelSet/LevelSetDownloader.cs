using System;
using System.IO;
using System.Threading.Tasks;
using UnityEngine.Networking;

namespace CorruptedDesign.LevelSets
{
    public enum FetchStatus { Ok, NotFound, Error }

    public readonly struct FetchResult
    {
        public readonly FetchStatus Status;
        public readonly string Text;

        public FetchResult(FetchStatus status, string text)
        {
            Status = status;
            Text = text;
        }
    }

    /// <summary>Fetches a level set file by its path relative to the sets root (<c>s1/manifest.json</c>, <c>s1/Level_31.json</c>).</summary>
    public interface ILevelSetDownloader
    {
        Task<FetchResult> FetchAsync(string relativePath);
    }

    /// <summary>Downloads level set files over HTTP.</summary>
    public sealed class UnityLevelSetDownloader : ILevelSetDownloader
    {
        private readonly Func<string, string> toUrl;
        private readonly int timeoutSeconds;

        public UnityLevelSetDownloader(string baseUrl, int timeoutSeconds = 10)
            : this(path => (baseUrl.EndsWith("/") ? baseUrl : baseUrl + "/") + path, timeoutSeconds) { }

        // A url builder, so a root read from remote config at fetch time is never stale.
        public UnityLevelSetDownloader(Func<string, string> toUrl, int timeoutSeconds = 10)
        {
            this.toUrl = toUrl;
            this.timeoutSeconds = timeoutSeconds;
        }

        /// <summary>Public-read Firebase Storage REST url; the object name is one url segment, so its slashes are escaped.</summary>
        public static string FirebaseUrl(string bucket, string folder, string path) =>
            $"https://firebasestorage.googleapis.com/v0/b/{bucket}/o/{Uri.EscapeDataString(folder + "/" + path)}?alt=media";

        public async Task<FetchResult> FetchAsync(string relativePath)
        {
            using var request = UnityWebRequest.Get(toUrl(relativePath));
            request.timeout = timeoutSeconds;
            var done = new TaskCompletionSource<bool>();
            request.SendWebRequest().completed += _ => done.TrySetResult(true);
            await done.Task;

            if (request.result == UnityWebRequest.Result.Success) return new FetchResult(FetchStatus.Ok, request.downloadHandler.text);
            if (request.responseCode == 404) return new FetchResult(FetchStatus.NotFound, null);
            return new FetchResult(FetchStatus.Error, null);
        }
    }

    /// <summary>Reads level set files from a local folder laid out like the remote one.</summary>
    // UnityWebRequest reports a missing file:// path as a connection error, which would hide the not-found path.
    public sealed class LocalFolderDownloader : ILevelSetDownloader
    {
        private readonly Func<string> folder;

        public LocalFolderDownloader(Func<string> folder) { this.folder = folder; }

        public async Task<FetchResult> FetchAsync(string relativePath)
        {
            // Completing synchronously would raise LevelCached inside Prefetch and re-enter the level system mid-call.
            await Task.Yield();
            var path = Path.Combine(folder(), relativePath);
            if (!File.Exists(path)) return new FetchResult(FetchStatus.NotFound, null);
            try { return new FetchResult(FetchStatus.Ok, File.ReadAllText(path)); }
            catch (Exception) { return new FetchResult(FetchStatus.Error, null); }
        }
    }
}
