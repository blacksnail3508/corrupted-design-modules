using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using CorruptedDesign.Data;
using CorruptedDesign.LevelSets;
using Sirenix.OdinInspector;
using UnityEngine;
using CC = CorruptedDesign.Remote.ConfigCollection;

/// <summary>The level pool: which content a player level is played from, built-in or a remote level set, and which levels were played.</summary>
[Serializable]
public class LevelSystem
{
    public static readonly Vector2Int DefaultLoop = new(21, 100);
    // A set only swaps level content by number; the pool and the loop are always the built-in ones.
    public static Vector2Int Loop { get; private set; } = DefaultLoop;

    [SerializeField] List<int> NewLevels = new();
    [SerializeField] Vault<List<int>> playedLevelVault = new("user_played_level", new List<int>());
    [SerializeField] Vault<int> pinPlayerLevelVault = new("user_loop_pin_level", 0);
    [SerializeField] Vault<int> pinRawLevelVault = new("user_loop_pin_raw", 0);
    [SerializeField] Vault<ContentPin> contentPinVault = new("user_level_content_pin", default);

    private readonly LevelSetService levelSets = new(IsReadableLevel);
    private LevelContentPicker picker;
    private string loadedSet;
    private int seenSetVersion = -1;
    // Last player level loaded; the prefetch window starts here.
    private int lastPosition;

    // Level read ahead of the run that will play it, so starting that run pays for no file read.
    private int preloadedRawLevel;
    private LevelJson preloadedLevel;

    public LevelSetService SetService => levelSets;

    /// <summary>Raised after a set switch cleared the pins, so a preloaded level may no longer be what the next load serves.</summary>
    public event Action ActiveSetSwitched;

    private LevelContentPicker Picker => picker ??= new LevelContentPicker(contentPinVault.Value);

    /// <summary>Starts the level set service and rescans which levels the player has not seen yet.</summary>
    [Button("REFRESH")]
    public void Initialize()
    {
        levelSets.Initialize();
        levelSets.Changed -= OnLevelSetsChanged;
        levelSets.Changed += OnLevelSetsChanged;

        if (loadedSet == null)
        {
            loadedSet = levelSets.ActiveSet;
            var pin = Picker.Pin;
            // A pin saved for a set that is no longer active points at content this session cannot serve.
            if (!string.IsNullOrEmpty(pin.Source) && pin.Source != LevelSetName.Builtin && pin.Source != loadedSet) ClearPins();
        }

        seenSetVersion = levelSets.SetVersion;
        RefreshLoop();
        PrefetchWindow();
    }

    private void OnLevelSetsChanged()
    {
        // A downloaded level changes neither the loop nor the window, and must not retry failed downloads.
        if (levelSets.SetVersion == seenSetVersion) return;
        seenSetVersion = levelSets.SetVersion;

        // Keeping the same set also bumps the version; only a real switch invalidates the pins.
        bool switched = levelSets.ActiveSet != loadedSet;
        if (switched)
        {
            loadedSet = levelSets.ActiveSet;
            ClearPins();
        }
        RefreshLoop();
        PrefetchWindow();

        if (!switched) return;
        try { ActiveSetSwitched?.Invoke(); }
        catch (Exception e) { Debug.LogError($"[LevelSet] ActiveSetSwitched handler failed: {e}"); }
    }

    private void RefreshLoop()
    {
        Loop = DefaultLoop;
        NewLevels = ScanForUnplayedLevels();
    }

    private bool IsAvailable(int level) => level >= 1 && level <= DefaultLoop.y;

    // first goes to the front of the window: the level about to be played that the set holds but has not downloaded.
    private void PrefetchWindow(int first = 0)
    {
        if (levelSets.ActiveManifest == null || lastPosition < 1) return;

        var wanted = LevelWindow.Predict(lastPosition, CC.LevelPrefetchCount.Value, DefaultLoop.y, Loop.x, Loop.y, NewLevels, levelSets.HasLevel);
        if (first > 0)
        {
            wanted.Remove(first);
            wanted.Insert(0, first);
        }
        levelSets.Prefetch(wanted);
    }

    private List<int> ScanForUnplayedLevels()
    {
        var played = playedLevelVault.Value ?? new List<int>();
        var result = new List<int>();
        for (int i = 1; i <= Loop.y; i++)
            if (!played.Contains(i) && IsAvailable(i)) result.Add(i);
        return result;
    }

    /// <summary>Level data a player level is played from: a cached set level, else the built-in pool looped. Never null.</summary>
    public LevelJson GetLevelJson(int level)
    {
        int raw = GetLevelLooped(level);
        int position = Mathf.Max(1, level);
        bool firstLoad = lastPosition == 0;
        lastPosition = position;

        var pick = Picker.Pick(position, raw, levelSets.ActiveSet, levelSets.IsCached, DefaultLoop.y, () => PickDefaultReuseLevel(position));
        LevelJson data = pick.FromSet ? GetSetLevelData(pick.Level) : null;
        if (pick.FromSet && data == null)
        {
            int builtin = pick.Level <= DefaultLoop.y ? pick.Level : PickDefaultReuseLevel(position);
            Picker.MarkBroken(position, builtin);
            pick = new LevelPick(false, builtin, LevelSetName.Builtin);
        }
        contentPinVault.Save(Picker.Pin);

        data ??= LoadRawLevel(pick.Level);

        if (firstLoad || (levelSets.HasLevel(raw) && !levelSets.IsCached(raw))) PrefetchWindow(raw);
        return data;
    }

    /// <summary>Same as <see cref="GetLevelJson"/> but leaves the content pin as it was, for a look ahead that is not a run.</summary>
    // A set file that downloads before the level starts is then still the one served.
    public LevelJson PreviewLevelJson(int level)
    {
        var saved = Picker.Pin;
        var data = GetLevelJson(level);
        picker = new LevelContentPicker(saved);
        contentPinVault.Save(saved);
        return data;
    }

    /// <summary>Tester path: bundled levels only, never a level set.</summary>
    public LevelJson GetBuiltinLevelJson(int level)
    {
        int builtin = level <= DefaultLoop.y ? Mathf.Max(1, level) : LoopClamp(level, DefaultLoop.x, DefaultLoop.y);
        return LoadRawLevel(builtin);
    }

    /// <summary>Built-in level to play instead of a set level the game failed to build; that set level is not served again this session.</summary>
    public LevelJson FallbackToDefault(LevelJson failed, Exception error)
    {
        int level = failed.RemoteLevel;
        levelSets.MarkBroken(level);
        Debug.LogError($"[LevelSet] Level_{level} of {levelSets.ActiveSet} failed to init, falling back to built-in. {error}");

        int builtin = level <= DefaultLoop.y ? level : PickDefaultReuseLevel(level);
        // The pin keeps a retry of this position on the built-in level instead of the broken set level.
        Picker.MarkBroken(Picker.Pin.Position, builtin);
        contentPinVault.Save(Picker.Pin);
        return LoadRawLevel(builtin);
    }

    private LevelJson GetSetLevelData(int level)
    {
        if (!levelSets.TryRead(level, out var text)) return null;

        var data = ParseLevel(text, $"Level_{level} of set {levelSets.ActiveSet}");
        if (data == null)
        {
            // A file that passed validation on download but no longer parses was damaged on disk.
            levelSets.Discard(level);
            Debug.LogError($"[LevelSet] Level_{level} of {levelSets.ActiveSet} is invalid, using built-in.");
            return null;
        }

        data.RemoteLevel = level;
        Bug.Log($"[LevelSystem] Loaded Level_{level} from set {levelSets.ActiveSet}.");
        return data;
    }

    /// <summary>Built-in level data for a file number, straight up: no looping, no progress touched. Never null.</summary>
    public LevelJson LoadRawLevel(int rawLevel, int levelPack = 0)
    {
        // A level read ahead is handed over rather than read a second time; the default pack stands in for what the pack lacks.
        var level = TakePreloaded(rawLevel)
                    ?? ReadLevelFile($"Levels_{levelPack}/Level_{rawLevel}")
                    ?? ReadLevelFile($"Levels/Level_{rawLevel}");
        if (level != null) return level;

        // The template ships no level files, so a game without them still boots on an empty level.
        Bug.LogWarning($"[LevelSystem] No level file for raw level {rawLevel}, using an empty level.");
        return new LevelJson();
    }

    private static LevelJson ReadLevelFile(string resourcePath) =>
        ParseLevel(Resources.Load<TextAsset>(resourcePath)?.text, resourcePath);

    // Level data from text, or null when it is empty or does not parse.
    private static LevelJson ParseLevel(string text, string source)
    {
        if (string.IsNullOrWhiteSpace(text)) return null;
        try { return JsonConvert.DeserializeObject<LevelJson>(text); }
        catch (Exception e)
        {
            Bug.LogWarning($"[LevelSystem] {source} is unreadable: {e.Message}");
            return null;
        }
    }

    // The set download check: a level text the game cannot parse is never cached.
    private static bool IsReadableLevel(string text) => ParseLevel(text, "Downloaded level") != null;

    #region PRELOADING

    /// <summary>Whether the file for a raw level has already been read ahead.</summary>
    public bool IsPreloaded(int rawLevel) => preloadedLevel != null && preloadedRawLevel == rawLevel;

    /// <summary>Reads a built-in level file over the next frames, for a run that has not started yet.</summary>
    public IEnumerator PreloadRawLevelAsync(int rawLevel, int levelPack = 0)
    {
        if (rawLevel < 1 || IsPreloaded(rawLevel)) yield break;

        // Anything read ahead before was for a run that never came.
        ClearPreloaded();

        // Async, so the read lands over the frames a popup plays rather than in one hitch.
        string path = $"Levels_{levelPack}/Level_{rawLevel}";
        ResourceRequest request = Resources.LoadAsync<TextAsset>(path);
        yield return request;

        if (request.asset == null)
        {
            path = $"Levels/Level_{rawLevel}";
            request = Resources.LoadAsync<TextAsset>(path);
            yield return request;
        }

        var level = ParseLevel((request.asset as TextAsset)?.text, path);
        if (level == null)
        {
            Bug.LogWarning($"[LevelSystem] No level file to preload for raw level {rawLevel}.");
            yield break;
        }

        preloadedRawLevel = rawLevel;
        preloadedLevel = level;
    }

    // Handed over once only: a retry reads the file again rather than replaying data a run already built a board from.
    private LevelJson TakePreloaded(int rawLevel)
    {
        if (!IsPreloaded(rawLevel)) return null;

        var level = preloadedLevel;
        ClearPreloaded();
        return level;
    }

    /// <summary>Drops a level read ahead that no run is going to play.</summary>
    public void ClearPreloaded()
    {
        preloadedRawLevel = 0;
        preloadedLevel = null;
    }

    #endregion

    /// <summary>Raw level a player level is played from, which loops once the player is past the pool.</summary>
    [Button("GET LEVEL LOOPED")]
    public int GetLevelLooped(int level)
    {
        if (level < 1) level = 1;

        if (level <= DefaultLoop.y) return level;

        // A level the set holds past the built-in pool is played at its own number; every other position keeps looping.
        if (levelSets.HasLevel(level)) return level;

        if (pinPlayerLevelVault.Value == level && IsAvailable(pinRawLevelVault.Value))
            return pinRawLevelVault.Value;

        int result = level <= Loop.y && IsAvailable(level) ? level : PickReuseLevel(level);
        pinPlayerLevelVault.Save(level);
        pinRawLevelVault.Save(result);
        return result;
    }

    private int PickReuseLevel(int level)
    {
        for (int i = 0; i < NewLevels.Count; i++)
            if (NewLevels[i] >= Loop.x && NewLevels[i] < level && IsAvailable(NewLevels[i])) return NewLevels[i];

        int looped = LoopClamp(level, Loop.x, Loop.y);
        return IsAvailable(looped) ? looped : LoopClamp(level, Loop.x, DefaultLoop.y);
    }

    private int PickDefaultReuseLevel(int level)
    {
        for (int i = 0; i < NewLevels.Count; i++)
            if (NewLevels[i] >= Loop.x && NewLevels[i] <= DefaultLoop.y) return NewLevels[i];
        return LoopClamp(level, Loop.x, DefaultLoop.y);
    }

    private void ClearLoopPin()
    {
        pinPlayerLevelVault.Save(0);
        pinRawLevelVault.Save(0);

        // A level read ahead was picked under the pin that just went, so it may be the wrong one now.
        ClearPreloaded();
    }

    private void ClearPins()
    {
        ClearLoopPin();
        Picker.ClearPin();
        contentPinVault.Save(Picker.Pin);
    }

    /// <summary>Marks the content a finished position was served from as played, when it counts toward the pool.</summary>
    public void CompleteLevel(int position)
    {
        var pin = Picker.Pin;
        // Built-in counts as the loop level itself unless it stood in for a level the set holds but has not downloaded yet.
        bool servedFromLoop = pin.Source == levelSets.ActiveSet || (pin.Source == LevelSetName.Builtin && !levelSets.HasLevel(pin.Level));
        if (pin.Position == Mathf.Max(1, position) && servedFromLoop)
        {
            MarkLevelAsPlayed(pin.Level);
            return;
        }

        // A built-in stand-in leaves the set level unplayed; the level-complete prefetch trigger still fires.
        PrefetchWindow();
    }

    /// <summary>Marks a raw level as played and saves it.</summary>
    [Button("Mark Play Level")]
    public void MarkLevelAsPlayed(int level)
    {
        var played = playedLevelVault.Value ?? new List<int>();
        if (level <= Loop.y && !played.Contains(level)) played.Add(level);
        playedLevelVault.Save(played);
        NewLevels.Remove(level);
        PrefetchWindow();
    }

    [Button("Mark Play Level Range")]
    public void MarkLevelAsPlayed(int from, int to)
    {
        var played = (playedLevelVault.Value ?? new List<int>()).ToHashSet();
        int maxLevel = Mathf.Min(to, Loop.y);
        for (int i = from; i <= maxLevel; i++) played.Add(i);
        playedLevelVault.Save(played.ToList());
        Initialize();
    }

    [Button("Mark Unplay Level Range")]
    public void MarkLevelAsUnplayed(int from, int to)
    {
        var played = playedLevelVault.Value ?? new List<int>();
        for (int i = from; i <= to; i++) played.Remove(i);
        playedLevelVault.Save(played);
        Initialize();
    }

    public void ClearPlayedLevels()
    {
        var played = playedLevelVault.Value ?? new List<int>();
        played.Clear();
        playedLevelVault.Save(played);
        ClearLoopPin();
        Initialize();
    }

    public void ResetPlayedLevel()
    {
        playedLevelVault.Save(new List<int>());
        ClearLoopPin();
        Initialize();
    }

    private int LoopClamp(int x, int loopStart, int loopEnd)
    {
        if (x <= loopEnd && x > 0)
            return x;

        // Wrap around into the range
        int rangeSize = loopEnd - loopStart + 1;
        return loopStart + ((x - loopStart) % rangeSize);
    }
}