using System;
using UnityEngine;

/// <summary>Opens the game's own screens; the game's UI layer assigns these so the CorruptedDesign modules need no reference to its popups and views.</summary>
public static class GameScreens
{
    public static Action OpenBuyHeart { get; set; }
    public static Action OpenShopInGame { get; set; }
    public static Action OpenShopInLobby { get; set; }
    public static Action ShowLobby { get; set; }
    public static Action ShowGameplay { get; set; }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    private static void ResetState()
    {
        OpenBuyHeart = null;
        OpenShopInGame = null;
        OpenShopInLobby = null;
        ShowLobby = null;
        ShowGameplay = null;
    }
}
