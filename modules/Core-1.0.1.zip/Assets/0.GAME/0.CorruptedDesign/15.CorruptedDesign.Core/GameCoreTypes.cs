using CorruptedDesign.Observer;
using System;
using Newtonsoft.Json;
using UnityEngine;

namespace CorruptedDesignTemplate
{
    public enum Difficulty
    {
        Normal,
        Hard,
        Expert
    }

    [Flags]
    public enum DifficultyMask
    {
        None = 0,
        Normal = 1 << 0,
        Hard = 1 << 1,
        Expert = 1 << 2,
        All = Normal | Hard | Expert
    }

    public static class DifficultyMaskExtensions
    {
        public static DifficultyMask ToMask(this Difficulty difficulty) => (DifficultyMask)(1 << (int)difficulty);

        public static bool Contains(this DifficultyMask mask, Difficulty difficulty) => (mask & difficulty.ToMask()) != 0;
    }
}

/// <summary>Content ids a level can introduce. Add the game's own unlockable content here.</summary>
public enum LevelContent
{
    TutorialCore,
    TutorialBooster1,
    TutorialBooster2,
}

public enum ReviveMethod
{
    ByCoin,
    ByAds
}

public enum LoseReason
{
    None,
}

/// <summary>Raised once the level intro is over and the player can act.</summary>
public class LevelIntroCompleteEvent : GameEvent { }

/// <summary>Level payload shared by local and remote levels. Game-specific data goes in <see cref="Data"/>.</summary>
[Serializable]
public class LevelJson
{
    public int Version = 1;
    public CorruptedDesignTemplate.Difficulty Difficulty;
    public string Data;

    [JsonIgnore] public int RemoteLevel { get; set; }
    [JsonIgnore] public bool IsRemote => RemoteLevel > 0;

    public string ToJson(bool pretty = true) => JsonUtility.ToJson(this, pretty);

    public static LevelJson FromJson(string json) => JsonUtility.FromJson<LevelJson>(json);
}

public enum BoosterType
{
    Booster1,
    Booster2,
    Booster3,
}
