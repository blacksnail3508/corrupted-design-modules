using System;
using CorruptedDesign.Observer;
using CorruptedDesignTemplate;

/// <summary>Raised when the player turns tester mode on, so tester-only objects can show themselves.</summary>
public class TesterLogin : GameEvent
{
}

/// <summary>The level the player last started, kept so a restart or a revive knows where it came from.</summary>
[Serializable]
public class PlaySnapShot
{
    public int Level = 0;
    public int RawLevel = 0;
    public Difficulty Difficulty = Difficulty.Normal;

    /// <summary>Goes the player has had at this level, the one in progress included.</summary>
    public int Attempt = 1;

    public int Loses = 0;

    public void SetNewLevel(int level, int rawLevel, Difficulty difficulty)
    {
        Level = level;
        RawLevel = rawLevel;
        Difficulty = difficulty;
        // 1, not 0: the caller counts this first go here and only increments on a replay.
        Attempt = 1;
        Loses = 0;
    }

    /// <summary>Whether this snapshot is already about that run, rather than an earlier one.</summary>
    public bool IsSameRun(int level, int rawLevel) => Level == level && RawLevel == rawLevel;

    public override string ToString() => $"Level {Level} (file {RawLevel}, {Difficulty}) attempt {Attempt}";
}
