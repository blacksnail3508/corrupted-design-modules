using System;
using UnityEngine;
using UnityEngine.UIElements;

namespace CorruptedDesign.GM
{
    /// <summary>Colours and small element builders shared by every GM panel, styled inline so no stylesheet is needed.</summary>
    public static class GMStyle
    {
        #region PALETTE
        public static readonly Color Backdrop = new(0f, 0f, 0f, 0.62f);
        public static readonly Color Window = Hex("#14171F");
        public static readonly Color Card = Hex("#1D222C");
        public static readonly Color CardHigh = Hex("#2A3140");
        public static readonly Color Accent = Hex("#5B8CFF");
        public static readonly Color Good = Hex("#35C48B");
        public static readonly Color Warn = Hex("#F5B94A");
        public static readonly Color Bad = Hex("#F0616D");
        public static readonly Color Text = Hex("#E8ECF4");
        public static readonly Color Dim = Hex("#8B93A7");
        #endregion

        public static Color Darken(Color color) => new(color.r * 0.7f, color.g * 0.7f, color.b * 0.7f, color.a);

        public static Color Hex(string html) => ColorUtility.TryParseHtmlString(html, out var color) ? color : Color.magenta;

        #region ELEMENTS
        public static Label Label(string text, int size = 28, Color? color = null, bool bold = false)
        {
            var label = new Label(text);
            label.style.fontSize = size;
            label.style.color = color ?? Text;
            label.style.whiteSpace = WhiteSpace.Normal;
            if (bold) label.style.unityFontStyleAndWeight = FontStyle.Bold;
            return label;
        }

        public static VisualElement Row(float gap = 12, bool wrap = true)
        {
            var row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row;
            row.style.alignItems = Align.Center;
            if (wrap) row.style.flexWrap = Wrap.Wrap;
            row.style.marginBottom = gap;
            return row;
        }

        /// <summary>A rounded block with a small title, the unit every panel is made of.</summary>
        public static VisualElement CardBlock(string title)
        {
            var card = new VisualElement();
            card.style.backgroundColor = Card;
            card.style.paddingTop = card.style.paddingBottom = 22;
            card.style.paddingLeft = card.style.paddingRight = 24;
            card.style.marginBottom = 18;
            Round(card, 22);

            if (!string.IsNullOrEmpty(title))
            {
                var heading = Label(title.ToUpperInvariant(), 22, Dim, true);
                heading.style.marginBottom = 14;
                heading.style.letterSpacing = 2;
                card.Add(heading);
            }
            return card;
        }

        public static Button Button(string text, Action onClick, Color? background = null, int size = 26)
        {
            var color = background ?? CardHigh;
            var button = new Button { text = text };
            button.style.backgroundColor = color;
            button.style.color = Text;
            button.style.fontSize = size;
            button.style.unityFontStyleAndWeight = FontStyle.Bold;
            button.style.minWidth = 130;
            button.style.minHeight = 76;
            button.style.paddingLeft = button.style.paddingRight = 24;
            button.style.marginRight = 12;
            button.style.marginBottom = 12;
            button.style.borderTopWidth = button.style.borderBottomWidth = 0;
            button.style.borderLeftWidth = button.style.borderRightWidth = 0;
            Round(button, 16);

            button.RegisterCallback<PointerDownEvent>(_ => button.style.backgroundColor = Darken(color));
            button.RegisterCallback<PointerUpEvent>(_ => button.style.backgroundColor = color);
            button.RegisterCallback<PointerLeaveEvent>(_ => button.style.backgroundColor = color);
            button.clicked += () => Run(onClick);
            return button;
        }

        public static TextField Input(string value, int size = 28)
        {
            var field = new TextField { value = value };
            field.style.flexGrow = 1;
            field.style.minHeight = 76;
            field.style.marginRight = 12;
            field.style.marginBottom = 12;

            var input = field.Q(TextField.textInputUssName);
            input.style.backgroundColor = Window;
            input.style.color = Text;
            input.style.fontSize = size;
            input.style.paddingLeft = input.style.paddingRight = 20;
            Round(input, 16);
            return field;
        }

        public static Toggle Toggle(string text, bool value, Action<bool> onChanged)
        {
            var toggle = new Toggle(text) { value = value };
            toggle.style.marginBottom = 14;
            toggle.style.minHeight = 64;
            toggle.Q<Label>().style.color = Text;
            toggle.Q<Label>().style.fontSize = 26;
            toggle.RegisterValueChangedCallback(e => Run(() => onChanged(e.newValue)));
            return toggle;
        }

        /// <summary>A key and value line, with the value in <paramref name="valueLabel"/> so a panel can update it.</summary>
        public static VisualElement Stat(string name, out Label valueLabel, Color? color = null)
        {
            var row = Row(8, false);
            row.style.justifyContent = Justify.SpaceBetween;
            var key = Label(name, 26, Dim);
            valueLabel = Label("-", 28, color ?? Text, true);
            valueLabel.style.unityTextAlign = TextAnchor.MiddleRight;
            row.Add(key);
            row.Add(valueLabel);
            return row;
        }

        public static VisualElement Notice(string message)
        {
            var card = CardBlock(null);
            card.Add(Label(message, 26, Warn));
            return card;
        }
        #endregion

        #region HELPERS
        public static void Round(VisualElement element, float radius)
        {
            element.style.borderTopLeftRadius = element.style.borderTopRightRadius = radius;
            element.style.borderBottomLeftRadius = element.style.borderBottomRightRadius = radius;
        }

        public static void Fill(VisualElement element)
        {
            element.style.position = Position.Absolute;
            element.style.left = element.style.right = element.style.top = element.style.bottom = 0;
        }

        // A throwing action must not break the panel it was clicked in.
        public static void Run(Action action)
        {
            try { action?.Invoke(); }
            catch (Exception e) { Debug.LogException(e); }
        }
        #endregion
    }
}
