using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace CorruptedDesign.GM
{
    /// <summary>Gizmo lines drawn in the game view of any build the GM tool runs in; cleared every frame.</summary>
    public static class GMGizmos
    {
        internal struct Line { public Vector3 a, b; public Color color; }

        internal static readonly List<Line> Lines = new();

        public static Color Color = Color.green;
        public static bool IsEnabled = true;

        private static GMGizmosRenderer host;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetState()
        {
            Lines.Clear();
            Color = Color.green;
            IsEnabled = true;
            host = null;
        }

        public static void DrawLine(Vector3 from, Vector3 to)
        {
            if (!IsEnabled || !Application.isPlaying || !GMToolService.IsAvailable) return;

            EnsureHost();
            Lines.Add(new Line { a = from, b = to, color = Color });
        }

        public static void DrawWireRect(Vector3 center, Vector2 size)
        {
            var h = size * 0.5f;
            var tl = center + new Vector3(-h.x, h.y, 0);
            var tr = center + new Vector3(h.x, h.y, 0);
            var br = center + new Vector3(h.x, -h.y, 0);
            var bl = center + new Vector3(-h.x, -h.y, 0);
            DrawLine(tl, tr); DrawLine(tr, br); DrawLine(br, bl); DrawLine(bl, tl);
        }

        public static void DrawWireCube(Vector3 center, Vector3 size)
        {
            var h = size * 0.5f;
            var c = new[]
            {
                center + new Vector3(-h.x, -h.y, -h.z),
                center + new Vector3(h.x, -h.y, -h.z),
                center + new Vector3(h.x, h.y, -h.z),
                center + new Vector3(-h.x, h.y, -h.z),
                center + new Vector3(-h.x, -h.y, h.z),
                center + new Vector3(h.x, -h.y, h.z),
                center + new Vector3(h.x, h.y, h.z),
                center + new Vector3(-h.x, h.y, h.z),
            };
            DrawLine(c[0], c[1]); DrawLine(c[1], c[2]); DrawLine(c[2], c[3]); DrawLine(c[3], c[0]);
            DrawLine(c[4], c[5]); DrawLine(c[5], c[6]); DrawLine(c[6], c[7]); DrawLine(c[7], c[4]);
            DrawLine(c[0], c[4]); DrawLine(c[1], c[5]); DrawLine(c[2], c[6]); DrawLine(c[3], c[7]);
        }

        public static void DrawCross(Vector3 center, float size)
        {
            var h = size * 0.5f;
            DrawLine(center - new Vector3(h, 0, 0), center + new Vector3(h, 0, 0));
            DrawLine(center - new Vector3(0, h, 0), center + new Vector3(0, h, 0));
        }

        private static void EnsureHost()
        {
            if (host != null) return;

            var go = new GameObject("[GMGizmos]");
            Object.DontDestroyOnLoad(go);
            host = go.AddComponent<GMGizmosRenderer>();
        }
    }

    /// <summary>Turns the frame's <see cref="GMGizmos"/> lines into pooled LineRenderers.</summary>
    // Runs last so lines drawn anywhere this frame, LateUpdate included, render before the clear.
    [DefaultExecutionOrder(10000)]
    public class GMGizmosRenderer : MonoBehaviour
    {
        [SerializeField] private float lineWidth = 0.04f;

        private readonly List<LineRenderer> pool = new();

        private void LateUpdate()
        {
            var lines = GMGizmos.Lines;
            for (int i = 0; i < lines.Count; i++)
            {
                var lr = GetOrCreate(i);
                lr.SetPosition(0, lines[i].a);
                lr.SetPosition(1, lines[i].b);
                lr.startColor = lines[i].color;
                lr.endColor = lines[i].color;
            }

            for (int i = lines.Count; i < pool.Count; i++)
                pool[i].gameObject.SetActive(false);

            lines.Clear();
        }

        private LineRenderer GetOrCreate(int index)
        {
            if (index < pool.Count)
            {
                pool[index].gameObject.SetActive(true);
                return pool[index];
            }

            var go = new GameObject("GMLine");
            go.transform.SetParent(transform, false);

            var lr = go.AddComponent<LineRenderer>();
            lr.positionCount = 2;
            lr.useWorldSpace = true;
            lr.widthMultiplier = lineWidth;
            lr.alignment = LineAlignment.View;
            lr.shadowCastingMode = ShadowCastingMode.Off;
            lr.receiveShadows = false;
            lr.generateLightingData = false;
            lr.material = CreateMaterial();
            pool.Add(lr);
            return lr;
        }

        private static Material CreateMaterial()
        {
            // Particles/Unlit takes the vertex colour (startColor/endColor) in both URP and Built-in RP.
            var shader = Shader.Find("Universal Render Pipeline/Particles/Unlit")
                      ?? Shader.Find("Particles/Standard Unlit")
                      ?? Shader.Find("Sprites/Default");
            return new Material(shader);
        }
    }
}
