using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using UnityEngine;

namespace CorruptedDesign.GM
{
    /// <summary>Picks a file or folder and reveals a folder, through the editor when there is one and the desktop shell in a player.</summary>
    public static class FolderBrowser
    {
        /// <summary>Asks for a folder, opening at <paramref name="startIn"/>; null when cancelled or the platform has no picker.</summary>
        public static string Pick(string title, string startIn)
        {
            string start = Absolute(startIn);

#if UNITY_EDITOR
            string chosen = UnityEditor.EditorUtility.OpenFolderPanel(title, start, string.Empty);
            return string.IsNullOrEmpty(chosen) ? null : chosen;
#elif UNITY_STANDALONE_WIN
            try
            {
                return Windows.PickFolder(title, start);
            }
            catch (Exception exception)
            {
                Bug.LogWarning($"[GM] The folder picker did not open: {exception.Message}");
                return null;
            }
#elif UNITY_STANDALONE_LINUX
            try
            {
                return Linux.PickFolder(title, start);
            }
            catch (Exception exception)
            {
                Bug.LogWarning($"[GM] The folder picker did not open: {exception.Message}");
                return null;
            }
#else
            Bug.LogWarning($"[GM] No folder picker on {Application.platform}. The folder stays at {startIn}.");
            return null;
#endif
        }

        /// <summary>Asks for one existing file with <paramref name="extension"/> (no dot, empty for any); null when cancelled or unsupported.</summary>
        public static string PickFile(string title, string startIn, string extension)
        {
            string start = Absolute(startIn);

#if UNITY_EDITOR
            string chosen = UnityEditor.EditorUtility.OpenFilePanel(title, start, extension);
            return string.IsNullOrEmpty(chosen) ? null : chosen;
#elif UNITY_STANDALONE_WIN
            try
            {
                return Windows.PickFile(title, start, extension);
            }
            catch (Exception exception)
            {
                Bug.LogWarning($"[GM] The file picker did not open: {exception.Message}");
                return null;
            }
#elif UNITY_STANDALONE_LINUX
            try
            {
                return Linux.PickFile(title, start, extension);
            }
            catch (Exception exception)
            {
                Bug.LogWarning($"[GM] The file picker did not open: {exception.Message}");
                return null;
            }
#else
            Bug.LogWarning($"[GM] No file picker on {Application.platform}.");
            return null;
#endif
        }

        /// <summary>Shows a folder in the desktop's file browser, creating it first when missing.</summary>
        public static void Reveal(string folder)
        {
            string full = Absolute(folder);
            if (string.IsNullOrEmpty(full)) return;

            // A shell handed a folder that does not exist opens somewhere else entirely.
            try
            {
                Directory.CreateDirectory(full);
            }
            catch (Exception exception)
            {
                Bug.LogWarning($"[GM] Could not make {full}: {exception.Message}");
                return;
            }

#if UNITY_EDITOR
            // The separator is what opens the folder rather than selecting it in its parent.
            UnityEditor.EditorUtility.RevealInFinder(full + Path.DirectorySeparatorChar);
#else
            OpenInShell(full);
#endif
        }

        // Relative paths resolve against the working directory, which is the project root in the editor.
        private static string Absolute(string folder)
        {
            if (string.IsNullOrWhiteSpace(folder)) return null;

            try
            {
                return Path.GetFullPath(folder);
            }
            catch (Exception)
            {
                // An unusable path is the caller's to report.
                return null;
            }
        }

        private static void OpenInShell(string full)
        {
            try
            {
                switch (Application.platform)
                {
                    case RuntimePlatform.WindowsPlayer:
                        Process.Start("explorer.exe", $"\"{full.Replace('/', '\\')}\"");
                        break;
                    case RuntimePlatform.OSXPlayer:
                        Process.Start("open", $"\"{full}\"");
                        break;
                    case RuntimePlatform.LinuxPlayer:
                        // Named rather than left to OpenURL, which on a bare machine opens a browser or nothing.
                        Process.Start("xdg-open", $"\"{full}\"");
                        break;
                    default:
                        Application.OpenURL("file://" + full);
                        break;
                }
            }
            catch (Exception exception)
            {
                Bug.LogWarning($"[GM] Could not open {full}: {exception.Message}");
            }
        }

#if !UNITY_EDITOR && UNITY_STANDALONE_WIN
        // GetOpenFileName for files and IFileOpenDialog for folders, the latter driven by vtable slot
        // so no [ComImport] is needed, which keeps it working under IL2CPP as well as Mono.
        private static class Windows
        {
            // Room for a returned path longer than MAX_PATH.
            private const int MaxFilePath = 1024;

            private const uint NoChangeDir = 0x0008;
            private const uint PathMustExist = 0x0800;
            private const uint FileMustExist = 0x1000;
            private const uint ExplorerStyle = 0x00080000;

            private const uint InprocServer = 0x1;
            private const uint PickFolders = 0x20;
            private const uint ForceFileSystem = 0x40;
            private const uint SigdnFileSysPath = 0x80058000;

            private static readonly Guid ClsidFileOpenDialog = new("DC1C5A9C-E88A-4dde-A5A1-60F82A20AEF7");
            private static readonly Guid IidFileOpenDialog = new("d57c7288-d4ad-4768-be02-9d969532d960");
            private static readonly Guid IidShellItem = new("43826d1e-e718-42ee-bc55-a1e261c37bfe");

            // OPENFILENAMEW at its Windows 2000+ size; the dialog rejects a size it does not know.
            [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
            private struct OpenFileName
            {
                public int StructSize;
                public IntPtr Owner;
                public IntPtr Instance;
                [MarshalAs(UnmanagedType.LPWStr)] public string Filter;
                [MarshalAs(UnmanagedType.LPWStr)] public string CustomFilter;
                public int MaxCustomFilter;
                public int FilterIndex;
                public IntPtr File;
                public int MaxFile;
                [MarshalAs(UnmanagedType.LPWStr)] public string FileTitle;
                public int MaxFileTitle;
                [MarshalAs(UnmanagedType.LPWStr)] public string InitialDir;
                [MarshalAs(UnmanagedType.LPWStr)] public string Title;
                public uint Flags;
                public ushort FileOffset;
                public ushort FileExtension;
                [MarshalAs(UnmanagedType.LPWStr)] public string DefaultExtension;
                public IntPtr CustomData;
                public IntPtr Hook;
                [MarshalAs(UnmanagedType.LPWStr)] public string TemplateName;
                public IntPtr Reserved;
                public int ReservedFlags;
                public int FlagsEx;
            }

            // IFileOpenDialog / IShellItem methods by vtable slot; each takes the object pointer first.
            [UnmanagedFunctionPointer(CallingConvention.StdCall)]
            private delegate int ShowFn(IntPtr self, IntPtr owner);
            [UnmanagedFunctionPointer(CallingConvention.StdCall)]
            private delegate int GetOptionsFn(IntPtr self, out uint options);
            [UnmanagedFunctionPointer(CallingConvention.StdCall)]
            private delegate int SetOptionsFn(IntPtr self, uint options);
            [UnmanagedFunctionPointer(CallingConvention.StdCall)]
            private delegate int SetTitleFn(IntPtr self, [MarshalAs(UnmanagedType.LPWStr)] string text);
            [UnmanagedFunctionPointer(CallingConvention.StdCall)]
            private delegate int SetFolderFn(IntPtr self, IntPtr item);
            [UnmanagedFunctionPointer(CallingConvention.StdCall)]
            private delegate int GetResultFn(IntPtr self, out IntPtr item);
            [UnmanagedFunctionPointer(CallingConvention.StdCall)]
            private delegate int GetDisplayNameFn(IntPtr self, uint sigdn, out IntPtr name);
            [UnmanagedFunctionPointer(CallingConvention.StdCall)]
            private delegate uint ReleaseFn(IntPtr self);

            [DllImport("comdlg32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
            private static extern bool GetOpenFileNameW(ref OpenFileName name);

            [DllImport("ole32.dll")]
            private static extern int OleInitialize(IntPtr reserved);

            [DllImport("ole32.dll")]
            private static extern void CoTaskMemFree(IntPtr memory);

            [DllImport("ole32.dll")]
            private static extern int CoCreateInstance(ref Guid clsid, IntPtr outer, uint context, ref Guid iid, out IntPtr result);

            [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
            private static extern int SHCreateItemFromParsingName(string path, IntPtr bindCtx, ref Guid iid, out IntPtr item);

            [DllImport("user32.dll")]
            private static extern IntPtr GetActiveWindow();

            public static string PickFile(string title, string startIn, string extension)
            {
                IntPtr buffer = IntPtr.Zero;

                try
                {
                    // The dialog writes the chosen path into this buffer, so it starts zeroed at full length.
                    buffer = Marshal.StringToCoTaskMemUni(new string('\0', MaxFilePath));

                    var name = new OpenFileName
                    {
                        StructSize = Marshal.SizeOf(typeof(OpenFileName)),
                        Owner = GetActiveWindow(),
                        Filter = Filter(extension),
                        FilterIndex = 1,
                        File = buffer,
                        MaxFile = MaxFilePath,
                        InitialDir = string.IsNullOrEmpty(startIn) ? null : startIn.Replace('/', '\\'),
                        Title = title,
                        DefaultExtension = extension,

                        // NoChangeDir: otherwise the process stays in the browsed folder and relative paths break.
                        Flags = FileMustExist | PathMustExist | NoChangeDir | ExplorerStyle,
                    };

                    if (!GetOpenFileNameW(ref name)) return null;

                    string path = Marshal.PtrToStringUni(buffer);
                    return string.IsNullOrEmpty(path) ? null : path;
                }
                finally
                {
                    if (buffer != IntPtr.Zero) Marshal.FreeCoTaskMem(buffer);
                }
            }

            // comdlg32 reads the filter as one nul separated run of pairs.
            private static string Filter(string extension)
            {
                if (string.IsNullOrEmpty(extension)) return "All files\0*.*\0\0";

                return $"{extension.ToUpperInvariant()} files\0*.{extension}\0All files\0*.*\0\0";
            }

            // A hard COM failure throws for Pick to log; a cancel is null.
            public static string PickFolder(string title, string startIn)
            {
                OleInitialize(IntPtr.Zero);

                Guid clsid = ClsidFileOpenDialog;
                Guid dialogIid = IidFileOpenDialog;

                if (CoCreateInstance(ref clsid, IntPtr.Zero, InprocServer, ref dialogIid, out IntPtr dialog) != 0
                    || dialog == IntPtr.Zero)
                    throw new InvalidOperationException("FileOpenDialog unavailable.");

                IntPtr folderItem = IntPtr.Zero;
                IntPtr resultItem = IntPtr.Zero;
                IntPtr pathPtr = IntPtr.Zero;

                try
                {
                    // Folders only, and only ones backed by a real filesystem path.
                    Method<GetOptionsFn>(dialog, 10)(dialog, out uint options);
                    Method<SetOptionsFn>(dialog, 9)(dialog, options | PickFolders | ForceFileSystem);

                    if (!string.IsNullOrEmpty(title))
                        Method<SetTitleFn>(dialog, 17)(dialog, title);

                    if (!string.IsNullOrEmpty(startIn))
                    {
                        Guid itemIid = IidShellItem;
                        if (SHCreateItemFromParsingName(startIn.Replace('/', '\\'), IntPtr.Zero, ref itemIid, out folderItem) == 0)
                            Method<SetFolderFn>(dialog, 12)(dialog, folderItem);
                    }

                    // Non-zero is cancel or close.
                    if (Method<ShowFn>(dialog, 3)(dialog, GetActiveWindow()) != 0) return null;

                    if (Method<GetResultFn>(dialog, 20)(dialog, out resultItem) != 0 || resultItem == IntPtr.Zero)
                        return null;

                    if (Method<GetDisplayNameFn>(resultItem, 5)(resultItem, SigdnFileSysPath, out pathPtr) != 0)
                        return null;

                    return Marshal.PtrToStringUni(pathPtr);
                }
                finally
                {
                    if (pathPtr != IntPtr.Zero) CoTaskMemFree(pathPtr);
                    if (resultItem != IntPtr.Zero) Method<ReleaseFn>(resultItem, 2)(resultItem);
                    if (folderItem != IntPtr.Zero) Method<ReleaseFn>(folderItem, 2)(folderItem);
                    if (dialog != IntPtr.Zero) Method<ReleaseFn>(dialog, 2)(dialog);
                }
            }

            private static T Method<T>(IntPtr obj, int index) where T : Delegate
            {
                IntPtr vtable = Marshal.ReadIntPtr(obj);
                IntPtr fn = Marshal.ReadIntPtr(vtable, index * IntPtr.Size);
                return Marshal.GetDelegateForFunctionPointer<T>(fn);
            }
        }
#endif

#if !UNITY_EDITOR && UNITY_STANDALONE_LINUX
        // zenity, or kdialog on KDE, run as a child process and read off stdout.
        private static class Linux
        {
            private const string Missing =
                "no folder dialog on this machine: install zenity (apt install zenity) or kdialog.";

            public static string PickFolder(string title, string startIn)
            {
                if (Installed("zenity"))
                    return Run("zenity", $"--file-selection --directory --title={Quote(title)}{OpensAt(startIn)}");

                if (Installed("kdialog"))
                    return Run("kdialog", $"--title {Quote(title)} --getexistingdirectory {Quote(startIn ?? ".")}");

                throw new InvalidOperationException(Missing);
            }

            public static string PickFile(string title, string startIn, string extension)
            {
                if (Installed("zenity"))
                    return Run("zenity", $"--file-selection --title={Quote(title)}{OpensAt(startIn)}{Filters(extension)}");

                if (Installed("kdialog"))
                    return Run("kdialog", $"--title {Quote(title)} --getopenfilename " +
                                          $"{Quote(startIn ?? ".")} {Quote(KdeFilter(extension))}");

                throw new InvalidOperationException(Missing);
            }

            // The chosen path, or null for a cancel, which both tools exit non-zero on.
            private static string Run(string program, string arguments)
            {
                var start = new ProcessStartInfo(program, arguments)
                {
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    CreateNoWindow = true,
                };

                using (Process dialog = Process.Start(start))
                {
                    if (dialog == null) throw new InvalidOperationException($"{program} would not start.");

                    // Read before the wait: a dialog whose output filled the pipe would never exit.
                    string output = dialog.StandardOutput.ReadToEnd();
                    dialog.WaitForExit();

                    if (dialog.ExitCode != 0) return null;

                    string path = output.Trim();
                    return string.IsNullOrEmpty(path) ? null : path;
                }
            }

            private static bool Installed(string program)
            {
                string path = Environment.GetEnvironmentVariable("PATH");
                if (string.IsNullOrEmpty(path)) return false;

                foreach (string folder in path.Split(':'))
                    if (folder.Length > 0 && File.Exists(Path.Combine(folder, program))) return true;

                return false;
            }

            // zenity only opens inside a folder given with the separator on the end.
            private static string OpensAt(string startIn) =>
                string.IsNullOrEmpty(startIn) ? string.Empty : $" --filename={Quote(startIn.TrimEnd('/') + "/")}";

            private static string Filters(string extension) =>
                string.IsNullOrEmpty(extension)
                    ? string.Empty
                    : $" --file-filter={Quote($"{extension.ToUpperInvariant()} files | *.{extension}")}" +
                      $" --file-filter={Quote("All files | *")}";

            // kdialog writes the filter the other way round.
            private static string KdeFilter(string extension) =>
                string.IsNullOrEmpty(extension) ? "*" : $"*.{extension}|{extension.ToUpperInvariant()} files";

            // No shell runs, so only the quote character needs escaping.
            private static string Quote(string text) => "\"" + (text ?? string.Empty).Replace("\"", "\\\"") + "\"";
        }
#endif
    }
}
