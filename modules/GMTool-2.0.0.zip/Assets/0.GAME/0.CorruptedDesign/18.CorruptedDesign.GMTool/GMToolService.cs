using System;
using System.Collections.Generic;
using System.Linq;
using CorruptedDesign.Observer;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UIElements;

namespace CorruptedDesign.GM
{
    /// <summary>Runtime GM tool: a tabbed cheat window opened with F10, a four-finger tap or the floating GM button.</summary>
    public class GMToolService : MonoBehaviour
    {
        private const string PanelSettingsPath = "CorruptedDesignGM/PanelSettings";
        private const int RefreshMilliseconds = 500;
        private const int OpenTouchCount = 4;

        private static GMToolService instance;

        private readonly List<IGMPanel> panels = new();

        private VisualElement shell;
        private VisualElement fab;
        private VisualElement tabBar;
        private ScrollView content;
        private Label headerInfo;
        private IGMPanel current;
        private int touchCount;
        private bool isOpen;

        #region PUBLIC API
        /// <summary>Whether this build may show the tool: the editor, development builds, or a player who logged in as tester.</summary>
        public static bool IsAvailable =>
            Application.isEditor || Debug.isDebugBuild || (GameService.DataManager != null && GameService.DataManager.IsTester);

        public static bool IsOpen => instance != null && instance.isOpen;

        public static void Open() { if (Ensure()) instance.SetOpen(true); }

        public static void Close() { if (instance != null) instance.SetOpen(false); }

        public static void Toggle()
        {
            if (IsOpen) Close();
            else Open();
        }
        #endregion

        #region BOOTSTRAP
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetState() => instance = null;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void Bootstrap()
        {
            GMLogBuffer.Start();
            if (Application.isEditor || Debug.isDebugBuild) Ensure();
            else EventService.AddListener<TesterLogin>(OnTesterLogin);
        }

        private static void OnTesterLogin(TesterLogin e) => Ensure();

        private static bool Ensure()
        {
            if (instance != null) return true;
            if (!IsAvailable) return false;

            var host = new GameObject("[GMTool]");
            DontDestroyOnLoad(host);
            instance = host.AddComponent<GMToolService>();
            return instance.shell != null;
        }
        #endregion

        #region LIFECYCLE
        private void Awake()
        {
            var settings = Resources.Load<PanelSettings>(PanelSettingsPath);
            if (settings == null)
            {
                Bug.LogWarning($"[GM] Missing Resources/{PanelSettingsPath}, the GM tool stays off.", "red");
                Destroy(gameObject);
                return;
            }

            var document = gameObject.AddComponent<UIDocument>();
            document.panelSettings = settings;
            document.sortingOrder = 5000;

            DiscoverPanels();
            BuildRoot(document.rootVisualElement);
            SetOpen(false);
        }

        private void OnDestroy()
        {
            if (ReferenceEquals(instance, this)) instance = null;
        }

        private void Update()
        {
            var keyboard = Keyboard.current;
            if (keyboard != null && keyboard.f10Key.wasPressedThisFrame) Toggle();

            var screen = Touchscreen.current;
            if (screen == null) return;

            int pressed = screen.touches.Count(t => t.press.isPressed);
            if (pressed >= OpenTouchCount && touchCount < OpenTouchCount) Toggle();
            touchCount = pressed;
        }
        #endregion

        #region LAYOUT
        private void DiscoverPanels()
        {
            var found = typeof(GMToolService).Assembly.GetTypes()
                .Where(t => typeof(IGMPanel).IsAssignableFrom(t) && t.IsClass && !t.IsAbstract && t.GetConstructor(Type.EmptyTypes) != null)
                .Select(t => (IGMPanel)Activator.CreateInstance(t))
                .OrderBy(p => p.Order);
            panels.AddRange(found);
        }

        private void BuildRoot(VisualElement root)
        {
            root.pickingMode = PickingMode.Ignore;
            GMStyle.Fill(root);

            shell = new VisualElement();
            GMStyle.Fill(shell);
            shell.style.backgroundColor = GMStyle.Backdrop;
            shell.style.paddingTop = 56;
            shell.style.paddingBottom = 28;
            shell.style.paddingLeft = shell.style.paddingRight = 24;
            root.Add(shell);

            var window = new VisualElement();
            window.style.flexGrow = 1;
            window.style.backgroundColor = GMStyle.Window;
            window.style.paddingTop = 24;
            window.style.paddingLeft = window.style.paddingRight = 24;
            window.style.paddingBottom = 12;
            GMStyle.Round(window, 32);
            shell.Add(window);

            window.Add(BuildHeader());
            window.Add(BuildTabBar());

            content = new ScrollView(ScrollViewMode.Vertical) { touchScrollBehavior = ScrollView.TouchScrollBehavior.Elastic };
            content.style.flexGrow = 1;
            content.style.marginTop = 8;
            window.Add(content);

            fab = BuildFab();
            root.Add(fab);

            root.schedule.Execute(RefreshCurrent).Every(RefreshMilliseconds);
        }

        private VisualElement BuildHeader()
        {
            var header = GMStyle.Row(16, false);
            header.style.justifyContent = Justify.SpaceBetween;

            var titles = new VisualElement();
            titles.Add(GMStyle.Label("CORRUPTED_DESIGN GM", 40, GMStyle.Text, true));
            headerInfo = GMStyle.Label(string.Empty, 22, GMStyle.Dim);
            titles.Add(headerInfo);
            header.Add(titles);

            var close = GMStyle.Button("CLOSE", Close, GMStyle.Bad);
            close.style.marginRight = 0;
            close.style.marginBottom = 0;
            header.Add(close);
            return header;
        }

        private VisualElement BuildTabBar()
        {
            var scroll = new ScrollView(ScrollViewMode.Horizontal)
            {
                verticalScrollerVisibility = ScrollerVisibility.Hidden,
                horizontalScrollerVisibility = ScrollerVisibility.Hidden,
                touchScrollBehavior = ScrollView.TouchScrollBehavior.Elastic,
            };
            scroll.style.flexShrink = 0;
            scroll.style.minHeight = 92;

            tabBar = new VisualElement();
            tabBar.style.flexDirection = FlexDirection.Row;
            scroll.Add(tabBar);

            foreach (var panel in panels)
            {
                var captured = panel;
                var tab = GMStyle.Button(panel.Title, () => Select(captured), GMStyle.Card, 24);
                tab.name = panel.Title;
                tabBar.Add(tab);
            }
            return scroll;
        }

        private VisualElement BuildFab()
        {
            var button = new Button(() => SetOpen(true)) { text = "GM" };
            button.style.position = Position.Absolute;
            button.style.right = 16;
            button.style.top = 280;
            button.style.width = button.style.height = 104;
            button.style.backgroundColor = new Color(GMStyle.Accent.r, GMStyle.Accent.g, GMStyle.Accent.b, 0.55f);
            button.style.color = Color.white;
            button.style.fontSize = 30;
            button.style.unityFontStyleAndWeight = FontStyle.Bold;
            button.style.borderTopWidth = button.style.borderBottomWidth = 0;
            button.style.borderLeftWidth = button.style.borderRightWidth = 0;
            GMStyle.Round(button, 52);
            return button;
        }
        #endregion

        #region STATE
        private void SetOpen(bool open)
        {
            isOpen = open;
            shell.style.display = open ? DisplayStyle.Flex : DisplayStyle.None;
            fab.style.display = open ? DisplayStyle.None : DisplayStyle.Flex;
            if (!open) return;

            if (current == null && panels.Count > 0) Select(panels[0]);
            else Select(current);
        }

        private void Select(IGMPanel panel)
        {
            if (panel == null) return;

            current = panel;
            foreach (var tab in tabBar.Children())
                tab.style.backgroundColor = tab.name == panel.Title ? GMStyle.Accent : GMStyle.Card;

            content.Clear();
            GMStyle.Run(() => panel.Build(content));
            RefreshCurrent();
        }

        private void RefreshCurrent()
        {
            if (current == null || !isOpen) return;

            var data = GameService.DataManager;
            headerInfo.text = data != null
                ? $"v{Application.version}  |  level {data.Level}  |  {Application.platform}  |  {(1f / Mathf.Max(Time.unscaledDeltaTime, 0.0001f)):0} fps"
                : $"v{Application.version}  |  {Application.platform}";
            GMStyle.Run(current.Refresh);
        }
        #endregion
    }
}
