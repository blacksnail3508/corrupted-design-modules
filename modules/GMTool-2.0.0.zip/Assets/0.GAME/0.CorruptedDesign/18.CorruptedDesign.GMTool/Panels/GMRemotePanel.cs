using System;
using System.Linq;
using System.Reflection;
using Newtonsoft.Json;
using CorruptedDesign.Remote;
using UnityEngine.UIElements;

namespace CorruptedDesign.GM
{
    /// <summary>Shows every remote config key with the value the game is using now.</summary>
    public sealed class GMRemotePanel : IGMPanel
    {
        private const int MaxValueLength = 140;

        private VisualElement list;
        private Label sourceLabel;
        private string filter = string.Empty;

        public string Title => "Remote";
        public int Order => 40;

        public void Build(VisualElement root)
        {
            var status = GMStyle.CardBlock("Status");
            status.Add(GMStyle.Stat("Source", out sourceLabel, GMStyle.Accent));
            root.Add(status);

            var card = GMStyle.CardBlock("Config values");
            var search = GMStyle.Input(string.Empty);
            search.RegisterValueChangedCallback(e =>
            {
                filter = e.newValue ?? string.Empty;
                Fill();
            });
            card.Add(search);

            list = new VisualElement();
            card.Add(list);
            root.Add(card);
            Fill();
        }

        public void Refresh()
        {
            var manager = RemoteManager.Instance;
            if (sourceLabel == null) return;

            sourceLabel.text = manager == null ? "not running" : $"{manager.Source}{(manager.IsFetchDone ? string.Empty : " (fetching)")}";
        }

        private void Fill()
        {
            list.Clear();
            foreach (var config in ConfigCollection.All.Where(c => c.Key.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0).OrderBy(c => c.Key))
            {
                var row = GMStyle.Row(6, false);
                row.style.justifyContent = Justify.SpaceBetween;

                var key = GMStyle.Label(config.Key, 22, GMStyle.Dim);
                key.style.flexShrink = 1;
                var value = GMStyle.Label(Describe(config), 22, GMStyle.Text, true);
                value.style.maxWidth = 520;
                value.style.unityTextAlign = UnityEngine.TextAnchor.MiddleRight;
                row.Add(key);
                row.Add(value);
                list.Add(row);
            }
        }

        // Entries are generic types, so the current value is read by name instead of through a shared interface.
        private static string Describe(IRemoteConfig config)
        {
            var property = config.GetType().GetProperty("Value", BindingFlags.Public | BindingFlags.Instance);
            if (property == null) return "?";

            var text = JsonConvert.SerializeObject(property.GetValue(config));
            return text.Length > MaxValueLength ? text.Substring(0, MaxValueLength) + "..." : text;
        }
    }
}
