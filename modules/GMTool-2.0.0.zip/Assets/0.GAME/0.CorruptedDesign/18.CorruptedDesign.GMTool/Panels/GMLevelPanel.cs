using UnityEngine.UIElements;

namespace CorruptedDesign.GM
{
    /// <summary>Jumps between levels and resets level progress.</summary>
    public sealed class GMLevelPanel : IGMPanel
    {
        private Label levelLabel;
        private Label difficultyLabel;
        private TextField levelInput;

        public string Title => "Level";
        public int Order => 20;

        public void Build(VisualElement root)
        {
            var data = GameService.DataManager;
            if (data == null)
            {
                root.Add(GMStyle.Notice("Player data is not ready yet."));
                return;
            }

            root.Add(BuildCurrent());
            root.Add(BuildJump(data));
            root.Add(BuildReset(data));
        }

        public void Refresh()
        {
            var data = GameService.DataManager;
            if (data == null || levelLabel == null) return;

            levelLabel.text = data.Level.ToString();
            difficultyLabel.text = data.CurrentDifficulty.ToString();
        }

        #region SECTIONS
        private VisualElement BuildCurrent()
        {
            var card = GMStyle.CardBlock("Current");
            card.Add(GMStyle.Stat("Level", out levelLabel, GMStyle.Accent));
            card.Add(GMStyle.Stat("Difficulty", out difficultyLabel));
            return card;
        }

        private VisualElement BuildJump(PlayerDataManager data)
        {
            var card = GMStyle.CardBlock("Go to level");

            var row = GMStyle.Row(8);
            levelInput = GMStyle.Input(data.Level.ToString());
            row.Add(levelInput);
            row.Add(GMStyle.Button("GO", GoToInput, GMStyle.Accent));
            card.Add(row);

            var steps = GMStyle.Row();
            steps.Add(GMStyle.Button("Previous", () => GameService.ForcePlayLevel(data.Level - 1)));
            steps.Add(GMStyle.Button("Next", () => GameService.ForcePlayLevel(data.Level + 1)));
            steps.Add(GMStyle.Button("Reload", () => GameService.ForcePlayLevel(data.Level), GMStyle.Warn));
            steps.Add(GMStyle.Button("Lobby", GameService.GoLobby));
            card.Add(steps);
            return card;
        }

        private VisualElement BuildReset(PlayerDataManager data)
        {
            var card = GMStyle.CardBlock("Progress");
            var row = GMStyle.Row();
            row.Add(GMStyle.Button("Clear played levels", () =>
            {
                data.LevelSystem.ClearPlayedLevels();
                GameService.ShowToast("Played levels cleared");
            }));
            row.Add(GMStyle.Button("Reset tutorials", () =>
            {
                data.ResetTutorialWatched();
                GameService.ShowToast("Tutorials reset");
            }));
            card.Add(row);
            return card;
        }

        private void GoToInput()
        {
            if (!int.TryParse(levelInput.value, out int level)) return;

            GameService.ForcePlayLevel(level);
        }
        #endregion
    }
}
