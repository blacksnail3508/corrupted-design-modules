using System;
using System.Collections.Generic;
using CorruptedDesign.Stamina;
using UnityEngine.UIElements;

namespace CorruptedDesign.GM
{
    /// <summary>Gives or takes coins, boosters and hearts.</summary>
    public sealed class GMResourcesPanel : IGMPanel
    {
        private static readonly int[] CoinSteps = { 100, 1000, 10000 };

        private readonly Dictionary<BoosterType, Label> boosterLabels = new();
        private Label coinLabel;
        private Label heartLabel;

        public string Title => "Resources";
        public int Order => 10;

        public void Build(VisualElement root)
        {
            boosterLabels.Clear();
            var data = GameService.DataManager;
            if (data == null)
            {
                root.Add(GMStyle.Notice("Player data is not ready yet. Open this tab after the lobby loads."));
                return;
            }

            root.Add(BuildCoins(data));
            root.Add(BuildBoosters(data));
            root.Add(BuildHearts());
        }

        public void Refresh()
        {
            var data = GameService.DataManager;
            if (data == null) return;

            if (coinLabel != null) coinLabel.text = data.Coin.ToString("N0");
            foreach (var pair in boosterLabels) pair.Value.text = data.GetBoosterBalance(pair.Key).ToString();
            if (heartLabel != null && StaminaManager.Instance != null)
                heartLabel.text = $"{StaminaManager.CurrentStamina} / {StaminaManager.MaxStamina}";
        }

        #region SECTIONS
        private VisualElement BuildCoins(PlayerDataManager data)
        {
            var card = GMStyle.CardBlock("Coins");
            card.Add(GMStyle.Stat("Balance", out coinLabel, GMStyle.Warn));

            var row = GMStyle.Row();
            foreach (int step in CoinSteps)
            {
                int amount = step;
                row.Add(GMStyle.Button($"+{amount:N0}", () => data.ClaimCoin(amount, ResourceReason.Free, ResourcePlacement.Cheat, true), GMStyle.Good));
            }
            row.Add(GMStyle.Button("-100", () => data.TrySpendCoin(100, ResourceReason.Exchange, ResourcePlacement.Cheat), GMStyle.Bad));
            card.Add(row);
            return card;
        }

        private VisualElement BuildBoosters(PlayerDataManager data)
        {
            var card = GMStyle.CardBlock("Boosters");
            foreach (BoosterType type in Enum.GetValues(typeof(BoosterType)))
            {
                var booster = type;
                card.Add(GMStyle.Stat(booster.ToString(), out var label));
                boosterLabels[booster] = label;

                var row = GMStyle.Row();
                row.Add(GMStyle.Button("+1", () => data.ClaimBooster(booster, 1, ResourceReason.Free, ResourcePlacement.Cheat), GMStyle.Good));
                row.Add(GMStyle.Button("+5", () => data.ClaimBooster(booster, 5, ResourceReason.Free, ResourcePlacement.Cheat), GMStyle.Good));
                row.Add(GMStyle.Button("-1", () => data.SpendBooster(booster, 1, ResourceReason.UseBooster, ResourcePlacement.Cheat), GMStyle.Bad));
                card.Add(row);
            }
            return card;
        }

        private VisualElement BuildHearts()
        {
            var card = GMStyle.CardBlock("Hearts");
            if (StaminaManager.Instance == null)
            {
                card.Add(GMStyle.Label("Stamina feature is not running.", 24, GMStyle.Dim));
                return card;
            }

            card.Add(GMStyle.Stat("Hearts", out heartLabel));
            var row = GMStyle.Row();
            row.Add(GMStyle.Button("Fill", () => StaminaManager.SetStamina(StaminaManager.MaxStamina), GMStyle.Good));
            row.Add(GMStyle.Button("Empty", () => StaminaManager.SetStamina(0), GMStyle.Bad));
            row.Add(GMStyle.Button("Infinite 10m", () => StaminaManager.InfiniteStamina(10)));
            card.Add(row);
            return card;
        }
        #endregion
    }
}
