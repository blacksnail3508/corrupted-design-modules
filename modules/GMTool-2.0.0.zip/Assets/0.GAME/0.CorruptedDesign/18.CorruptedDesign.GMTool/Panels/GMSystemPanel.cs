using System.IO;
using CorruptedDesign.Data;
using CorruptedDesign.Observer;
using UnityEngine;
using UnityEngine.UIElements;

namespace CorruptedDesign.GM
{
    /// <summary>Time scale, frame rate, ads switches, tester mode and wiping saved data.</summary>
    public sealed class GMSystemPanel : IGMPanel
    {
        private Label scaleLabel;
        private Label memoryLabel;
        private Button wipeButton;
        private bool wipeArmed;

        public string Title => "System";
        public int Order => 60;

        public void Build(VisualElement root)
        {
            wipeArmed = false;
            root.Add(BuildTime());
            root.Add(BuildSwitches());
            root.Add(BuildAds());
            root.Add(BuildDevice());
            root.Add(BuildData());
        }

        public void Refresh()
        {
            if (scaleLabel != null) scaleLabel.text = $"{Time.timeScale:0.0#}x";
            if (memoryLabel != null) memoryLabel.text = $"{(Application.platform == RuntimePlatform.WebGLPlayer ? 0 : UnityEngine.Profiling.Profiler.GetTotalAllocatedMemoryLong() / 1048576f):0} MB";
        }

        #region SECTIONS
        private VisualElement BuildTime()
        {
            var card = GMStyle.CardBlock("Time and frame rate");
            card.Add(GMStyle.Stat("Time scale", out scaleLabel, GMStyle.Accent));

            var slider = new Slider(0f, 5f) { value = Time.timeScale };
            slider.style.marginBottom = 16;
            slider.RegisterValueChangedCallback(e => Time.timeScale = Mathf.Round(e.newValue * 10f) / 10f);
            card.Add(slider);

            var row = GMStyle.Row();
            row.Add(GMStyle.Button("Pause", () => { Time.timeScale = 0f; slider.SetValueWithoutNotify(0f); }, GMStyle.Bad));
            row.Add(GMStyle.Button("1x", () => { Time.timeScale = 1f; slider.SetValueWithoutNotify(1f); }, GMStyle.Good));
            row.Add(GMStyle.Button("3x", () => { Time.timeScale = 3f; slider.SetValueWithoutNotify(3f); }));
            card.Add(row);

            var fps = GMStyle.Row();
            foreach (int rate in new[] { 30, 60, 120 })
            {
                int target = rate;
                fps.Add(GMStyle.Button($"{target} fps", () => Application.targetFrameRate = target));
            }
            card.Add(fps);
            return card;
        }

        private VisualElement BuildSwitches()
        {
            var card = GMStyle.CardBlock("Switches");
            var data = GameService.DataManager;
            if (data == null)
            {
                card.Add(GMStyle.Label("Player data is not ready yet.", 24, GMStyle.Dim));
                return card;
            }

            card.Add(GMStyle.Toggle("Tester mode", data.IsTester, on =>
            {
                data.IsTester = on;
                if (on) EventService.Raise(new TesterLogin());
            }));
            card.Add(GMStyle.Toggle("Skip ads (rewards still granted)", AdsProvider.SkipAds, on => AdsProvider.SkipAds = on));
            return card;
        }

        private VisualElement BuildAds()
        {
            var card = GMStyle.CardBlock("Ads");
            var row = GMStyle.Row();
            row.Add(GMStyle.Button("Interstitial", () => AdsProvider.ShowInterstitial(AdsPlacement.Win, ok => GameService.ShowToast($"Interstitial: {ok}"), null, true)));
            row.Add(GMStyle.Button("Rewarded", () => AdsProvider.ShowRewarded(AdsPlacement.FreeReward, ok => GameService.ShowToast($"Rewarded: {ok}"))));
            card.Add(row);
            return card;
        }

        private VisualElement BuildDevice()
        {
            var card = GMStyle.CardBlock("Device");
            card.Add(GMStyle.Label($"{SystemInfo.deviceModel}  |  {SystemInfo.operatingSystem}", 22, GMStyle.Dim));
            card.Add(GMStyle.Label($"{Screen.width}x{Screen.height}  |  quality {QualitySettings.names[QualitySettings.GetQualityLevel()]}", 22, GMStyle.Dim));
            card.Add(GMStyle.Stat("Allocated memory", out memoryLabel));
            return card;
        }

        private VisualElement BuildData()
        {
            var card = GMStyle.CardBlock("Saved data");
            card.Add(GMStyle.Label("Wipes every Vault and PlayerPrefs value. Tap twice to confirm, then restart the app.", 22, GMStyle.Dim));

            wipeButton = GMStyle.Button("Wipe all saved data", OnWipe, GMStyle.Bad);
            wipeButton.style.marginTop = 14;
            card.Add(wipeButton);
            return card;
        }

        private void OnWipe()
        {
            if (!wipeArmed)
            {
                wipeArmed = true;
                wipeButton.text = "Tap again to wipe";
                return;
            }

            SecuredPrefs.DeleteAll();
            JsonFileStore.DeleteAll();
            // DeleteAll only clears memory; without Save the JSON-backed data comes back on the next launch.
            JsonFileStore.Save();
            wipeArmed = false;
            wipeButton.text = "Wiped. Restart the app";
            Bug.Log("[GM] All saved data wiped.", "red");
        }
        #endregion
    }
}
