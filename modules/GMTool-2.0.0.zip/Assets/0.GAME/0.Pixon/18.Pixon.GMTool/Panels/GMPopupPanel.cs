using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Pixon.UI;
using UnityEngine.UIElements;

namespace Pixon.GM
{
    /// <summary>Opens any popup of the game by name, to check it without playing up to it.</summary>
    public sealed class GMPopupPanel : IGMPanel
    {
        private static readonly MethodInfo ShowPopupMethod = typeof(UIManager).GetMethod(nameof(UIManager.ShowPopup));

        private readonly List<Type> popupTypes = new();
        private VisualElement list;

        public string Title => "Popups";
        public int Order => 30;

        public void Build(VisualElement root)
        {
            popupTypes.Clear();
            popupTypes.AddRange(typeof(Window).Assembly.GetTypes()
                .Where(t => t.IsClass && !t.IsAbstract && typeof(Window).IsAssignableFrom(t) && t.Name.StartsWith("UIPopup"))
                .OrderBy(t => t.Name));

            var card = GMStyle.CardBlock("Popups");
            var row = GMStyle.Row(8);
            var search = GMStyle.Input(string.Empty);
            search.label = string.Empty;
            search.RegisterValueChangedCallback(e => Fill(e.newValue));
            row.Add(search);
            row.Add(GMStyle.Button("Close all", () => GameService.UIManager?.ClosePopups(), GMStyle.Bad));
            card.Add(row);

            list = new VisualElement();
            card.Add(list);
            root.Add(card);
            Fill(string.Empty);
        }

        public void Refresh() { }

        private void Fill(string filter)
        {
            list.Clear();
            foreach (var type in popupTypes.Where(t => t.Name.IndexOf(filter ?? string.Empty, StringComparison.OrdinalIgnoreCase) >= 0))
            {
                var popup = type;
                list.Add(GMStyle.Button(popup.Name.Replace("UIPopup", string.Empty), () => Show(popup)));
            }
        }

        private static void Show(Type popup)
        {
            var manager = GameService.UIManager;
            if (manager == null)
            {
                GameService.ShowToast("UI is not ready");
                return;
            }

            // ShowPopup<T> is generic, so the popup type is only known here as a Type.
            ShowPopupMethod.MakeGenericMethod(popup).Invoke(manager, new object[] { UITrigger.Click, -1 });
        }
    }
}
