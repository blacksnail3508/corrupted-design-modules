using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine.UIElements;

namespace Pixon.GM
{
    /// <summary>Lists every static method marked <see cref="GMActionAttribute"/> as a button, grouped by its group name.</summary>
    public sealed class GMActionsPanel : IGMPanel
    {
        private const BindingFlags Flags = BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;

        public string Title => "Actions";
        public int Order => 70;

        public void Build(VisualElement root)
        {
            var actions = Discover().ToList();
            if (actions.Count == 0)
            {
                root.Add(GMStyle.Notice("No [GMAction] methods found. Add the attribute to a static method to list it here."));
                return;
            }

            foreach (var group in actions.GroupBy(a => a.attribute.Group).OrderBy(g => g.Key))
            {
                var card = GMStyle.CardBlock(group.Key);
                var row = GMStyle.Row();
                foreach (var (attribute, method) in group.OrderBy(a => a.attribute.Label))
                {
                    var target = method;
                    row.Add(GMStyle.Button(attribute.Label, () => target.Invoke(null, null)));
                }
                card.Add(row);
                root.Add(card);
            }
        }

        public void Refresh() { }

        private static IEnumerable<(GMActionAttribute attribute, MethodInfo method)> Discover()
        {
            foreach (var type in typeof(GMActionsPanel).Assembly.GetTypes())
            foreach (var method in type.GetMethods(Flags))
            {
                if (method.GetParameters().Length != 0) continue;

                var attribute = method.GetCustomAttribute<GMActionAttribute>();
                if (attribute != null) yield return (attribute, method);
            }
        }
    }
}
