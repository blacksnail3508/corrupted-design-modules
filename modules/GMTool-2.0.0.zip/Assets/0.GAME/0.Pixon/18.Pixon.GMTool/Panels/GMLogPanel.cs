using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UIElements;

namespace Pixon.GM
{
    /// <summary>Shows recent console messages with a filter for warnings and errors.</summary>
    public sealed class GMLogPanel : IGMPanel
    {
        private const int MaxShown = 120;

        private VisualElement list;
        private int drawnVersion = -1;
        private bool showLog = true;
        private bool showWarning = true;
        private bool showError = true;

        public string Title => "Logs";
        public int Order => 50;

        public void Build(VisualElement root)
        {
            drawnVersion = -1;

            var card = GMStyle.CardBlock("Console");
            var filters = GMStyle.Row();
            filters.Add(GMStyle.Toggle("Log", showLog, v => { showLog = v; Redraw(); }));
            filters.Add(GMStyle.Toggle("Warn", showWarning, v => { showWarning = v; Redraw(); }));
            filters.Add(GMStyle.Toggle("Error", showError, v => { showError = v; Redraw(); }));
            card.Add(filters);

            var actions = GMStyle.Row();
            actions.Add(GMStyle.Button("Clear", () => { GMLogBuffer.Clear(); Redraw(); }, GMStyle.Bad));
            actions.Add(GMStyle.Button("Copy", Copy));
            card.Add(actions);

            list = new VisualElement();
            card.Add(list);
            root.Add(card);
            Redraw();
        }

        public void Refresh()
        {
            if (list != null && drawnVersion != GMLogBuffer.Version) Redraw();
        }

        private void Redraw()
        {
            drawnVersion = GMLogBuffer.Version;
            list.Clear();
            foreach (var entry in Visible().Skip(Mathf.Max(0, Visible().Count() - MaxShown)))
            {
                var label = GMStyle.Label(Trim(entry.Message), 20, ColorOf(entry.Type));
                label.style.marginBottom = 8;
                list.Add(label);
            }
        }

        private IEnumerable<GMLogBuffer.Entry> Visible() => GMLogBuffer.Snapshot().Where(IsShown);

        private bool IsShown(GMLogBuffer.Entry entry) => entry.Type switch
        {
            LogType.Warning => showWarning,
            LogType.Log => showLog,
            _ => showError,
        };

        private void Copy()
        {
            GUIUtility.systemCopyBuffer = string.Join("\n", Visible().Select(e => $"[{e.Type}] {e.Message}"));
            GameService.ShowToast("Logs copied");
        }

        private static string Trim(string message) => message.Length > 400 ? message.Substring(0, 400) + "..." : message;

        private static Color ColorOf(LogType type) => type switch
        {
            LogType.Warning => GMStyle.Warn,
            LogType.Log => GMStyle.Text,
            _ => GMStyle.Bad,
        };
    }
}
