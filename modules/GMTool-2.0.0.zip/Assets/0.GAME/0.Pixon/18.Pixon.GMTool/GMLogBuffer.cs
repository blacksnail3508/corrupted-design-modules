using System.Collections.Generic;
using UnityEngine;

namespace Pixon.GM
{
    /// <summary>Keeps the last console messages so the GM tool can show them on a device with no console.</summary>
    public static class GMLogBuffer
    {
        public readonly struct Entry
        {
            public readonly LogType Type;
            public readonly string Message;

            public Entry(LogType type, string message)
            {
                Type = type;
                Message = message;
            }
        }

        private const int Capacity = 300;

        private static readonly object Sync = new();
        private static readonly List<Entry> Entries = new(Capacity);
        private static bool isStarted;

        // Bumped on every message so a panel can tell whether it has anything new to draw.
        public static int Version { get; private set; }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetState()
        {
            // Without domain reload the old subscription would survive and log every message twice.
            Application.logMessageReceivedThreaded -= OnMessage;
            isStarted = false;
            Entries.Clear();
            Version = 0;
        }

        public static void Start()
        {
            if (isStarted) return;

            isStarted = true;
            Application.logMessageReceivedThreaded += OnMessage;
        }

        /// <summary>Copies the stored messages, oldest first.</summary>
        public static List<Entry> Snapshot()
        {
            lock (Sync) return new List<Entry>(Entries);
        }

        public static void Clear()
        {
            lock (Sync) Entries.Clear();
            Version++;
        }

        private static void OnMessage(string message, string stackTrace, LogType type)
        {
            lock (Sync)
            {
                if (Entries.Count >= Capacity) Entries.RemoveAt(0);
                Entries.Add(new Entry(type, message));
            }
            Version++;
        }
    }
}
