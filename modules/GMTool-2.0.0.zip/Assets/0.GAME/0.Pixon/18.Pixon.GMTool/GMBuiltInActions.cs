using System;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Pixon.GM
{
    /// <summary>Generic actions every project gets in the Actions tab; copy the pattern to add game-specific ones.</summary>
    public static class GMBuiltInActions
    {
        [GMAction("Show toast", "Debug")]
        private static void ShowToast() => GameService.ShowToast("Hello from the GM tool");

        [GMAction("Log message", "Debug")]
        private static void LogMessage() => Bug.Log("[GM] test message");

        [GMAction("Log warning", "Debug")]
        private static void LogWarning() => Bug.LogWarning("[GM] test warning");

        [GMAction("Collect garbage", "Debug")]
        private static void CollectGarbage()
        {
            GC.Collect();
            Resources.UnloadUnusedAssets();
        }

        [GMAction("Reload scene", "Scene")]
        private static void ReloadScene() => SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);

        [GMAction("Go to lobby", "Scene")]
        private static void GoToLobby() => GameService.GoLobby();
    }
}
