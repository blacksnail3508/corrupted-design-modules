using UnityEngine.UIElements;

namespace Pixon.GM
{
    /// <summary>One tab of the GM tool. Any class with this interface and a parameterless constructor is picked up automatically.</summary>
    public interface IGMPanel
    {
        string Title { get; }

        // Tabs are sorted by this, lowest first.
        int Order { get; }

        /// <summary>Builds the tab's content into <paramref name="root"/> each time the tab is opened.</summary>
        void Build(VisualElement root);

        /// <summary>Called twice a second while the tab is open, to update live values.</summary>
        void Refresh();
    }
}
