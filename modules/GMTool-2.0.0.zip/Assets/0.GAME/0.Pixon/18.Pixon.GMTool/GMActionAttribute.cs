using System;

namespace Pixon.GM
{
    /// <summary>Marks a static method with no parameters as a button in the GM tool's Actions tab.</summary>
    [AttributeUsage(AttributeTargets.Method)]
    public sealed class GMActionAttribute : Attribute
    {
        public string Label { get; }
        public string Group { get; }

        public GMActionAttribute(string label, string group = "General")
        {
            Label = label;
            Group = group;
        }
    }
}
