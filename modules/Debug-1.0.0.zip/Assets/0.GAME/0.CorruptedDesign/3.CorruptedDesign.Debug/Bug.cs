using Sirenix.Utilities;
using UnityEngine;

public static class Bug
{
    public static bool AllowDebug = true;
    private static string baseColor = "#f5c07a";
    
    public static void Log(string message, string color = "")
    {
        if (!AllowDebug) return;
        if (color.IsNullOrWhitespace()) Debug.Log($"<color={baseColor}>{message}</color>");
        else Debug.Log($"<color={color}>{message}</color>");
    }

    public static void LogWarning(string message, string color = "")
    {
        if (!AllowDebug) return;
        if (color.IsNullOrWhitespace()) Debug.LogWarning($"<color={baseColor}>{message}</color>");
        else Debug.Log($"<color={color}>{message}</color>");
    }
    
    public static void Report(string managerReport, string message)
    {
        if (!AllowDebug) return;
        Debug.Log($"<color={baseColor}>{managerReport}</color> : {message}");
    }
}
