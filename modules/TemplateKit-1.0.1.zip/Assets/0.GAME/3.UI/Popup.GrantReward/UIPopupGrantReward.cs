using System.Collections.Generic;
using CorruptedDesign.IAP;
using CorruptedDesign.UI;
using UnityEngine;

/// <summary>Post-purchase recap: lists what an IAP already paid out; Claim only closes it.</summary>
public class UIPopupGrantReward : Popup
{
    public override string PopupType => "popup_grant_reward";

    [SerializeField] private Transform rewardRoot;
    [SerializeField] private UIResourceHolder uiResourceHolder;
    [SerializeField] private ButtonBase claimButton;
    [SerializeField] private List<UIResourceHolder> activeHolders = new();

    public override void Initialize() => claimButton.AddListener(OnClaim);

    public UIPopupGrantReward SetRewards(IEnumerable<IapReward> rewards)
    {
        DisableAllCurrentHolders();

        // One slot per item type, so a pack that lists a type twice still shows a single total.
        var totals = new Dictionary<ItemType, int>();
        foreach (var reward in rewards)
        {
            totals.TryGetValue(reward.type, out int sum);
            totals[reward.type] = sum + reward.amount;
        }

        int index = 0;
        float interval = 0.05f;
        float totalDelay = 0.15f;
        foreach (var pair in totals)
        {
            if (pair.Value <= 0) continue;
            var holder = GetHolder(index++);
            holder.SetData(pair.Key, pair.Value);
            holder.gameObject.SetActive(true);
            holder.Intro(index * interval + totalDelay);
        }
        return this;
    }

    private UIResourceHolder GetHolder(int index)
    {
        while (activeHolders.Count <= index)
        {
            // The prefab's template doubles as the first slot, so nothing is instantiated for a one-item grant.
            var holder = activeHolders.Count == 0 && uiResourceHolder.transform.parent == rewardRoot
                ? uiResourceHolder
                : Instantiate(uiResourceHolder, rewardRoot);
            activeHolders.Add(holder);
        }
        return activeHolders[index];
    }

    private void DisableAllCurrentHolders()
    {
        foreach (var holder in activeHolders) holder.gameObject.SetActive(false);
        // Before any slot is registered the template itself is the only thing that could show up empty.
        if (activeHolders.Count == 0) uiResourceHolder.gameObject.SetActive(false);
    }

    private void OnClaim() => this.ClosePopup<UIPopupGrantReward>();

    public override void ResetData() => DisableAllCurrentHolders();
}
