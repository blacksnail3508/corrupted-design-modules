using CorruptedDesign.Remote;
using CorruptedDesign.UI;

/// <summary>Auto-shows an offer popup once, on the first home visit after winning the level set in remote config.</summary>
public abstract class UIStepAutoOffer<TPopup> : UIRevealStep where TPopup : CorruptedDesign.UI.Popup
{
    private readonly int slot;
    private readonly IntConfig winLevelConfig;

    protected UIStepAutoOffer(int slot, IntConfig winLevelConfig)
    {
        this.slot = slot;
        this.winLevelConfig = winLevelConfig;
    }

    protected abstract bool IsOwned();

    public bool ShouldShow()
    {
        var data = GameService.DataManager;
        if (data == null || data.IsOfferAutoShown(slot)) return false;

        // Level is the next level to play, so the level just won is Level - 1.
        if (data.Level - 1 != winLevelConfig.Value) return false;

        return !IsOwned();
    }

    public void Process(ref bool isPause)
    {
        if (!ShouldShow()) return;

        // Marked before showing so a closed or interrupted popup is never re-triggered.
        GameService.DataManager.MarkOfferAutoShown(slot);

        // A missing popup must not pause the pipeline, nothing would resume it.
        isPause = GameService.UIManager.ShowPopup<TPopup>(UITrigger.Auto) != null;
    }

    public void OnShow() { }
}

public class UIStepStarterPack : UIStepAutoOffer<UIPopupStarterPack>
{
    public UIStepStarterPack() : base(0, ConfigCollection.StarterPackAutoShowLv) { }

    protected override bool IsOwned() => CorruptedDesign.IAP.ShopService.IsBoughtBefore(CorruptedDesign.IAP.ProductName.StarterPack);
}

public class UIStepRemoveAds : UIStepAutoOffer<UIPopupRemoveAdsVip>
{
    public UIStepRemoveAds() : base(1, ConfigCollection.RemoveAdsAutoShowLv) { }

    protected override bool IsOwned() => CorruptedDesign.IAP.ShopService.IsNoAds();
}
