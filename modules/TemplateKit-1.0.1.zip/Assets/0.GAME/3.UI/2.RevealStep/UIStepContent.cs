public class UIStepContent : UIRevealStep
{
    /// <summary>Set by the game: returns true when it found newly unlocked content and opened a popup for it.</summary>
    public static System.Func<bool> SearchNewContent { get; set; }

    public bool ShouldShow() => true;

    public void Process(ref bool isPause)
    {
        bool found = SearchNewContent?.Invoke() ?? false;
        if (found) isPause = true;
    }

    public void OnShow()
    {
        
    }
}
