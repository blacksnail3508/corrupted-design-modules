using UnityEngine;

public class UIStepInitGame : UIRevealStep
{
    public bool ShouldShow()
    {
        return true;
    }

    public void OnShow()
    {

    }
}
