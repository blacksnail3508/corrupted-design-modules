using UnityEngine;
using CorruptedDesign.UI;
using TMPro;

public class UIPopupRetry : Popup
{
    public override string PopupType => "popup_core";
    [SerializeField] ButtonBase retryButton, homeButton;
    [SerializeField] private TMP_Text levelText;

    private void Start()
    {
        retryButton.AddListener(OnRetry);
        homeButton.AddListener(OnHome);
    }
    
    public override void Show()
    {
        base.Show();
        levelText.text = $"Level {GameService.DataManager.Level}";
    }

    private void OnHome()
    {
        GameService.GoLobby();
    }

    private void OnRetry()
    {
        GameService.TryStartLevel();
    }
}
