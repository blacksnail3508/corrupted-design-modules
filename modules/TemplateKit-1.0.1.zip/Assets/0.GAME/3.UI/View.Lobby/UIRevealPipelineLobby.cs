using System;
using System.Collections.Generic;

[Serializable]
public class UIRevealPipelineLobby : UIRevealPipeline
{
    private List<UIRevealStep> OpenAppSteps = new()
    {
        // new UIStepFarmPassReclaim(),
        // new UIStepFarmPassIntroduce(),
    };

    // The starter pack steps sit only in the back-home lists: they fire after a win, not on app open.
    private List<UIRevealStep> FirstBackHomeSteps = new()
    {
        // new UIStepFarmPassReclaim(),
        // new UIStepRemoveAds(),
        // new UIStepFarmPassIntroduce(),
        new UIStepStarterPack(),
        new UIStepRemoveAds(),
    };

    private List<UIRevealStep> SequenceNormalSteps = new()
    {
        // new UIStepFarmPassReclaim(),
        // new UIStepRemoveAds(),
        // new UIStepFarmPassIntroduce()
        new UIStepStarterPack(),
        new UIStepRemoveAds(),
    };

    private int refreshTime = 0;

    protected override List<UIRevealStep> GetCurrentOrder()
    {
        Bug.Log($"UIHome AUTO SHOW SEQUENCE: refreshed {refreshTime} times!");
        var result = GetOrder();
        refreshTime++;
        return result;
    }

    private List<UIRevealStep> GetOrder()
    {
        switch (refreshTime)
        {
            case 0:
                if (GameService.DataManager.Level <= 11) return FirstBackHomeSteps;
                return OpenAppSteps;
            case 1:
                if (GameService.DataManager.Level <= 11) return SequenceNormalSteps;
                return FirstBackHomeSteps;
            default:
                return SequenceNormalSteps;
        }
    }
}
