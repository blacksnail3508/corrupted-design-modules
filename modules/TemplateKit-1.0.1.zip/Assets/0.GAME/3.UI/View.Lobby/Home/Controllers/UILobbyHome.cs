using System;
using CorruptedDesign.UI;
using UnityEngine;

public class UILobbyHome : MonoBehaviour
{
    [SerializeField] UILobbyHomeLevelNode[] levelNodes = new UILobbyHomeLevelNode[5];
    public PlayButton PlayButton;

    private void Start()
    {
    }

    private void OnEnable()
    {
        Refresh();
    }

    public void Refresh()
    {
        PlayButton.Refresh();
        foreach (var node in levelNodes)
        {
            node.Init();
        }
    }

    public void OnLoadingComplete()
    {
        // Delay.Call(0.05f, PlayFarmPassKeyCollect);
    }

    private void PlayFarmPassKeyCollect()
    {
        // int keyToCollect = GameService.FarmPassManager.UnseenExp;
        // int clampValue = Mathf.Clamp(keyToCollect, 0, 10);
        // if (keyToCollect > 0)
        // {
        //     GameService.FarmPassManager.MarkExpSeen();
        //     keyAttractor.DoAttract(clampValue);
        // }
    }
}
