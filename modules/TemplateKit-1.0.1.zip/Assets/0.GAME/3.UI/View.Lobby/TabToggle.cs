using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Button))]
public class TabToggle : MonoBehaviour
{
    [SerializeField] private GameObject iconOn;
    [SerializeField] private GameObject iconOff;
    [SerializeField] TabButtonManager tabButtonManager;
    [SerializeField] private float tabIndicator = 0;
    private Button button;

    private void Awake()
    {
        button = GetComponent<Button>();
        button.onClick.AddListener(ScrollToTab);
    }

    private void ScrollToTab()
    {
        tabButtonManager.SetScrollValue(tabIndicator);
    }

    public void SetOn() => Apply(true);

    public void SetOff() => Apply(false);

    // Scaling instead of SetActive: the first selection happens inside a canvas rebuild, where disabling a TMP text logs an error.
    private void Apply(bool on)
    {
        iconOn.transform.localScale = on ? Vector3.one : Vector3.zero;
        iconOff.transform.localScale = on ? Vector3.zero : Vector3.one;
    }
}
