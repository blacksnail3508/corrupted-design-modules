using System.Collections;
using CorruptedDesign.IAP;
using CorruptedDesign.Observer;
using CorruptedDesign.UI;
using TMPro;
using UnityEngine;

/// <summary>A shop pack card: reads its price and rewards from ShopConfig through ShopService and buys on tap.</summary>
public class ShopPackItem : MonoBehaviour
{
    [SerializeField] private ProductName product;
    [SerializeField] private ButtonBase buyButton;
    [SerializeField] private TMP_Text nameText;
    [SerializeField] private TMP_Text priceText;
    [SerializeField] private UIResourceHolder[] rewardSlots;

    private bool listening;

    public ProductName Product => product;

    private void Awake() => buyButton.AddListener(OnBuyClicked);

    private void OnEnable()
    {
        if (!listening)
        {
            EventService.AddListener<NoAdsEvent>(OnNoAds);
            EventService.AddListener<PurchaseCompletedEvent>(OnPurchased);
            listening = true;
        }
        // Started first: Refresh may deactivate the card, which would make StartCoroutine fail.
        StartCoroutine(RefreshWhenReady());
        Refresh();
    }

    private void OnDestroy()
    {
        if (!listening) return;
        EventService.RemoveListener<NoAdsEvent>(OnNoAds);
        EventService.RemoveListener<PurchaseCompletedEvent>(OnPurchased);
    }

    private void OnNoAds(NoAdsEvent e) => Refresh();

    private void OnPurchased(PurchaseCompletedEvent e) => Refresh();

    // The store answers after boot, so the cached price shown first is replaced once it is ready.
    private IEnumerator RefreshWhenReady()
    {
        yield return new WaitUntil(() => ShopService.IsReady);
        Refresh();
    }

    private void Refresh()
    {
        var data = ShopService.GetProductData(product);
        gameObject.SetActive(!(data.GrantsNoAds && ShopService.IsNoAds()) && !ShopService.IsSoldOut(product));
        priceText.text = ShopService.GetPriceString(product);
        if (nameText != null && !string.IsNullOrEmpty(data.DisplayName)) nameText.text = data.DisplayName;

        foreach (var slot in rewardSlots)
        {
            int amount = 0;
            foreach (var reward in data.Rewards)
                if (reward.type == slot.Resource) amount += reward.amount;
            slot.SetActive(amount > 0);
            if (amount > 0) slot.SetValue(amount);
        }
    }

    private void OnBuyClicked()
    {
        buyButton.SetInteract(false);
        ShopService.Buy(product, "shop", success =>
        {
            if (this == null) return;
            buyButton.SetInteract(true);
        });
    }
}
