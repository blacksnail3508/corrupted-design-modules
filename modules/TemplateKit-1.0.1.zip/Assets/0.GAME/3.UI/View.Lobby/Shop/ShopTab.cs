using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UI.Extensions;

/// <summary>The lobby shop tab: a vertical list of pack prefabs that scrolls without stealing the lobby's tab swipe.</summary>
public class ShopTab : MonoBehaviour
{
    [SerializeField] private ScrollRect scrollRect;
    [SerializeField] private ScrollConflictManager conflictManager;
    [SerializeField] private RectTransform content;

    private void Start()
    {
        // Horizontal drags belong to the lobby's page swipe; vertical drags scroll this list.
        var lobbyScroll = transform.parent != null ? transform.parent.GetComponentInParent<ScrollRect>() : null;
        if (lobbyScroll != null) conflictManager.SetParentScrollRect(lobbyScroll);
        LayoutRebuilder.ForceRebuildLayoutImmediate(content);
        scrollRect.verticalNormalizedPosition = 1f;
    }
}
