using CorruptedDesign.IAP;
using CorruptedDesign.Observer;
using CorruptedDesign.UI;
using UnityEngine;

public class RestoreButton : MonoBehaviour
{
    private ButtonBase button;

    private void Awake()
    {
        button = GetComponent<ButtonBase>();
        button.AddListener(OnClick);

#if UNITY_ANDROID
        // Google Play restores owned purchases automatically at init, so only iOS needs the button.
        gameObject.SetActive(false);
#endif
    }

    private void OnEnable()
    {
        RefreshVisibility();
        EventService.AddListener<NoAdsEvent>(OnNoAds);
    }

    private void OnDisable()
    {
        EventService.RemoveListener<NoAdsEvent>(OnNoAds);
    }

    private void OnNoAds(NoAdsEvent e) => RefreshVisibility();

    private void RefreshVisibility()
    {
        // Hide once no-ads is active: there is nothing left to restore.
        gameObject.SetActive(!ShopService.IsNoAds());
    }

    private void OnClick()
    {
        button.SetInteract(false);
        ShopService.RestorePurchases(success =>
        {
            button.SetInteract(true);
            GameService.ShowToast(success ? "Purchases restored." : "Restore failed. Please try again.");
        });
    }
}
