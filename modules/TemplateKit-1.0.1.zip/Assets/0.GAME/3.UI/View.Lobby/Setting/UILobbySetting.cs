using System;
using CorruptedDesign.UI;
using TMPro;
using UnityEngine;

public class UILobbySetting : MonoBehaviour
{
    [SerializeField] private UserDeviceSetting userSetting;
    [SerializeField] TMP_Text versionText;

    private void Start()
    {
        userSetting.Refresh();
        versionText.text = $"Version: {Application.version}";
    }
}
