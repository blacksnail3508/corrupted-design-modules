using System;
using CorruptedDesign.Observer;
using CorruptedDesign.UI;
using UnityEngine;

public class RateUsButton : MonoBehaviour
{
    private ButtonBase button;

    private void Awake()
    {
        button = GetComponent<ButtonBase>();
        button.AddListener(OpenPopupRate);

        EventService.AddListener<RateEvent>(RefreshButton);
    }

    private void Start()
    {
        RefreshButton(null);
    }

    private void OnDestroy()
    {
        EventService.RemoveListener<RateEvent>(RefreshButton);
    }

    private void OpenPopupRate()
    {
        this.ShowPopup<UIPopupRate>(UITrigger.Click);
    }

    private void RefreshButton(GameEvent e)
    {
        bool isRated = GameService.DataManager.IsRated;
        this.gameObject.SetActive(!isRated);
    }
}
