using CorruptedDesign.UI;
using UnityEngine;

public class UserDeviceSetting : MonoBehaviour
{
    [Space(10)]
    public ButtonBase btnMusicOn, btnMusicOff, btnSoundOn, btnSoundOff, btnVibrateOn, btnVibrateOff;
    bool isMusic, isSound, isVibrate;
    private void Start()
    {
        btnMusicOn.AddListener(ClickMusic);
        btnMusicOff.AddListener(ClickMusic);
        
        btnSoundOn.AddListener(ClickSound);
        btnSoundOff.AddListener(ClickSound);
        
        btnVibrateOn.AddListener(ClickVibrate);
        btnVibrateOff.AddListener(ClickVibrate);
    }
    
    public void Refresh()
    {
        isSound = GameService.AudioManager.EnableSfx;
        isMusic = GameService.AudioManager.EnableMusic;
        isVibrate = GameService.AudioManager.EnableVibrate;
        
        btnMusicOn.gameObject.SetActive(isMusic);
        btnMusicOff.gameObject.SetActive(!isMusic);
  
        btnSoundOn.gameObject.SetActive(isSound);
        btnSoundOff.gameObject.SetActive(!isSound);
  
        btnVibrateOn.gameObject.SetActive(isVibrate);
        btnVibrateOff.gameObject.SetActive(!isVibrate);
    }public void ClickSound() 
    {
        isSound = !isSound;
        // SoundManager.Instance.SettingFxSound(isSound ? 1 : 0);
        GameService.AudioManager.EnableSfx = isSound;
        Refresh();
    }

    public void ClickMusic() 
    {
        isMusic = !isMusic;
        GameService.AudioManager.EnableMusic = isMusic;
        // SoundManager.Instance.SettingMusic(isMusic ? 1 : 0);
        Refresh();
    }

    public void ClickVibrate() 
    {
        isVibrate = !isVibrate;
        // SoundManager.Instance.SettingVirbration(isVibrate ? 1 : 0);
        GameService.AudioManager.EnableVibrate = isVibrate;
        Refresh();
    }
}
