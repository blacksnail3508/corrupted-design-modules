using System.Collections;
using DG.Tweening;
using Sirenix.OdinInspector;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIResourceHolder : MonoBehaviour
{
    [SerializeField] private RectTransform rectTransform;

    [SerializeField, OnValueChanged(nameof(Resize))]
    private Vector2 size;
    [SerializeField, OnValueChanged(nameof(ResizeText))]
    private float fontSize;

    [SerializeField] [FoldoutGroup("Sprites")]
    private Sprite coinSprite,
        booster1Sprite,
        booster2Sprite,
        booster3Sprite,
        heartSprite, 
        noadsSprite;
    
    [SerializeField] [FoldoutGroup("REFERENCES")]
    private TMP_Text text;

    [SerializeField] [FoldoutGroup("REFERENCES")]
    private Image image;
    
    [SerializeField] [OnValueChanged(nameof(Refresh))]
    private ItemType resource;

    private int currentValue;

    public ItemType Resource => resource;

    public void SetData(ItemType resource, int value)
    {
        this.resource = resource;
        Refresh();
        SetValue(value);
    }

    public void SetValue(int value)
    {
        currentValue = value;
        if (value == 0) text.gameObject.SetActive(false);
        else text.gameObject.SetActive(true);

        switch (resource)
        {
            case ItemType.RemoveAds:
                text.text = string.Empty; break;
            case ItemType.Coin:
                text.text = $"{value}"; break;
            case ItemType.Booster_1:
            case ItemType.Booster_2:
            case ItemType.Booster_3:
                text.text = $"x{value}"; break;
            case ItemType.InfiniteHeart:
                text.text = $"{value}h"; break;
            default:
                text.text = value.ToString(); break;
        }
    }

    public void SetText(string text)
    {
        this.text.text = $"{text}";
    }

    private void Refresh()
    {
#if UNITY_EDITOR
        gameObject.name = $"RH_{resource}";
        text.gameObject.name = $"RH_{resource}_Text";
        image.gameObject.name = $"RH_{resource}_Image";
#endif

        switch (resource)
        {
            case ItemType.RemoveAds: image.sprite = noadsSprite; break;
            case ItemType.Coin: image.sprite = coinSprite; break;
            case ItemType.Booster_1: image.sprite = booster1Sprite; break;
            case ItemType.Booster_2: image.sprite = booster2Sprite; break;
            case ItemType.Booster_3: image.sprite = booster3Sprite; break;
            case ItemType.Heart:
            case ItemType.InfiniteHeart: image.sprite = heartSprite; break;
            default:
                image.sprite = coinSprite;
                Bug.Log("Sprite not found!");
                break;
        }

    }

    public void SetActive(bool active)
    {
        gameObject.SetActive(active);
    }

    public void Resize(Vector2 sizeDelta)
    {
        image.rectTransform.sizeDelta = sizeDelta;
    }

    public void ResizeText(float _fontSize)
    {
        text.fontSize = _fontSize;
    }

    public void DoChangeValue(int targetValue)
    {
        StartCoroutine(IEChangeText(currentValue, targetValue, 0.75f));
    }
    
    private IEnumerator IEChangeText(int startValue, int endValue, float duration)
    {
        yield return null;
        float t = 0;
        var originalScale = text.transform.localScale;
        int tempvalue;
        while (t < duration)
        {
            float progress = t / duration;
            tempvalue = (int)Mathf.Lerp(startValue, endValue, progress);
            text.text = tempvalue.ToString();
            float scaleFactor = 1f + 0.1f * Mathf.Sin(Mathf.PI * progress);
            text.transform.localScale = originalScale * scaleFactor;
            t += Time.deltaTime;
            yield return null;
        }

        text.transform.localScale = originalScale;
        startValue = endValue;
        text.text = startValue.ToString();
    }

    public void Intro(float delay)
    {
        transform.DOKill();
        transform.localScale = Vector3.zero;
        Delay.Cancel(this);
        Delay.Call(this, delay, () =>
        {
            transform.DOScale(1, 0.25f).SetEase(Ease.OutBack);
        });
    }
}