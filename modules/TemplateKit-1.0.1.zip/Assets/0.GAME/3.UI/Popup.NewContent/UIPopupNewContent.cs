using System;
using CorruptedDesign.UI;
using Sirenix.OdinInspector;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIPopupNewContent : Popup
{
    public override string PopupType => "popup_tutorial";
    [SerializeField] SpriteCollection spriteCollection;
    [SerializeField] TMP_Text contentName, contentDesc;
    [SerializeField] private Image featureIcon;
    [SerializeField, OnValueChanged(nameof(EditorRefresh))]LevelContent currentContent;

    private void EditorRefresh()
    {
        SetContent(currentContent);
    }
    
    public UIPopupNewContent SetContent(LevelContent content)
    {
        currentContent = content;
        var contentData = spriteCollection.GetContentConfig(content);
        if (contentData == null)
        {
            Bug.Log($"SpriteCollection has no ContentConfig for {content}");
            return this;
        }

        featureIcon.sprite = contentData.Icon;
        contentName.text = contentData.ContentName;
        contentDesc.text = contentData.ContentDescription;
        return this;
    }

    public override void Hide(Action onComplete = null)
    {
        GameService.DataManager.SetTutorialWatched(currentContent);
        base.Hide(onComplete);
    }
}
