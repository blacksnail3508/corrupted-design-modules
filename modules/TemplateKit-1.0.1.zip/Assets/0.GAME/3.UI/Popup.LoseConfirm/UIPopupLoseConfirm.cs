using UnityEngine;
using CorruptedDesign.UI;
using TMPro;

public class UIPopupLoseConfirm : Popup
{
    public override string PopupType => "popup_core";
    [SerializeField] TMP_Text levelText;
    [SerializeField] ButtonBase giveUpButton;
    [SerializeField] ButtonBase noButton;
    [SerializeField] ButtonBase closeButton;

    private bool isResolved;

    public override void Initialize()
    {
        base.Initialize();
        giveUpButton.AddListener(OnGiveUp);
        noButton.AddListener(OnKeepPlaying);
        closeButton.AddListener(OnKeepPlaying);
    }

    public override void Show()
    {
        base.Show();
        isResolved = false;
        if (levelText) levelText.text = $"Level {GameService.DataManager.Level}";
    }

    private void OnGiveUp()
    {
        if (isResolved) return;
        isResolved = true;
        AnalyticAdapter.LogLevelLose();
        this.Replace<UIPopupLose>(UITrigger.Click);
    }

    private void OnKeepPlaying()
    {
        if (isResolved) return;
        isResolved = true;
        this.Replace<UIPopupSoftLose>(UITrigger.Click);
    }
}
