
using Coffee.UIExtensions;
using DG.Tweening;
using CorruptedDesign.Audio;
using CorruptedDesign.Feature;
using CorruptedDesign.Observer;
using CorruptedDesign.Remote;
using CorruptedDesign.UI;
using Sirenix.OdinInspector;
using Spine.Unity;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class UIPopupWin : Popup
{
    public override string PopupType => "popup_core";
    private const float DoubleClaimDelay = 2.05f;
    private const float NextClaimDelay = 1.85f;
    private const float AutoClaimDelay = 0.8f;
    private const float PanelShowDuration = 0.35f;
    private const float PanelStartScale = 0.5f;
    private const string TitleIntroAnim = "Start";
    private const string TitleIdleAnim = "Idle";

    [SerializeField] private TMP_Text levelText;
    [SerializeField] private GameObject panel;
    [SerializeField, FoldoutGroup("Buttons")] private ButtonBase nextButton;
    [SerializeField, FoldoutGroup("Buttons")] private ButtonBase claimx2;
    [SerializeField, FoldoutGroup("Buttons")] private TMP_Text claimMultipleTxt;
    [SerializeField, FoldoutGroup("Win Reward")] private UIResourceHolder coinReward;
    [SerializeField, FoldoutGroup("Vfx")] private UIAttractor attractor;
    [SerializeField, FoldoutGroup("Vfx")] private UIParticle fireWork;
    [SerializeField, FoldoutGroup("Vfx")] private UIParticle confetti;
    [SerializeField] private CoinBox coinBox;
    [SerializeField] SkeletonGraphic levelUpTitle;
    private bool isClaimed;
    private bool watchedRewarded;
    private bool autoContinue;
    private int CoinPerWin => GameService.DataManager.CoinPerWin;

    private int RewardedCoinPerWin
    {
        get
        {
            float multiplier = ConfigCollection.RwWinAdConfig.Value
                .GetMultiplier(GameService.DataManager.CurrentDifficulty);
            return Mathf.Max(CoinPerWin, Mathf.RoundToInt(CoinPerWin * multiplier));
        }
    }

    public override void Initialize()
    {
        base.Initialize();
        nextButton.AddListener(OnNextButton);
        claimx2.AddListener(OnClaimDouble);
    }

    public override void Show()
    {
        base.Show();

        isClaimed = false;
        watchedRewarded = false;
        int completedLevel = GameService.DataManager.Level;

        levelText.text = $"Level {completedLevel} Completed";
        coinReward.SetValue(CoinPerWin);
        nextButton.SetText(CoinPerWin.ToString());

        float multiplier = ConfigCollection.RwWinAdConfig.Value.GetMultiplier(GameService.DataManager.CurrentDifficulty);
        claimMultipleTxt.text = $"x{(multiplier)} reward";
        claimx2.SetText(RewardedCoinPerWin.ToString());
        // Every win up to and including the last pre-lobby level rolls straight on; later wins keep the tap flow.
        autoContinue = completedLevel <= GameService.LobbyStartLevel;
        nextButton.gameObject.SetActive(!autoContinue);
        claimx2.gameObject.SetActive(!autoContinue && completedLevel >= ConfigCollection.RwWinAdConfig.Value.StartLv);

        PlayShowSequence();
    }

    public override void ResetData()
    {
        base.ResetData();
        Delay.Cancel(this);
        panel.transform.DOKill();
        if (levelUpTitle.IsValid)
        {
            levelUpTitle.AnimationState.ClearTracks();
        }
    }

    private void OnClaimDouble()
    {
        if (isClaimed)
        {
            return;
        }
        double amount = RewardedCoinPerWin;
        AdsProvider.ShowRewarded(AdsPlacement.WinDoubleCoin, success =>
        {
            if (success)
            {
                watchedRewarded = true;
                ClaimDoubleCoin();
                return;
            }

            GameService.ShowToast("No ads available!");
        });
    }

    private void OnNextButton()
    {
        if (!TryMarkClaimed())
        {
            return;
        }

        PlayCoinReward(CoinPerWin);
        ContinueAfterDelay(NextClaimDelay);
    }

    private void ClaimDoubleCoin()
    {
        if (!TryMarkClaimed())
        {
            return;
        }

        int total = RewardedCoinPerWin;
        coinReward.DoChangeValue(total);
        GameService.DataManager.ClaimCoin(total - CoinPerWin,
            ResourceReason.WatchAds, ResourcePlacement.WinPopup, false);
        PlayCoinReward(total);
        ContinueAfterDelay(DoubleClaimDelay);

    }

    private bool TryMarkClaimed()
    {
        if (isClaimed)
        {
            return false;
        }

        isClaimed = true;
        return true;
    }

    private void PlayCoinReward(int coinReward)
    {
        int coinIconNumber = 10;
        // int coinIconNumber = coinReward / 5 + coinReward / 20;
        GameService.AudioManager.PlaySound(SoundID.CoinAppear);

        attractor.DoAttract(coinIconNumber, () =>
        {
            GameService.AudioManager.PlaySound(SoundID.CoinCollect);
            EventService.Raise(new CoinChange(coinReward));
        });
    }

    private void ContinueAfterDelay(float delay)
    {
        Delay.Call(this, delay, ContinueAfterClaimAnimation);
    }

    private void ContinueAfterClaimAnimation()
    {
        var config = ConfigCollection.InterConfig.Value;
        if (watchedRewarded)
        {
            AdsProvider.ShowInterstitialFromLevel(AdsPlacement.Win, config.AfRwWinStartLv,
                _ => GoNext(), ignoreRwInterval: true);
            return;
        }

        AdsProvider.ShowInterstitialFromLevel(AdsPlacement.Win, config.WinStartLv, _ => GoNext());
    }

    private void GoNext()
    {
        // Level has not been bumped yet, so it is still the one just won.
        UIPopupRate.ShowIfDue(GameService.DataManager.Level, GameService.NextLevel);
    }

    private void PlayShowSequence()
    {
        panel.transform.DOKill();
        panel.SetActive(false);
        fireWork.Clear();
        fireWork.Play();
        GameService.AudioManager.PlaySound(SoundID.FireWork);
        GameService.AudioManager.PlaySound(SoundID.Win);

        PlayTitleIntro();
    }

    private void PlayTitleIntro()
    {
        levelUpTitle.gameObject.SetActive(true);
        levelUpTitle.PlayAnimation(TitleIntroAnim, () =>
        {
            levelUpTitle.PlayAnimation(TitleIdleAnim);
            ShowPanel();
        });
    }

    private void ShowPanel()
    {
        Transform panelTransform = panel.transform;
        panelTransform.localScale = Vector3.one * PanelStartScale;
        panel.SetActive(true);
        panelTransform.DOScale(Vector3.one, PanelShowDuration)
            .SetEase(Ease.OutBack)
            .OnComplete(() =>
            {
                PlayConfetti();
                if (autoContinue) Delay.Call(this, AutoClaimDelay, OnNextButton);
            });
    }

    private void PlayConfetti()
    {
        confetti.gameObject.SetActive(true);
        confetti.Clear();
        confetti.Play();

        var ps = confetti.GetComponentInChildren<ParticleSystem>();
        float duration = 1f;
        if (ps != null)
        {
            var main = ps.main;
            duration = main.duration + main.startLifetime.constantMax;
        }

        Delay.Call(duration, () =>
        {
            if (confetti) confetti.gameObject.SetActive(false);
        });
    }

    public void ForceSetCoin(int coinBeforeReward)
    {
        coinBox.ForceSetValue(coinBeforeReward);
    }
}
