using System;
using CorruptedDesign.UI;
using Sirenix.OdinInspector;
using Spine.Unity;
using UnityEngine;

public class UIResourceChest : MonoBehaviour
{
    [SerializeField, FoldoutGroup("Visual")] SkeletonGraphic chestSpine;
    [SerializeField, FoldoutGroup("Visual"), SpineSkin(dataField: "chestSpine")]
    string chest0, chest1, chest3, chest4, chest5, chest6;
    [SerializeField, FoldoutGroup("Visual"), SpineAnimation(dataField: "chestSpine")]
    string closeIdleAnim, openAnim, openIdleAnim;
    [SerializeField] UIRewardHolder rewardHolder;
    [SerializeField] private ButtonBase showButton;
    [SerializeField] UIShowForSecond showForSecond;

    private void Start()
    {
        showButton.AddListener(OnClick);
    }

    private void OnClick()
    {
        showForSecond.ShowFor(2.5f);
    }

    public void OpenChest(Action onStart = null, Action onEnd = null)
    {
        onStart?.Invoke();
        chestSpine.PlayAnimation(openAnim, () =>
        {
            chestSpine.PlayAnimation(openIdleAnim);
            onEnd?.Invoke();
        });
    }

    public void OpenChestImmediate()
    {
        chestSpine.SetAnimation(openIdleAnim);
    }

    public void SetClosedIdle()
    {
        chestSpine.SetAnimation(closeIdleAnim);
    }

    public void SetContent(RewardSlot[] values)
    {
        rewardHolder.SetData(values);    
    }
    
    public void SetChestVisual(int chestSprite)
    {
        switch (chestSprite)
        {
            case 0: chestSpine.SetSkin(chest0); break;
            case 1: chestSpine.SetSkin(chest1); break;
            case 2: chestSpine.SetSkin(chest3); break;
            case 3: chestSpine.SetSkin(chest4); break;
            case 4: chestSpine.SetSkin(chest5); break;
            case 5: chestSpine.SetSkin(chest6); break;
        }
    }
}
