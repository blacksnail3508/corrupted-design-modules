using CorruptedDesign.UI;

public class CloseButton : ButtonBase
{
    protected override void OnClick()
    {
        base.OnClick();
        CloseCurrentPopup();
    }

    public void CloseCurrentPopup()
    {
        GameService.UIManager.ClosePopup();
    }
}
