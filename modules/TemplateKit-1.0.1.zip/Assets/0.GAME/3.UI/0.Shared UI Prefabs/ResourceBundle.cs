using System;
using UnityEngine;

[Serializable]
public class ResourceBundle
{
    public int Coin;
    public int Booster1;
    public int Booster2;
    public int Booster3;
    public int Heart;

    public void Add(RewardSlot[] rawData)
    {
        //TODO
    }
}
