using System;
using System.Collections.Generic;
using DG.Tweening;
using CorruptedDesign.Audio;
using CorruptedDesign.Data;
using CorruptedDesign.Observer;
using UnityEngine;
using UnityEngine.UI;

public class DynamicRewardLayout : MonoBehaviour
{
    [SerializeField] private List<UIResourceHolder> Small1, Small2, LineBig;
    [SerializeField] private GameObject BigLayout, SmallLayout;
    [SerializeField] private RectTransform RootLayout;
    [SerializeField] private UIAttractor coinAttractor;

    /// <summary>
    /// Core method
    /// </summary>
    public DynamicRewardLayout SetValue(List<RewardSlot> rewardSlots)
    {
        //scan for 0 value
        rewardSlots.RemoveAll(x => x.RewardValue == 0);

        if (rewardSlots.Count <= 3)
            SetLayoutBig(rewardSlots);
        else
            SetLayoutSmall(rewardSlots);

        LayoutRebuilder.ForceRebuildLayoutImmediate(RootLayout);
        return this;
    }

    public DynamicRewardLayout SetSingleValue(ItemType resource, int value)
    {
        SetValue(new List<RewardSlot> { new(resource, value) });
        return this;
    }

    public DynamicRewardLayout SetValue(ResourceBundle reward)
    {
        var rewardSlots = new List<RewardSlot>();

        if (reward.Coin != 0) rewardSlots.Add(new RewardSlot(ItemType.Coin, reward.Coin));
        if (reward.Booster1 != 0) rewardSlots.Add(new RewardSlot(ItemType.Booster_1, reward.Booster1));
        if (reward.Booster2 != 0) rewardSlots.Add(new RewardSlot(ItemType.Booster_2, reward.Booster2));
        if (reward.Booster3 != 0) rewardSlots.Add(new RewardSlot(ItemType.Booster_3, reward.Booster3));
        if (reward.Heart != 0) rewardSlots.Add(new RewardSlot(ItemType.Heart, reward.Heart));

        return SetValue(rewardSlots);
    }

    #region Less Layout

    private void SetLayoutBig(List<RewardSlot> rewards)
    {
        //set root object
        BigLayout.SetActive(true);
        SmallLayout.SetActive(false);

        //off all slot in big line
        foreach (var slot in LineBig) slot.gameObject.SetActive(false);

        for (var i = 0; i < rewards.Count; i++)
        {
            var slot = LineBig[i];
            var reward = rewards[i];

            ShowSlot(slot, reward.RewardType, reward.RewardValue, 0.2f + 0.1f * i);
        }
    }

    #endregion

    #region Multiple Layout

    private void SetLayoutSmall(List<RewardSlot> rewards)
    {
        //set root object
        BigLayout.SetActive(false);
        SmallLayout.SetActive(true);

        //off all slot in lines
        foreach (var slot in Small1) slot.gameObject.SetActive(false);
        foreach (var slot in Small2) slot.gameObject.SetActive(false);

        //prepare slots
        var slots = GetResourceHolder(rewards.Count);

        for (var i = 0; i < rewards.Count; i++)
        {
            var slot = slots[i];
            ShowSlot(slot, rewards[i].RewardType, rewards[i].RewardValue, 0.2f + 0.1f * i);
        }
    }

    private List<UIResourceHolder> GetResourceHolder(int slotNeeded)
    {
        var result = new List<UIResourceHolder>();

        switch (slotNeeded)
        {
            case 4: return GetResourceHolder(4, 0);
            case 5: return GetResourceHolder(3, 2);
            case 6: return GetResourceHolder(4, 2);
            case 7: return GetResourceHolder(4, 3);
            case 8: return GetResourceHolder(4, 4);
        }

        return result;
    }

    private List<UIResourceHolder> GetResourceHolder(int fromSmall1, int fromSmall2)
    {
        var result = new List<UIResourceHolder>();

        for (var i = 0; i < fromSmall1 && i < Small1.Count; i++)
            result.Add(Small1[i]);

        for (var i = 0; i < fromSmall2 && i < Small2.Count; i++)
            result.Add(Small2[i]);

        return result;
    }

    #endregion

    private void ShowSlot(UIResourceHolder slot, ItemType resource, int value, float delay)
    {
        slot.transform.localScale = Vector3.zero;
        slot.SetData(resource, value);
        slot.SetActive(true);
        slot.transform.DOScale(1, 0.25f)
            .SetEase(Ease.OutBack)
            .SetDelay(delay)
            .OnComplete(() =>
            {
                if (resource == ItemType.Coin)
                {
                    GameService.AudioManager.PlaySound(SoundID.CoinCollect);
                    coinAttractor?.DoAttract(() =>
                    {
                        GameService.AudioManager.PlaySound(SoundID.CoinCollect);
                        EventService.Raise(new CoinChange(value));
                    });
                    return;
                }

                // if (resource == ItemType.Booster_1 || resource == ItemType.Booster_2 || resource == ItemType.Booster_3)
                // {
                //     GameService.AudioManager.PlaySound(SoundID.PopBooster);
                // }
            });
    }
}

[Serializable]
public class RewardSlot
{
    public ItemType RewardType;
    public int RewardValue;

    public RewardSlot(ItemType rewardType, int rewardValue)
    {
        RewardType = rewardType;
        RewardValue = rewardValue;
    }
}