using DG.Tweening;
using Sirenix.OdinInspector;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

[RequireComponent(typeof(Button))]
public class FullScreenButton : MonoBehaviour
{
    [SerializeField, FoldoutGroup("References")] private Button button;
    [SerializeField, FoldoutGroup("References")] private Transform scaler;
    [SerializeField, FoldoutGroup("Config")] private float showDuration = 0.25f;

    public Button Button => button != null ? button : button = GetComponent<Button>();

    private Transform Scaler => scaler != null ? scaler : scaler = transform;

    private void Reset()
    {
        button = GetComponent<Button>();
        scaler = transform;
    }

    public void AddListener(UnityAction action)
    {
        Button.onClick.AddListener(action);
    }

    public void RemoveListener(UnityAction action)
    {
        Button.onClick.RemoveListener(action);
    }

    public void Show()
    {
        KillTween();
        Scaler.localScale = Vector3.zero;
        gameObject.SetActive(true);
        SetInteractable(true);
        Scaler.DOScale(Vector3.one, showDuration).SetEase(Ease.OutBack).SetUpdate(true);
    }

    public void Hide()
    {
        KillTween();
        Scaler.localScale = Vector3.zero;
        SetInteractable(false);
        gameObject.SetActive(false);
    }

    public void SetInteractable(bool value)
    {
        if (Button != null) Button.interactable = value;
    }

    private void KillTween()
    {
        Scaler.DOKill();
    }

    private void OnDisable()
    {
        KillTween();
    }
}
