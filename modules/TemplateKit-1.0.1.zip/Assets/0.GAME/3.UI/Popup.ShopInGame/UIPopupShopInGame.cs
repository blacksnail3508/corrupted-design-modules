using System;
using CorruptedDesign.UI;

public class UIPopupShopInGame : Popup
{
    // private IapTracker tracker => ServiceManager.I.Get<GameProgressTracker>().iapTracker;
    public override string PopupType => $"popup_shop";
    private string placement = "ingame_shop";
    private string showType = "popup";
    private string packageName = "null";

    public override void Show()
    {
        base.Show();
        // tracker.TrackIAPShow(packageName, placement, showType, LastTrigger.ToString());
    }
    
    public override void Hide(Action onComplete = null)
    {
        base.Hide(onComplete);
        // tracker.TrackIAPClose(packageName, placement, showType, LastTrigger.ToString());
    }
}
