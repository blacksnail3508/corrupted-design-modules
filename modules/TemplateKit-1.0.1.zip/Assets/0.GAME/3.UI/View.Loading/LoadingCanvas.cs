using DG.Tweening;
using CorruptedDesign.Observer;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class LoadingCanvas : MonoBehaviour
{
    public static bool IsShowing { get; private set; }

    private int minSliderValue = 15;
    [SerializeField] private Slider loadingSlider;
    [SerializeField] TMP_Text loadingText;
    private void Awake()
    {
        IsShowing = true;
        DontDestroyOnLoad(gameObject);
        EventService.AddListener<LoadingProgressEvent>(OnLoadingProgressEvent);
        loadingSlider.value = minSliderValue;
    }

    private void OnDestroy()
    {
        IsShowing = false;
        EventService.RemoveListener<LoadingProgressEvent>(OnLoadingProgressEvent);
    }

    private void OnLoadingProgressEvent(LoadingProgressEvent e)
    {
        float loadingProgress = e.progress;
        
        if (loadingProgress is > 0 and < 100) Show();
        else HideAfter(1.25f);

        DoSliderValue(loadingProgress);
        loadingText.text = e.message;
    }

    private void DoSliderValue(float sliderValue)
    {
        float value = Mathf.Max(minSliderValue, sliderValue);
        
        loadingSlider?.DOKill();
        loadingSlider?.DOValue(value, 0.5f).SetEase(Ease.Linear);
    }

    private void Show()
    {
        IsShowing = true;
        this.gameObject.SetActive(true);
    }

    private void Hide()
    {
        IsShowing = false;
        this.gameObject.SetActive(false);
        loadingSlider.value = minSliderValue;
        EventService.Raise(new LoadingCompleteEvent());
    }

    private void HideAfter(float after = 0)
    {
        Invoke(nameof(Hide), after);
    }
}

public class LoadingCompleteEvent : GameEvent {}

