using System;
using CorruptedDesign.Audio;
using CorruptedDesign.Stamina;
using CorruptedDesign.UI;
using TMPro;
using UnityEngine;

public class HeartBox : MonoBehaviour
{
    [SerializeField] private GameObject noneInfinite;
    [SerializeField] private GameObject infinite;
    
    [SerializeField] private ButtonBase addButton;
    [SerializeField] private TMP_Text heartValue;
    [SerializeField]  private TMP_Text refillTime;
    [SerializeField] TMP_Text infiniteTime;
    
    private void Start()
    {
        if (StaminaManager.Instance == null)
        {
            this.gameObject.SetActive(false);
            return;
        }
        
        heartValue.text = $"{StaminaManager.CurrentStamina}";
        refillTime.text = StaminaManager.RecoverTimeRemainingString;
        addButton?.AddListener(OnAddClicked);
    }

    private void OnEnable()
    {
        Refresh();
        Clock.CallPerSecond += Refresh;
    }

    private void OnDisable()
    {
        Clock.CallPerSecond -= Refresh;
    }

    private void OnAddClicked()
    {
        if (StaminaManager.IsFull == false)
        {
            GameService.ShowPopup<UIPopupBuyHeart>(UITrigger.Click);
        }
        else
        {
            GameService.ShowToast("Heart is full!");
        }
    }

    private void Refresh()
    {
        if (!gameObject.activeInHierarchy) return; 
        noneInfinite.SetActive(StaminaManager.InfiniteTimeRemaining <= 0);
        infinite.SetActive(StaminaManager.InfiniteTimeRemaining > 0);
        
        heartValue.text = $"{StaminaManager.CurrentStamina}";
        refillTime.text = StaminaManager.RecoverTimeRemainingString;

        infiniteTime.text = StaminaManager.InfiniteTimeRemainingString;
    }
}
