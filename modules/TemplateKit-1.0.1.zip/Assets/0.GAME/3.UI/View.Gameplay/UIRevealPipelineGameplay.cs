using System;
using System.Collections.Generic;

[Serializable]
public class UIRevealPipelineGameplay : UIRevealPipeline
{
    private List<UIRevealStep> Steps = new()
    {
        // new UIStepRemoveAds(),
        // new UIStepStarterPack(),
        new UIStepContent(),
    };

    protected override List<UIRevealStep> GetCurrentOrder() => Steps;
}
