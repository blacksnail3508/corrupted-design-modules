using CorruptedDesign.Remote;
using CorruptedDesign.Stamina;
using CorruptedDesign.UI;

public class ReplayButton : ButtonBase
{
    protected override void OnClick()
    {
        base.OnClick();

        if (StaminaManager.Instance == null)
        {
            Replay();
            return;
        }

        // Same gate as the pause popup's replay: no heart means the buy-heart popup, not a free restart.
        if (!StaminaManager.HaveStamina())
        {
            GameService.UIManager.ShowPopup<UIPopupBuyHeart>(UITrigger.Click);
            return;
        }

        StaminaManager.SpendStamina(1, Replay);
    }

    private static void Replay()
    {
        AnalyticAdapter.LogLevelAbandoned();
        AdsProvider.ShowInterstitialFromLevel(AdsPlacement.Setting,
            ConfigCollection.InterConfig.Value.SettingStartLv, _ => GameService.ForceReload());
    }
}
