using Sirenix.OdinInspector;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIGameplayLevelBox : MonoBehaviour
{
    [SerializeField, InlineEditor] SpriteCollection spriteCollection;
    [SerializeField] private Image boxImage;
    [SerializeField] private TMP_Text levelText, levelRawText;
    
    public void Refresh()
    {
        levelText.text = $"Level {GameService.DataManager.Level}";
        levelRawText.text = $"Level_{GameService.DataManager.LevelSystem.GetLevelLooped(GameService.DataManager.Level)}.json";

        // var dif = GameService.DataManager.CurrentLevelData.Difficulty;
        // boxImage.sprite = spriteCollection.GetLevelBoxSprite(dif);
    }
}
