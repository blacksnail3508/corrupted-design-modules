using CorruptedDesign.UI;
using UnityEngine;

public class PauseButton : ButtonBase
{
    protected override void OnClick()
    {
        base.OnClick();
        GameService.ShowPopup<UIPopupSetting>(UITrigger.Auto);
        GameService.GameController?.Pause();
    }
}
