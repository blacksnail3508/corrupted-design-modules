
#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.UI;
#endif
using System.Collections;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class HoldableButton : Button
{
    [SerializeField] private UnityEvent startHold;
    [SerializeField] private UnityEvent endHold;
    [SerializeField] private UnityEvent holdComplete;

    [SerializeField] private float holdSeconds = 3f;

    // Optional external references
    [Header("Optional References")]
    [SerializeField] private Text targetLabel;
    [SerializeField] private AudioSource buttonSound;
    [SerializeField] private GameObject highlightEffect;

    private Coroutine holdRoutine;

    public override void OnPointerDown(PointerEventData eventData)
    {
        base.OnPointerDown(eventData);
        StartHold();
    }

    public override void OnPointerUp(PointerEventData eventData)
    {
        base.OnPointerUp(eventData);
        EndHold();
    }

    public virtual void StartHold()
    {
        startHold?.Invoke();
        if (targetLabel) targetLabel.text = "Holding...";
        if (buttonSound) buttonSound.Play();
        if (highlightEffect) highlightEffect.SetActive(true);

        if (holdRoutine != null) StopCoroutine(holdRoutine);
        holdRoutine = StartCoroutine(HoldRoutine());
    }

    public virtual void EndHold()
    {
        endHold?.Invoke();
        if (targetLabel) targetLabel.text = "Released";
        if (highlightEffect) highlightEffect.SetActive(false);

        if (holdRoutine != null)
        {
            StopCoroutine(holdRoutine);
            holdRoutine = null;
        }
    }

    protected virtual void HoldComplete()
    {
        holdComplete?.Invoke();
    }

    private IEnumerator HoldRoutine()
    {
        float start = Time.realtimeSinceStartup;
        while (Time.realtimeSinceStartup - start < holdSeconds)
        {
            yield return null;
        }

        holdRoutine = null;
        HoldComplete();
    }
}
#if UNITY_EDITOR
[CustomEditor(typeof(HoldableButton))]
public class HoldableButtonEditor : ButtonEditor
{
    SerializedProperty startHold;
    SerializedProperty endHold;
    SerializedProperty holdComplete;
    SerializedProperty holdSeconds;

    protected override void OnEnable()
    {
        base.OnEnable();
        startHold = serializedObject.FindProperty("startHold");
        endHold = serializedObject.FindProperty("endHold");
        holdComplete = serializedObject.FindProperty("holdComplete");
        holdSeconds = serializedObject.FindProperty("holdSeconds");
    }

    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();
        serializedObject.Update();

        EditorGUILayout.PropertyField(startHold);
        EditorGUILayout.PropertyField(endHold);
        EditorGUILayout.PropertyField(holdComplete);
        EditorGUILayout.PropertyField(holdSeconds);

        serializedObject.ApplyModifiedProperties();
    }
}
#endif
