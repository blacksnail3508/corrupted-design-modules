using DG.Tweening;
using Sirenix.OdinInspector;
using UnityEngine;
using UnityEngine.Serialization;

public class UIVerticalMovement : MonoBehaviour
{
    [FormerlySerializedAs("root")] [SerializeField] RectTransform MoveItem;
    [SerializeField] private float ShowPosition;
    [SerializeField] private float HidePosition;
    [SerializeField] private float AnimationTime = 0.25f;

    public bool IsShowing { get; private set; }

    public void SetShowPosition(float position)
    {
        ShowPosition = position;
    }

    public void Show()
    {
        IsShowing = true;
        MoveItem.DOKill();
        MoveItem.DOAnchorPosY(ShowPosition, AnimationTime).SetEase(Ease.OutBack).SetUpdate(true).SetLink(MoveItem.gameObject, LinkBehaviour.KillOnDisable).SetLink(MoveItem.gameObject, LinkBehaviour.KillOnDestroy);
    }

    public void Show(float duration)
    {
        if (duration <= 0)
        {
            ShowNow();
            return;
        }
        
        IsShowing = true;
        MoveItem.DOKill();
        MoveItem.DOAnchorPosY(ShowPosition, duration).SetEase(Ease.OutBack).SetUpdate(true).SetLink(MoveItem.gameObject, LinkBehaviour.KillOnDisable).SetLink(MoveItem.gameObject, LinkBehaviour.KillOnDestroy);
    }

    [Button]
    void ShowNow()
    {
        IsShowing = true;
        MoveItem.DOKill();
        MoveItem.anchoredPosition = new Vector3(MoveItem.localPosition.x, ShowPosition, MoveItem.localPosition.z);
    }

    public void Hide()
    {
        IsShowing = false;
        MoveItem.DOKill();
        MoveItem.DOAnchorPosY(HidePosition, AnimationTime).SetUpdate(true).SetLink(MoveItem.gameObject, LinkBehaviour.KillOnDisable).SetLink(MoveItem.gameObject, LinkBehaviour.KillOnDestroy);;
    }

    public void Hide(float duration)
    {
        if (duration <= 0)
        {
            HideNow();
            return;
        }
        
        IsShowing = false;
        MoveItem.DOKill();
        MoveItem.DOAnchorPosY(HidePosition, duration).SetUpdate(true).SetLink(MoveItem.gameObject, LinkBehaviour.KillOnDisable).SetLink(MoveItem.gameObject, LinkBehaviour.KillOnDestroy);;
    }

    [Button]
    void HideNow()
    {
        IsShowing = false;
        MoveItem.DOKill();
        MoveItem.anchoredPosition = new Vector3(MoveItem.localPosition.x, HidePosition, MoveItem.localPosition.z);
    }
}
