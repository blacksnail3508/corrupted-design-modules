using System;
using System.Collections;
using System.Collections.Generic;
using Sirenix.Utilities;
using Spine;
using Spine.Unity;
using UnityEngine;
using AnimationState = Spine.AnimationState;

public static class SpineUtils
{
    public static void SetSkin(this SkeletonAnimation skeleton, string newSkin)
    {
        if (skeleton == null) return;

        Skin skin = skeleton.Skeleton.Data.FindSkin(newSkin);
        if (skin == null)
        {
            Debug.LogWarning($"Skin '{newSkin}' not found in skeleton data.");
            return;
        }

        skeleton.Skeleton.SetSkin(skin);
        skeleton.Skeleton.SetSlotsToSetupPose();
        skeleton.AnimationState.Apply(skeleton.Skeleton);
    }

    public static TrackEntry SetAnimation(this SkeletonAnimation skeleton, string animationName, bool loop = true)
    {
        if (skeleton == null)
        {
            Debug.LogWarning("SetAnimation: SkeletonAnimation is null.");
            return null;
        }

        var skeletonData = skeleton.Skeleton.Data;
        if (skeletonData == null)
        {
            Debug.LogWarning("SetAnimation: Skeleton data is missing.");
            return null;
        }

        var animation = skeletonData.FindAnimation(animationName);
        if (animation == null)
        {
            Debug.LogWarning($"SetAnimation: Animation '{animationName}' not found in skeleton data.");
            return null;
        }

        return skeleton.AnimationState.SetAnimation(0, animationName, loop);
    }

    public static TrackEntry AddAnimation(this SkeletonAnimation skeleton, string animationName, bool loop = true, float delay = 0)
    {
        if (skeleton == null)
        {
            Debug.LogWarning("AddAnimation: SkeletonAnimation is null.");
            return null;
        }

        var skeletonData = skeleton.Skeleton.Data;
        if (skeletonData == null)
        {
            Debug.LogWarning("AddAnimation: Skeleton data is missing.");
            return null;
        }

        var animation = skeletonData.FindAnimation(animationName);
        if (animation == null)
        {
            Debug.LogWarning($"AddAnimation: Animation '{animationName}' not found in skeleton data.");
            return null;
        }

        return skeleton.AnimationState.AddAnimation(0, animationName, loop, delay);
    }

    public static void PlayAnimation(this SkeletonAnimation skeleton, string entryAnim, Action onComplete = null)
    {
        TrackEntry entry = skeleton.SetAnimation(entryAnim, false);
        if (entry == null) return;

        AnimationState.TrackEntryDelegate handler = null;
        handler = delegate(TrackEntry trackEntry)
        {
            onComplete?.Invoke();
            trackEntry.Complete -= handler;
        };

        entry.Complete += handler;
    }

    public static void PlayAnimation(this SkeletonAnimation skeleton, string entryAnim)
    {
        skeleton.SetAnimation(entryAnim, true);
    }

    public static void SetSkin(this SkeletonGraphic skeleton, string newSkin)
    {
        if (skeleton == null) return;

        // Will throw if the skin name doesn't exist, so guard it:
        Skin skin = skeleton.Skeleton.Data.FindSkin(newSkin);
        if (skin == null)
        {
            Debug.LogWarning($"Skin '{newSkin}' not found in skeleton data.");
            return;
        }

        skeleton.Skeleton.SetSkin(skin);
        skeleton.Skeleton.SetSlotsToSetupPose(); // refresh attachments to new skin

        // Re-apply current animation pose and update the mesh
        skeleton.AnimationState.Apply(skeleton.Skeleton);
        skeleton.UpdateMesh();
    }
    
    public static void SetAnimation(this SkeletonGraphic skeleton, string animationName, bool loop = true)
    {
        if (skeleton == null)
        {
            Debug.LogWarning("SetAnimation: SkeletonGraphic is null.");
            return;
        }

        var skeletonData = skeleton.Skeleton.Data;
        if (skeletonData == null)
        {
            Debug.LogWarning("SetAnimation: Skeleton data is missing.");
            return;
        }

        var animation = skeletonData.FindAnimation(animationName);
        if (animation == null)
        {
            Debug.LogWarning($"SetAnimation: Animation '{animationName}' not found in skeleton data.");
            return;
        }

        skeleton.AnimationState.SetAnimation(0, animationName, loop);
        skeleton.UpdateMesh();

        Debug.Log($"SetAnimation: Animation '{animationName}' applied with loop={loop}.");
    }

    public static void PlayAnimation(this SkeletonGraphic skeleton,string entryAnim, Action onComplete = null)
    {
        TrackEntry entry = skeleton.AnimationState.SetAnimation(0, entryAnim, false);
        
        AnimationState.TrackEntryDelegate handler = null;
        handler = delegate (TrackEntry trackEntry)
        {
            onComplete?.Invoke();
            trackEntry.Complete -= handler; // Unsubscribe safely
        };

        entry.Complete += handler;
    }
    public static void PlayAnimation(this SkeletonGraphic skeleton,string entryAnim)
    {
        TrackEntry entry = skeleton.AnimationState.SetAnimation(0, entryAnim, true);
    }
}
