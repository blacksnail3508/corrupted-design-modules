#if UNITY_EDITOR
using UnityEditor;
#endif
using System.Collections;
using UnityEngine;

public class HoldToTransparent : HoldableButton
{
    [SerializeField] private CanvasGroup targetCanvasGroup;
    [SerializeField] private float fadeDuration = 0.25f;

    private Coroutine fadeRoutine;

    public override void StartHold()
    {
        base.StartHold();
        StartFade(0f);
    }

    public override void EndHold()
    {
        base.EndHold();
        StartFade(1f);
    }

    private void StartFade(float targetAlpha)
    {
        if (!targetCanvasGroup) return;
        if (fadeRoutine != null) StopCoroutine(fadeRoutine);
        fadeRoutine = StartCoroutine(FadeRoutine(targetAlpha));
    }

    private IEnumerator FadeRoutine(float targetAlpha)
    {
        float startAlpha = targetCanvasGroup.alpha;
        float elapsed = 0f;
        while (elapsed < fadeDuration)
        {
            elapsed += Time.unscaledDeltaTime;
            targetCanvasGroup.alpha = Mathf.Lerp(startAlpha, targetAlpha, elapsed / fadeDuration);
            yield return null;
        }

        targetCanvasGroup.alpha = targetAlpha;
        fadeRoutine = null;
    }
}
#if UNITY_EDITOR
[CustomEditor(typeof(HoldToTransparent))]
public class HoldToTransparentEditor : HoldableButtonEditor
{
    SerializedProperty targetCanvasGroup;
    SerializedProperty fadeDuration;

    protected override void OnEnable()
    {
        base.OnEnable();
        targetCanvasGroup = serializedObject.FindProperty("targetCanvasGroup");
        fadeDuration = serializedObject.FindProperty("fadeDuration");
    }

    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();
        serializedObject.Update();

        EditorGUILayout.PropertyField(targetCanvasGroup);
        EditorGUILayout.PropertyField(fadeDuration);

        serializedObject.ApplyModifiedProperties();
    }
}
#endif
