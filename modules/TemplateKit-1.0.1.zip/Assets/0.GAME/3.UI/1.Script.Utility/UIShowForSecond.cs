using DG.Tweening;
using UnityEngine;

public class UIShowForSecond : MonoBehaviour
{
    public void ShowFor(float second)
    {
        this.transform.DOKill();
        
        this.transform.localScale = Vector3.zero;
        this.gameObject.SetActive(true);
        this.transform.DOScale(1, 0.15f).SetEase(Ease.OutBack);
        
        this.transform.DOScale(0, 0.15f).SetEase(Ease.InBack).SetDelay(second).OnComplete(() =>
        {
            this.gameObject.SetActive(false);
        });
    }

    public void ForceHide()
    {
        this.transform.DOKill();
        this.gameObject.SetActive(false);
    }
}
