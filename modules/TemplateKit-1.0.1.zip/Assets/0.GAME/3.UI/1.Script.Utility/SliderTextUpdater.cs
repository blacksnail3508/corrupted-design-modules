using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SliderTextUpdater : MonoBehaviour
{
    [SerializeField] Slider slider;
    [SerializeField] TMP_Text text;

    public void UpdateText(float currentValue)
    {
        text.text = $"{slider.normalizedValue * 100f:0.0}%";
    }
}
