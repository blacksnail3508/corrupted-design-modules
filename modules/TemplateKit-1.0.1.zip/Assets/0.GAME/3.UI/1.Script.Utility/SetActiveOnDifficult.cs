using System;
using System.Collections.Generic;
using CorruptedDesign.Observer;
using CorruptedDesignTemplate;
using UnityEngine;

public class SetActiveOnDifficult : MonoBehaviour
{
    [SerializeField] private List<ActiveOnDifficult> entries = new();

    private void Awake()
    {
        EventService.AddListener<LoadingCompleteEvent>(OnLoadingComplete);
        Refresh();
    }

    private void OnDestroy()
    {
        EventService.RemoveListener<LoadingCompleteEvent>(OnLoadingComplete);
    }

    private void OnLoadingComplete(LoadingCompleteEvent e) { Refresh(); }

    public void Refresh()
    {
        var current = GameService.DataManager.CurrentDifficulty;

        foreach (var entry in entries)
        {
            if (entry.target == null) continue;
            entry.target.SetActive(entry.ActiveOn.Contains(current));
        }
    }
}

[Serializable]
public class ActiveOnDifficult
{
    public GameObject target;
    public DifficultyMask ActiveOn = DifficultyMask.All;
}
