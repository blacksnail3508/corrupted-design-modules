using TMPro;
using UnityEngine;

public class LevelBox : MonoBehaviour
{
    [SerializeField] TMP_Text levelText;
    private void OnEnable()
    {
        levelText.text = $"Level {GameService.DataManager.Level}";
    }
}
