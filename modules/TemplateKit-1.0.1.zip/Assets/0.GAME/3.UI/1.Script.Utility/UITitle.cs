using System;
using Sirenix.OdinInspector;
using Spine.Unity;
using UnityEngine;
using UnityEngine.UI;

public class UITitle : MonoBehaviour
{
    const string AnimWinStart = "win/apear_win";
    const string AnimWinIdle = "win/idle_win";
    const string AnimLoseStart = "lose/apear_lose";
    const string AnimLoseIdle = "lose/idle_lose";
    
    [FoldoutGroup("SPINE")] [SerializeField] SkeletonGraphic mascot;

    [FoldoutGroup("Ribbon Sprites")] [SerializeField]
    private Sprite ribbonBlue, ribbonGray, ribbonPurple, pinkCurvy;
    
    [FoldoutGroup("References")][SerializeField] private Image ribbon;

    [OnValueChanged(nameof(Refresh))] [SerializeField] DecorType DecorType;
    [OnValueChanged(nameof(Refresh))] [SerializeField] RibbonColor RibbonColor;


    private void OnEnable()
    {
        Refresh();
        
        //select mascot
        switch (DecorType)
        {
            case DecorType.Happy:
                mascot.PlayAnimation(AnimWinStart, () =>
                {
                    mascot.PlayAnimation(AnimWinIdle);
                });
                break;
            case DecorType.Sad:
                mascot.PlayAnimation(AnimLoseStart, () =>
                {
                    mascot.PlayAnimation(AnimLoseIdle);
                });
                break;
            default:
                throw new ArgumentOutOfRangeException();
        }
    }

    private void Refresh()
    {
        switch (DecorType)
        {
            case DecorType.Happy:
                mascot.SetSkin("win");
                break;
            case DecorType.Sad:
                mascot.SetSkin("lose");
                break;
        }

        switch (RibbonColor)
        {
            case RibbonColor.Gray: ribbon.sprite = ribbonGray; break;
            case RibbonColor.Blue:  ribbon.sprite = ribbonBlue; break; 
            case RibbonColor.Purple:  ribbon.sprite = ribbonPurple; break; 
            case RibbonColor.PinkCurvy : ribbon.sprite = pinkCurvy; break;
        }
    }
}

public enum DecorType
{
    Happy,
    Sad,
}

public enum RibbonColor
{
    Gray,
    Blue,
    Purple,
    PinkCurvy
}