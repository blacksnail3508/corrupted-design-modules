using System;
using CorruptedDesign.Observer;
using CorruptedDesign.UI;
using CorruptedDesignTemplate;
using UnityEngine;
using UnityEngine.UI;

public class UIPopupDifficultMask : Popup
{
    public override string PopupType => "popup_core";
    [SerializeField] SpriteCollection spriteCollection;
    [SerializeField] Image border, icon, bar, title;
    [SerializeField] private GameObject vfxHard, vfxSp;
    private float showDuration = 2f;
    public float ShowDuration => showDuration;

    public static bool ShouldShow(Difficulty difficulty)
        => difficulty == Difficulty.Hard || difficulty == Difficulty.Expert;

    public UIPopupDifficultMask SetDif(Difficulty difficulty)
    {
        var config = spriteCollection.GetDifficultMaskConfig(difficulty);
        
        vfxHard.gameObject.SetActive(difficulty == Difficulty.Hard);
        vfxSp.gameObject.SetActive(difficulty == Difficulty.Expert);
        
        border.sprite = config.Border;
        icon.sprite = config.Icon;
        bar.sprite = config.Bar;
        title.sprite = config.Title;
        title.SetNativeSize();
        
        return this;
    }

    public override void Show()
    {
        base.Show();
        SetAutoClose();
    }

    public override void Hide(Action onComplete = null)
    {
        base.Hide(() =>
        {
            onComplete?.Invoke();
            EventService.Raise(new DifficultMaskClosedEvent());
        });
    }

    private void SetAutoClose()
    {
        Delay.Cancel(this);
        Delay.Call(showDuration, Close, this);
    }

    private void Close()
    {
        this.ClosePopup();
    }
}

public class DifficultMaskClosedEvent : GameEvent { }
