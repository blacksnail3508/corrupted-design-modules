using System;
using System.Collections.Generic;
using CorruptedDesign.IAP;
using CorruptedDesign.UI;
using TMPro;
using UnityEngine;

/// <summary>The No Ads Bundle offer: price and rewards come from ShopConfig, and it closes once the bundle is bought.</summary>
public class UIPopupRemoveAdsVip : Popup
{
    public override string PopupType => "popup_purchasing";

    [SerializeField] private ButtonBase buyButton;
    [SerializeField] private TMP_Text nameText;
    [SerializeField] private TMP_Text priceText;
    [SerializeField] private ButtonBase restoreButton;
    [SerializeField] private TMP_Text restoreText;
    [SerializeField] private UIResourceHolder noAdsSlot;
    [SerializeField] private List<UIResourceHolder> resourceSlot = new ();

    private const ProductName Product = ProductName.NoAdsBundle;

    private void Start()
    {
        buyButton.AddListener(TryPurchase);
        SetupRestore();
        Refresh();
    }

    private void SetupRestore()
    {
// #if UNITY_ANDROID
//         // Google Play restores owned purchases automatically at init, so only iOS needs the button.
//         restoreButton.gameObject.SetActive(false);
// #else
//         restoreText.text = "Restore";
//         restoreButton.AddListener(TryRestore);
// #endif
    }

    private void TryRestore()
    {
        restoreButton.SetInteract(false);
        ShopService.RestorePurchases(success =>
        {
            if (this == null) return;
            restoreButton.SetInteract(true);
            // A restored no-ads purchase has nothing left to offer, so the popup closes.
            if (success && ShopService.IsNoAds()) GameService.UIManager.ClosePopup<UIPopupRemoveAdsVip>();
        });
    }

    private void TryPurchase()
    {
        buyButton.SetInteract(false);
        ShopService.Buy(Product, LastTrigger.ToString(), success =>
        {
            if (this == null) return;
            buyButton.SetInteract(true);
            if (success) CloseAfterReward();
        });
    }

    private void CloseAfterReward()
    {
        // The reward recap opens on top of this popup, so closing is deferred until it is claimed.
        var reward = GameService.UIManager.GetPopup<UIPopupGrantReward>();
        if (reward != null && reward.gameObject.activeSelf)
            reward.SetOnCloseCallback(() => GameService.UIManager.ClosePopup<UIPopupRemoveAdsVip>());
        else
            GameService.UIManager.ClosePopup<UIPopupRemoveAdsVip>();
    }

    private void Refresh()
    {
        var data = ShopService.GetProductData(Product);
        if (priceText != null) priceText.text = ShopService.GetPriceString(Product);
        if (nameText != null && !string.IsNullOrEmpty(data.DisplayName)) nameText.text = data.DisplayName;

        // RemoveAds is the no-ads icon with its text left empty.
        if (noAdsSlot != null) noAdsSlot.SetData(ItemType.RemoveAds, 1);

        foreach (var slot in resourceSlot)
        {
            // The no-ads slot is also in resourceSlot but never has a reward entry, so the loop would hide it.
            if (slot == noAdsSlot) { slot.SetActive(true); continue; }

            int amount = 0;
            foreach (var reward in data.Rewards)
                if (reward.type == slot.Resource) amount += reward.amount;
            slot.SetActive(amount > 0);
            if (amount > 0) slot.SetData(slot.Resource, amount);
        }
    }

    public override void Show()
    {
        base.Show();
        // The store price can arrive after Start, so it is read again each time the popup opens.
        Refresh();
    }
}
