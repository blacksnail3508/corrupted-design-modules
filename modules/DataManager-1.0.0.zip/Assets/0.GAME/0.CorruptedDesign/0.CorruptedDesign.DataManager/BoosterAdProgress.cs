using System;
using CorruptedDesign;

[Serializable]
public class BoosterAdProgress
{
    public int Day;
    public int[] WatchedToday = new int[3];

    public static int TodayUtc()
    {
        var now = TrustedClock.UtcNow;
        return now.Year * 10000 + now.Month * 100 + now.Day;
    }

    public int[] EnsureToday()
    {
        // Resize keeps today's counts when a save from a build with fewer boosters is read.
        if (WatchedToday == null) WatchedToday = new int[3];
        else if (WatchedToday.Length < 3) Array.Resize(ref WatchedToday, 3);

        int today = TodayUtc();
        if (Day != today)
        {
            Day = today;
            Array.Clear(WatchedToday, 0, WatchedToday.Length);
        }

        return WatchedToday;
    }
}
