#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

namespace CorruptedDesign.Data.EditorTools
{
    public sealed class VaultEditorWindow : EditorWindow
    {
        private enum RowSource { PlayerPrefs, PersistentFile }

        private static readonly Color ColorPlayerPrefs    = new Color(0.35f, 0.75f, 1f);
        private static readonly Color ColorPersistentFile = new Color(1f,    0.38f, 0.38f);

        [MenuItem("CorruptedDesign/Vault Editor")]
        public static void Open()
        {
            var win = GetWindow<VaultEditorWindow>(false, "Vault Editor", true);
            win.minSize = new Vector2(720, 480);
            win.Show();
        }

        private string search      = string.Empty;
        private Vector2 scroll;
        private List<Row> rows     = new List<Row>();
        private bool showRawValues;
        private string newKey      = string.Empty;
        private VaultDataType newType = VaultDataType.String;
        private string newValue    = string.Empty;
        private RowSource addTarget = RowSource.PlayerPrefs;

        private bool filterPP = true;
        private bool filterPF = true;

        private enum SortMode { KeyAsc, KeyDesc, SourceThenKey }
        private SortMode sortMode = SortMode.KeyAsc;

        private HashSet<VaultDataType> typeFilter = new HashSet<VaultDataType>
        {
            VaultDataType.Int, VaultDataType.Float, VaultDataType.String,
            VaultDataType.Bool, VaultDataType.Enum, VaultDataType.Json,
        };

        private sealed class Row
        {
            public string Key;
            public VaultDataType Type;
            public string DisplayValue;
            public string OriginalValue;
            public bool Exists;
            public RowSource Source;
            public string FilePath;

            public string SecuredKey;
            public string DisplayKey;
            public string SecuredLabel;
            public bool   ReadOnly;
        }

        private void OnEnable() => RefreshRows();

        private void OnGUI()
        {
            DrawToolbar();
            DrawFilter();
            EditorGUILayout.Space(4);
            DrawHeader();
            DrawRows();
            EditorGUILayout.Space(8);
            DrawAddNew();
            EditorGUILayout.Space(4);
            DrawFooter();
        }

        private void DrawToolbar()
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                if (GUILayout.Button("Delete All PP", EditorStyles.toolbarButton, GUILayout.Width(95)))
                {
                    if (EditorUtility.DisplayDialog("Delete All PlayerPrefs",
                        "Xóa TOÀN BỘ PlayerPrefs?\nKhông thể hoàn tác.", "Delete", "Cancel"))
                    {
                        SecuredPrefs.DeleteAll();
                        RefreshRows();
                    }
                }

                if (GUILayout.Button("Refresh", EditorStyles.toolbarButton, GUILayout.Width(70)))
                    RefreshRows();

                if (GUILayout.Button("Save All", EditorStyles.toolbarButton, GUILayout.Width(70)))
                {
                    PlayerPrefs.Save();
                    try { JsonFileStore.Save(); } catch { }
                }

                GUILayout.FlexibleSpace();

                showRawValues = GUILayout.Toggle(showRawValues, "Raw", EditorStyles.toolbarButton, GUILayout.Width(50));

                if (GUILayout.Button("Export JSON", EditorStyles.toolbarButton, GUILayout.Width(90)))
                    ExportToJson();

                if (GUILayout.Button("Import JSON", EditorStyles.toolbarButton, GUILayout.Width(90)))
                    ImportFromJson();

                if (GUILayout.Button("Open PersistPath", EditorStyles.toolbarButton, GUILayout.Width(115)))
                    EditorUtility.RevealInFinder(Application.persistentDataPath);
            }
        }

        private void DrawFilter()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField("Search:", GUILayout.Width(50));
                var ns = EditorGUILayout.TextField(search);
                if (ns != search) { search = ns; Repaint(); }
                EditorGUILayout.LabelField($"Total: {rows.Count}", GUILayout.Width(80));
            }

            using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField("Sources:", GUILayout.Width(58));
                var old = GUI.color;
                GUI.color = ColorPlayerPrefs;
                filterPP = GUILayout.Toggle(filterPP, "● PlayerPrefs",      "Button", GUILayout.Width(105));
                GUI.color = ColorPersistentFile;
                filterPF = GUILayout.Toggle(filterPF, "● Persistent Files", "Button", GUILayout.Width(125));
                GUI.color = old;
                GUILayout.FlexibleSpace();
            }

            using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField("Type:", GUILayout.Width(40));
                bool changed = false;
                changed |= DrawTypeToggle(VaultDataType.Int,    "Int",    48);
                changed |= DrawTypeToggle(VaultDataType.Float,  "Float",  52);
                changed |= DrawTypeToggle(VaultDataType.String, "String", 58);
                changed |= DrawTypeToggle(VaultDataType.Bool,   "Bool",   50);
                changed |= DrawTypeToggle(VaultDataType.Enum,   "Enum",   50);
                changed |= DrawTypeToggle(VaultDataType.Json,   "Json",   48);
                GUILayout.FlexibleSpace();
                if (GUILayout.Button("All",  EditorStyles.miniButton, GUILayout.Width(35)))
                {
                    foreach (VaultDataType t in Enum.GetValues(typeof(VaultDataType))) typeFilter.Add(t);
                    changed = true;
                }
                if (GUILayout.Button("None", EditorStyles.miniButton, GUILayout.Width(40)))
                {
                    typeFilter.Clear();
                    changed = true;
                }
                if (changed) Repaint();
            }
        }

        private bool DrawTypeToggle(VaultDataType type, string label, float w)
        {
            bool was = typeFilter.Contains(type);
            bool now = GUILayout.Toggle(was, label, "Button", GUILayout.Width(w));
            if (now == was) return false;
            if (now) typeFilter.Add(type); else typeFilter.Remove(type);
            return true;
        }

        private void DrawHeader()
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                GUILayout.Space(28);

                string kl = sortMode == SortMode.KeyAsc  ? "Key ▲" :
                            sortMode == SortMode.KeyDesc ? "Key ▼" : "Key";
                if (GUILayout.Button(kl, EditorStyles.toolbarButton, GUILayout.Width(200)))
                    sortMode = sortMode == SortMode.KeyAsc ? SortMode.KeyDesc : SortMode.KeyAsc;

                string sl = sortMode == SortMode.SourceThenKey ? "Source ▲" : "Source";
                if (GUILayout.Button(sl, EditorStyles.toolbarButton, GUILayout.Width(110)))
                    sortMode = SortMode.SourceThenKey;

                EditorGUILayout.LabelField("Type",  EditorStyles.toolbarButton, GUILayout.Width(63));
                EditorGUILayout.LabelField("Value", EditorStyles.toolbarButton);
                EditorGUILayout.LabelField("",      EditorStyles.toolbarButton, GUILayout.Width(140));
            }
        }

        private void DrawRows()
        {
            scroll = EditorGUILayout.BeginScrollView(scroll, GUILayout.ExpandHeight(true));
            try
            {
                int visible = 0;
                for (int i = 0; i < rows.Count; i++)
                {
                    var row = rows[i];
                    if (!PassesSourceFilter(row.Source)) continue;
                    if (!typeFilter.Contains(row.Type))  continue;
                    if (!string.IsNullOrEmpty(search) &&
                        row.Key.IndexOf(search, StringComparison.OrdinalIgnoreCase) < 0 &&
                        (row.FilePath == null ||
                         row.FilePath.IndexOf(search, StringComparison.OrdinalIgnoreCase) < 0))
                        continue;

                    DrawRow(row);
                    visible++;
                }

                if (rows.Count == 0)
                    EditorGUILayout.HelpBox("Không có dữ liệu. Nhấn Refresh.", MessageType.Info);
                else if (visible == 0)
                    EditorGUILayout.HelpBox($"{rows.Count} entries nhưng bị filter ẩn hết.", MessageType.Info);
            }
            finally { EditorGUILayout.EndScrollView(); }
        }

        private bool PassesSourceFilter(RowSource s)
        {
            switch (s)
            {
                case RowSource.PlayerPrefs:    return filterPP;
                case RowSource.PersistentFile: return filterPF;
                default: return true;
            }
        }

        private void DrawRow(Row row)
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
            {
                var srcColor = row.Source == RowSource.PlayerPrefs ? ColorPlayerPrefs : ColorPersistentFile;
                var srcLabel = row.Source == RowSource.PlayerPrefs ? "PP" : "PF";

                var badgeStyle = new GUIStyle(EditorStyles.miniLabel)
                {
                    fontStyle = FontStyle.Bold,
                    alignment = TextAnchor.MiddleCenter,
                };
                badgeStyle.normal.textColor = srcColor;
                EditorGUILayout.LabelField(srcLabel, badgeStyle, GUILayout.Width(24));

                var keyStyle = new GUIStyle(EditorStyles.label);
                if (row.DisplayValue != row.OriginalValue)
                    keyStyle.normal.textColor = new Color(1f, 0.7f, 0.3f);
                else
                    keyStyle.normal.textColor = srcColor;

                string tooltip = row.FilePath != null ? $"File: {row.FilePath}" : "PlayerPrefs";
                if (row.DisplayKey != null) tooltip = $"Slot: {row.Key}\n{tooltip}";
                EditorGUILayout.LabelField(new GUIContent(row.DisplayKey ?? row.Key, tooltip), keyStyle, GUILayout.Width(200));

                string srcDetail = row.SecuredLabel
                                   ?? (row.FilePath != null ? Path.GetFileName(row.FilePath) : "PlayerPrefs");
                EditorGUILayout.LabelField(srcDetail, EditorStyles.miniLabel, GUILayout.Width(110));

                EditorGUILayout.LabelField(row.Type.ToString(), GUILayout.Width(63));

                DrawValueField(row);

                using (new EditorGUILayout.HorizontalScope(GUILayout.Width(140)))
                {
                    GUI.enabled = !row.ReadOnly && row.DisplayValue != row.OriginalValue;
                    if (GUILayout.Button("Apply", GUILayout.Width(55))) ApplyRow(row);
                    GUI.enabled = true;

                    if (GUILayout.Button("Delete", GUILayout.Width(60)))
                    {
                        if (EditorUtility.DisplayDialog("Delete Key",
                            $"Xóa key '{row.Key}' ({row.Source})?", "Delete", "Cancel"))
                            DeleteRow(row);
                    }
                }
            }
        }

        private void DrawValueField(Row row)
        {
            if (row.ReadOnly)
            {
                using (new EditorGUI.DisabledScope(true))
                    EditorGUILayout.TextField(row.DisplayValue ?? string.Empty);
                return;
            }

            if (showRawValues)
            {
                row.DisplayValue = EditorGUILayout.TextField(row.DisplayValue ?? string.Empty);
                return;
            }

            switch (row.Type)
            {
                case VaultDataType.Int:
                case VaultDataType.Enum:
                {
                    int.TryParse(row.DisplayValue, out var n);
                    var nn = EditorGUILayout.IntField(n);
                    if (nn != n) row.DisplayValue = nn.ToString();
                    break;
                }
                case VaultDataType.Float:
                {
                    float.TryParse(row.DisplayValue,
                        System.Globalization.NumberStyles.Float,
                        System.Globalization.CultureInfo.InvariantCulture, out var f);
                    var nf = EditorGUILayout.FloatField(f);
                    if (!Mathf.Approximately(nf, f))
                        row.DisplayValue = nf.ToString("R", System.Globalization.CultureInfo.InvariantCulture);
                    break;
                }
                case VaultDataType.Bool:
                {
                    var b = row.DisplayValue == "1" || row.DisplayValue == "True" || row.DisplayValue == "true";
                    var nb = EditorGUILayout.Toggle(b);
                    if (nb != b) row.DisplayValue = nb ? "1" : "0";
                    break;
                }
                case VaultDataType.String:
                    row.DisplayValue = EditorGUILayout.TextField(row.DisplayValue ?? string.Empty);
                    break;
                case VaultDataType.Json:
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        var preview = row.DisplayValue ?? string.Empty;
                        if (preview.Length > 60) preview = preview.Substring(0, 60) + "…";
                        EditorGUILayout.LabelField(preview, EditorStyles.miniLabel);
                        if (GUILayout.Button("Edit", GUILayout.Width(50)))
                        {
                            VaultJsonEditorPopup.Open(row.Key, row.DisplayValue, edited =>
                            {
                                row.DisplayValue = edited;
                                Repaint();
                            });
                        }
                    }
                    break;
            }
        }

        private void DrawAddNew()
        {
            EditorGUILayout.LabelField("Add new entry", EditorStyles.boldLabel);
            using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
            {
                newKey    = EditorGUILayout.TextField(newKey,  GUILayout.Width(200));
                newType   = (VaultDataType)EditorGUILayout.EnumPopup(newType, GUILayout.Width(70));
                newValue  = EditorGUILayout.TextField(newValue);
                addTarget = (RowSource)EditorGUILayout.EnumPopup(addTarget, GUILayout.Width(120));
                GUI.enabled = !string.IsNullOrEmpty(newKey);
                if (GUILayout.Button("Add", GUILayout.Width(60))) AddNewEntry();
                GUI.enabled = true;
            }
        }

        private void DrawFooter()
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
            {
                var old = GUI.color;
                GUI.color = ColorPlayerPrefs;
                EditorGUILayout.LabelField("● PP = PlayerPrefs", EditorStyles.miniLabel, GUILayout.Width(120));
                GUI.color = ColorPersistentFile;
                EditorGUILayout.LabelField("● PF = Persistent file", EditorStyles.miniLabel, GUILayout.Width(135));
                GUI.color = old;
                EditorGUILayout.LabelField(Application.persistentDataPath, EditorStyles.miniLabel);
            }
        }

        private void RefreshRows()
        {
            rows.Clear();
            ReadPlayerPrefsRows();
            ReadPersistentFileRows();
            SortRows();
        }

        private void ReadPlayerPrefsRows()
        {
            var securedMap = BuildSecuredKeyMap();

            foreach (var entry in EnumeratePlayerPrefsNative())
            {
                var row = new Row
                {
                    Key          = entry.Key,
                    Type         = entry.NativeType,
                    DisplayValue = entry.Value,
                    OriginalValue = entry.Value,
                    Exists       = true,
                    Source       = RowSource.PlayerPrefs,
                };

                ApplySecuredView(row, securedMap);
                rows.Add(row);
            }
        }

        private static Dictionary<string, string> BuildSecuredKeyMap()
        {
            var map = new Dictionary<string, string>();
            try
            {
                var fields = typeof(PlayerPrefsKey).GetFields(BindingFlags.Public | BindingFlags.Static);
                foreach (var f in fields)
                {
                    if (f.FieldType != typeof(string)) continue;
                    if (!(f.GetValue(null) is string original) || string.IsNullOrEmpty(original)) continue;
                    map[SecuredPrefs.GetStorageKey(original)] = original;
                }
            }
            catch (Exception e)
            {
                Debug.LogWarning($"[VaultEditor] Dựng bảng tra key thất bại: {e.Message}");
            }
            return map;
        }

        private static void ApplySecuredView(Row row, Dictionary<string, string> securedMap)
        {
            var stored = row.DisplayValue;
            if (string.IsNullOrEmpty(stored)) return;

            bool isV3 = VaultSecurityPort.Cipher.IsSealedString(stored);
            bool isV2 = VaultSecurityPort.Cipher.IsLegacyString(stored);
            if (!isV3 && !isV2) return;

            if (!securedMap.TryGetValue(row.Key, out var original))
            {
                row.SecuredLabel = isV3 ? "v3 🔒?" : "v2 🔒?";
                row.ReadOnly     = true;
                return;
            }

            row.DisplayKey = original;

            string plain;
            bool opened = isV3
                ? VaultSecurityPort.Cipher.TryOpenString(stored, original, out plain)
                : VaultSecurityPort.Cipher.TryOpenLegacy(stored, out plain);

            if (!opened)
            {
                row.SecuredLabel = isV3 ? "v3 ✗MAC" : "v2 ✗";
                row.ReadOnly     = true;
                return;
            }

            row.SecuredKey    = original;
            row.SecuredLabel  = isV3 ? "v3 🔓" : "v2 🔓";
            row.DisplayValue  = plain;
            row.OriginalValue = plain;
            row.Type          = InferTypeFromPlainText(plain);
        }

        private static VaultDataType InferTypeFromPlainText(string plain)
        {
            if (string.IsNullOrEmpty(plain)) return VaultDataType.String;

            var t = plain.TrimStart();
            if (t.StartsWith("{") || t.StartsWith("[")) return VaultDataType.Json;
            if (int.TryParse(plain, out _)) return VaultDataType.Int;
            if (float.TryParse(plain, System.Globalization.NumberStyles.Float,
                    System.Globalization.CultureInfo.InvariantCulture, out _)) return VaultDataType.Float;
            return VaultDataType.String;
        }

        private void ReadPersistentFileRows()
        {
            var persistPath = Application.persistentDataPath;
            if (!Directory.Exists(persistPath)) return;
            try
            {
                foreach (var filePath in Directory.GetFiles(persistPath, "*", SearchOption.AllDirectories))
                {
                    try { ReadPersistentFile(filePath); }
                    catch { }
                }
            }
            catch { }
        }

        private void ReadPersistentFile(string filePath)
        {
            var ext      = Path.GetExtension(filePath).ToLowerInvariant();
            var fileName = Path.GetFileName(filePath);

            if (fileName.EndsWith(".meta", StringComparison.OrdinalIgnoreCase)) return;

            if (ext != ".json")
            {
                var info = new FileInfo(filePath);
                if (info.Length > 65536) return;
            }

            var bytes = File.ReadAllBytes(filePath);
            if (bytes.Length == 0) return;

            bool encrypted = VaultSecurityPort.Cipher.IsSealedBlob(bytes);
            if (encrypted || LooksBinary(bytes))
            {
                var summary = encrypted
                    ? $"🔒 PXVT encrypted — {bytes.Length} bytes"
                    : $"binary — {bytes.Length} bytes";

                rows.Add(new Row
                {
                    Key           = $"[{fileName}]",
                    Type          = VaultDataType.String,
                    DisplayValue  = summary,
                    OriginalValue = summary,
                    Exists        = true,
                    Source        = RowSource.PersistentFile,
                    FilePath      = filePath,
                    SecuredLabel  = encrypted ? "v3 🔒" : "bin",
                    ReadOnly      = true,
                });
                return;
            }

            if (ext == ".json")
            {
                var text = Encoding.UTF8.GetString(bytes);
                if (string.IsNullOrWhiteSpace(text)) return;

                try
                {
                    var dict = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(text);
                    if (dict != null)
                    {
                        foreach (var kv in dict)
                        {
                            string raw;
                            VaultDataType type;
                            if (kv.Value is Newtonsoft.Json.Linq.JObject || kv.Value is Newtonsoft.Json.Linq.JArray)
                            {
                                raw  = kv.Value.ToString();
                                type = VaultDataType.Json;
                            }
                            else
                            {
                                raw  = kv.Value?.ToString() ?? string.Empty;
                                type = InferTypeFromJsonValue(kv.Value);
                            }

                            rows.Add(new Row
                            {
                                Key          = kv.Key,
                                Type         = type,
                                DisplayValue = raw,
                                OriginalValue = raw,
                                Exists       = true,
                                Source       = RowSource.PersistentFile,
                                FilePath     = filePath,
                            });
                        }
                        return;
                    }
                }
                catch { }

                rows.Add(new Row
                {
                    Key          = $"[{fileName}]",
                    Type         = VaultDataType.Json,
                    DisplayValue = text,
                    OriginalValue = text,
                    Exists       = true,
                    Source       = RowSource.PersistentFile,
                    FilePath     = filePath,
                });
            }
            else
            {
                var text = Encoding.UTF8.GetString(bytes);
                rows.Add(new Row
                {
                    Key          = $"[{fileName}]",
                    Type         = VaultDataType.String,
                    DisplayValue = text,
                    OriginalValue = text,
                    Exists       = true,
                    Source       = RowSource.PersistentFile,
                    FilePath     = filePath,
                });
            }
        }

        private static bool LooksBinary(byte[] bytes)
        {
            int n = Math.Min(bytes.Length, 512);
            for (int i = 0; i < n; i++)
                if (bytes[i] == 0) return true;
            return false;
        }

        private struct NativePrefEntry
        {
            public string Key;
            public string Value;
            public VaultDataType NativeType;
        }

        private static List<NativePrefEntry> EnumeratePlayerPrefsNative()
        {
            var result = new List<NativePrefEntry>();
#if UNITY_EDITOR_WIN
            try
            {
                var regPath = string.Format(@"Software\Unity\UnityEditor\{0}\{1}",
                    Application.companyName, Application.productName);
                using (var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(regPath))
                {
                    if (key == null) return result;
                    foreach (var valueName in key.GetValueNames())
                    {
                        var cleanKey  = Regex.Replace(valueName, @"_h\d+$", "");
                        var kind      = key.GetValueKind(valueName);
                        string strVal        = string.Empty;
                        VaultDataType nativeType = VaultDataType.String;

                        switch (kind)
                        {
                            case Microsoft.Win32.RegistryValueKind.DWord:
                                strVal     = ((int)key.GetValue(valueName)).ToString();
                                nativeType = VaultDataType.Int;
                                break;

                            case Microsoft.Win32.RegistryValueKind.Binary:
                                var bytes   = (byte[])key.GetValue(valueName);
                                {
                                    int byteLen = bytes.Length;
                                    while (byteLen > 0 && bytes[byteLen - 1] == 0) byteLen--;
                                    bool decoded = false;
                                    if (byteLen > 0)
                                    {
                                        try
                                        {
                                            var utf8  = System.Text.Encoding.UTF8.GetString(bytes, 0, byteLen);
                                            bool ok   = true;
                                            foreach (var ch in utf8)
                                                if (ch < 0x20) { ok = false; break; }
                                            if (ok)
                                            {
                                                strVal = utf8;
                                                var tr = strVal.TrimStart();
                                                if (tr.StartsWith("{") || tr.StartsWith("["))
                                                    nativeType = VaultDataType.Json;
                                                else if (float.TryParse(strVal,
                                                             System.Globalization.NumberStyles.Float,
                                                             System.Globalization.CultureInfo.InvariantCulture, out _))
                                                    nativeType = VaultDataType.Float;
                                                else
                                                    nativeType = VaultDataType.String;
                                                decoded = true;
                                            }
                                        }
                                        catch { }
                                    }
                                    if (!decoded)
                                    {
                                        if (bytes.Length == 4)
                                        {
                                            strVal     = BitConverter.ToSingle(bytes, 0)
                                                             .ToString("R", System.Globalization.CultureInfo.InvariantCulture);
                                            nativeType = VaultDataType.Float;
                                        }
                                        else
                                        {
                                            strVal     = BitConverter.ToString(bytes);
                                            nativeType = VaultDataType.String;
                                        }
                                    }
                                }
                                break;

                            default:
                                strVal = key.GetValue(valueName)?.ToString() ?? string.Empty;
                                var trSz = strVal.TrimStart();
                                nativeType = (trSz.StartsWith("{") || trSz.StartsWith("["))
                                    ? VaultDataType.Json
                                    : VaultDataType.String;
                                break;
                        }

                        result.Add(new NativePrefEntry { Key = cleanKey, Value = strVal, NativeType = nativeType });
                    }
                }
            }
            catch (Exception e)
            {
                Debug.LogWarning($"[VaultEditor] Registry read failed: {e.Message}");
            }
#endif
            return result;
        }

        private static VaultDataType InferTypeFromJsonValue(object val)
        {
            if (val == null) return VaultDataType.String;
            if (val is Newtonsoft.Json.Linq.JValue jv)
            {
                switch (jv.Type)
                {
                    case Newtonsoft.Json.Linq.JTokenType.Integer: return VaultDataType.Int;
                    case Newtonsoft.Json.Linq.JTokenType.Float:   return VaultDataType.Float;
                    case Newtonsoft.Json.Linq.JTokenType.Boolean: return VaultDataType.Bool;
                    case Newtonsoft.Json.Linq.JTokenType.String:
                    {
                        var jvStr = jv.ToString();
                        var jvTr  = jvStr.TrimStart();
                        return (jvTr.StartsWith("{") || jvTr.StartsWith("[")) ? VaultDataType.Json : VaultDataType.String;
                    }
                    default: return VaultDataType.String;
                }
            }
            if (val is Newtonsoft.Json.Linq.JObject || val is Newtonsoft.Json.Linq.JArray) return VaultDataType.Json;
            if (val is long || val is int)     return VaultDataType.Int;
            if (val is double || val is float) return VaultDataType.Float;
            if (val is bool)                   return VaultDataType.Bool;
            var s = val.ToString();
            return (s.TrimStart().StartsWith("{") || s.TrimStart().StartsWith("[")) ? VaultDataType.Json : VaultDataType.String;
        }

        private void SortRows()
        {
            switch (sortMode)
            {
                case SortMode.KeyAsc:
                    rows.Sort((a, b) => string.Compare(a.Key, b.Key, StringComparison.OrdinalIgnoreCase));
                    break;
                case SortMode.KeyDesc:
                    rows.Sort((a, b) => string.Compare(b.Key, a.Key, StringComparison.OrdinalIgnoreCase));
                    break;
                case SortMode.SourceThenKey:
                    rows.Sort((a, b) =>
                    {
                        int c = ((int)a.Source).CompareTo((int)b.Source);
                        return c != 0 ? c : string.Compare(a.Key, b.Key, StringComparison.OrdinalIgnoreCase);
                    });
                    break;
            }
        }

        private void ApplyRow(Row row)
        {
            try
            {
                WriteRow(row);
                row.OriginalValue = row.DisplayValue;
                row.Exists        = true;
                FlushSource(row.Source);
            }
            catch (Exception e) { EditorUtility.DisplayDialog("Apply failed", e.Message, "OK"); }
        }

        private void WriteRow(Row row)
        {
            if (row.Source == RowSource.PlayerPrefs)  WriteToPlayerPrefs(row);
            else                                       WriteToPersistentFile(row);
        }

        private void WriteToPlayerPrefs(Row row)
        {
            if (row.SecuredKey != null)
            {
                PlayerPrefs.SetString(row.Key,
                    VaultSecurityPort.Cipher.SealToString(row.DisplayValue ?? string.Empty, row.SecuredKey));
                return;
            }

            switch (row.Type)
            {
                case VaultDataType.Int:
                case VaultDataType.Enum:
                    PlayerPrefs.SetInt(row.Key, int.Parse(row.DisplayValue)); break;
                case VaultDataType.Float:
                    PlayerPrefs.SetFloat(row.Key, float.Parse(row.DisplayValue,
                        System.Globalization.NumberStyles.Float,
                        System.Globalization.CultureInfo.InvariantCulture)); break;
                case VaultDataType.Bool:
                    PlayerPrefs.SetInt(row.Key, row.DisplayValue == "1" ? 1 : 0); break;
                default:
                    PlayerPrefs.SetString(row.Key, row.DisplayValue ?? string.Empty); break;
            }
        }

        private void WriteToPersistentFile(Row row)
        {
            if (row.Key.StartsWith("[") && row.Key.EndsWith("]"))
            {
                if (!string.IsNullOrEmpty(row.FilePath))
                    File.WriteAllText(row.FilePath, row.DisplayValue ?? string.Empty);
                return;
            }

            if (!string.IsNullOrEmpty(row.FilePath) && File.Exists(row.FilePath))
            {
                var text = File.ReadAllText(row.FilePath);
                var dict = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(text)
                           ?? new Dictionary<string, object>();
                dict[row.Key] = CoerceForJson(row);
                File.WriteAllText(row.FilePath,
                    Newtonsoft.Json.JsonConvert.SerializeObject(dict, Newtonsoft.Json.Formatting.Indented));
                return;
            }

            switch (row.Type)
            {
                case VaultDataType.Int:
                case VaultDataType.Enum:
                    JsonFileStore.SetInt(row.Key, int.Parse(row.DisplayValue)); break;
                case VaultDataType.Float:
                    JsonFileStore.SetFloat(row.Key, float.Parse(row.DisplayValue,
                        System.Globalization.NumberStyles.Float,
                        System.Globalization.CultureInfo.InvariantCulture)); break;
                case VaultDataType.Bool:
                    JsonFileStore.SetBool(row.Key,
                        row.DisplayValue == "1" || row.DisplayValue == "True" || row.DisplayValue == "true"); break;
                default:
                    JsonFileStore.SetRaw(row.Key, row.DisplayValue ?? string.Empty); break;
            }
        }

        private static object CoerceForJson(Row row)
        {
            var v = row.DisplayValue ?? string.Empty;
            switch (row.Type)
            {
                case VaultDataType.Int:
                case VaultDataType.Enum:
                    if (int.TryParse(v, out var i)) return i;
                    return v;
                case VaultDataType.Float:
                    if (float.TryParse(v, System.Globalization.NumberStyles.Float,
                        System.Globalization.CultureInfo.InvariantCulture, out var f)) return f;
                    return v;
                case VaultDataType.Bool:
                    return v == "1" || v == "true" || v == "True";
                case VaultDataType.Json:
                    try { return Newtonsoft.Json.JsonConvert.DeserializeObject(v); } catch { return v; }
                default:
                    return v;
            }
        }

        private void DeleteRow(Row row)
        {
            if (row.Source == RowSource.PlayerPrefs)
                PlayerPrefs.DeleteKey(row.Key);
            else
                DeleteFromPersistentFile(row);

            FlushSource(row.Source);
            RefreshRows();
        }

        private void DeleteFromPersistentFile(Row row)
        {
            if (string.IsNullOrEmpty(row.FilePath) || !File.Exists(row.FilePath)) return;

            if (row.Key.StartsWith("[") && row.Key.EndsWith("]"))
            {
                if (EditorUtility.DisplayDialog("Delete File",
                    $"Xóa toàn bộ file:\n{row.FilePath}?", "Delete File", "Cancel"))
                    File.Delete(row.FilePath);
                return;
            }

            var text = File.ReadAllText(row.FilePath);
            var dict = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, object>>(text);
            if (dict != null && dict.Remove(row.Key))
                File.WriteAllText(row.FilePath,
                    Newtonsoft.Json.JsonConvert.SerializeObject(dict, Newtonsoft.Json.Formatting.Indented));
        }

        private void FlushSource(RowSource source)
        {
            if (source == RowSource.PlayerPrefs) PlayerPrefs.Save();
        }

        private void AddNewEntry()
        {
            try
            {
                var row = new Row
                {
                    Key          = newKey,
                    Type         = newType,
                    DisplayValue = newValue,
                    OriginalValue = null,
                    Exists       = false,
                    Source       = addTarget,
                };
                if (addTarget == RowSource.PersistentFile)
                    row.FilePath = JsonFileStore.GetFilePath();

                WriteRow(row);
                FlushSource(addTarget);
                newKey  = string.Empty;
                newValue = string.Empty;
                RefreshRows();
            }
            catch (Exception e) { EditorUtility.DisplayDialog("Add failed", e.Message, "OK"); }
        }

        private void ExportToJson()
        {
            var path = EditorUtility.SaveFilePanel("Export to JSON", Application.dataPath, "vault_export.json", "json");
            if (string.IsNullOrEmpty(path)) return;
            try
            {
                var dict = new Dictionary<string, string>();
                foreach (var row in rows)
                    if (row.Exists && PassesSourceFilter(row.Source))
                        dict[row.Key] = row.DisplayValue ?? string.Empty;
                File.WriteAllText(path,
                    Newtonsoft.Json.JsonConvert.SerializeObject(dict, Newtonsoft.Json.Formatting.Indented));
                EditorUtility.RevealInFinder(path);
            }
            catch (Exception e) { EditorUtility.DisplayDialog("Export failed", e.Message, "OK"); }
        }

        private void ImportFromJson()
        {
            var path = EditorUtility.OpenFilePanel("Import JSON", Application.dataPath, "json");
            if (string.IsNullOrEmpty(path)) return;
            if (!EditorUtility.DisplayDialog("Import",
                $"Ghi đè các key trùng vào {addTarget}?", "Import", "Cancel")) return;
            try
            {
                var text = File.ReadAllText(path);
                var dict = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, string>>(text);
                if (dict == null) throw new Exception("File không phải dictionary JSON.");
                foreach (var kv in dict)
                {
                    var row = new Row
                    {
                        Key          = kv.Key,
                        Type         = VaultDataType.String,
                        DisplayValue = kv.Value,
                        Source       = addTarget,
                    };
                    if (addTarget == RowSource.PersistentFile)
                        row.FilePath = JsonFileStore.GetFilePath();
                    WriteRow(row);
                }
                FlushSource(addTarget);
                RefreshRows();
            }
            catch (Exception e) { EditorUtility.DisplayDialog("Import failed", e.Message, "OK"); }
        }
    }

    internal sealed class VaultJsonEditorPopup : EditorWindow
    {
        private string _key;
        private string _text;
        private Action<string> _onSave;
        private Vector2 _scroll;
        private bool _isPretty = true;

        public static void Open(string key, string current, Action<string> onSave)
        {
            var win = CreateInstance<VaultJsonEditorPopup>();
            win.titleContent = new GUIContent($"JSON: {key}");
            win._key    = key;
            win._onSave = onSave;
            win.minSize = new Vector2(560, 400);
            win._text   = TryFormat(current ?? string.Empty, indented: true) ?? current ?? string.Empty;
            win.ShowUtility();
        }

        private void OnGUI()
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                EditorGUILayout.LabelField($"Key: {_key}", EditorStyles.boldLabel);
                GUILayout.FlexibleSpace();

                var sp = new GUIStyle(EditorStyles.toolbarButton);
                var sm = new GUIStyle(EditorStyles.toolbarButton);
                if (_isPretty)  sp.fontStyle = FontStyle.Bold;
                if (!_isPretty) sm.fontStyle = FontStyle.Bold;

                if (GUILayout.Button("Pretty",  sp, GUILayout.Width(65)))
                {
                    var r = TryFormat(_text, indented: true);
                    if (r != null) { _text = r; _isPretty = true; }
                    else EditorUtility.DisplayDialog("Pretty Print", "JSON không hợp lệ.", "OK");
                    Repaint();
                }
                if (GUILayout.Button("Minimal", sm, GUILayout.Width(65)))
                {
                    var r = TryFormat(_text, indented: false);
                    if (r != null) { _text = r; _isPretty = false; }
                    else EditorUtility.DisplayDialog("Minimal", "JSON không hợp lệ.", "OK");
                    Repaint();
                }
            }

            var taStyle = new GUIStyle(EditorStyles.textArea) { wordWrap = false };
            _scroll = EditorGUILayout.BeginScrollView(_scroll, GUILayout.ExpandHeight(true));
            _text = EditorGUILayout.TextArea(_text, taStyle, GUILayout.ExpandHeight(true));
            EditorGUILayout.EndScrollView();

            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.FlexibleSpace();
                if (GUILayout.Button("Cancel", GUILayout.Width(80))) Close();
                if (GUILayout.Button("Save",   GUILayout.Width(80))) { _onSave?.Invoke(_text); Close(); }
            }
        }

        private static string TryFormat(string text, bool indented)
        {
            if (string.IsNullOrWhiteSpace(text)) return text;
            try
            {
                var parsed = Newtonsoft.Json.JsonConvert.DeserializeObject(text);
                return Newtonsoft.Json.JsonConvert.SerializeObject(
                    parsed,
                    indented ? Newtonsoft.Json.Formatting.Indented : Newtonsoft.Json.Formatting.None);
            }
            catch { return null; }
        }
    }
}
#endif
