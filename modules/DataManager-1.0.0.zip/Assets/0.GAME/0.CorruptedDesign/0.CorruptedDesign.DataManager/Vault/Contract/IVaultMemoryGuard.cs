namespace CorruptedDesign.Data
{
    public interface IVaultMemoryGuard
    {
        void Encode(long value, out long stored, out int token, out int check);
        bool TryDecode(long stored, int token, int check, out long value);
        bool IsIntact(long stored, int token, int check);
    }

    internal sealed class PlainMemoryGuard : IVaultMemoryGuard
    {
        public void Encode(long value, out long stored, out int token, out int check)
        {
            stored = value;
            token  = 1;
            check  = 0;
        }

        public bool TryDecode(long stored, int token, int check, out long value)
        {
            value = stored;
            return true;
        }

        public bool IsIntact(long stored, int token, int check) => true;
    }
}
