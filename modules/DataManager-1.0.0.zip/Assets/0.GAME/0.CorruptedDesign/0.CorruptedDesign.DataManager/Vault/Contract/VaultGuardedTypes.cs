using System;
using System.Runtime.InteropServices;

namespace CorruptedDesign.Data
{
    [StructLayout(LayoutKind.Explicit)]
    internal struct FloatBits
    {
        [FieldOffset(0)] public float AsFloat;
        [FieldOffset(0)] public int   AsInt;
    }

    [Serializable]
    public struct ObscuredLong : IEquatable<ObscuredLong>
    {
        private int  token;
        private long stored;
        private int  check;

        public static ObscuredLong From(long value)
        {
            var o = new ObscuredLong();
            o.Set(value);
            return o;
        }

        public long Get(string keyForReport = null)
        {
            if (token == 0) return 0L;

            if (!VaultSecurityPort.MemoryGuard.TryDecode(stored, token, check, out var value))
            {
                VaultSecurity.Report(VaultTamperKind.ObscuredValue, keyForReport ?? "<obscured>",
                    "checksum lệch — giá trị trong RAM đã bị sửa");
                return 0L;
            }

            Set(value);
            return value;
        }

        public void Set(long value) =>
            VaultSecurityPort.MemoryGuard.Encode(value, out stored, out token, out check);

        public bool IsIntact() =>
            token == 0 || VaultSecurityPort.MemoryGuard.IsIntact(stored, token, check);

        public bool Equals(ObscuredLong other) => Get() == other.Get();
        public override bool Equals(object obj) => obj is ObscuredLong o && Equals(o);
        public override int GetHashCode() => Get().GetHashCode();
        public override string ToString() => Get().ToString();

        public static implicit operator long(ObscuredLong v) => v.Get();
        public static implicit operator ObscuredLong(long v) => From(v);
    }

    [Serializable]
    public struct ObscuredInt : IEquatable<ObscuredInt>
    {
        private ObscuredLong inner;

        public static ObscuredInt From(int value)
        {
            var o = new ObscuredInt();
            o.Set(value);
            return o;
        }

        public int  Get(string keyForReport = null) => (int)inner.Get(keyForReport);
        public void Set(int value) => inner.Set(value);
        public bool IsIntact() => inner.IsIntact();

        public bool Equals(ObscuredInt other) => Get() == other.Get();
        public override bool Equals(object obj) => obj is ObscuredInt o && Equals(o);
        public override int GetHashCode() => Get();
        public override string ToString() => Get().ToString();

        public static implicit operator int(ObscuredInt v) => v.Get();
        public static implicit operator ObscuredInt(int v) => From(v);
    }

    [Serializable]
    public struct ObscuredFloat : IEquatable<ObscuredFloat>
    {
        private ObscuredLong inner;

        public static ObscuredFloat From(float value)
        {
            var o = new ObscuredFloat();
            o.Set(value);
            return o;
        }

        public float Get(string keyForReport = null)
        {
            FloatBits fb = default;
            fb.AsInt = (int)inner.Get(keyForReport);
            return fb.AsFloat;
        }

        public void Set(float value)
        {
            FloatBits fb = default;
            fb.AsFloat = value;
            inner.Set(fb.AsInt);
        }

        public bool IsIntact() => inner.IsIntact();

        public bool Equals(ObscuredFloat other) => Get().Equals(other.Get());
        public override bool Equals(object obj) => obj is ObscuredFloat o && Equals(o);
        public override int GetHashCode() => Get().GetHashCode();
        public override string ToString() => Get().ToString();

        public static implicit operator float(ObscuredFloat v) => v.Get();
        public static implicit operator ObscuredFloat(float v) => From(v);
    }

    [Serializable]
    public struct ObscuredBool : IEquatable<ObscuredBool>
    {
        private const long TrueBits  = 0x5A5A5A5AL;
        private const long FalseBits = 0x2D2D2D2DL;

        private ObscuredLong inner;

        public static ObscuredBool From(bool value)
        {
            var o = new ObscuredBool();
            o.Set(value);
            return o;
        }

        public bool Get(string keyForReport = null) => inner.Get(keyForReport) == TrueBits;

        public void Set(bool value) => inner.Set(value ? TrueBits : FalseBits);

        public bool IsIntact() => inner.IsIntact();

        public bool Equals(ObscuredBool other) => Get() == other.Get();
        public override bool Equals(object obj) => obj is ObscuredBool o && Equals(o);
        public override int GetHashCode() => Get() ? 1 : 0;
        public override string ToString() => Get().ToString();

        public static implicit operator bool(ObscuredBool v) => v.Get();
        public static implicit operator ObscuredBool(bool v) => From(v);
    }
}
