using System;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;

namespace CorruptedDesign.Data
{
    internal static class VaultGuard
    {
        private const int IdStep = 0x2545F491;

        private static long sessionKey;
        private static int  nextId;
        private static uint rngState;

        private static void EnsureInit()
        {
            if (sessionKey != 0) return;

            var seed = new byte[12];
            using (var rng = RandomNumberGenerator.Create())
                rng.GetBytes(seed);

            sessionKey = BitConverter.ToInt64(seed, 0);
            if (sessionKey == 0) sessionKey = unchecked((long)0x9E3779B97F4A7C15UL);

            rngState = BitConverter.ToUInt32(seed, 8);
            if (rngState == 0) rngState = 0x6D2B79F5u;

            nextId = (int)(rngState & 0x00FFFFFF) | 1;
        }

        public static int NewId()
        {
            EnsureInit();
            unchecked { nextId += IdStep; }
            if (nextId == 0) nextId = 1;
            return nextId;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static long MaskFor(int id)
        {
            EnsureInit();
            unchecked
            {
                ulong x = (ulong)(uint)id * 0x9E3779B97F4A7C15UL;
                x ^= (ulong)sessionKey;
                x ^= x >> 33;
                x *= 0xFF51AFD7ED558CCDUL;
                x ^= x >> 33;
                x *= 0xC4CEB9FE1A85EC53UL;
                x ^= x >> 33;
                return (long)x;
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static int Checksum(int id, long bits)
        {
            EnsureInit();
            unchecked
            {
                ulong x = (ulong)bits ^ ((ulong)(uint)id * 0xD6E8FEB86659FD93UL) ^ (ulong)sessionKey;
                x ^= x >> 32;
                x *= 0xD6E8FEB86659FD93UL;
                x ^= x >> 32;
                return (int)x;
            }
        }

        public static int NextRandom()
        {
            EnsureInit();
            unchecked
            {
                rngState ^= rngState << 13;
                rngState ^= rngState >> 17;
                rngState ^= rngState << 5;
                return (int)(rngState & 0x7FFFFFFF);
            }
        }
    }

    internal sealed class VaultMemoryGuard : IVaultMemoryGuard
    {
        public void Encode(long value, out long stored, out int token, out int check)
        {
            token  = VaultGuard.NewId();
            stored = value ^ VaultGuard.MaskFor(token);
            check  = VaultGuard.Checksum(token, value);
        }

        public bool TryDecode(long stored, int token, int check, out long value)
        {
            value = stored ^ VaultGuard.MaskFor(token);

            if (VaultGuard.Checksum(token, value) == check) return true;

            value = 0L;
            return false;
        }

        public bool IsIntact(long stored, int token, int check) =>
            VaultGuard.Checksum(token, stored ^ VaultGuard.MaskFor(token)) == check;
    }
}
