using System;
using System.Security.Cryptography;
using System.Text;

namespace CorruptedDesign.Data
{
    internal static class VaultKeyName
    {
        private const string KeyPrefix = "sc_";

        private static readonly byte[] KeyNameHmacSecret = Encoding.UTF8.GetBytes("MyGame_SecretK3y");

        public static string Hash(string key)
        {
            using var hmac = new HMACSHA256(KeyNameHmacSecret);
            var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(KeyPrefix + key));
            return Convert.ToBase64String(hash, 0, 16)
                .Replace('+', '-').Replace('/', '_').Replace("=", "");
        }
    }
}
