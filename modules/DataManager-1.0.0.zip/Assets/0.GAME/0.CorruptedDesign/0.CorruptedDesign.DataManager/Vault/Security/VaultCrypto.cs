using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using UnityEngine;

namespace CorruptedDesign.Data
{
    public static class VaultCrypto
    {
        private static readonly byte[] Magic = { (byte)'P', (byte)'X', (byte)'V', (byte)'T' };

        private const byte VersionAes256 = 0x04;
        private const byte VersionCurrent = VersionAes256;

        private const int  HeaderLength  = 5;
        private const int  IvLength      = 16;
        private const int  TagLength     = 32;
        private const int  AesBlockBytes = 16;

        private const int MinBlobLength = HeaderLength + IvLength + AesBlockBytes + TagLength;

        public const string BlobPrefix = "pv:";

        public const string V2Prefix = "v2:";

        private const string KeySeed           = "MyGame_SecretK3y";
        private const int    Pbkdf2Iterations  = 10_000;
        private const int    V2KeyLength       = 16;
        private const int    EncKeyLength      = 32;
        private const int    MacKeyLength      = 32;
        private const int    MasterKeyLength   = V2KeyLength + EncKeyLength + MacKeyLength;

        private const string SaltPrefKey  = "sc__install_salt";
        private const string SaltFileName = "sc_salt.bin";
        private const int    SaltLength   = 16;

        public static bool TamperDetected { get; private set; }

        private sealed class KeySet
        {
            public byte[] V2;
            public byte[] Enc;
            public byte[] Mac;
        }

        private static volatile KeySet keys;
        private static readonly object KeySync = new object();

        private static string cachedDataPath;

        private static string DataPath
        {
            get
            {
                if (string.IsNullOrEmpty(cachedDataPath))
                    cachedDataPath = Application.persistentDataPath;
                return cachedDataPath;
            }
        }

        private static string SaltFilePath => Path.Combine(DataPath, SaltFileName);

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        public static void Prime()
        {
            cachedDataPath = Application.persistentDataPath;
            EnsureKeys();
        }

        public static void ResetKeyCache()
        {
            lock (KeySync)
            {
                keys = null;
                TamperDetected = false;
            }
        }

        public static void DeleteSaltAndResetKeys()
        {
            DeleteSaltFile();
            PlayerPrefs.DeleteKey(SaltPrefKey);
            ResetKeyCache();
        }

        public static byte[] Seal(byte[] plain, string aad)
        {
            if (plain == null) plain = Array.Empty<byte>();
            var k = Keys;

            using var aes = Aes.Create();
            aes.Key     = k.Enc;
            aes.Mode    = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;
            aes.GenerateIV();

            byte[] cipher;
            using (var enc = aes.CreateEncryptor())
                cipher = enc.TransformFinalBlock(plain, 0, plain.Length);

            var blob = new byte[HeaderLength + IvLength + cipher.Length + TagLength];
            Buffer.BlockCopy(Magic,   0, blob, 0, Magic.Length);
            blob[4] = VersionCurrent;
            Buffer.BlockCopy(aes.IV,  0, blob, HeaderLength, IvLength);
            Buffer.BlockCopy(cipher,  0, blob, HeaderLength + IvLength, cipher.Length);

            int macedLength = blob.Length - TagLength;
            var tag = ComputeTag(k.Mac, blob, macedLength, aad);
            Buffer.BlockCopy(tag, 0, blob, macedLength, TagLength);

            return blob;
        }

        public static bool TryOpen(byte[] blob, string aad, out byte[] plain)
        {
            plain = null;
            if (!HasMagic(blob)) return false;

            if (blob.Length < MinBlobLength)
            {
                Debug.LogError($"[VaultCrypto] Blob hỏng: length={blob.Length}.");
                return false;
            }

            if (blob[4] != VersionAes256)
            {
                Debug.LogError($"[VaultCrypto] Version blob không hỗ trợ: 0x{blob[4]:X2}. " +
                               $"Build này đọc được tối đa 0x{VersionCurrent:X2}.");
                return false;
            }

            int macedLength  = blob.Length - TagLength;
            int cipherLength = macedLength - HeaderLength - IvLength;
            if (cipherLength <= 0 || cipherLength % AesBlockBytes != 0)
            {
                Debug.LogError($"[VaultCrypto] Độ dài ciphertext không hợp lệ: {cipherLength}.");
                return false;
            }

            var k = Keys;

            var expected = ComputeTag(k.Mac, blob, macedLength, aad);
            if (!ConstantTimeEquals(expected, 0, blob, macedLength, TagLength))
            {
                TamperDetected = true;
                Debug.LogError($"[VaultCrypto] Verify MAC thất bại (aad='{aad}') — dữ liệu bị sửa từ bên ngoài, " +
                               "hoặc khóa đã đổi. Từ chối giải mã.");
                return false;
            }

            try
            {
                var iv = new byte[IvLength];
                Buffer.BlockCopy(blob, HeaderLength, iv, 0, IvLength);

                using var aes = Aes.Create();
                aes.Key     = k.Enc;
                aes.IV      = iv;
                aes.Mode    = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;

                using var dec = aes.CreateDecryptor();
                plain = dec.TransformFinalBlock(blob, HeaderLength + IvLength, cipherLength);
                return true;
            }
            catch (Exception e)
            {
                Debug.LogError($"[VaultCrypto] Decrypt thất bại sau khi verify MAC OK: {e.Message}");
                return false;
            }
        }

        public static bool HasMagic(byte[] blob)
        {
            if (blob == null || blob.Length < HeaderLength) return false;
            for (int i = 0; i < Magic.Length; i++)
                if (blob[i] != Magic[i]) return false;
            return true;
        }

        public static string SealToString(string plain, string aad)
        {
            var blob = Seal(Encoding.UTF8.GetBytes(plain ?? string.Empty), aad);
            return BlobPrefix + Convert.ToBase64String(blob);
        }

        public static bool TryOpenString(string stored, string aad, out string plain)
        {
            plain = null;
            if (string.IsNullOrEmpty(stored) || !stored.StartsWith(BlobPrefix, StringComparison.Ordinal))
                return false;

            byte[] blob;
            try
            {
                blob = Convert.FromBase64String(stored.Substring(BlobPrefix.Length));
            }
            catch
            {
                Debug.LogError("[VaultCrypto] Base64 không hợp lệ ở blob v3.");
                return false;
            }

            if (!TryOpen(blob, aad, out var bytes)) return false;
            plain = Encoding.UTF8.GetString(bytes);
            return true;
        }

        public static bool TryOpenV2(string stored, out string plain)
        {
            plain = null;
            if (string.IsNullOrEmpty(stored) || !stored.StartsWith(V2Prefix, StringComparison.Ordinal))
                return false;

            try
            {
                var combined = Convert.FromBase64String(stored.Substring(V2Prefix.Length));
                if (combined.Length <= IvLength) return false;

                var iv     = new byte[IvLength];
                var cipher = new byte[combined.Length - IvLength];
                Buffer.BlockCopy(combined, 0, iv, 0, IvLength);
                Buffer.BlockCopy(combined, IvLength, cipher, 0, cipher.Length);

                using var aes = Aes.Create();
                aes.Key     = Keys.V2;
                aes.IV      = iv;
                aes.Mode    = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;

                using var dec = aes.CreateDecryptor();
                plain = Encoding.UTF8.GetString(dec.TransformFinalBlock(cipher, 0, cipher.Length));
                return true;
            }
            catch
            {
                Debug.LogWarning("[VaultCrypto] Đọc dữ liệu v2 thất bại.");
                return false;
            }
        }

        private static byte[] ComputeTag(byte[] macKey, byte[] blob, int length, string aad)
        {
            var aadBytes = string.IsNullOrEmpty(aad) ? Array.Empty<byte>() : Encoding.UTF8.GetBytes(aad);
            if (aadBytes.Length > ushort.MaxValue)
                throw new ArgumentException($"AAD quá dài: {aadBytes.Length} byte.", nameof(aad));

            var aadLen = new byte[2];
            aadLen[0] = (byte)(aadBytes.Length & 0xFF);
            aadLen[1] = (byte)((aadBytes.Length >> 8) & 0xFF);

            using var hmac = new HMACSHA256(macKey);
            hmac.TransformBlock(blob, 0, length, null, 0);
            hmac.TransformBlock(aadLen, 0, aadLen.Length, null, 0);
            hmac.TransformFinalBlock(aadBytes, 0, aadBytes.Length);
            return hmac.Hash;
        }

        private static bool ConstantTimeEquals(byte[] a, int aOffset, byte[] b, int bOffset, int length)
        {
            int diff = 0;
            for (int i = 0; i < length; i++)
                diff |= a[aOffset + i] ^ b[bOffset + i];
            return diff == 0;
        }

        private static KeySet Keys
        {
            get
            {
                var k = keys;
                if (k != null) return k;
                EnsureKeys();
                return keys;
            }
        }

        private static void EnsureKeys()
        {
            if (keys != null) return;

            lock (KeySync)
            {
                if (keys != null) return;

                var salt = LoadOrCreateSalt();
                var v2   = new byte[V2KeyLength];
                var enc  = new byte[EncKeyLength];
                var mac  = new byte[MacKeyLength];

                using (var pbkdf2 = new Rfc2898DeriveBytes(KeySeed, salt, Pbkdf2Iterations, HashAlgorithmName.SHA256))
                {
                    var master = pbkdf2.GetBytes(MasterKeyLength);
                    Buffer.BlockCopy(master, 0,                         v2,  0, V2KeyLength);
                    Buffer.BlockCopy(master, V2KeyLength,               enc, 0, EncKeyLength);
                    Buffer.BlockCopy(master, V2KeyLength + EncKeyLength, mac, 0, MacKeyLength);
                    Array.Clear(master, 0, master.Length);
                }

                keys = new KeySet { V2 = v2, Enc = enc, Mac = mac };
            }
        }

        private static byte[] LoadOrCreateSalt()
        {
            var fromPrefs = TryParseSalt(PlayerPrefs.GetString(SaltPrefKey, null));
            var fromFile  = TryParseSalt(ReadSaltFile());

            if (fromPrefs != null)
            {
                if (fromFile == null || !SaltEquals(fromPrefs, fromFile))
                    WriteSaltFile(Convert.ToBase64String(fromPrefs));
                return fromPrefs;
            }

            if (fromFile != null)
            {
                Debug.LogWarning("[VaultCrypto] Salt trong PlayerPrefs bị mất — khôi phục từ file backup.");
                PersistSaltToPrefs(Convert.ToBase64String(fromFile));
                return fromFile;
            }

            var salt = new byte[SaltLength];
            using (var rng = RandomNumberGenerator.Create())
                rng.GetBytes(salt);

            var b64 = Convert.ToBase64String(salt);
            PersistSaltToPrefs(b64);
            WriteSaltFile(b64);
            return salt;
        }

        private static byte[] TryParseSalt(string b64)
        {
            if (string.IsNullOrEmpty(b64)) return null;
            try
            {
                var salt = Convert.FromBase64String(b64);
                return salt.Length == SaltLength ? salt : null;
            }
            catch
            {
                return null;
            }
        }

        private static bool SaltEquals(byte[] a, byte[] b)
        {
            if (a.Length != b.Length) return false;
            for (int i = 0; i < a.Length; i++)
                if (a[i] != b[i]) return false;
            return true;
        }

        private static void PersistSaltToPrefs(string b64)
        {
            PlayerPrefs.SetString(SaltPrefKey, b64);
            PlayerPrefs.Save();

            if (PlayerPrefs.GetString(SaltPrefKey, null) != b64)
                Debug.LogError("[VaultCrypto] Ghi salt vào PlayerPrefs thất bại — dữ liệu mã hóa có thể mất ở lần chạy sau.");
        }

        private static string ReadSaltFile()
        {
            try
            {
                return File.Exists(SaltFilePath) ? File.ReadAllText(SaltFilePath, Encoding.UTF8) : null;
            }
            catch (Exception e)
            {
                Debug.LogWarning($"[VaultCrypto] Đọc salt file lỗi: {e.Message}");
                return null;
            }
        }

        private static void WriteSaltFile(string b64)
        {
            try
            {
                Directory.CreateDirectory(DataPath);
                File.WriteAllText(SaltFilePath, b64, Encoding.UTF8);
            }
            catch (Exception e)
            {
                Debug.LogWarning($"[VaultCrypto] Ghi salt file lỗi: {e.Message}");
            }
        }

        private static void DeleteSaltFile()
        {
            try
            {
                if (File.Exists(SaltFilePath)) File.Delete(SaltFilePath);
            }
            catch (Exception e)
            {
                Debug.LogWarning($"[VaultCrypto] Xóa salt file lỗi: {e.Message}");
            }
        }
    }
}
