using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CorruptedDesign.Data
{
    public static class VaultIntegrity
    {
        public const float MinScanInterval = 4f;
        public const float MaxScanInterval = 11f;

        public static bool Enabled = true;
        public static bool VerifyAgainstStorageOnScan = false;

        public static readonly IVaultWatchdog Watchdog = new Adapter();

        private sealed class Adapter : IVaultWatchdog
        {
            public bool Enabled
            {
                get => VaultIntegrity.Enabled;
                set => VaultIntegrity.Enabled = value;
            }

            public void Register(IVaultGuarded target) => VaultIntegrity.Register(target);
            public void Unregister(IVaultGuarded target) => VaultIntegrity.Unregister(target);
            public int RegisterHoneypot(string key, Func<int> truth) => VaultIntegrity.RegisterHoneypot(key, truth);
            public void SyncHoneypot(int handle) => VaultIntegrity.SyncHoneypot(handle);
            public int ScanNow() => VaultIntegrity.ScanNow();
            public void Clear() => VaultIntegrity.Clear();
        }

        private static readonly List<IVaultGuarded> Guarded = new List<IVaultGuarded>();
        private static readonly List<Honeypot> Honeypots = new List<Honeypot>();

        private static Runner runner;

        private sealed class Honeypot
        {
            public string Key;
            public Func<int> Truth;

            public int Decoy;
            public ObscuredInt LastSet;

            public void Refresh()
            {
                Decoy = Truth();
                LastSet.Set(Decoy);
            }

            public bool WasEditedFromOutside() => Decoy != LastSet.Get();
        }

        private static bool runtimeReady;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void MarkRuntime()
        {
            runtimeReady = true;
            Guarded.Clear();
            Honeypots.Clear();
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void Boot() => EnsureRunner();

        public static void Register(IVaultGuarded target)
        {
            if (target == null || !runtimeReady) return;
            if (!Guarded.Contains(target)) Guarded.Add(target);
        }

        public static void Unregister(IVaultGuarded target)
        {
            if (target != null) Guarded.Remove(target);
        }

        public static int RegisterHoneypot(string key, Func<int> truth)
        {
            if (truth == null || !runtimeReady) return -1;

            var pot = new Honeypot { Key = key, Truth = truth };
            pot.Refresh();
            Honeypots.Add(pot);
            return Honeypots.Count - 1;
        }

        public static void SyncHoneypot(int handle)
        {
            if (handle < 0 || handle >= Honeypots.Count) return;
            Honeypots[handle].Refresh();
        }

        public static int PeekHoneypot(int handle)
        {
            if (handle < 0 || handle >= Honeypots.Count) return 0;
            return Honeypots[handle].Decoy;
        }

        public static void SetHoneypot(int handle, int value)
        {
            if (handle < 0 || handle >= Honeypots.Count) return;
            Honeypots[handle].Decoy = value;
        }

        public static int ScanNow()
        {
            int problems = 0;

            for (int i = 0; i < Guarded.Count; i++)
            {
                var g = Guarded[i];
                if (g == null) continue;

                if (!g.VerifyIntegrity()) problems++;
                else if (VerifyAgainstStorageOnScan && !g.VerifyAgainstStorage()) problems++;
            }

            for (int i = 0; i < Honeypots.Count; i++)
            {
                var pot = Honeypots[i];

                if (pot.WasEditedFromOutside())
                {
                    VaultSecurity.Report(VaultTamperKind.Honeypot, pot.Key,
                        $"mồi bị sửa từ ngoài: {pot.Decoy}");
                    problems++;
                }

                pot.Refresh();
            }

            return problems;
        }

        public static void Clear()
        {
            Guarded.Clear();
            Honeypots.Clear();
        }

        private static void EnsureRunner()
        {
            if (runner != null || !runtimeReady) return;

            var go = new GameObject("VaultIntegrity");
            UnityEngine.Object.DontDestroyOnLoad(go);
            go.hideFlags = HideFlags.HideInHierarchy;
            runner = go.AddComponent<Runner>();
        }

        private sealed class Runner : MonoBehaviour
        {
            private void Start() => StartCoroutine(ScanLoop());

            private IEnumerator ScanLoop()
            {
                while (true)
                {
                    float span = MaxScanInterval - MinScanInterval;
                    float wait = MinScanInterval + (VaultGuard.NextRandom() % 1000) / 1000f * span;
                    yield return new WaitForSecondsRealtime(wait);

                    if (Enabled) ScanNow();
                }
            }
        }
    }
}
