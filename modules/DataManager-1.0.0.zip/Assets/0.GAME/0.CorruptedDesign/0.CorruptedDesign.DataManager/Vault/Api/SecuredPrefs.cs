using System.Collections.Generic;
using UnityEngine;

namespace CorruptedDesign.Data
{
    public static class SecuredPrefs
    {
        private const string CanaryKey   = "sc__key_canary";
        private const string CanaryPlain = "corrupteddesign-vault-v2";

        public static bool KeyMismatchDetected { get; private set; }

        private static bool canaryChecked;
        private static readonly HashSet<string> unreadableKeys = new();

        private static IVaultCipher Cipher => VaultSecurityPort.Cipher;

        public static void SetInt   (string key, int    value) => Write(key, value.ToString());
        public static void SetFloat (string key, float  value) => Write(key, value.ToString("R"));
        public static void SetString(string key, string value) => Write(key, value ?? string.Empty);
        public static void SetBool  (string key, bool   value) => Write(key, value ? "1" : "0");

        public static int    GetInt   (string key, int    def = 0)     => TryRead(key, out var r) && int.TryParse(r, out var i)    ? i   : def;
        public static float  GetFloat (string key, float  def = 0f)    => TryRead(key, out var r) && float.TryParse(r, out var f)  ? f   : def;
        public static string GetString(string key, string def = "")    => TryRead(key, out var r)                                  ? r   : def;
        public static bool   GetBool  (string key, bool   def = false) => TryRead(key, out var r)                                  ? r == "1" : def;

        public static bool HasKey   (string key) => PlayerPrefs.HasKey(HashKey(key));
        public static void DeleteKey(string key) => PlayerPrefs.DeleteKey(HashKey(key));
        public static void Save()                => PlayerPrefs.Save();

        public static string GetStorageKey(string key) => HashKey(key);

        public static void DeleteAll()
        {
            PlayerPrefs.DeleteAll();
            PlayerPrefs.Save();
            Cipher.DeleteKeysAndSalt();
            ResetKeyCache();
        }

        public static void ResetKeyCache()
        {
            Cipher.ResetKeys();
            canaryChecked = false;
            KeyMismatchDetected = false;
            unreadableKeys.Clear();
        }

        private static void Write(string key, string plain)
        {
            EnsureCanary();
            var hk = HashKey(key);
            if (unreadableKeys.Remove(hk)) KeepUnreadable(hk, key);
            PlayerPrefs.SetString(hk, Cipher.SealToString(plain, key));
        }

        private static bool TryRead(string key, out string plain)
        {
            plain = null;
            EnsureCanary();

            var hk = HashKey(key);
            if (!PlayerPrefs.HasKey(hk)) return false;

            var stored = PlayerPrefs.GetString(hk);
            if (string.IsNullOrEmpty(stored)) return false;

            if (Cipher.TryOpenString(stored, key, out plain)) return true;

            if (Cipher.TryOpenLegacy(stored, out plain))
            {
                PlayerPrefs.SetString(hk, Cipher.SealToString(plain, key));
                return true;
            }

            unreadableKeys.Add(hk);
            return false;
        }

        // Only the first unreadable copy is kept: it holds the original data, not a later default.
        private static void KeepUnreadable(string hk, string key)
        {
            var backup = hk + "_unreadable";
            if (PlayerPrefs.HasKey(backup)) return;
            PlayerPrefs.SetString(backup, PlayerPrefs.GetString(hk));
            Debug.LogError($"[SecuredPrefs] '{key}' could not be decrypted; old blob kept at {backup} before overwrite.");
        }

        private static string HashKey(string key) => Cipher.HashKeyName(key);

        private static void EnsureCanary()
        {
            if (canaryChecked) return;
            canaryChecked = true;

            if (!VaultSecurityPort.Encrypts) return;

            var hk = HashKey(CanaryKey);

            if (PlayerPrefs.HasKey(hk))
            {
                var stored = PlayerPrefs.GetString(hk);

                if (Cipher.TryOpenString(stored, CanaryKey, out var plain) && plain == CanaryPlain)
                    return;

                if (Cipher.TryOpenLegacy(stored, out var plainV2) && plainV2 == CanaryPlain)
                {
                    WriteCanary(hk);
                    return;
                }

                KeyMismatchDetected = true;
                Debug.LogError("[SecuredPrefs] Khóa hiện tại không mở được canary — salt đã đổi. " +
                               "Toàn bộ dữ liệu SecuredPrefs cũ không thể phục hồi.");
            }

            WriteCanary(hk);
        }

        private static void WriteCanary(string hashedKey)
        {
            PlayerPrefs.SetString(hashedKey, Cipher.SealToString(CanaryPlain, CanaryKey));
            PlayerPrefs.Save();
        }
    }
}
