# Tích hợp tầng Security với package save/load khác

Guide này nói cụ thể: **tạo class nào, implement interface nào, gọi hàm nào, ở thời điểm nào.**

Tầng `Security/` không biết `Vault<T>` hay `SecuredPrefs` tồn tại. Toàn bộ liên lạc đi qua `Contract/`,
và signature trong `Contract/` chỉ dùng kiểu BCL (`byte[]`, `string`, `long`, `int`) — không có kiểu
nào của tầng save/load lọt vào. Nhờ vậy hai chiều thay thế đều mở.

Chọn đường theo tình huống của bạn:

| Tình huống | Đọc mục |
|---|---|
| Có package save/load riêng, muốn dùng crypto của CorruptedDesign | **[Đường A](#đường-a--dùng-securityhiện-có-cho-tầng-saveload-của-bạn)** |
| Dùng package save/load của người khác, không sửa được source | **[Đường A.5](#a5-package-saveload-không-sửa-được-source)** |
| Muốn tự viết crypto / anti-cheat, cắm vào `Api/` của CorruptedDesign hoặc host khác | **[Đường B](#đường-b--tự-viết-tầng-security)** |
| Chỉ muốn bỏ security | Xóa folder `Security/`. Xem README mục 1.2 |

---

## 0. Chuẩn bị

Copy sang project mới, giữ nguyên tên folder:

```
Vault/
  Contract/     ← BẮT BUỘC. Cả hai đường đều cần
  Security/     ← chỉ cần ở Đường A (implement sẵn của CorruptedDesign)
```

Cả hai folder dùng namespace `CorruptedDesign.Data`, không có asmdef, không phụ thuộc `Api/`. Yêu cầu duy nhất
ngoài Unity: **không có** — `Contract/` và `Security/` chỉ dùng `System.*` + `UnityEngine`.
(`Api/` mới là chỗ cần Newtonsoft.Json và Odin.)

Kiểm nhanh sau khi copy:

```bash
grep -rn "Vault<\|SecuredPrefs\|JsonFileStore\|VaultBackend\|Newtonsoft\|Sirenix" Contract/ Security/
# phải rỗng
```

---

## 1. Bản đồ hợp đồng

Bốn thứ bạn sẽ chạm tới. Tất cả ở namespace `CorruptedDesign.Data`.

### 1.1 `VaultSecurityPort` — điểm cắm và điểm gọi

```csharp
public static class VaultSecurityPort
{
    public static IVaultCipher      Cipher      { get; }   // KHÔNG BAO GIỜ null (fallback bản trần)
    public static IVaultMemoryGuard MemoryGuard { get; }   // KHÔNG BAO GIỜ null (fallback bản trần)
    public static IVaultWatchdog    Watchdog    { get; }   // CÓ THỂ null → dùng facade VaultWatch

    public static bool Encrypts     { get; }   // true khi đã cắm cipher thật
    public static bool GuardsMemory { get; }   // true khi đã cắm memory guard thật

    public static void InstallCipher(IVaultCipher impl);
    public static void InstallMemoryGuard(IVaultMemoryGuard impl);
    public static void InstallWatchdog(IVaultWatchdog impl);
    public static void Install(IVaultCipher c, IVaultMemoryGuard g, IVaultWatchdog w);
    public static void Uninstall();
}
```

`Cipher` và `MemoryGuard` không bao giờ null nên **không cần null-check** ở chỗ dùng. Cái cần check là
`Encrypts` — dùng nó khi quyết định "có từ chối dữ liệu trần hay không" (xem [mục 5](#5-ràng-buộc-bắt-buộc)).

### 1.2 `IVaultCipher` — 12 method

```csharp
public interface IVaultCipher
{
    byte[] Seal(byte[] plain, string aad);
    bool   TryOpen(byte[] blob, string aad, out byte[] plain);
    bool   IsSealedBlob(byte[] blob);

    string SealToString(string plain, string aad);
    bool   TryOpenString(string stored, string aad, out string plain);
    bool   IsSealedString(string stored);

    bool   IsLegacyString(string stored);
    bool   TryOpenLegacy(string stored, out string plain);

    string HashKeyName(string key);

    void   Prime();
    void   ResetKeys();
    void   DeleteKeysAndSalt();
}
```

| Method | Dùng khi | Bản trần trả gì |
|---|---|---|
| `Seal` | ghi blob nhị phân (1 file) | `plain` |
| `TryOpen` | đọc blob nhị phân | `plain = blob`, `true` |
| `IsSealedBlob` | phân loại file **trước** khi quyết định giải mã | `false` |
| `SealToString` | ghi 1 ô dạng string (PlayerPrefs...) | `plain` |
| `TryOpenString` | đọc 1 ô dạng string | `plain = stored`, `true` |
| `IsSealedString` | gắn nhãn trạng thái (editor tool) | `false` |
| `IsLegacyString` / `TryOpenLegacy` | đọc format cũ để nâng cấp dần | `false` |
| `HashKeyName` | đặt tên slot trên storage | `key` |
| `Prime` | derive khóa sớm, cache path — gọi ở splash | no-op |
| `ResetKeys` | sau khi khôi phục dữ liệu từ ngoài (cloud save) | no-op |
| `DeleteKeysAndSalt` | xóa sạch dữ liệu người chơi | no-op |

### 1.3 `IVaultMemoryGuard` — 3 method

```csharp
public interface IVaultMemoryGuard
{
    void Encode(long value, out long stored, out int token, out int check);
    bool TryDecode(long stored, int token, int check, out long value);
    bool IsIntact(long stored, int token, int check);
}
```

Đây là phần đằng sau `ObscuredInt / ObscuredLong / ObscuredFloat / ObscuredBool` (ở
`Contract/VaultGuardedTypes.cs`). Ba field `stored` (8 byte) + `token` (4 byte) + `check` (4 byte) là
**toàn bộ chỗ chứa** mà mỗi ô cấp cho bạn.

### 1.4 `IVaultWatchdog` + `IVaultGuarded` + `VaultWatch`

```csharp
public interface IVaultGuarded
{
    string GuardKey { get; }
    bool VerifyIntegrity();        // giá trị trong RAM còn nguyên?
    bool VerifyAgainstStorage();   // RAM có khớp bản đã seal trên đĩa?
}

public interface IVaultWatchdog
{
    bool Enabled { get; set; }
    void Register(IVaultGuarded target);
    void Unregister(IVaultGuarded target);
    int  RegisterHoneypot(string key, Func<int> truth);
    void SyncHoneypot(int handle);
    int  ScanNow();
    void Clear();
}
```

Code gọi **luôn đi qua facade `VaultWatch`**, không gọi `IVaultWatchdog` trực tiếp:

```csharp
VaultWatch.Register(myGuardedObject);                          // no-op nếu chưa cắm watchdog
int h = VaultWatch.RegisterHoneypot("Coin", () => wallet.Coin); // trả -1 nếu chưa cắm
VaultWatch.ScanNow();                                           // trả 0 nếu chưa cắm
VaultWatch.Enabled = false;
bool có = VaultWatch.Installed;
```

Nhờ vậy code gọi không cần `#if` hay null-check, và vẫn compile khi đã xóa `Security/`.

### 1.5 `VaultSecurity` — kênh báo động chung

```csharp
public enum VaultTamperKind { ObscuredValue, Honeypot, DiskMismatch, Ledger, MacFail }

public static class VaultSecurity
{
    public static event Action<VaultTamperEvent> OnTamperDetected;

    public static int              TamperCount       { get; }
    public static bool             AnyTamperDetected { get; }
    public static VaultTamperKind  LastKind          { get; }
    public static string           LastKey           { get; }
    public static bool             LogToConsole;

    public static void Report(VaultTamperKind kind, string key, string detail);
    public static void ResetCounters();
}
```

Nằm ở `Contract/` **cố ý**: nó là kênh thông báo, không phải logic bảo mật. Mọi bên phát hiện tamper
đều gọi `VaultSecurity.Report(...)`, game chỉ đăng ký một chỗ. **Đừng dựng event riêng trong implement
của bạn.**

---

## Đường A — dùng `Security/` hiện có cho tầng save/load của bạn

Copy `Contract/` + `Security/`. `VaultSecurityInstaller` trong `Security/` **tự cắm** ở
`SubsystemRegistration` — bạn **không phải tạo class nào cả**. Việc còn lại là gọi port ở đúng chỗ.

### A.1 Bảng điểm gọi

| Trong store của bạn | Gọi cái này |
|---|---|
| Đặt tên slot / tên file con | `VaultSecurityPort.Cipher.HashKeyName(key)` |
| Ghi 1 ô dạng string | `VaultSecurityPort.Cipher.SealToString(plain, key)` |
| Đọc 1 ô dạng string | `VaultSecurityPort.Cipher.TryOpenString(stored, key, out plain)` |
| Đọc ô format cũ, nâng cấp dần | `Cipher.TryOpenLegacy(stored, out plain)` → mở được thì `SealToString` ghi đè lại |
| Ghi cả file nhị phân | `VaultSecurityPort.Cipher.Seal(bytes, aadCủaFile)` |
| Đọc cả file nhị phân | `Cipher.IsSealedBlob(raw)` → `Cipher.TryOpen(raw, aadCủaFile, out plain)` |
| Quyết định có mã hóa hay không | `!Application.isEditor && VaultSecurityPort.Encrypts` |
| Quyết định có từ chối dữ liệu trần hay không | **cùng biểu thức trên** — xem [mục 5](#5-ràng-buộc-bắt-buộc) |
| Xóa sạch dữ liệu (`DeleteAll`) | `VaultSecurityPort.Cipher.DeleteKeysAndSalt()` |
| Sau khi restore dữ liệu từ ngoài | `VaultSecurityPort.Cipher.ResetKeys()` |
| Ở splash, trước khi load nền | `VaultSecurityPort.Cipher.Prime()` |
| Phát hiện dữ liệu bị sửa | `VaultSecurity.Report(VaultTamperKind.MacFail, key, detail)` |

### A.2 Store dạng key–value (PlayerPrefs, registry, SQLite...)

```csharp
using CorruptedDesign.Data;
using UnityEngine;

public static class MyStore
{
    private static IVaultCipher Cipher => VaultSecurityPort.Cipher;

    public static void SetString(string key, string value)
    {
        var slot   = Cipher.HashKeyName(key);
        var stored = Cipher.SealToString(value ?? string.Empty, key);   // aad = TÊN KEY GỐC
        PlayerPrefs.SetString(slot, stored);
    }

    public static bool TryGetString(string key, out string value)
    {
        value = null;

        var slot = Cipher.HashKeyName(key);
        if (!PlayerPrefs.HasKey(slot)) return false;

        var stored = PlayerPrefs.GetString(slot);
        if (string.IsNullOrEmpty(stored)) return false;

        if (Cipher.TryOpenString(stored, key, out value)) return true;

        if (Cipher.TryOpenLegacy(stored, out value))
        {
            PlayerPrefs.SetString(slot, Cipher.SealToString(value, key));
            return true;
        }

        return false;
    }

    public static void DeleteAll()
    {
        PlayerPrefs.DeleteAll();
        PlayerPrefs.Save();
        Cipher.DeleteKeysAndSalt();
    }
}
```

`aad` là **tên key gốc**, không phải `slot`. Đó là thứ ràng buộc blob với đúng ô của nó: chép giá trị
đã mã hóa từ `highest_score` sang `coin` sẽ verify fail.

### A.3 Store dạng 1 file

```csharp
using System.IO;
using System.Text;
using CorruptedDesign.Data;
using UnityEngine;

public static class MyFileStore
{
    private const string FileName  = "mysave.dat";
    private const string CryptoAad = "MyFileStore:" + FileName;   // hằng, định danh CHÍNH FILE này

    private static string path;
    private static bool?  outsideEditor;

    private static bool EncryptOnDisk
    {
        get
        {
            if (outsideEditor == null) outsideEditor = !Application.isEditor;
            return outsideEditor.Value && VaultSecurityPort.Encrypts;
        }
    }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void Prime()
    {
        path          = Path.Combine(Application.persistentDataPath, FileName);
        outsideEditor = !Application.isEditor;
        VaultSecurityPort.Cipher.Prime();          // derive khóa ngay tại đây, trên main thread
    }

    public static void Save(string json)
    {
        var payload = EncryptOnDisk
            ? VaultSecurityPort.Cipher.Seal(Encoding.UTF8.GetBytes(json), CryptoAad)
            : Encoding.UTF8.GetBytes(json);

        File.WriteAllBytes(path, payload);
    }

    public static bool TryLoad(out string json)
    {
        json = null;
        if (!File.Exists(path)) return false;

        var raw = File.ReadAllBytes(path);
        if (raw.Length == 0) return false;

        if (VaultSecurityPort.Cipher.IsSealedBlob(raw))
        {
            if (!VaultSecurityPort.Cipher.TryOpen(raw, CryptoAad, out var plain))
            {
                VaultSecurity.Report(VaultTamperKind.MacFail, FileName, "verify thất bại");
                return false;
            }
            json = Encoding.UTF8.GetString(plain);
            return true;
        }

        if (EncryptOnDisk)                                    // chống hạ cấp
        {
            Debug.LogError($"[MyFileStore] Từ chối file trần trong build: {path}");
            return false;
        }

        json = Encoding.UTF8.GetString(raw);
        return true;
    }
}
```

Nhánh `if (EncryptOnDisk) → từ chối` là **lớp chống hạ cấp**: không có nó thì ghi đè file bằng JSON trần
là bypass sạch mọi lớp mã hóa. Nhưng phải là `EncryptOnDisk` (có xét `Encrypts`) chứ không phải
`!Application.isEditor` — nếu không, bản đã xóa `Security/` sẽ từ chối chính file nó vừa ghi.

### A.4 Che giá trị trong RAM + nối watchdog

Kiểu `Obscured*` ở `Contract/` dùng được ngay, không cần biết implement nào đang cắm:

```csharp
using CorruptedDesign.Data;

public class MyWallet : IVaultGuarded
{
    private ObscuredInt coin;

    public string GuardKey => "MyWallet";

    public int Coin
    {
        get => coin.Get("MyWallet.Coin");     // .Get() đổi mask mỗi lần đọc
        set => coin.Set(value);
    }

    public bool VerifyIntegrity()
    {
        if (coin.IsIntact()) return true;
        VaultSecurity.Report(VaultTamperKind.ObscuredValue, GuardKey, "checksum lệch");
        return false;
    }

    public bool VerifyAgainstStorage() => true;   // hoặc so với bản đã seal trên đĩa
}
```

Ghi danh để watchdog quét định kỳ (4–11 s, chu kỳ ngẫu nhiên):

```csharp
VaultWatch.Register(myWallet);
int handle = VaultWatch.RegisterHoneypot("MyWallet.Coin", () => myWallet.Coin);
```

Gọi lúc nào cũng được — chưa cắm watchdog thì thành no-op, không cần `#if`.

⚠️ **Đường nóng thì gọi `.Get()` thẳng.** `int x = coin;` (implicit operator) đi qua bản sao struct nên
**mất tác dụng đổi mask**.

### A.5 Package save/load không sửa được source

Đừng cố sửa package. Bọc nó lại: seal trước khi đưa vào, open sau khi lấy ra. Package chỉ thấy string
đã mã hóa và tên slot đã hash.

```csharp
using CorruptedDesign.Data;

public static class SecureBridge
{
    private static IVaultCipher Cipher => VaultSecurityPort.Cipher;

    public static void Write(string key, string plain) =>
        ThirdPartySave.Write(Cipher.HashKeyName(key), Cipher.SealToString(plain, key));

    public static bool TryRead(string key, out string plain)
    {
        plain = null;

        var stored = ThirdPartySave.Read(Cipher.HashKeyName(key));
        if (string.IsNullOrEmpty(stored)) return false;

        return Cipher.TryOpenString(stored, key, out plain);
    }
}
```

Điều kiện duy nhất: package phải cho phép lưu **string tùy ý** (blob là base64 với prefix `"pv:"`) và
**tên key tùy ý** (slot là base64url 22 ký tự). Nếu package tự áp schema/kiểu số thì chỉ bọc được các
field string, phần còn lại đành để trần.

---

## Đường B — tự viết tầng Security

### B.1 Class cần tạo

Không kế thừa class nào — **implement interface**. Ba interface độc lập: thay cipher mà giữ nguyên
memory guard là hợp lệ, và ngược lại.

| Class bạn tạo | Implement | Bắt buộc? | Không tạo thì sao |
|---|---|---|---|
| `MyCipher` | `IVaultCipher` | không | dữ liệu lưu trần |
| `MyMemoryGuard` | `IVaultMemoryGuard` | không | `Obscured*` lưu thẳng giá trị, `IsIntact()` luôn `true` |
| `MyWatchdog` | `IVaultWatchdog` | không | `VaultWatch.*` thành no-op |
| `MySecurityInstaller` | — (static class) | **có** | không có gì được cắm ⇒ chạy hoàn toàn ở chế độ trần |

Đặt tất cả trong một folder riêng, ví dụ `Vault/MySecurity/`, và giữ đúng luật: **không tham chiếu
class nào của tầng save/load.** Kiểm bằng grep như [mục 0](#0-chuẩn-bị).

### B.2 `MyCipher : IVaultCipher`

```csharp
using System;
using System.Text;
using CorruptedDesign.Data;

internal sealed class MyCipher : IVaultCipher
{
    private const string Prefix = "mc:";

    // ---- blob nhị phân ----------------------------------------------------

    public byte[] Seal(byte[] plain, string aad)
    {
        // aad PHẢI nằm trong phạm vi xác thực (MAC/AEAD), KHÔNG mã hóa nó.
        throw new NotImplementedException();
    }

    public bool TryOpen(byte[] blob, string aad, out byte[] plain)
    {
        // Thứ tự bắt buộc: kiểm magic → kiểm version → verify tag → MỚI decrypt.
        // Verify sau khi decrypt = mở lại padding oracle.
        // Sai tag ⇒ VaultSecurity.Report(VaultTamperKind.MacFail, aad, ...) rồi trả false.
        throw new NotImplementedException();
    }

    public bool IsSealedBlob(byte[] blob)
    {
        // CHỈ so magic. KHÔNG được cần tới khóa — hàm này chạy trước khi quyết định giải mã.
        throw new NotImplementedException();
    }

    // ---- ô dạng string ---------------------------------------------------

    public string SealToString(string plain, string aad) =>
        Prefix + Convert.ToBase64String(Seal(Encoding.UTF8.GetBytes(plain ?? string.Empty), aad));

    public bool TryOpenString(string stored, string aad, out string plain)
    {
        plain = null;
        if (!IsSealedString(stored)) return false;

        byte[] blob;
        try { blob = Convert.FromBase64String(stored.Substring(Prefix.Length)); }
        catch { return false; }

        if (!TryOpen(blob, aad, out var bytes)) return false;

        plain = Encoding.UTF8.GetString(bytes);
        return true;
    }

    public bool IsSealedString(string stored) =>
        !string.IsNullOrEmpty(stored) && stored.StartsWith(Prefix, StringComparison.Ordinal);

    // ---- format cũ (bỏ được nếu project mới) -----------------------------

    public bool IsLegacyString(string stored) => false;

    public bool TryOpenLegacy(string stored, out string plain)
    {
        plain = null;
        return false;
    }

    // ---- tên slot --------------------------------------------------------

    public string HashKeyName(string key)
    {
        // Một chiều, ổn định giữa các phiên và giữa các máy (KHÔNG trộn salt riêng máy vào đây,
        // nếu không mất salt là mất luôn đường tìm slot).
        // Đổi hằng số trong hàm này = đổi tên mọi slot = mất toàn bộ save của người chơi.
        throw new NotImplementedException();
    }

    // ---- vòng đời khóa ---------------------------------------------------

    public void Prime()
    {
        // Gọi trên MAIN THREAD ở splash. Làm 2 việc:
        //  1. cache mọi thứ chỉ đọc được ở main thread (Application.persistentDataPath, PlayerPrefs)
        //  2. derive khóa trước (KDF tốn vài chục ms — đừng để nó rơi vào giữa gameplay)
        throw new NotImplementedException();
    }

    public void ResetKeys()
    {
        // Bỏ khóa đang cache trong RAM. Gọi sau khi dữ liệu bị thay từ ngoài (restore cloud save).
        throw new NotImplementedException();
    }

    public void DeleteKeysAndSalt()
    {
        // Xóa salt/khóa đã lưu. CHỈ gọi khi đã xóa sạch dữ liệu — gọi nhầm là mất hết.
        throw new NotImplementedException();
    }
}
```

### B.3 `MyMemoryGuard : IVaultMemoryGuard`

```csharp
using CorruptedDesign.Data;

internal sealed class MyMemoryGuard : IVaultMemoryGuard
{
    public void Encode(long value, out long stored, out int token, out int check)
    {
        token  = NewNonZeroToken();              // BẮT BUỘC != 0
        stored = value ^ MaskFor(token);
        check  = Checksum(token, value);
    }

    public bool TryDecode(long stored, int token, int check, out long value)
    {
        value = stored ^ MaskFor(token);

        if (Checksum(token, value) == check) return true;

        value = 0L;                              // fail thì trả 0, ĐỪNG trả giá trị đã sai
        return false;
    }

    public bool IsIntact(long stored, int token, int check) =>
        Checksum(token, stored ^ MaskFor(token)) == check;
}
```

Bốn luật:

1. **`token` phải khác 0.** `Contract/` giữ riêng `token == 0` làm nghĩa "ô này chưa set bao giờ".
2. **Instance là singleton dùng chung cho mọi ô.** Không được giữ state per-ô trong field của class —
   mọi thứ phải nhét vào `stored/token/check`. Cần mask riêng từng ô thì suy nó ra từ `token` +
   một session key sinh ngẫu nhiên mỗi phiên.
3. **`IsIntact` không được có side effect.** Watchdog gọi nó mỗi 4–11 s.
4. **`Encode` nên đổi `token` mỗi lần gọi.** `ObscuredLong.Get()` tự gọi lại `Set()` sau khi decode
   thành công, nên byte trong RAM đổi **kể cả khi chỉ đọc** — đó là thứ phá scan
   "unknown initial value" rồi lọc *unchanged / increased / decreased*. Giữ `token` cố định là mất
   tác dụng này.

### B.4 `MyWatchdog : IVaultWatchdog`

Chỉ cần khi muốn quét nền riêng. Không tạo thì `VaultWatch.*` là no-op.

```csharp
using System;
using System.Collections.Generic;
using CorruptedDesign.Data;

internal sealed class MyWatchdog : IVaultWatchdog
{
    public static readonly MyWatchdog Instance = new MyWatchdog();

    private readonly List<IVaultGuarded> guarded = new List<IVaultGuarded>();

    public bool Enabled { get; set; } = true;

    public void Register(IVaultGuarded target)
    {
        if (target != null && !guarded.Contains(target)) guarded.Add(target);
    }

    public void Unregister(IVaultGuarded target) => guarded.Remove(target);

    public int RegisterHoneypot(string key, Func<int> truth) => -1;   // bỏ qua nếu không cần

    public void SyncHoneypot(int handle) { }

    public int ScanNow()
    {
        int problems = 0;

        for (int i = 0; i < guarded.Count; i++)
            if (!guarded[i].VerifyIntegrity()) problems++;

        return problems;
    }

    public void Clear() => guarded.Clear();
}
```

Chu kỳ quét nên **ngẫu nhiên** (CorruptedDesign dùng 4–11 s) để cheater không xác định được thời điểm kiểm tra.
Chỗ chạy coroutine thì tự tạo `GameObject` + `DontDestroyOnLoad` ở `AfterSceneLoad`.

### B.5 `MySecurityInstaller` — file bắt buộc

```csharp
using UnityEngine;
using CorruptedDesign.Data;

public static class MySecurityInstaller
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    public static void Install()
    {
        VaultSecurityPort.Install(new MyCipher(), new MyMemoryGuard(), MyWatchdog.Instance);
    }

#if UNITY_EDITOR
    [UnityEditor.InitializeOnLoadMethod]
    private static void InstallInEditor() => Install();
#endif
}
```

Hoặc cắm lẻ từng cái, phần nào không có thì bỏ — port tự dùng bản trần cho phần đó:

```csharp
VaultSecurityPort.InstallCipher(new MyCipher());
// không gọi InstallMemoryGuard ⇒ Obscured* lưu thẳng giá trị
```

⚠️ **`Install()` chỉ được gán static, không được derive khóa, không được đọc `PlayerPrefs` hay
`Application.persistentDataPath`.** Việc đó thuộc `Prime()`, chạy ở `BeforeSceneLoad`.

---

## 2. Timing — chạy gì ở thời điểm nào

| # | Thời điểm | Attribute | Làm gì |
|---|---|---|---|
| 0 | Domain reload trong editor | `[UnityEditor.InitializeOnLoadMethod]` | `Install()` — để editor tool và các lần ghi **ngoài play mode** cũng đi qua implement của bạn |
| 1 | Sớm nhất của runtime | `[RuntimeInitializeOnLoadMethod(SubsystemRegistration)]` | `Install()` — **chỉ gán static** |
| 2 | Trước scene đầu tiên | `[RuntimeInitializeOnLoadMethod(BeforeSceneLoad)]` | `Cipher.Prime()` — cache path, derive khóa, trên **main thread** |
| 3 | Sau scene đầu tiên | `[RuntimeInitializeOnLoadMethod(AfterSceneLoad)]` | Tạo runner `DontDestroyOnLoad` cho watchdog |
| 4 | `Awake`/`Start` của manager | — | `VaultWatch.Register(...)`, `RegisterHoneypot(...)`, lần đọc save đầu tiên |

Ba điều quan trọng về timing:

- **Cắm muộn hơn lần đọc đầu tiên = lần đọc đó chạy bằng bản trần.** `SubsystemRegistration` chạy trước
  `BeforeSceneLoad`, trước mọi `Awake`, nên an toàn. Đừng cắm trong `Awake` của một MonoBehaviour.
- **Thiếu nhánh `UNITY_EDITOR` là editor tool và code ngoài play mode chạy bằng bản trần** —
  `RuntimeInitializeOnLoadMethod` không chạy ngoài play mode. Ghi ở chế độ trần rồi build đọc bằng
  cipher thật = verify fail = mất ô đó.
- **`Prime()` phải ở `BeforeSceneLoad`, không ở `SubsystemRegistration`.** Store hay load nền trên
  thread phụ, mà `PlayerPrefs` / `Application.persistentDataPath` không an toàn ngoài main thread —
  `Prime()` là chỗ cache chúng lại trước.

---

## 3. Cần gọi `Prime()` — không ai gọi hộ

`Api/` của CorruptedDesign **không gọi `Cipher.Prime()`**; implement của CorruptedDesign tự prime bằng attribute riêng trong
`VaultCrypto`. Nghĩa là:

- **Đường A:** implement của CorruptedDesign tự prime, bạn không cần làm gì. Gọi thêm
  `VaultSecurityPort.Cipher.Prime()` ở splash là vô hại (idempotent) và nên gọi — nó bảo hiểm cho
  trường hợp sau này thay implement khác.
- **Đường B:** hoặc `MyCipher` tự prime bằng attribute của riêng nó, **hoặc** host gọi
  `VaultSecurityPort.Cipher.Prime()` ở `BeforeSceneLoad`. Chọn một. Không làm gì cả thì lần đọc đầu
  tiên phải derive khóa tại chỗ — có thể rơi vào giữa gameplay, hoặc tệ hơn là rơi vào thread phụ.

---

## 4. Thread-safety

Tầng save/load thường load nền (`Task.Run`) để không block splash. Hệ quả với implement của bạn:

| Yêu cầu | Vì sao |
|---|---|
| `Seal`, `TryOpen`, `IsSealedBlob`, `TryOpenString` phải **thread-safe** | được gọi từ worker thread lúc load nền |
| Không gọi `PlayerPrefs`, `Application.*`, `Debug.Log` từ các hàm đó | Unity API, không an toàn ngoài main thread |
| Mọi thứ cần Unity API phải cache trong `Prime()` | `Prime()` là hàm duy nhất được đảm bảo chạy ở main thread |
| Cache khóa bằng double-checked lock + field `volatile`, gán **một lần** | thread phụ hoặc thấy `null` hoặc thấy KeySet hoàn chỉnh, không có trạng thái nửa vời |

Đây là lý do `Prime()` tồn tại trong hợp đồng chứ không phải chi tiết nội bộ của `VaultCrypto`.

---

## 5. Ràng buộc bắt buộc

Sáu luật. Vi phạm luật 1–3 là lỗ bảo mật thật; luật 4–6 là mất dữ liệu.

1. **`aad` phải định danh đúng ô của nó.** Ô riêng lẻ ⇒ `aad` = tên key gốc (không phải slot đã hash).
   Blob cả file ⇒ `aad` = một hằng định danh file đó. Truyền `null` hoặc dùng chung một hằng cho mọi ô
   là mở lỗ splicing: đổi chỗ hai blob là đổi được giá trị mà không phá mã hóa.
2. **Encrypt-then-MAC: verify tag TRƯỚC khi decrypt.** Verify sau là mở lại padding oracle.
3. **`aad` được ký, không được mã hóa.** Nó nằm trong phạm vi MAC, không nằm trong ciphertext.
4. **Đọc `VaultSecurityPort.Encrypts` trước khi từ chối dữ liệu trần.** Từ chối vô điều kiện thì bản
   không có `Security/` không đọc được chính file nó vừa ghi.
5. **Đi qua `VaultSecurityPort`, không `new MyCipher()` ở chỗ dùng.** `new` trực tiếp là đóng luôn cửa
   thay thế mà tầng này tồn tại để mở.
6. **Đừng đổi các hằng đã ship.** Input của `HashKeyName` (prefix + secret), seed KDF, số vòng, độ dài
   khóa, magic header, `aad`. Đổi bất kỳ cái nào = toàn bộ người chơi hiện có mất sạch dữ liệu. Muốn
   đổi thật thì thêm version mới, giữ đường đọc format cũ, nâng cấp dần khi đọc (upgrade-on-read) —
   đúng cơ chế `IsLegacyString` / `TryOpenLegacy` có sẵn trong hợp đồng.

---

## 6. Checklist

Đường A:

- [ ] Copy `Contract/` + `Security/`, grep xác nhận không tham chiếu tầng save/load
- [ ] Mọi lần ghi đi qua `SealToString` / `Seal`, mọi lần đọc qua `TryOpenString` / `TryOpen`
- [ ] `aad` = tên key gốc (ô lẻ) hoặc hằng định danh file (blob cả file)
- [ ] Tên slot qua `HashKeyName`
- [ ] `Prime()` được gọi ở `BeforeSceneLoad`
- [ ] Nhánh từ chối dữ liệu trần có xét `VaultSecurityPort.Encrypts`
- [ ] `DeleteAll` gọi `DeleteKeysAndSalt`
- [ ] Đối tượng cần quét implement `IVaultGuarded` + `VaultWatch.Register`

Đường B — thêm:

- [ ] `MyCipher` implement đủ 12 method, `IsSealedBlob` không cần khóa
- [ ] `MyMemoryGuard.Encode` trả `token != 0` và đổi `token` mỗi lần gọi
- [ ] Không giữ state per-ô ngoài `stored/token/check`
- [ ] `IsIntact` không side effect
- [ ] `MySecurityInstaller` có **cả hai** attribute (`SubsystemRegistration` + `UNITY_EDITOR`)
- [ ] `Install()` chỉ gán static, không derive khóa
- [ ] `Seal`/`TryOpen` thread-safe, không gọi Unity API
- [ ] Phát hiện tamper thì gọi `VaultSecurity.Report`, không dựng event riêng

---

## 7. Verify

**Kiểm chiều phụ thuộc** — cả hai lệnh phải rỗng:

```bash
grep -rn "MyCipher\|MyMemoryGuard\|MyWatchdog" <folder-save-load>/
grep -rn "<tên-class-save-load-của-bạn>" <folder-security>/
```

**Kiểm compile khi không có security** — xóa folder security rồi build. Còn compile được thì boundary
đúng; lỗi `CS0246 type not found` là còn tham chiếu lọt qua.

**Kiểm roundtrip + ràng buộc `aad`** (chạy khi implement đã được cắm — bản trần sẽ fail hết, đó là
đúng):

```csharp
var c = VaultSecurityPort.Cipher;

var sealed1 = c.SealToString("1234", "Coin");
Debug.Assert(c.TryOpenString(sealed1, "Coin", out var back) && back == "1234");   // mở đúng aad → OK
Debug.Assert(!c.TryOpenString(sealed1, "Gem", out _));                            // sai aad → PHẢI fail
Debug.Assert(c.SealToString("1234", "Coin") != sealed1);                          // IV ngẫu nhiên
Debug.Assert(c.HashKeyName("Coin") == c.HashKeyName("Coin"));                     // hash ổn định
Debug.Assert(c.HashKeyName("Coin") != "Coin");                                    // hash có tác dụng
```

Dòng thứ hai là dòng quan trọng nhất — nó là bài test cho luật 1.

**Kiểm memory guard:**

```csharp
var g = VaultSecurityPort.MemoryGuard;

g.Encode(999L, out var stored, out var token, out var check);
Debug.Assert(token != 0);
Debug.Assert(g.TryDecode(stored, token, check, out var v) && v == 999L);
Debug.Assert(g.IsIntact(stored, token, check));
Debug.Assert(!g.TryDecode(stored + 1, token, check, out _));   // sửa 1 bit → PHẢI fail

// đổi token/mask ngay cả khi CHỈ ĐỌC
g.Encode(50L, out var s1, out var t1, out var c1);
g.TryDecode(s1, t1, c1, out var read);
g.Encode(read, out var s2, out var t2, out _);                 // đúng những gì ObscuredLong.Get() làm
Debug.Assert(read == 50L);                                     // giá trị giữ nguyên...
Debug.Assert(t1 != t2 && s1 != s2);                            // ...nhưng byte trong RAM đã khác
```

---

## 8. Lỗi thường gặp

| Triệu chứng | Nguyên nhân |
|---|---|
| Save mất sạch sau khi update | Đổi hằng ảnh hưởng `HashKeyName` hoặc KDF (luật 6) |
| Editor ghi được, build đọc ra default | Thiếu nhánh `UNITY_EDITOR` trong installer — editor ghi trần, build đọc bằng cipher thật |
| Lần đọc đầu ra default, các lần sau đúng | Cắm implement muộn hơn lần đọc đầu tiên |
| `UnityException: get_persistentDataPath is not allowed to be called from a MonoBehaviour constructor` hoặc lỗi thread | Gọi Unity API trong `Seal`/`TryOpen` (chạy trên worker thread) — phải cache ở `Prime()` |
| Xóa `Security/` xong build không đọc được file nó vừa ghi | Nhánh từ chối dữ liệu trần không xét `Encrypts` (luật 4) |
| `ObscuredInt` luôn trả 0 | `Encode` trả `token == 0` |
| Đổi mask không có tác dụng | Dùng implicit operator (`int x = coin;`) thay vì `.Get()` |
| Copy save sang máy khác vẫn chạy | Salt/khóa không riêng từng máy — khóa đang hardcode |
| Sửa 1 byte trong file mà vẫn load được | Không có MAC, hoặc verify sau khi decrypt (luật 2) |

---

Chi tiết thuật toán, format blob, vòng đời khóa, và những hằng tuyệt đối không được đổi: xem
[`README.md`](README.md) mục 3, 5 và 12.
