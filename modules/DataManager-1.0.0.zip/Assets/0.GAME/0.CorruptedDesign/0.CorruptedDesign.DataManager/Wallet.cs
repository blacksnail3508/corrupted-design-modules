using System;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using CorruptedDesign.Data;
using UnityEngine.Scripting;

[Serializable]
// IL2CPP strips the private [OnDeserialized] callback and [JsonProperty] members, which Newtonsoft only reaches by reflection.
[Preserve]
public class Wallet
{
    public const int MaxSaneDelta = 1_000_000;

    private ObscuredInt gCoin;
    private ObscuredInt gBooster1;
    private ObscuredInt gBooster2;
    private ObscuredInt gBooster3;

    private long ledger;
    private bool ledgerReady;

    [JsonProperty("Coin")]
    private int CoinIo { get => gCoin.Get(); set => gCoin.Set(value); }

    [JsonProperty("Booster1")]
    private int Booster1Io { get => gBooster1.Get(); set => gBooster1.Set(value); }

    [JsonProperty("Booster2")]
    private int Booster2Io { get => gBooster2.Get(); set => gBooster2.Set(value); }

    [JsonProperty("Booster3")]
    private int Booster3Io { get => gBooster3.Get(); set => gBooster3.Set(value); }

    [JsonIgnore]
    public int Coin
    {
        get => gCoin.Get("Wallet.Coin");
        set => Assign(ref gCoin, value, "Wallet.Coin");
    }

    [JsonIgnore]
    public int Booster1
    {
        get => gBooster1.Get("Wallet.Booster1");
        set => Assign(ref gBooster1, value, "Wallet.Booster1");
    }

    [JsonIgnore]
    public int Booster2
    {
        get => gBooster2.Get("Wallet.Booster2");
        set => Assign(ref gBooster2, value, "Wallet.Booster2");
    }

    [JsonIgnore]
    public int Booster3
    {
        get => gBooster3.Get("Wallet.Booster3");
        set => Assign(ref gBooster3, value, "Wallet.Booster3");
    }

    public Wallet() { }

    public Wallet(int coin, int booster1 = 0, int booster2 = 0, int booster3 = 0)
    {
        gCoin.Set(coin);
        gBooster1.Set(booster1);
        gBooster2.Set(booster2);
        gBooster3.Set(booster3);
        TouchLedger();
    }

    public bool VerifyLedger()
    {
        if (!ledgerReady)
        {
            TouchLedger();
            return true;
        }

        if (!gCoin.IsIntact() || !gBooster1.IsIntact() || !gBooster2.IsIntact() || !gBooster3.IsIntact())
        {
            VaultSecurity.Report(VaultTamperKind.ObscuredValue, "Wallet", "checksum ô obscured lệch");
            return false;
        }

        if (ComputeLedger() == ledger) return true;

        VaultSecurity.Report(VaultTamperKind.Ledger, "Wallet", "ledger lệch — có field bị sửa ngoài API");
        return false;
    }

    [OnDeserialized, Preserve]
    private void OnDeserialized(StreamingContext _) => TouchLedger();

    private void Assign(ref ObscuredInt guard, int value, string label)
    {
        int old = guard.Get(label);

        if (Math.Abs((long)value - old) > MaxSaneDelta)
            VaultSecurity.Report(VaultTamperKind.Ledger, label, $"delta bất thường: {old} -> {value}");

        guard.Set(value);
        TouchLedger();
    }

    private void TouchLedger()
    {
        ledger = ComputeLedger();
        ledgerReady = true;
    }

    private long ComputeLedger()
    {
        unchecked
        {
            ulong h = 14695981039346656037UL;
            h = Mix(h, (uint)gCoin.Get());
            h = Mix(h, (uint)gBooster1.Get());
            h = Mix(h, (uint)gBooster2.Get());
            h = Mix(h, (uint)gBooster3.Get());
            return (long)h;
        }
    }

    private static ulong Mix(ulong h, uint v)
    {
        unchecked
        {
            h ^= v;
            h *= 1099511628211UL;
            h ^= h >> 29;
            return h;
        }
    }
}
