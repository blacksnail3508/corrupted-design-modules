using System;
using System.Collections.Generic;

[Serializable]
public class TutorialProgress
{
    public List<LevelContent> Watched = new List<LevelContent>();
}
