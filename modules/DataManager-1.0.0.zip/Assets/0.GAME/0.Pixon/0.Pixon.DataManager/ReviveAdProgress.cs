using System;

[Serializable]
public class ReviveAdProgress
{
    public int Day;
    public int WatchedToday;

    public int EnsureToday()
    {
        int today = BoosterAdProgress.TodayUtc();
        if (Day != today)
        {
            Day = today;
            WatchedToday = 0;
        }

        return WatchedToday;
    }
}
