﻿public enum ResourceReason
{
    WinReward,
    WatchAds,
    Free,
    Exchange, //buy with coin
    Revive,
    UseBooster,
    Purchase
}