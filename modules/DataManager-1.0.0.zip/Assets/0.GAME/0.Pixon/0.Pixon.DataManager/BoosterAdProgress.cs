using System;

[Serializable]
public class BoosterAdProgress
{
    public int Day;
    public int[] WatchedToday = new int[3];

    public static int TodayUtc()
    {
        var now = DateTime.UtcNow;
        return now.Year * 10000 + now.Month * 100 + now.Day;
    }

    public int[] EnsureToday()
    {
        if (WatchedToday == null || WatchedToday.Length < 3)
            WatchedToday = new int[3];

        int today = TodayUtc();
        if (Day != today)
        {
            Day = today;
            Array.Clear(WatchedToday, 0, WatchedToday.Length);
        }

        return WatchedToday;
    }
}
