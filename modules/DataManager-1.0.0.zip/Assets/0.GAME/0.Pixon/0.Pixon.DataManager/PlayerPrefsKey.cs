public static class PlayerPrefsKey
{
    public const string AUDIO = "Audio";
    public const string PlayerData = "PlayerData";
    public const string Cheat = "cheat_data";
    public static string Level = "Level";
    public static string Wallet =  "Wallet";
    public static string PlaySnapShot = "last_play_info";
    public static string TutorialWatched = "tutorial_watched";
    public static string BoosterAdProgress = "booster_ad_progress";
    public static string ReviveAdProgress = "revive_ad_progress";
    public static string AutoPlay = "auto_play_enabled";
    public static string ConveyorSandSizeMultiplier = "conveyor_sand_size_multiplier";
    public static string RoundSandGrain = "round_sand_grain";
    public static string UserProperties = "analytic_user_properties";
    public static string UATracker = "analytic_ua_tracker";
    public static string LevelAttempt = "analytic_level_attempt";
    public static string IsRated = "is_rated";
    public static string StarterPackAutoShown = "starter_pack_auto_shown";
    
    //remote levels
    public static string FetchedLevels = "fetched_levels";
}
