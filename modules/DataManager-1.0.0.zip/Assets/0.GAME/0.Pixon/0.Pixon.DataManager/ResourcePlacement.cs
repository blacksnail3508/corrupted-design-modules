﻿public enum ResourcePlacement
{
    WinPopup,
    Cheat,PopupBuyBooster,
    LosePopup,
    Gameplay,
    ContentUnlock,
    PopupBuyHeart,
    Shop
}