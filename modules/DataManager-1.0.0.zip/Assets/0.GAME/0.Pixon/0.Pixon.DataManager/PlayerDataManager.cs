using Pixon.Data;
using Pixon.Observer;
using Pixon.Remote;
using PixonTemplate;
using UnityEngine;
using PPK = PlayerPrefsKey;

public class PlayerDataManager : MonoBehaviour
{
    [SerializeField] Vault<Wallet> wallet = new (PPK.Wallet, new Wallet());
    
    [SerializeField] Vault<int> levelVault = new(PPK.Level, 1);
    [SerializeField] Vault<PlaySnapShot>  playSnapShot = new(PPK.PlaySnapShot, new PlaySnapShot());
    [SerializeField] Vault<TutorialProgress> tutorialProgress = new(PPK.TutorialWatched, new TutorialProgress());
    [SerializeField] Vault<BoosterAdProgress> boosterAdProgress = new(PPK.BoosterAdProgress, new BoosterAdProgress());
    [SerializeField] Vault<ReviveAdProgress> reviveAdProgress = new(PPK.ReviveAdProgress, new ReviveAdProgress());
    [SerializeField] public Vault<float> ConveyorSandSizeMultiplier = new(PPK.ConveyorSandSizeMultiplier, 1.5f);
    [SerializeField] private Vault<bool> ratedVault = new(PPK.IsRated, false);
    [SerializeField] private Vault<int> starterPackAutoShown = new(PPK.StarterPackAutoShown, 0);

    private readonly int[] boosterRwThisLevel = new int[3];
    private int reviveThisLevel;
    private int reviveRwThisLevel;
    
    
    public PlaySnapShot LastPlaySnapShot
    {
        get => playSnapShot.Value;
        set => playSnapShot.Value = value;
    }

    public int Level => levelVault.Value;

    public bool IsRated => ratedVault.Value;

    public void MarkRated() => ratedVault.Save(true);

    public bool IsOfferAutoShown(int slot) => (starterPackAutoShown.Value & (1 << slot)) != 0;

    public void MarkOfferAutoShown(int slot) => starterPackAutoShown.Save(starterPackAutoShown.Value | (1 << slot));
    
    [SerializeField] private Vault<CheatData> cheatData = new(PPK.Cheat, new CheatData());

    private CheatData Cheat => cheatData.Value ?? new CheatData();

    public bool IsTester
    {
        get
        {
            #if FULL_CHEAT
            return true;
            #endif
            return Cheat.IsCheated;
        }
        set
        {
            var data = Cheat;
            data.IsCheated = value;
            cheatData.Save(data);
        }
    }

    public bool IsSkipAds
    {
        get => Cheat.IsSkipAds;
        set
        {
            var data = Cheat;
            data.IsSkipAds = value;
            cheatData.Save(data);
        }
    }
    public int Coin => wallet.Value.Coin;

    public LevelSystem LevelSystem = new LevelSystem();
    public LevelJson CurrentLevelData;

    public Difficulty CurrentDifficulty => CurrentLevelData?.Difficulty ?? Difficulty.Normal;

    public int CoinPerWin => ConfigCollection.RwWinAdConfig.Value.GetReward(CurrentDifficulty);

    public bool IsTutorialWatched(LevelContent content)
    {
        var progress = tutorialProgress.Value;
        return progress != null && progress.Watched.Contains(content);
    }

    public void SetTutorialWatched(LevelContent content)
    {
        var progress = tutorialProgress.Value ?? new TutorialProgress();
        if (progress.Watched.Contains(content)) return;

        progress.Watched.Add(content);
        tutorialProgress.Save(progress);
    }

    public void ResetTutorialWatched()
    {
        tutorialProgress.Save(new TutorialProgress());
    }

    public int GetBoosterBalance(BoosterType boosterType)
    {
        return boosterType switch
        {
            BoosterType.Booster1 => wallet.Value.Booster1,
            BoosterType.Booster2 => wallet.Value.Booster2,
            BoosterType.Booster3 => wallet.Value.Booster3,
            _ => 0
        };
    }


    public int GetBoosterRwCountThisLevel(BoosterType boosterType)
    {
        return boosterRwThisLevel[BoosterIndex(boosterType)];
    }

    public int GetBoosterRwCountToday(BoosterType boosterType)
    {
        return ResolveBoosterAdProgress().EnsureToday()[BoosterIndex(boosterType)];
    }

    public void RegisterBoosterRwWatched(BoosterType boosterType)
    {
        int index = BoosterIndex(boosterType);
        boosterRwThisLevel[index]++;

        var progress = ResolveBoosterAdProgress();
        progress.EnsureToday()[index]++;
        boosterAdProgress.Save(progress);
    }

    public void ResetBoosterRwLevelCounters()
    {
        System.Array.Clear(boosterRwThisLevel, 0, boosterRwThisLevel.Length);
    }

    private BoosterAdProgress ResolveBoosterAdProgress()
    {
        var progress = boosterAdProgress.Value;
        if (progress != null) return progress;

        progress = new BoosterAdProgress();
        boosterAdProgress.Save(progress);
        return progress;
    }

    public int ReviveCountThisLevel => reviveThisLevel;

    public int ReviveRwCountThisLevel => reviveRwThisLevel;

    public int ReviveRwCountToday => ResolveReviveAdProgress().EnsureToday();

    public void RegisterRevive(ReviveMethod method)
    {
        reviveThisLevel++;
        if (method != ReviveMethod.ByAds) return;

        reviveRwThisLevel++;

        var progress = ResolveReviveAdProgress();
        progress.EnsureToday();
        progress.WatchedToday++;
        reviveAdProgress.Save(progress);
    }

    public void ResetReviveLevelCounters()
    {
        reviveThisLevel = 0;
        reviveRwThisLevel = 0;
    }

    private ReviveAdProgress ResolveReviveAdProgress()
    {
        var progress = reviveAdProgress.Value;
        if (progress != null) return progress;

        progress = new ReviveAdProgress();
        reviveAdProgress.Save(progress);
        return progress;
    }

    private static int BoosterIndex(BoosterType boosterType) => boosterType switch
    {
        BoosterType.Booster1 => 0,
        BoosterType.Booster2 => 1,
        BoosterType.Booster3 => 2,
        _ => 0
    };

    public bool TrySpendCoin(int cost, ResourceReason spendReason, ResourcePlacement placement)
    {
        if (wallet.Value.Coin < cost) return false;

        wallet.Value.Coin -= cost;
        wallet.Save(wallet.Value);
        AnalyticAdapter.LogResourceSpent(ItemType.Coin, cost, spendReason, placement);
        EventService.Raise(new CoinChange(-cost));
        return true;
    }

    public void ClaimCoin(int value, ResourceReason claimReason,
        ResourcePlacement placement, bool forceUpdateUI, bool logAnalytic = true)
    {
        wallet.Value.Coin += value;
        wallet.Save(wallet.Value);
        AnalyticAdapter.LogResourceGain(ItemType.Coin, value, claimReason, placement, toLion: logAnalytic);

        if(forceUpdateUI) EventService.Raise(new CoinChange(value));
    }

    private int coinHoneypot = -1;

    private void Awake()
    {
        GameService.DataManager = this;
        // DontDestroyOnLoad only accepts root objects, and the scene keeps this one under a parent.
        transform.SetParent(null);
        DontDestroyOnLoad(gameObject);
        GrantStarterResourcesIfNewPlayer();
        LevelSystem.Initialize();
        PreloadNextLevel();
        InstallIntegrityChecks();
        // Lets Lion finish initialising Adjust before the retention event goes out.
        Delay.CallUnscaled(5f, AnalyticAdapter.LogRetention);
    }

    private void InstallIntegrityChecks()
    {
        VaultWatch.Register(new WalletGuard(this));
        coinHoneypot = VaultWatch.RegisterHoneypot("Wallet.Coin", () => wallet.Value?.Coin ?? 0);
    }

    private sealed class WalletGuard : IVaultGuarded
    {
        private readonly PlayerDataManager owner;
        public WalletGuard(PlayerDataManager owner) => this.owner = owner;

        public string GuardKey => PPK.Wallet;

        public bool VerifyIntegrity() => owner.wallet.Value?.VerifyLedger() ?? true;

        public bool VerifyAgainstStorage() => owner.wallet.VerifyAgainstStorage();
    }

    private void GrantStarterResourcesIfNewPlayer()
    {
        if (wallet.Exists) return;

        var fresh = wallet.Value ?? new Wallet();
        fresh.Coin = ConfigCollection.StarterGoldAmount.Value;

        int starterBooster = ConfigCollection.StarterBoosterAmount.Value;
        fresh.Booster1 = starterBooster;
        fresh.Booster2 = starterBooster;
        fresh.Booster3 = starterBooster;
        wallet.Save(fresh);
    }

    public void LevelUp()
    {
        levelVault.Value++;
        levelVault.Save(levelVault.Value);
        PreloadNextLevel();
    }

    public void SetLevel(int level)
    {
        levelVault.Value = Mathf.Max(1, level);
        levelVault.Save(levelVault.Value);
        PreloadNextLevel();
    }
    
    private void PreloadNextLevel()
    {
        //pre-calculate next level
        CurrentLevelData = LevelSystem.GetLevelJson(Level);
    }

    public void ClaimBooster(BoosterType boosterType, int value,
        ResourceReason claimReason, ResourcePlacement placement)
    {
        switch (boosterType)
        {
            case BoosterType.Booster1: wallet.Value.Booster1 += value; break;
            case BoosterType.Booster2: wallet.Value.Booster2 += value; break;
            case BoosterType.Booster3: wallet.Value.Booster3 += value; break;
        }
        wallet.Save(wallet.Value);
        AnalyticAdapter.LogResourceGain(ToItemType(boosterType), value, claimReason, placement);
        EventService.Raise(new BoosterChanged(boosterType));
    }

    public bool SpendBooster(BoosterType boosterType, int value = 1,
        ResourceReason spendReason = ResourceReason.UseBooster,
        ResourcePlacement placement = ResourcePlacement.Gameplay)
    {
        if (GetBoosterBalance(boosterType) < value) return false;

        switch (boosterType)
        {
            case BoosterType.Booster1: wallet.Value.Booster1 -= value; break;
            case BoosterType.Booster2: wallet.Value.Booster2 -= value; break;
            case BoosterType.Booster3: wallet.Value.Booster3 -= value; break;
        }
        wallet.Save(wallet.Value);
        AnalyticAdapter.LogResourceSpent(ToItemType(boosterType), value, spendReason, placement);
        if (spendReason == ResourceReason.UseBooster)
            AnalyticAdapter.LogBoosterUse(boosterType, GetBoosterBalance(boosterType));
        EventService.Raise(new BoosterChanged(boosterType));
        return true;
    }

    private static ItemType ToItemType(BoosterType boosterType) => boosterType switch
    {
        BoosterType.Booster1 => ItemType.Booster_1,
        BoosterType.Booster2 => ItemType.Booster_2,
        BoosterType.Booster3 => ItemType.Booster_3,
        _ => ItemType.Booster_1
    };

    public void CachePlaySnapShot(int _level, int rawLevel, Difficulty _difficulty)
    {
        ResetBoosterRwLevelCounters();
        ResetReviveLevelCounters();

        var temp = LastPlaySnapShot;
        if (_level != temp.Level)
        {
            //new play
            temp.SetNewLevel(_level, rawLevel, _difficulty);
        }
        else
        {
            //replay
            temp.RawLevel = rawLevel;
            temp.Difficulty = _difficulty;
            temp.Attempt++;
        }
        playSnapShot.Save(temp);
    }

    public void RecordLoss()
    {
        var temp = LastPlaySnapShot;
        temp.Loses++;
        playSnapShot.Save(temp);
    }
}

