using System;

[Serializable]
public class CheatData
{
    public bool IsCheated = false;

    public bool IsSkipAds = false;
}
