﻿public enum ItemType
{
    Coin,
    Booster_1,
    Booster_2,
    Booster_3,

    Heart,
    InfiniteHeart,
    RemoveAds,
}