namespace Pixon.Data
{
    public interface IVaultCipher
    {
        byte[] Seal(byte[] plain, string aad);
        bool TryOpen(byte[] blob, string aad, out byte[] plain);
        bool IsSealedBlob(byte[] blob);

        string SealToString(string plain, string aad);
        bool TryOpenString(string stored, string aad, out string plain);
        bool IsSealedString(string stored);

        bool IsLegacyString(string stored);
        bool TryOpenLegacy(string stored, out string plain);

        string HashKeyName(string key);

        void Prime();
        void ResetKeys();
        void DeleteKeysAndSalt();
    }

    internal sealed class PlainVaultCipher : IVaultCipher
    {
        public byte[] Seal(byte[] plain, string aad) => plain;

        public bool TryOpen(byte[] blob, string aad, out byte[] plain)
        {
            plain = blob;
            return blob != null;
        }

        public bool IsSealedBlob(byte[] blob) => false;

        public string SealToString(string plain, string aad) => plain ?? string.Empty;

        public bool TryOpenString(string stored, string aad, out string plain)
        {
            plain = stored;
            return stored != null;
        }

        public bool IsSealedString(string stored) => false;

        public bool IsLegacyString(string stored) => false;

        public bool TryOpenLegacy(string stored, out string plain)
        {
            plain = null;
            return false;
        }

        public string HashKeyName(string key) => key;

        public void Prime() { }

        public void ResetKeys() { }

        public void DeleteKeysAndSalt() { }
    }
}
