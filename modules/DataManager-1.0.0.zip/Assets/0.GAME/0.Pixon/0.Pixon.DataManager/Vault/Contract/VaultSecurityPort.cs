namespace Pixon.Data
{
    public static class VaultSecurityPort
    {
        private static readonly IVaultCipher      Plaintext  = new PlainVaultCipher();
        private static readonly IVaultMemoryGuard Passthrough = new PlainMemoryGuard();

        private static IVaultCipher      cipher;
        private static IVaultMemoryGuard memoryGuard;
        private static IVaultWatchdog    watchdog;

        public static IVaultCipher      Cipher      => cipher      ?? Plaintext;
        public static IVaultMemoryGuard MemoryGuard => memoryGuard ?? Passthrough;
        public static IVaultWatchdog    Watchdog    => watchdog;

        public static bool Encrypts     => cipher      != null;
        public static bool GuardsMemory => memoryGuard != null;

        public static void InstallCipher(IVaultCipher impl) => cipher = impl;

        public static void InstallMemoryGuard(IVaultMemoryGuard impl) => memoryGuard = impl;

        public static void InstallWatchdog(IVaultWatchdog impl) => watchdog = impl;

        public static void Install(IVaultCipher cipherImpl, IVaultMemoryGuard guardImpl, IVaultWatchdog watchdogImpl)
        {
            cipher      = cipherImpl;
            memoryGuard = guardImpl;
            watchdog    = watchdogImpl;
        }

        public static void Uninstall()
        {
            cipher      = null;
            memoryGuard = null;
            watchdog    = null;
        }
    }
}
