using System;
using UnityEngine;

namespace Pixon.Data
{
    public enum VaultTamperKind
    {
        ObscuredValue,
        Honeypot,
        DiskMismatch,
        Ledger,
        MacFail,
    }

    public readonly struct VaultTamperEvent
    {
        public readonly VaultTamperKind Kind;
        public readonly string Key;
        public readonly string Detail;

        public VaultTamperEvent(VaultTamperKind kind, string key, string detail)
        {
            Kind = kind;
            Key = key;
            Detail = detail;
        }

        public override string ToString() => $"{Kind} @ '{Key}': {Detail}";
    }

    public static class VaultSecurity
    {
        public static event Action<VaultTamperEvent> OnTamperDetected;

        public static int TamperCount { get; private set; }
        public static bool AnyTamperDetected => TamperCount > 0;
        public static VaultTamperKind LastKind { get; private set; }
        public static string LastKey { get; private set; }

        public static bool LogToConsole = true;

        public static void Report(VaultTamperKind kind, string key, string detail)
        {
            TamperCount++;
            LastKind = kind;
            LastKey = key;

            if (LogToConsole)
                Debug.LogWarning($"[VaultSecurity] {kind} @ '{key}': {detail}");

            var handler = OnTamperDetected;
            if (handler == null) return;

            try
            {
                handler.Invoke(new VaultTamperEvent(kind, key, detail));
            }
            catch (Exception e)
            {
                Debug.LogException(e);
            }
        }

        public static void ResetCounters()
        {
            TamperCount = 0;
            LastKey = null;
        }
    }
}
