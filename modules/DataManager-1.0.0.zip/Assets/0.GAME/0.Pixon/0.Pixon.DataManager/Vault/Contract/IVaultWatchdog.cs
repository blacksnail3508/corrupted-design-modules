using System;

namespace Pixon.Data
{
    public interface IVaultGuarded
    {
        string GuardKey { get; }
        bool VerifyIntegrity();
        bool VerifyAgainstStorage();
    }

    public interface IVaultWatchdog
    {
        bool Enabled { get; set; }

        void Register(IVaultGuarded target);
        void Unregister(IVaultGuarded target);

        int RegisterHoneypot(string key, Func<int> truth);
        void SyncHoneypot(int handle);

        int ScanNow();
        void Clear();
    }

    public static class VaultWatch
    {
        public static bool Installed => VaultSecurityPort.Watchdog != null;

        public static bool Enabled
        {
            get => VaultSecurityPort.Watchdog?.Enabled ?? false;
            set
            {
                var w = VaultSecurityPort.Watchdog;
                if (w != null) w.Enabled = value;
            }
        }

        public static void Register(IVaultGuarded target) => VaultSecurityPort.Watchdog?.Register(target);

        public static void Unregister(IVaultGuarded target) => VaultSecurityPort.Watchdog?.Unregister(target);

        public static int RegisterHoneypot(string key, Func<int> truth) =>
            VaultSecurityPort.Watchdog?.RegisterHoneypot(key, truth) ?? -1;

        public static void SyncHoneypot(int handle) => VaultSecurityPort.Watchdog?.SyncHoneypot(handle);

        public static int ScanNow() => VaultSecurityPort.Watchdog?.ScanNow() ?? 0;

        public static void Clear() => VaultSecurityPort.Watchdog?.Clear();
    }
}
