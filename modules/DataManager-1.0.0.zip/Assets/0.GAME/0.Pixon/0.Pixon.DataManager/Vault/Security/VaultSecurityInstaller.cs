using UnityEngine;

namespace Pixon.Data
{
    public static class VaultSecurityInstaller
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        public static void Install()
        {
            VaultSecurityPort.Install(new VaultCipher(), new VaultMemoryGuard(), VaultIntegrity.Watchdog);
        }

#if UNITY_EDITOR
        [UnityEditor.InitializeOnLoadMethod]
        private static void InstallInEditor() => Install();
#endif
    }
}
