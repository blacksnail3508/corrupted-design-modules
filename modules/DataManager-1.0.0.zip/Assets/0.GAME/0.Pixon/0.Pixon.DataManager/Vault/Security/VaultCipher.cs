using System;

namespace Pixon.Data
{
    internal sealed class VaultCipher : IVaultCipher
    {
        public byte[] Seal(byte[] plain, string aad) => VaultCrypto.Seal(plain, aad);

        public bool TryOpen(byte[] blob, string aad, out byte[] plain) =>
            VaultCrypto.TryOpen(blob, aad, out plain);

        public bool IsSealedBlob(byte[] blob) => VaultCrypto.HasMagic(blob);

        public string SealToString(string plain, string aad) => VaultCrypto.SealToString(plain, aad);

        public bool TryOpenString(string stored, string aad, out string plain) =>
            VaultCrypto.TryOpenString(stored, aad, out plain);

        public bool IsSealedString(string stored) =>
            !string.IsNullOrEmpty(stored) && stored.StartsWith(VaultCrypto.BlobPrefix, StringComparison.Ordinal);

        public bool IsLegacyString(string stored) =>
            !string.IsNullOrEmpty(stored) && stored.StartsWith(VaultCrypto.V2Prefix, StringComparison.Ordinal);

        public bool TryOpenLegacy(string stored, out string plain) =>
            VaultCrypto.TryOpenV2(stored, out plain);

        public string HashKeyName(string key) => VaultKeyName.Hash(key);

        public void Prime() => VaultCrypto.Prime();

        public void ResetKeys() => VaultCrypto.ResetKeyCache();

        public void DeleteKeysAndSalt() => VaultCrypto.DeleteSaltAndResetKeys();
    }
}
