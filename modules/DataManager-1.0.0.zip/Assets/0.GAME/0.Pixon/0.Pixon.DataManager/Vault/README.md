# Pixon.DataManager — Vault

Hệ thống lưu dữ liệu người chơi cho Unity. Một API duy nhất (`Vault<T>`) đứng trước nhiều nơi lưu
khác nhau, có mã hóa + xác thực toàn vẹn ở tầng dưới.

Yêu cầu: Unity 6000.x, .NET Standard 2.1, IL2CPP, Newtonsoft.Json, Odin Inspector (chỉ dùng cho attribute hiển thị).

> **Code trong package không có comment.** Toàn bộ giải thích — kể cả từng method — nằm ở file này.
> Sửa code thì cập nhật file này theo.

Tài liệu kèm theo: **[`SECURITY_INTEGRATION.md`](SECURITY_INTEGRATION.md)** — guide tích hợp tầng
security với package save/load khác, hoặc tự viết tầng security thay thế.

---

## Mục lục

1. [Cấu trúc package](#1-cấu-trúc-package)
   - [1.1 Hợp đồng giữa hai tầng](#11-hợp-đồng-giữa-hai-tầng)
   - [1.2 Chạy không có tầng security](#12-chạy-không-có-tầng-security)
   - [1.3 Tự implement tầng security](#13-tự-implement-tầng-security)
2. [Dùng thế nào](#2-dùng-thế-nào)
3. [Các loại mã hóa và tác dụng](#3-các-loại-mã-hóa-và-tác-dụng)
4. [Tham chiếu API — `Vault<T>`](#4-tham-chiếu-api--vaultt)
5. [Tham chiếu API — `VaultCrypto`](#5-tham-chiếu-api--vaultcrypto)
6. [Tham chiếu API — `SecuredPrefs`](#6-tham-chiếu-api--securedprefs)
7. [Tham chiếu API — `JsonFileStore`](#7-tham-chiếu-api--jsonfilestore)
8. [Tham chiếu API — `VaultMigrator`](#8-tham-chiếu-api--vaultmigrator)
9. [Editor tool](#9-editor-tool)
10. [Chặn được gì, không chặn được gì](#10-chặn-được-gì-không-chặn-được-gì)
11. [Chống sửa RAM](#11-chống-sửa-ram)
12. [Những thứ tuyệt đối không được đổi](#12-những-thứ-tuyệt-đối-không-được-đổi)

---

## 1. Cấu trúc package

Package chia làm **3 tầng, mỗi tầng một folder**, và hai tầng ngoài **không hề biết nhau** — chúng chỉ
nói chuyện qua tầng hợp đồng ở giữa.

```
Vault/
  Contract/          ── HỢP ĐỒNG: chỉ interface + struct, không có logic
    IVaultCipher.cs         Hợp đồng mã hóa  + PlainVaultCipher (bản trần, mặc định)
    IVaultMemoryGuard.cs    Hợp đồng che RAM + PlainMemoryGuard (bản trần, mặc định)
    IVaultWatchdog.cs       Hợp đồng quét nền + IVaultGuarded + facade VaultWatch
    VaultSecurityPort.cs    Nơi cắm implement vào. Chưa cắm gì ⇒ dùng bản trần
    VaultGuardedTypes.cs    ObscuredInt/Long/Float/Bool — vỏ, phần mã hóa đi qua port
    VaultSecurity.cs        Event OnTamperDetected + VaultTamperKind + Report()

  Api/               ── SAVE/LOAD: không có một dòng crypto nào
    Vault.cs                Vault<T> + VaultSaveQueue — API người dùng, cache RAM, gom write
    SecuredPrefs.cs         Backend: PlayerPrefs (tên key + giá trị đi qua IVaultCipher)
    JsonFileStore.cs        Backend: 1 file JSON ở persistentDataPath
    VaultMigrator.cs        Chuyển dữ liệu giữa các backend theo schema

  Security/          ── SECURITY: không biết Vault<T> hay backend nào tồn tại
    VaultCrypto.cs          Toàn bộ crypto: khóa, salt, seal/open  ← nơi DUY NHẤT biết về mã hóa
    VaultKeyName.cs         Hash tên key (HMAC "sc_"+key)
    VaultCipher.cs          implement IVaultCipher, gói VaultCrypto + VaultKeyName
    VaultMemoryGuard.cs     VaultGuard + implement IVaultMemoryGuard — chống sửa RAM (mục 11)
    VaultIntegrity.cs       implement IVaultWatchdog: quét ngẫu nhiên, honeypot, đối chiếu đĩa
    VaultSecurityInstaller.cs  Cắm cả 3 implement vào port lúc SubsystemRegistration

Editor/
  VaultEditorWindow.cs   Tool xem/sửa dữ liệu (Menu: Pixon > Vault Editor)
PlayerPrefsKey.cs    Khai báo tên key. Editor tool tra ngược tên key từ đây.
```

Chiều phụ thuộc:

```
   Api/  ────────►  Contract/  ◄────────  Security/
 (save/load)      (interface)          (implement)
```

Không có mũi tên nào giữa `Api/` và `Security/`. Kiểm được bằng grep — cả hai chiều đều rỗng:

```bash
cd Vault
grep -rn "VaultCrypto\|VaultIntegrity\|VaultKeyName" Api/                # rỗng
grep -rn "Vault<\|SecuredPrefs\|JsonFileStore\|VaultBackend" Security/   # rỗng
```

Hệ quả — hai chiều thay thế đều mở:

| Muốn | Làm gì |
|---|---|
| Chạy không cần security | Xóa cả folder `Security/`. `Api/` vẫn compile, tự chạy ở chế độ trần (mục 1.2) |
| Đổi suite mã hóa / tự viết security | Viết class implement `IVaultCipher`, cắm vào port (mục 1.3) |
| Dùng `Security/` cho package save/load khác | Copy `Contract/` + `Security/`, bên save/load mới gọi qua `VaultSecurityPort` (mục 1.3) |

Cả 3 folder dùng chung namespace `Pixon.Data` — chia folder là để đọc code và để kiểm chiều phụ thuộc,
không tạo thêm assembly, nên không có `using` nào phải sửa khi file di chuyển.

### 1.1 Hợp đồng giữa hai tầng

Toàn bộ bề mặt tiếp xúc gói trong 3 interface. Signature **chỉ dùng kiểu BCL** (`byte[]`, `string`,
`long`) — không có kiểu nào của `Api/` lọt vào, đó là lý do `Security/` mang đi project khác dùng được.

`IVaultCipher` — `Api/` gọi mỗi lần đọc/ghi:

| Method | Api dùng ở đâu | Bản trần làm gì |
|---|---|---|
| `Seal(byte[] plain, string aad)` | `JsonFileStore.FlushToDisk` | trả thẳng `plain` |
| `TryOpen(byte[] blob, string aad, out byte[] plain)` | `JsonFileStore.TryLoadFile` | trả thẳng blob |
| `IsSealedBlob(byte[] blob)` | phân loại file trước khi giải mã | `false` |
| `SealToString(string plain, string aad)` | `SecuredPrefs.Write` | trả thẳng `plain` |
| `TryOpenString(string stored, string aad, out string plain)` | `SecuredPrefs.TryRead` | trả thẳng `stored` |
| `IsSealedString` / `IsLegacyString` | editor tool gắn nhãn trạng thái | `false` |
| `TryOpenLegacy(string stored, out string plain)` | đọc format cũ để nâng cấp | `false` |
| `HashKeyName(string key)` | `SecuredPrefs` đặt tên slot | trả thẳng `key` |
| `Prime()` | derive khóa sớm ở splash | no-op |
| `ResetKeys()` / `DeleteKeysAndSalt()` | `SecuredPrefs.ResetKeyCache` / `DeleteAll` | no-op |

`IVaultMemoryGuard` — 3 method, che giá trị trong RAM (mục 11):

| Method | Ý nghĩa | Bản trần |
|---|---|---|
| `Encode(long value, out long stored, out int token, out int check)` | mã hóa 1 ô | `stored = value`, `token = 1`, `check = 0` |
| `TryDecode(long stored, int token, int check, out long value)` | giải mã, `false` nếu bị sửa | luôn `true` |
| `IsIntact(long stored, int token, int check)` | kiểm tra không side-effect | luôn `true` |

Ba field `stored/token/check` là **toàn bộ chỗ chứa** mà `ObscuredLong` cấp cho implement — muốn lưu
thêm state thì phải nhét vào 3 field này. `token == 0` được `Contract/` giữ riêng làm nghĩa "chưa set
bao giờ", nên `Encode` **phải** trả `token != 0`.

`IVaultWatchdog` — quét nền, hoàn toàn tùy chọn:

`Register(IVaultGuarded)`, `Unregister`, `RegisterHoneypot(key, Func<int> truth)`, `SyncHoneypot(handle)`,
`ScanNow()`, `Clear()`, `Enabled`. Game code **không gọi trực tiếp** mà gọi qua facade
`VaultWatch.*` — chưa cắm watchdog thì mọi lời gọi thành no-op (`RegisterHoneypot` trả `-1`,
`ScanNow` trả `0`), nên code gọi không cần `#if` hay null-check.

`VaultSecurity` nằm ở `Contract/` **cố ý**: nó là kênh báo động chung, không phải logic bảo mật. Cả
`Api/` (MAC fail, lệch đĩa) và `Security/` (honeypot, checksum RAM) đều báo về đây, và game vẫn
`VaultSecurity.OnTamperDetected += ...` được dù đã xóa `Security/` — chỉ là không còn ai bắn event.

### 1.2 Chạy không có tầng security

Xóa folder `Security/` (kèm `.meta`) là xong — không cần sửa define, không cần sửa `using`. Không có
implement nào được cắm ⇒ `VaultSecurityPort` trả bản trần ⇒ hệ thống tự tụt xuống chế độ không bảo mật:

| Thành phần | Có `Security/` | Không có `Security/` |
|---|---|---|
| Tên slot PlayerPrefs | HMAC 16 byte base64url | **tên key gốc** |
| Giá trị trong PlayerPrefs | `"pv:"` + blob AES-256 + HMAC | **plaintext** |
| `vault.json` khi build | blob `PXVT` | **JSON trần** |
| `vault.json` trần trong build | bị từ chối (chống hạ cấp) | được chấp nhận |
| `ObscuredInt/Long/Float/Bool` | mask + checksum, đổi mask mỗi lần đọc | **lưu thẳng giá trị**, `IsIntact()` luôn `true` |
| `VaultWatch.*` | quét mỗi 4–11 s, honeypot | no-op |
| `VaultSecurity.OnTamperDetected` | có bắn | không bao giờ bắn |
| Canary key-mismatch | có kiểm | bỏ qua |

> ⚠️ **Không phải công tắc bật/tắt tự do trên bản đã phát hành.** Xóa `Security/` đổi cả *tên slot* lẫn
> *định dạng giá trị*. Người chơi đang có dữ liệu mã hóa sẽ **mất sạch save** ở bản update đó: tên slot
> mới tra không ra slot cũ, và bản trần không giải mã được blob `PXVT`. Thêm lại `Security/` thì dữ liệu
> cũ đọc lại được (salt vẫn còn), nhưng những gì ghi trong lúc chạy trần thì mất.
>
> Xóa/thêm thoải mái được khi: project mới chưa phát hành, hoặc prototype, hoặc bản build test đang
> cần xem save bằng mắt. Với build đã phát hành thì phải đi đường migrate — xem `VaultMigrator` (mục 8).

Muốn **tạm bỏ security mà không mất dữ liệu** thì đừng xóa folder — chỉ cần đổi backend sang
`VaultBackend.PlayerPrefs` cho từng key cần đọc bằng mắt, hoặc tắt riêng phần quét nền bằng
`VaultWatch.Enabled = false`. Cả hai không đụng tới định dạng của các key khác.

### 1.3 Tự implement tầng security

> 📄 Phần này là bản tóm tắt. Guide đầy đủ — tạo class nào, implement interface nào, gọi hàm nào, ở
> thời điểm nào, thread-safety, checklist, cách test, lỗi thường gặp — nằm ở
> **[`SECURITY_INTEGRATION.md`](SECURITY_INTEGRATION.md)**.

Ba bước. Không cần sửa file nào trong `Api/`.

**Bước 1 — implement interface cần thay.** Ba interface độc lập nhau: thay mã hóa mà giữ nguyên phần
chống sửa RAM là hợp lệ, và ngược lại.

```csharp
using Pixon.Data;

internal sealed class MyCipher : IVaultCipher
{
    public byte[] Seal(byte[] plain, string aad)                             { /* ... */ }
    public bool   TryOpen(byte[] blob, string aad, out byte[] plain)          { /* ... */ }
    public bool   IsSealedBlob(byte[] blob)                                   { /* ... */ }
    public string SealToString(string plain, string aad)                      { /* ... */ }
    public bool   TryOpenString(string stored, string aad, out string plain)  { /* ... */ }
    public bool   IsSealedString(string stored)                               { /* ... */ }
    public bool   IsLegacyString(string stored) => false;
    public bool   TryOpenLegacy(string stored, out string plain) { plain = null; return false; }
    public string HashKeyName(string key)                                     { /* ... */ }
    public void   Prime()               { }
    public void   ResetKeys()           { }
    public void   DeleteKeysAndSalt()   { }
}
```

**Bước 2 — cắm vào port, càng sớm càng tốt.**

```csharp
public static class MySecurityInstaller
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    public static void Install()
    {
        VaultSecurityPort.InstallCipher(new MyCipher());
        VaultSecurityPort.InstallMemoryGuard(new MyMemoryGuard());   // hoặc bỏ, dùng bản trần
        VaultSecurityPort.InstallWatchdog(MyWatchdog.Instance);      // hoặc bỏ
    }

#if UNITY_EDITOR
    [UnityEditor.InitializeOnLoadMethod]
    private static void InstallInEditor() => Install();
#endif
}
```

`SubsystemRegistration` là điểm khởi tạo **sớm nhất** của Unity, chạy trước `BeforeSceneLoad` nơi
`VaultCrypto.Prime()` derive khóa. Cắm muộn hơn lần đọc Vault đầu tiên = lần đọc đó chạy bằng bản trần.
Nhánh `UNITY_EDITOR` là bắt buộc nếu muốn editor tool và các lần ghi ngoài play mode cũng đi qua
implement của bạn — `RuntimeInitializeOnLoadMethod` không chạy ngoài play mode.

**Bước 3 — báo động thì gọi về `VaultSecurity.Report`**, đừng tự dựng event riêng, để game chỉ phải
đăng ký một chỗ:

```csharp
VaultSecurity.Report(VaultTamperKind.MacFail, key, "verify MAC thất bại");
```

**Dùng `Security/` với package save/load khác.** Copy `Contract/` + `Security/` sang project mới rồi
cho tầng save/load bên đó gọi qua port — đúng những gì `Api/` đang gọi:

```csharp
// ghi
var blob = VaultSecurityPort.Cipher.Seal(bytes, aad);
var slot = VaultSecurityPort.Cipher.HashKeyName(key);

// đọc
if (VaultSecurityPort.Cipher.IsSealedBlob(raw) &&
    VaultSecurityPort.Cipher.TryOpen(raw, aad, out var plain)) { /* ... */ }

// chỉ mã hóa khi thật sự có implement được cắm
bool encrypt = !Application.isEditor && VaultSecurityPort.Encrypts;
```

Ba quy tắc bắt buộc khi viết tầng save/load riêng:

1. **`aad` phải ràng buộc blob với đúng ô của nó** — `Api/` dùng tên key gốc làm `aad`. Truyền `null`
   hoặc một hằng dùng chung cho mọi ô là mở lại lỗ splicing (mục 3).
2. **Đọc `VaultSecurityPort.Encrypts` trước khi quyết định từ chối dữ liệu trần.** Từ chối vô điều kiện
   thì bản không có `Security/` sẽ không đọc được chính file nó vừa ghi.
3. **Đi qua `VaultSecurityPort`, không `new` implement trực tiếp.** `new MyCipher()` ở chỗ dùng là đóng
   luôn cửa thay thế mà tầng này tồn tại để mở.

Kèm theo: [`VAULT_SECURITY_PLAN.md`](../../../../VAULT_SECURITY_PLAN.md) ở root repo — lịch sử các
vấn đề bảo mật đã/đang xử lý.

---

## 2. Dùng thế nào

```csharp
using Pixon.Data;
using PPK = PlayerPrefsKey;

[SerializeField] Vault<Wallet> wallet     = new(PPK.Wallet, new Wallet());
[SerializeField] Vault<int>    levelVault = new(PPK.Level, 1);

int level = levelVault.Value;      // đọc (cache sau lần đầu)
levelVault.Value = level + 1;      // ghi
levelVault.Save(level + 1);        // tương đương
if (levelVault.Exists) { ... }     // key đã tồn tại trên đĩa chưa
```

**Kiểu `T` hỗ trợ:** `int`, `float`, `string`, `bool`, `enum` (lưu như int), và **mọi object khác**
(serialize bằng Newtonsoft.Json rồi lưu như string).

**Chọn nơi lưu** — `VaultBackend`:

| Backend | Nơi lưu | Mã hóa |
|---|---|---|
| `Auto` *(mặc định)* | Editor → PlayerPrefs trần; Build → SecuredPrefs | Có, khi build |
| `PlayerPrefs` | PlayerPrefs trần | Không |
| `SecuredPrefs` | PlayerPrefs, tên key hash + giá trị seal | Có |
| `JsonFile` | `persistentDataPath/vault.json` | Có, khi build |

```csharp
var remote = new Vault<RemoteSnapshot>("Remote_Cache", null, VaultBackend.JsonFile);
```

---

## 3. Các loại mã hóa và tác dụng

Mỗi thành phần giải quyết một vấn đề cụ thể — không cái nào là trang trí.

| Thành phần | Thuật toán / tham số | Tác dụng | Bỏ đi thì hở chỗ nào |
|---|---|---|---|
| **Dẫn xuất khóa** | PBKDF2-HMAC-SHA256, 10.000 vòng, salt ngẫu nhiên 16 byte/máy, ra 80 byte | Mỗi lần cài đặt có khóa riêng ⇒ save không dùng chung giữa máy, tool cheat "một khóa cho mọi máy" vô dụng | Khóa cứng trong binary ⇒ một người crack, cả cộng đồng dùng được |
| **Mã hóa giá trị** | AES-256-CBC + PKCS7 | Che nội dung: mở PlayerPrefs / file save không đọc được `coin`, `level` là bao nhiêu | Ai cũng sửa được bằng Notepad |
| **IV ngẫu nhiên mỗi lần ghi** | 16 byte từ CSPRNG, ghép đầu blob | Cùng một giá trị ghi 2 lần ra 2 ciphertext khác nhau ⇒ không suy được "giá trị này có đổi không" | IV cố định ⇒ so 2 bản save là biết cái gì vừa đổi |
| **Xác thực toàn vẹn** | HMAC-SHA256, tag 32 byte, phủ `magic‖ver‖IV‖ciphertext‖AAD` | **Quan trọng nhất.** Chặn sửa mù: CBC cho phép lật bit trong IV để lật đúng bit trong plaintext — sửa được `coin` mà **không cần biết khóa** | Mã hóa mà vẫn sửa được giá trị. Lỗ hổng thực tế, không phải lý thuyết |
| **Encrypt-then-MAC** | Verify tag **trước** khi decrypt | Không chạy unpad/parse trên dữ liệu chưa xác thực ⇒ đóng padding oracle | Verify sau khi decrypt là mở lại chính lỗ vừa vá |
| **AAD (dữ liệu phụ được ký)** | Tên key gốc đưa vào phạm vi HMAC, có prefix độ dài 2 byte | Ràng buộc blob với đúng ô của nó ⇒ chép giá trị đã mã hóa từ `highest_score` sang `coin` sẽ fail | Splicing: đổi chỗ 2 blob là đổi được giá trị mà không phá mã hóa |
| **Hash tên key** | HMAC-SHA256(secret, `"sc_"+key`) → 16 byte → base64url | Người mở PlayerPrefs không biết ô nào là `Wallet`. Một chiều, không tra ngược được | Tên key lộ hết, biết ngay nên sửa ô nào |
| **Magic header** | 4 byte `"PXVT"` + 1 byte version, nằm trong phạm vi MAC | Phân biệt format và **chặn hạ cấp**: thay file mã hóa bằng JSON trần không còn được chấp nhận | Chỉ cần ghi đè file bằng JSON thường là bypass sạch mọi lớp mã hóa |
| **So sánh tag** | Constant-time (vòng XOR, không return sớm) | Không rò rỉ thông tin qua thời gian so sánh | Ít giá trị trên client offline, nhưng là chuẩn đúng |
| **Sinh số ngẫu nhiên** | `RandomNumberGenerator` (CSPRNG) cho salt và IV | Không đoán trước được | `System.Random` đoán được từ seed |
| **Canary** | Một plaintext đã biết, seal bằng khóa hiện tại | Phát hiện ngay khi khóa lệch (mất salt) thay vì im lặng trả default cho từng key | Mất dữ liệu âm thầm, không ai biết vì sao |

Newtonsoft.Json chỉ để serialize object thành string — **không có tác dụng bảo mật nào**.

### 3.1 Format blob

```
offset   size   field
0        4      magic   "PXVT"     (cố định, không đổi giữa các version)
4        1      version 0x04       (= AES-256-CBC + HMAC-SHA256)
5        16     IV
21       N      ciphertext   AES-256-CBC + PKCS7
21+N     32     tag          HMAC-SHA256(macKey, magic‖ver‖IV‖ciphertext‖aadLen(2B LE)‖aad)
```

Trong PlayerPrefs lưu dạng string: `"pv:"` + base64(blob). Trong file lưu nhị phân thẳng.
`aadLen` có mặt để `"ab"+"c"` và `"a"+"bc"` không cho ra cùng một tag.

**Magic tách rời khỏi version là cố ý.** `"PXVT"` chỉ trả lời "đây có phải blob của Vault không" —
`HasMagic()` dùng nó để phân loại file mà không cần đụng tới khóa, và nó **không bao giờ đổi**.
Version byte mới là thứ nói suite mã hóa nào đang dùng. Nâng cấp lần sau (đổi thuật toán, đổi độ dài
khóa) chỉ cần thêm một hằng `VersionXxx` và một nhánh trong `TryOpen` — không đụng gì tới cách nhận
diện file.

| Version | Suite | Tình trạng |
|---|---|---|
| `0x04` | AES-256-CBC + HMAC-SHA256, AAD | Hiện hành, được ghi ra |
| *(v2, không có magic)* | AES-128-CBC, không MAC, prefix `"v2:"` | Chỉ đọc, tự nâng cấp khi đọc được |

### 3.2 Vòng đời khóa

```
KeySeed (hằng số trong code)  +  salt (16 byte ngẫu nhiên, riêng từng máy)
                    │
              PBKDF2-SHA256, 10.000 vòng
                    │
              master 80 byte
                    ├── byte 0..16   → v2Key  (AES-128, CHỈ để đọc dữ liệu format cũ)
                    ├── byte 16..48  → encKey (AES-256)
                    └── byte 48..80  → macKey (HMAC-SHA256)
```

Ba khóa **không chồng lấn nhau** — dùng chung key material cho hai thuật toán khác nhau là practice sai.
`v2Key` giữ đúng vị trí `[0..16]` vì đó chính là khóa mà format v2 đã dùng; nhờ vậy dữ liệu người chơi
hiện có vẫn giải mã được sau khi lên AES-256.

**Salt được lưu 2 nơi** có kiểu hỏng độc lập: `PlayerPrefs["sc__install_salt"]` (chính) và
`persistentDataPath/sc_salt.bin` (backup). Mất một bên thì tự khôi phục từ bên kia. Mất cả hai =
sinh salt mới = **toàn bộ dữ liệu đã mã hóa không đọc lại được** — salt là thứ quan trọng nhất
trong hệ thống này, dù bản thân nó không bí mật.

Khóa được derive sớm ở `BeforeSceneLoad` (`VaultCrypto.Prime()`) vì hai lý do: PBKDF2 tốn vài chục ms
(làm lúc splash, không phải giữa gameplay), và `PlayerPrefs` / `Application.persistentDataPath` không
an toàn khi gọi ngoài main thread — trong khi `JsonFileStore.WarmupAsync()` đọc file trên thread phụ.

### 3.3 Ghi chú về AES-256

Package dùng AES-256. Cần nói rõ để không kỳ vọng sai: **so với AES-128 nó không làm game khó cheat hơn.**
Bẻ 2^128 vốn đã bất khả thi; điểm yếu thật là seed nằm cứng trong binary và salt nằm plain trên máy —
ai lấy được cả hai thì derive lại khóa, độ dài khóa bao nhiêu cũng vậy. Phần MAC thì vốn đã 256-bit từ đầu.

Lý do chọn 256 ở đây là **tính bền của package**: nó được tái sử dụng cho nhiều project (kể cả PC, nơi
mô hình đe dọa nặng hơn) và cho các đợt nâng cấp sau. Chi phí gần như bằng 0:

- PBKDF2 phải sinh 3 block thay vì 2 ⇒ derive chậm hơn ~50% (30k thay vì 20k vòng HMAC). Chỉ chạy một
  lần lúc splash, vài chục ms.
- AES-256 chạy 14 vòng thay vì 10 ⇒ chậm hơn ~30% trên mỗi block. Với vài trăm byte thì không đo được.
- Không đổi API, không đổi layout blob: `Aes.Create()` tự chọn AES-256 khi `Key.Length == 32`, và IV
  vẫn 16 byte vì block size của AES luôn là 128-bit bất kể độ dài khóa.

### 3.4 Nâng cấp suite mã hóa về sau

Format được thiết kế để nâng cấp mà không mất dữ liệu. Quy trình:

1. Thêm hằng `VersionXxx = 0x05` trong `VaultCrypto`, đặt `VersionCurrent = VersionXxx`.
2. Trong `TryOpen`, thay `if (blob[4] != VersionAes256)` bằng switch theo version — nhánh cũ giữ nguyên.
3. Nếu suite mới cần khóa mới: **nối thêm** vào cuối master (`MasterKeyLength` tăng), **không** dịch
   chuyển các đoạn đã có. PBKDF2 sinh theo stream nên các byte đầu giữ nguyên ⇒ khóa cũ không đổi ⇒
   dữ liệu cũ vẫn đọc được.
4. `Seal` luôn ghi ra `VersionCurrent`. Dữ liệu cũ tự nâng cấp khi được đọc (upgrade-on-read), giống
   cách v2 đang được nâng lên hiện nay.

Không cần đụng `HasMagic`, `SecuredPrefs`, `JsonFileStore` hay editor tool.

### 3.5 Vì sao không dùng AES-GCM

Project ở API level .NET Standard 2.1, mà `System.Security.Cryptography.AesGcm` là .NET Core 3.0+ —
không tồn tại trong netstandard2.1. AES-CBC + HMAC (encrypt-then-MAC) cho cùng tính chất bảo mật
với primitive luôn có sẵn trên Mono/IL2CPP.

---

## 4. Tham chiếu API — `Vault<T>`

File `Vault/Api/Vault.cs`. Lớp mặt tiền: cache giá trị trong RAM, chọn backend, gom write.

### `Vault<T>` — public

| Thành viên | Làm gì | Cần biết |
|---|---|---|
| `Vault(string key, T defaultValue = default)` | Tạo với backend `Auto` | Không chạm đĩa cho tới lần đọc/ghi đầu |
| `Vault(string key, T defaultValue, VaultBackend backend)` | Tạo với backend chỉ định | Backend là `readonly`, không đổi được sau khi tạo |
| `T Value { get; set; }` | Đọc/ghi giá trị | **get**: lần đầu đọc từ backend rồi cache vĩnh viễn trong instance. **set**: gọi `Save()` |
| `void Save(T newValue)` | Cập nhật cache + xếp hàng ghi | Không ghi đĩa ngay — xem `VaultSaveQueue` |
| `bool Exists { get; }` | Key đã có trên backend chưa | Đi thẳng xuống backend, **không** dùng cache |

**Bẫy cần nhớ:** hai instance `Vault<T>` cùng trỏ một key sẽ có 2 cache riêng và không thấy thay đổi
của nhau. Mỗi key nên có đúng một instance (thường là field của manager).

### `Vault<T>` — private

| Method | Làm gì |
|---|---|
| `ResolvedBackend` | `Auto` → `PlayerPrefs` trong editor, `SecuredPrefs` khi build. Backend khác thì giữ nguyên |
| `Read()` | Điều phối sang `ReadFromPlayerPrefs` / `ReadFromSecuredPrefs` / `ReadFromJsonFile` |
| `ReadFromPlayerPrefs/SecuredPrefs/JsonFile()` | Đọc theo đúng kiểu native của `T`; kiểu lạ thì đọc string rồi `ReadJson` |
| `WriteToPlayerPrefs/SecuredPrefs/JsonFile(T)` | Ghi theo đúng kiểu native; kiểu lạ thì `WriteJson` rồi ghi string |
| `QueueWrite(T value)` | **Chụp lại giá trị** (snapshot) theo kiểu rồi đẩy vào `VaultSaveQueue`. Chụp là để nếu giá trị bị sửa tiếp trước lúc flush thì cái được ghi vẫn là cái tại thời điểm gọi |
| `GetStorageKey()` | `"{backend}::{key}"` — khóa gom trong queue. Có prefix backend để cùng một tên key ở 2 backend không đè lên nhau |
| `WriteSnapshot / WriteEnumSnapshot / WriteJsonSnapshot` | Ba dạng ghi thật, chạy lúc flush |
| `ReadJson(Func<string>)` | Đọc string rồi `JsonConvert.DeserializeObject<T>`. Rỗng hoặc parse lỗi → trả `defaultValue` và log warning |
| `WriteJson(T)` | `JsonConvert.SerializeObject` |

### `VaultSaveQueue` (internal static)

Gom nhiều lệnh ghi trong cùng một frame thành một lần chạm đĩa.

| Method | Làm gì |
|---|---|
| `Enqueue(storageKey, writeAction, backend)` | Đặt/ghi đè action theo `storageKey` (nên ghi cùng key 10 lần chỉ còn 1 action cuối). Ngoài play mode thì flush ngay. Trong play mode thì khởi động coroutine trễ **50 ms** |
| `FlushNow()` | Chạy hết action đang chờ, rồi gọi `PlayerPrefs.Save()` và/hoặc `JsonFileStore.Save()` tùy backend nào có việc |
| `FlushDeferred()` | Coroutine chờ 50 ms (realtime) rồi `FlushNow()` |
| `EnsureRunner()` | Tạo GameObject `"VaultSaveQueue"` + `DontDestroyOnLoad` để có chỗ chạy coroutine |
| `Runner.OnApplicationPause(true)` / `OnApplicationQuit()` | Flush ngay — chống mất dữ liệu khi app bị đưa xuống nền hoặc thoát |

Gọi `VaultSaveQueue.FlushNow()` thủ công nếu cần chắc chắn dữ liệu đã xuống đĩa (trước khi mở IAP, trước khi gửi telemetry...).

---

## 5. Tham chiếu API — `VaultCrypto`

File `Vault/Security/VaultCrypto.cs`. **Nơi duy nhất biết về khóa và format.** Không backend nào được tự chế crypto.

### Public

| Thành viên | Làm gì | Cần biết |
|---|---|---|
| `bool TamperDetected { get; }` | Bật `true` khi gặp blob đúng magic nhưng sai tag | Hai nguyên nhân: dữ liệu bị sửa từ ngoài, hoặc khóa đã đổi. Dùng canary của `SecuredPrefs` để phân biệt |
| `const string BlobPrefix = "pv:"` | Prefix của blob khi lưu dạng string | Không mang số version — version nằm trong blob |
| `const string V2Prefix = "v2:"` | Prefix format cũ | Chỉ đọc, không bao giờ ghi ra |
| `void Prime()` | Cache `persistentDataPath` + derive khóa | Có `[RuntimeInitializeOnLoadMethod(BeforeSceneLoad)]` nên tự chạy. **Đừng xóa attribute** — nó là thứ giữ cho background thread không chạm PlayerPrefs |
| `void ResetKeyCache()` | Bỏ khóa trong RAM | Gọi sau khi xóa/khôi phục PlayerPrefs bằng đường khác (restore cloud save) |
| `void DeleteSaltAndResetKeys()` | Xóa cả 2 bản sao salt + reset khóa | **Chỉ dùng khi đã xóa sạch dữ liệu.** Gọi nhầm = mất hết |
| `byte[] Seal(byte[] plain, string aad)` | Mã hóa + ký, trả blob v3 | `aad` được ký nhưng **không** mã hóa; nó ràng buộc blob với ngữ cảnh |
| `bool TryOpen(byte[] blob, string aad, out byte[] plain)` | Kiểm magic → kiểm version → verify tag → mới decrypt | `false` nếu không phải blob Vault / version lạ / sai tag / hỏng. Sai tag ⇒ bật `TamperDetected` + log error. **Chỗ thêm nhánh khi lên version mới** |
| `bool HasMagic(byte[] blob)` | Buffer có bắt đầu bằng `"PXVT"` không | Không đụng tới khóa — dùng để phân loại file trước khi quyết định giải mã. Đúng với mọi version |
| `string SealToString(string plain, string aad)` | `Seal` + base64 + prefix `"pv:"` | Bản tiện dụng cho PlayerPrefs |
| `bool TryOpenString(string stored, string aad, out string plain)` | Ngược lại của `SealToString` | |
| `bool TryOpenV2(string stored, out string plain)` | Đọc format v2 cũ (AES-128-CBC, IV ghép đầu, **không MAC**) | Chỉ để nâng cấp dữ liệu người chơi hiện có. Dùng `KeySet.V2` = `master[0..16]`, tách rời khỏi `encKey` |

### Private

| Method | Làm gì |
|---|---|
| `ComputeTag(macKey, blob, length, aad)` | HMAC-SHA256 lần lượt qua `blob[0..length]`, 2 byte độ dài AAD (little-endian), rồi AAD |
| `ConstantTimeEquals(a, aOff, b, bOff, len)` | So sánh bằng XOR dồn, không return sớm |
| `Keys` | Property trả `KeySet` đã derive, gọi `EnsureKeys()` nếu chưa có |
| `EnsureKeys()` | Double-checked lock; PBKDF2 ra 80 byte rồi tách `[0..16]` = v2Key, `[16..48]` = encKey, `[48..80]` = macKey; xóa mảng master sau khi tách. Gán `keys` **một lần** vào field `volatile` để thread phụ hoặc thấy `null` hoặc thấy KeySet hoàn chỉnh, không có trạng thái nửa vời |
| `LoadOrCreateSalt()` | Đọc salt từ PlayerPrefs (chính) và file (backup). Có prefs → đồng bộ lại file nếu lệch. Chỉ có file → **khôi phục vào prefs** (ca cứu dữ liệu). Không có gì → sinh mới bằng CSPRNG và ghi cả 2 nơi |
| `TryParseSalt(b64)` | Parse base64 + kiểm tra đúng 16 byte; sai thì coi như không có (thay vì ném exception) |
| `SaltEquals(a, b)` | So sánh 2 salt |
| `PersistSaltToPrefs(b64)` | Ghi + `Save()` + **đọc lại kiểm chứng**; ghi hụt thì log error ngay thay vì để phát hiện ở session sau |
| `ReadSaltFile / WriteSaltFile / DeleteSaltFile` | Thao tác bản backup ở `persistentDataPath/sc_salt.bin` |
| `DataPath` | `persistentDataPath` đã cache (lazy fallback nếu `Prime()` chưa chạy) |

---

## 6. Tham chiếu API — `SecuredPrefs`

File `Vault/Api/SecuredPrefs.cs`. PlayerPrefs với tên key được hash và giá trị được seal.

### Public

| Method | Làm gì | Cần biết |
|---|---|---|
| `SetInt / SetFloat / SetString / SetBool` | Ghi | Tất cả quy về string rồi seal. `float` dùng `"R"`, `bool` dùng `"1"/"0"` |
| `GetInt / GetFloat / GetString / GetBool` | Đọc, có default | Mở blob thất bại → trả default (im lặng với caller, nhưng `VaultCrypto` đã log error) |
| `bool HasKey(string key)` | Slot đã tồn tại chưa | Không giải mã, không cần khóa |
| `void DeleteKey(string key)` | Xóa slot | |
| `void Save()` | `PlayerPrefs.Save()` | |
| `string GetStorageKey(string key)` | Trả tên slot thật (đã hash) | Hash một chiều — muốn tra ngược phải tự dựng bảng từ danh sách key đã biết |
| `void DeleteAll()` | Xóa sạch PlayerPrefs + salt + khóa cache | **Bắt buộc phải reset khóa cache**, nếu không các lần ghi sau vẫn dùng khóa cũ trong RAM còn session kế tiếp lại derive khóa mới ⇒ dữ liệu vừa ghi đọc không ra |
| `void ResetKeyCache()` | Reset khóa + cờ canary | Dùng khi xóa/khôi phục prefs bằng đường khác |
| `bool KeyMismatchDetected { get; }` | Canary không mở được ⇒ salt đã đổi | Game nên dùng cờ này để mở flow khôi phục (cloud save / restore purchase) thay vì lẳng lặng cho chơi lại từ đầu |

### Private

| Method | Làm gì |
|---|---|
| `Write(key, plain)` | `EnsureCanary()` rồi `PlayerPrefs.SetString(HashKey(key), SealToString(plain, key))`. AAD = **key gốc** |
| `TryRead(key, out plain)` | Thử mở v3 (AAD = key gốc). Không được thì thử v2; mở được v2 thì **seal lại thành v3 ngay** (upgrade-on-read) |
| `HashKey(key)` | `HMACSHA256(KeyNameHmacSecret, "sc_" + key)` → lấy 16 byte đầu → base64url (`+`→`-`, `/`→`_`, bỏ `=`) |
| `EnsureCanary()` | Chạy đúng một lần mỗi session. Canary mở được → thôi. Canary v2 → nâng lên v3, không báo động. Không mở được → `KeyMismatchDetected = true` + log error, rồi ghi canary mới. Đặt cờ `canaryChecked` **trước** khi làm gì để không đệ quy |
| `WriteCanary(hashedKey)` | Ghi canary mới + `PlayerPrefs.Save()` |

---

## 7. Tham chiếu API — `JsonFileStore`

File `Vault/Api/JsonFileStore.cs`. Toàn bộ dữ liệu nằm trong một `Dictionary<string,string>` trong RAM,
đổ xuống `persistentDataPath/vault.json`. API cố ý giống PlayerPrefs.

### Public

| Method | Làm gì | Cần biết |
|---|---|---|
| `SetInt / SetFloat / SetString / SetBool` | Ghi vào dict, bật cờ `dirty` | Số dùng `InvariantCulture` (khác `SecuredPrefs`). Giá trị không đổi thì **không** bật `dirty` |
| `GetInt / GetFloat / GetString / GetBool` | Đọc từ dict | Tự `EnsureLoaded()` nếu chưa load |
| `bool HasKey(string key)` | | |
| `void DeleteKey(string key)` | | |
| `void DeleteAll()` | Xóa sạch dict | Chưa chạm đĩa cho tới `Save()` |
| `bool IsLoaded { get; }` | Đã nạp vào RAM chưa | Đã load thì đọc/ghi không còn chạm đĩa |
| `string[] GetAllKeys()` | Snapshot toàn bộ key | Copy ra mảng mới nên duyệt an toàn |
| `string GetRaw(string key)` | Đọc string đã serialize | Dành cho editor tool |
| `void SetRaw(string key, string value)` | Ghi string thô | Caller tự chịu trách nhiệm format |
| `string GetFilePath()` | Đường dẫn file | |
| `void Warmup()` | Load đồng bộ, block tới xong | Dùng ở splash khi cần chắc chắn dữ liệu sẵn sàng. Idempotent |
| `void WarmupAsync(Action onComplete = null)` | Load ở thread phụ, callback về main thread | Gom callback của các lời gọi trùng vào cùng một đợt. Đã load rồi thì gọi callback ngay |
| `void Save()` | Flush xuống đĩa nếu `dirty` | |
| `void Reload()` | Bỏ cache RAM, đọc lại từ đĩa | |

### Private

| Method | Làm gì |
|---|---|
| `Prime()` | `[RuntimeInitializeOnLoadMethod]` — cache `persistentDataPath` và `isEditor`. Cần vì `LoadFromDisk` chạy trên Task thread mà hai API đó không an toàn ngoài main thread |
| `EncryptOnDisk` | `!isEditor` — editor để plaintext cho dễ debug, build thì mã hóa |
| `Write / TryRead` | Thao tác dict trong `lock (Sync)` |
| `EnsureLoaded()` | Double-checked lock; nếu `WarmupAsync` đang chạy song song thì cả hai có thể cùng đọc đĩa — chấp nhận, vì bên warmup có kiểm tra `!loaded` trước khi commit nên cái nào xong trước thì thắng |
| `enum LoadOutcome` | `Missing` (chưa có file, không phải lỗi) / `Corrupt` (có nhưng không tin được) / `Ok` |
| `LoadFromDisk()` | `Ok` → dùng, đánh dấu bản trên đĩa là lành. `Missing` → thử `.bak` rồi coi như install mới. `Corrupt` → thử `.bak` và **đánh dấu không lành** để lần Save tới không đè lên bản `.bak` đang tốt |
| `TryLoadFile(path, out result)` | Phân loại theo đầu file: có magic `PXVT` → verify MAC rồi decrypt; byte đầu là `{` → JSON trần, **chỉ chấp nhận trong editor**, trong build là từ chối (đây chính là đường bypass mã hóa nếu cho phép); còn lại → từ chối |
| `FlushToDisk()` | Serialize → seal (nếu build) → ghi `.tmp` → copy file cũ sang `.bak` (**chỉ khi bản cũ lành**) → `File.Replace` (hoặc `File.Move` nếu chưa có file đích) → đánh dấu bản trên đĩa là lành |

---

## 8. Tham chiếu API — `VaultMigrator`

File `Vault/Api/VaultMigrator.cs`. Chuyển dữ liệu giữa các backend.

**Vì sao phải khai báo schema:** PlayerPrefs không cho enumerate và không cho biết key nào kiểu gì;
`SecuredPrefs` hash tên key nên không suy ngược ra tên gốc. Không có schema thì không biết phải chuyển cái gì.

### Kiểu dữ liệu

| Kiểu | Vai trò |
|---|---|
| `enum VaultDataType` | `Int`, `Float`, `String`, `Bool`, `Enum` (xử lý như int), `Json` (xử lý như string) |
| `struct VaultEntry` | Một dòng schema: `Key` + `Type`. Factory: `VaultEntry.Int/Float/String/Bool/Enum/Json(key)` |
| `class VaultMigrationReport` | `Copied`, `Skipped`, `Failed`, `Deleted`, `Errors`. `ToString()` in ra gọn để log |

### Method

| Method | Làm gì | Cần biết |
|---|---|---|
| `Migrate(from, to, schema, overwrite = true, deleteSourceAfter = false)` | Copy từng entry trong schema | `Auto` bị từ chối — phải chỉ định backend cụ thể. `from == to` → không làm gì. `overwrite: false` thì key đã có ở đích sẽ bị bỏ qua và tính vào `Skipped`. Flush đích **trước** khi xóa nguồn. Chỉ xóa những key copy thành công |
| `MigrateOnce(from, to, schema, versionKey, deleteSourceAfter = false, onComplete = null)` | Chỉ migrate nếu cờ `versionKey` chưa được set ở đích, xong thì set cờ | Dùng cho auto-migrate một lần ở lần chạy đầu sau update. Trả `false` nếu đã migrate rồi |

### Private dispatch

`HasKeyOn`, `DeleteKeyOn`, `FlushBackend`, `CopyEntry`, và các cặp `GetIntOn/SetIntOn`,
`GetFloatOn/SetFloatOn`, `GetStringOn/SetStringOn`, `GetBoolOn/SetBoolOn` — chuyển lời gọi tới đúng backend.

Dùng API typed của từng backend (chứ không đọc raw string) để định dạng số khớp nhau giữa hai bên.
`PlayerPrefs` trần không có `Bool` nên quy ước của Vault là int `0/1`.

---

## 9. Editor tool

`Pixon > Vault Editor` — xem toàn bộ PlayerPrefs (đọc thẳng registry/plist) và mọi file trong `persistentDataPath`.

| Hành vi | Chi tiết |
|---|---|
| Tra ngược tên key | Dựng bảng `slot đã hash → key gốc` bằng reflection trên `PlayerPrefsKey`. **Key không khai báo ở đó thì tool không giải mã được** |
| Nhãn trạng thái | `v3 🔓` mở được · `v3 ✗MAC` sai tag · `v3 🔒?` không tra được key gốc · `v2 🔓` format cũ · `v3 🔒` file đã mã hóa · `bin` file nhị phân |
| Sửa giá trị | Khi Apply, ô đã mã hóa được **seal lại với AAD = key gốc**. Ghi plaintext thẳng vào slot đã hash sẽ khiến game verify MAC fail và mất giá trị đó |
| Chế độ chỉ-đọc | Blob không tra/không mở được, file nhị phân hoặc đã mã hóa — chặn ghi đè làm hỏng save |
| `Delete All PP` | Đi qua `SecuredPrefs.DeleteAll()` để salt file và khóa cache cũng được dọn theo |

---

## 10. Chặn được gì, không chặn được gì

**Chặn được:**
- Đọc/sửa save bằng tay (Notepad, file explorer, save editor generic).
- Sửa giá trị bằng cách lật bit trên ciphertext/IV mà không cần khóa.
- Chép blob giữa các key để nhân giá trị.
- Thay file mã hóa bằng JSON trần.
- Copy save từ máy này sang máy khác.

**KHÔNG chặn được:**
- **Người reverse engineering có nghề trên PC**: Cheat Engine + Mono dissector đọc thẳng tên
  class/field, patch hàm kiểm tra, inject code. Xem mục 11 để biết lớp chống sửa RAM chặn tới đâu.
- **Người reverse engineering có nghề.** Có root máy là lấy được salt (lưu plain) và seed (hằng số
  trong binary) ⇒ derive lại được cả 2 khóa ⇒ ký lại blob hợp lệ. Lớp này nâng chi phí cheat, **không
  phải là biên giới tin cậy**.
- **Rollback** — chép đè bản save cũ để quay lại trạng thái trước.

⇒ Dữ liệu có giá trị thương mại thật (IAP, tiền tệ mua được) **phải validate ở server**.

---

## 11. Chống sửa RAM

Mã hóa trên đĩa không giúp gì khi giá trị nằm trần trong bộ nhớ. Package có 5 tầng phòng thủ.

**Android vs PC khác hẳn nhau:**

| | Android (GameGuardian) | PC (Cheat Engine) |
|---|---|---|
| Tìm giá trị | Scan theo giá trị | Scan giá trị **+ pointer scan** |
| Đọc tên field | Khó (phải dump IL2CPP) | **Mono dissector đọc thẳng `Wallet.Coin` theo tên** |
| Sửa code | Hiếm | Dễ: inject, patch hàm kiểm tra |

⇒ Che giá trị chỉ hiệu quả với đường scan-theo-giá-trị. Trên PC bản Mono, obfuscation giá trị gần như
vô hiệu vì field tra được theo tên. Đó là lý do phòng thủ không dừng ở tầng 1.

### Tầng 1 — `ObscuredInt / ObscuredLong / ObscuredFloat / ObscuredBool`

Vỏ struct ở `Contract/VaultGuardedTypes.cs`, phần mask/checksum ở `Security/VaultMemoryGuard.cs`.
Lưu `value ^ mask` kèm checksum, không lưu giá trị thật. Xóa `Security/` thì vỏ vẫn còn nhưng lưu thẳng
giá trị (mục 1.2).

| Thành viên | Làm gì | Cần biết |
|---|---|---|
| `From(v)` / `Set(v)` | Đặt giá trị | Sinh `id` mới mỗi lần ⇒ mask mới ⇒ byte trong RAM đổi |
| `Get(keyForReport = null)` | Lấy giá trị | **Đổi mask ngay cả khi chỉ đọc.** Checksum lệch ⇒ `VaultSecurity.Report` + trả 0 |
| `IsIntact()` | Kiểm tra không đổi mask | Dùng cho quét định kỳ — không gây side effect |
| implicit operator | `int x = obscuredInt;` | Chuyển ngầm đi qua bản sao nên **mất tác dụng re-mask**; đường nóng nên gọi `.Get()` thẳng |

**Vì sao đổi mask cả lúc đọc:** đổi khi ghi chỉ phá được scan "exact value". Cheater không biết giá trị
sẽ dùng scan "unknown initial value" rồi lọc *unchanged / increased / decreased* — đổi mask khi đọc làm
hỏng luôn cách đó, vì byte trong RAM đổi kể cả khi giá trị không đổi.

`VaultGuard` (internal, `Security/`) giữ `sessionKey` ngẫu nhiên mỗi phiên, `NewId()`, `MaskFor(id)`, `Checksum(id, bits)`
và một PRNG rẻ (`NextRandom`). Mask **không** nằm cạnh giá trị đã mã trong struct — nó suy ra từ
session key và id.

### Tầng 2 + 4 — `VaultIntegrity`

| Thành viên | Làm gì | Cần biết |
|---|---|---|
| `Register(IVaultGuarded)` | Ghi danh đối tượng để quét | Bỏ qua khi không ở play mode. Game nên gọi qua `VaultWatch.Register` để còn chạy được khi đã xóa `Security/` |
| `RegisterHoneypot(key, truth)` | Đặt mồi, trả handle | Mồi là `int` trần chứa đúng số hiển thị, không dùng cho logic |
| `SyncHoneypot(handle)` | Làm mới mồi ngay | Không bắt buộc — quét định kỳ tự làm mới |
| `ScanNow()` | Quét một lượt, trả số vấn đề | Gọi được thủ công ở checkpoint |
| `Enabled` | Bật/tắt quét nền | |
| `VerifyAgainstStorageOnScan` | Bật đối chiếu với đĩa mỗi lần quét | Mặc định **false** vì mỗi lần quét phải giải mã lại |
| `MinScanInterval` / `MaxScanInterval` | 4–11 giây | Chu kỳ **ngẫu nhiên** để khó xác định thời điểm kiểm tra |

**Honeypot so với cái gì:** so `Decoy` với giá trị **ta tự đặt lần cuối** (giữ trong `ObscuredInt`),
**không** so với giá trị thật. So với giá trị thật thì mỗi lần coin đổi hợp lệ sẽ báo nhầm. Sau mỗi
lượt quét thì mồi được refresh để không bị cũ.

**Tầng 4 — đối chiếu đĩa** (`Vault<T>.VerifyAgainstStorage()`): dữ liệu trên đĩa đã có MAC nên không sửa
được nếu không có khóa ⇒ đĩa đáng tin hơn RAM. Bỏ qua khi `VaultSaveQueue.HasPending` để không báo nhầm
với thay đổi vừa ghi còn nằm trong queue 50 ms.

### Tầng 3 — Ledger trong `Wallet`

`Wallet` giữ giá trị trong `ObscuredInt` và **không có mirror `int`** — serialize qua private property
`[JsonProperty]` đọc/ghi thẳng từ ô obscured (giữ mirror là hỏng toàn bộ mục đích tầng 1). Tên JSON
không đổi nên tương thích dữ liệu người chơi hiện có.

| Thành viên | Làm gì |
|---|---|
| `Coin`, `Booster1..3` | Property công khai, đọc/ghi qua ô obscured |
| `VerifyLedger()` | Kiểm checksum từng ô + đối chiếu ledger tổng. Lệch ⇒ có field bị sửa ngoài API |
| `MaxSaneDelta` | Ngưỡng delta hợp lý (1.000.000). Vượt ngưỡng ⇒ report, **không** chặn |

### Tầng 5 — `VaultSecurity`

| Thành viên | Làm gì |
|---|---|
| `event OnTamperDetected` | Nơi game cắm chính sách xử lý |
| `VaultTamperKind` | `ObscuredValue` / `Honeypot` / `DiskMismatch` / `Ledger` / `MacFail` |
| `TamperCount`, `AnyTamperDetected`, `LastKind`, `LastKey` | Trạng thái tích lũy |
| `LogToConsole` | Tắt khi không muốn lộ chỗ phát hiện |

**Nguyên tắc bắt buộc khi xử lý:** KHÔNG crash/quit ngay tại chỗ phát hiện — cheater sẽ lần ra đúng hàm
đó rồi patch. Nên: ghi telemetry → đánh dấu tài khoản → degrade âm thầm có độ trễ (từ chối submit
leaderboard, `ReloadFromStorage()` ở lần load sau).

```csharp
VaultSecurity.OnTamperDetected += e => Analytics.Log("tamper", e.Kind.ToString(), e.Key);
```

### Chặn được tới đâu

Chặn được: exact-value scan, unknown-value scan với filter unchanged/increased/decreased, sửa mồi,
sửa field bên trong `Wallet` không qua API, sửa RAM không đi qua `Save()`.

Không chặn được: đọc tên field qua Mono dissector trên PC, patch thẳng hàm kiểm tra, inject code.
Mục tiêu thực tế là chặn nhóm dùng tool có sẵn — tức phần lớn tuyệt đối số cheater.

---

## 12. Những thứ tuyệt đối không được đổi

Đổi bất kỳ giá trị nào dưới đây trong một bản update = **toàn bộ người chơi hiện có mất sạch dữ liệu**:

| Hằng số | File | Vì sao |
|---|---|---|
| `KeyNameHmacSecret` | `Security/VaultKeyName.cs` | Đổi ⇒ mọi tên slot trong PlayerPrefs đổi theo ⇒ không tìm thấy dữ liệu cũ |
| `KeyPrefix` (`"sc_"`) | `Security/VaultKeyName.cs` | Nằm trong input của hash tên key |
| `KeySeed` | `Security/VaultCrypto.cs` | Đổi ⇒ khóa khác ⇒ không giải mã được gì |
| `Pbkdf2Iterations`, `SaltLength`, `V2KeyLength`, `EncKeyLength`, `MacKeyLength` | `Security/VaultCrypto.cs` | Như trên. Đổi độ dài khóa ⇒ lệch toàn bộ layout master ⇒ cả 3 khóa đều khác |
| `SaltPrefKey`, `SaltFileName` | `Security/VaultCrypto.cs` | Đổi ⇒ không tìm thấy salt cũ ⇒ sinh salt mới |
| `Magic`, `HeaderLength`, `IvLength`, `TagLength` | `Security/VaultCrypto.cs` | Layout blob. Đổi phải kèm version mới + đường đọc format cũ |
| `CryptoAad` | `Api/JsonFileStore.cs` | Là AAD của file — đổi ⇒ verify MAC fail toàn bộ |
| Giá trị trong `PlayerPrefsKey` | `PlayerPrefsKey.cs` | Là AAD của từng ô, đồng thời là input hash tên slot |

Muốn đổi thật thì phải làm đúng quy trình: thêm version mới, giữ đường đọc format cũ, nâng cấp dần
khi đọc (upgrade-on-read) — đúng cách v3 hiện đang xử lý dữ liệu v2.
