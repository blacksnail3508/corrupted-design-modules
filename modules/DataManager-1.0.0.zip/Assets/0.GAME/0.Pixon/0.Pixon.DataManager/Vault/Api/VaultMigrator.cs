using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using UnityEngine;

namespace Pixon.Data
{
    public enum VaultDataType
    {
        Int,
        Float,
        String,
        Bool,
        Enum,
        Json,
    }

    [Serializable]
    public readonly struct VaultEntry
    {
        public readonly string Key;
        public readonly VaultDataType Type;

        public VaultEntry(string key, VaultDataType type)
        {
            Key = key;
            Type = type;
        }

        public static VaultEntry Int(string key)    => new(key, VaultDataType.Int);
        public static VaultEntry Float(string key)  => new(key, VaultDataType.Float);
        public static VaultEntry String(string key) => new(key, VaultDataType.String);
        public static VaultEntry Bool(string key)   => new(key, VaultDataType.Bool);
        public static VaultEntry Enum(string key)   => new(key, VaultDataType.Enum);
        public static VaultEntry Json(string key)   => new(key, VaultDataType.Json);
    }

    public sealed class VaultMigrationReport
    {
        public int Copied;
        public int Skipped;
        public int Failed;
        public int Deleted;
        public readonly List<string> Errors = new();

        public override string ToString()
            => $"[VaultMigration] Copied={Copied}, Skipped={Skipped}, Failed={Failed}, Deleted={Deleted}" +
               (Errors.Count > 0 ? $"\n - {string.Join("\n - ", Errors)}" : string.Empty);
    }

    public static class VaultMigrator
    {
        public static VaultMigrationReport Migrate(
            VaultBackend from,
            VaultBackend to,
            IReadOnlyList<VaultEntry> schema,
            bool overwrite = true,
            bool deleteSourceAfter = false)
        {
            var report = new VaultMigrationReport();

            if (from == VaultBackend.Auto || to == VaultBackend.Auto)
            {
                report.Errors.Add("VaultBackend.Auto không được chấp nhận trong migration — hãy chỉ định backend cụ thể.");
                report.Failed = schema?.Count ?? 0;
                return report;
            }

            if (from == to)
            {
                report.Errors.Add($"Source và destination giống nhau ({from}), không có gì để làm.");
                return report;
            }

            if (schema == null || schema.Count == 0)
            {
                report.Errors.Add("Schema rỗng — không có entry nào để migrate.");
                return report;
            }

            var copiedKeys = deleteSourceAfter ? new List<VaultEntry>(schema.Count) : null;

            for (int i = 0; i < schema.Count; i++)
            {
                var entry = schema[i];
                try
                {
                    if (!HasKeyOn(from, entry.Key))
                    {
                        report.Skipped++;
                        continue;
                    }

                    if (!overwrite && HasKeyOn(to, entry.Key))
                    {
                        report.Skipped++;
                        continue;
                    }

                    if (CopyEntry(from, to, entry, report))
                    {
                        report.Copied++;
                        copiedKeys?.Add(entry);
                    }
                }
                catch (Exception e)
                {
                    report.Failed++;
                    report.Errors.Add($"{entry.Key} ({entry.Type}): {e.Message}");
                }
            }

            FlushBackend(to);

            if (copiedKeys != null)
            {
                for (int i = 0; i < copiedKeys.Count; i++)
                {
                    try
                    {
                        DeleteKeyOn(from, copiedKeys[i].Key);
                        report.Deleted++;
                    }
                    catch (Exception e)
                    {
                        report.Errors.Add($"Delete source {copiedKeys[i].Key}: {e.Message}");
                    }
                }
                FlushBackend(from);
            }

            return report;
        }

        public static bool MigrateOnce(
            VaultBackend from,
            VaultBackend to,
            IReadOnlyList<VaultEntry> schema,
            string versionKey,
            bool deleteSourceAfter = false,
            Action<VaultMigrationReport> onComplete = null)
        {
            if (string.IsNullOrEmpty(versionKey))
            {
                Debug.LogError("[VaultMigrator] versionKey không được rỗng.");
                return false;
            }

            if (GetBoolOn(to, versionKey, false))
            {
                onComplete?.Invoke(new VaultMigrationReport());
                return false;
            }

            var report = Migrate(from, to, schema, overwrite: false, deleteSourceAfter);
            SetBoolOn(to, versionKey, true);
            FlushBackend(to);

            onComplete?.Invoke(report);
            return true;
        }

        private static bool HasKeyOn(VaultBackend backend, string key) => backend switch
        {
            VaultBackend.PlayerPrefs  => PlayerPrefs.HasKey(key),
            VaultBackend.SecuredPrefs => SecuredPrefs.HasKey(key),
            VaultBackend.JsonFile     => JsonFileStore.HasKey(key),
            _ => false,
        };

        private static void DeleteKeyOn(VaultBackend backend, string key)
        {
            switch (backend)
            {
                case VaultBackend.PlayerPrefs:  PlayerPrefs.DeleteKey(key);   break;
                case VaultBackend.SecuredPrefs: SecuredPrefs.DeleteKey(key);  break;
                case VaultBackend.JsonFile:     JsonFileStore.DeleteKey(key); break;
            }
        }

        private static void FlushBackend(VaultBackend backend)
        {
            switch (backend)
            {
                case VaultBackend.PlayerPrefs:
                case VaultBackend.SecuredPrefs:
                    PlayerPrefs.Save();
                    break;
                case VaultBackend.JsonFile:
                    JsonFileStore.Save();
                    break;
            }
        }

        private static bool CopyEntry(VaultBackend from, VaultBackend to, VaultEntry entry, VaultMigrationReport report)
        {
            switch (entry.Type)
            {
                case VaultDataType.Int:
                case VaultDataType.Enum:
                    {
                        int v = GetIntOn(from, entry.Key, 0);
                        SetIntOn(to, entry.Key, v);
                        return true;
                    }
                case VaultDataType.Float:
                    {
                        float v = GetFloatOn(from, entry.Key, 0f);
                        SetFloatOn(to, entry.Key, v);
                        return true;
                    }
                case VaultDataType.String:
                case VaultDataType.Json:
                    {
                        string v = GetStringOn(from, entry.Key, string.Empty);
                        SetStringOn(to, entry.Key, v);
                        return true;
                    }
                case VaultDataType.Bool:
                    {
                        bool v = GetBoolOn(from, entry.Key, false);
                        SetBoolOn(to, entry.Key, v);
                        return true;
                    }
            }

            report.Failed++;
            report.Errors.Add($"{entry.Key}: unknown VaultDataType {entry.Type}");
            return false;
        }

        private static int GetIntOn(VaultBackend b, string k, int d) => b switch
        {
            VaultBackend.PlayerPrefs  => PlayerPrefs.GetInt(k, d),
            VaultBackend.SecuredPrefs => SecuredPrefs.GetInt(k, d),
            VaultBackend.JsonFile     => JsonFileStore.GetInt(k, d),
            _ => d,
        };

        private static void SetIntOn(VaultBackend b, string k, int v)
        {
            switch (b)
            {
                case VaultBackend.PlayerPrefs:  PlayerPrefs.SetInt(k, v);   break;
                case VaultBackend.SecuredPrefs: SecuredPrefs.SetInt(k, v);  break;
                case VaultBackend.JsonFile:     JsonFileStore.SetInt(k, v); break;
            }
        }

        private static float GetFloatOn(VaultBackend b, string k, float d) => b switch
        {
            VaultBackend.PlayerPrefs  => PlayerPrefs.GetFloat(k, d),
            VaultBackend.SecuredPrefs => SecuredPrefs.GetFloat(k, d),
            VaultBackend.JsonFile     => JsonFileStore.GetFloat(k, d),
            _ => d,
        };

        private static void SetFloatOn(VaultBackend b, string k, float v)
        {
            switch (b)
            {
                case VaultBackend.PlayerPrefs:  PlayerPrefs.SetFloat(k, v);   break;
                case VaultBackend.SecuredPrefs: SecuredPrefs.SetFloat(k, v);  break;
                case VaultBackend.JsonFile:     JsonFileStore.SetFloat(k, v); break;
            }
        }

        private static string GetStringOn(VaultBackend b, string k, string d) => b switch
        {
            VaultBackend.PlayerPrefs  => PlayerPrefs.GetString(k, d),
            VaultBackend.SecuredPrefs => SecuredPrefs.GetString(k, d),
            VaultBackend.JsonFile     => JsonFileStore.GetString(k, d),
            _ => d,
        };

        private static void SetStringOn(VaultBackend b, string k, string v)
        {
            switch (b)
            {
                case VaultBackend.PlayerPrefs:  PlayerPrefs.SetString(k, v);   break;
                case VaultBackend.SecuredPrefs: SecuredPrefs.SetString(k, v);  break;
                case VaultBackend.JsonFile:     JsonFileStore.SetString(k, v); break;
            }
        }

        private static bool GetBoolOn(VaultBackend b, string k, bool d) => b switch
        {
            VaultBackend.PlayerPrefs  => PlayerPrefs.GetInt(k, d ? 1 : 0) == 1,
            VaultBackend.SecuredPrefs => SecuredPrefs.GetBool(k, d),
            VaultBackend.JsonFile     => JsonFileStore.GetBool(k, d),
            _ => d,
        };

        private static void SetBoolOn(VaultBackend b, string k, bool v)
        {
            switch (b)
            {
                case VaultBackend.PlayerPrefs:  PlayerPrefs.SetInt(k, v ? 1 : 0); break;
                case VaultBackend.SecuredPrefs: SecuredPrefs.SetBool(k, v);      break;
                case VaultBackend.JsonFile:     JsonFileStore.SetBool(k, v);     break;
            }
        }
    }
}
