using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using UnityEngine;

namespace Pixon.Data
{
    public static class JsonFileStore
    {
        private const string FileName = "vault.json";

        private static bool EncryptOnDisk
        {
            get
            {
                if (cachedOutsideEditor == null) cachedOutsideEditor = !Application.isEditor;
                return cachedOutsideEditor.Value && VaultSecurityPort.Encrypts;
            }
        }

        private const string CryptoAad = "JsonFileStore:" + FileName;

        private static Dictionary<string, string> data;
        private static bool loaded;
        private static bool dirty;
        private static readonly object Sync = new object();

        private static bool diskCopyTrusted;

        private static readonly object warmupSync = new object();
        private static readonly List<Action> pendingWarmupCallbacks = new List<Action>();
        private static bool warmupInFlight;

        private static string cachedDataPath;
        private static bool?  cachedOutsideEditor;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void Prime()
        {
            cachedDataPath      = Application.persistentDataPath;
            cachedOutsideEditor = !Application.isEditor;
        }

        private static string DataPath
        {
            get
            {
                if (string.IsNullOrEmpty(cachedDataPath))
                    cachedDataPath = Application.persistentDataPath;
                return cachedDataPath;
            }
        }

        private static string FilePath => Path.Combine(DataPath, FileName);
        private static string TempPath => FilePath + ".tmp";
        private static string BackupPath => FilePath + ".bak";

        public static void SetInt   (string key, int    value) => Write(key, value.ToString(System.Globalization.CultureInfo.InvariantCulture));
        public static void SetFloat (string key, float  value) => Write(key, value.ToString("R", System.Globalization.CultureInfo.InvariantCulture));
        public static void SetString(string key, string value) => Write(key, value ?? string.Empty);
        public static void SetBool  (string key, bool   value) => Write(key, value ? "1" : "0");

        public static int    GetInt   (string key, int    def = 0)     => TryRead(key, out var r) && int.TryParse(r, System.Globalization.NumberStyles.Integer, System.Globalization.CultureInfo.InvariantCulture, out var i)   ? i   : def;
        public static float  GetFloat (string key, float  def = 0f)    => TryRead(key, out var r) && float.TryParse(r, System.Globalization.NumberStyles.Float,   System.Globalization.CultureInfo.InvariantCulture, out var f) ? f   : def;
        public static string GetString(string key, string def = "")    => TryRead(key, out var r) ? r : def;
        public static bool   GetBool  (string key, bool   def = false) => TryRead(key, out var r) ? r == "1" : def;

        public static bool HasKey(string key)
        {
            EnsureLoaded();
            lock (Sync) return data.ContainsKey(key);
        }

        public static void DeleteKey(string key)
        {
            EnsureLoaded();
            lock (Sync)
            {
                if (data.Remove(key)) dirty = true;
            }
        }

        public static void DeleteAll()
        {
            EnsureLoaded();
            lock (Sync)
            {
                data.Clear();
                dirty = true;
            }
        }

        public static bool IsLoaded => loaded;

        public static string[] GetAllKeys()
        {
            EnsureLoaded();
            lock (Sync)
            {
                var arr = new string[data.Count];
                int i = 0;
                foreach (var k in data.Keys) arr[i++] = k;
                return arr;
            }
        }

        public static string GetRaw(string key)
        {
            EnsureLoaded();
            lock (Sync)
            {
                return data.TryGetValue(key, out var v) ? v : null;
            }
        }

        public static void SetRaw(string key, string value)
        {
            if (string.IsNullOrEmpty(key)) return;
            EnsureLoaded();
            lock (Sync)
            {
                if (data.TryGetValue(key, out var existing) && existing == (value ?? string.Empty)) return;
                data[key] = value ?? string.Empty;
                dirty = true;
            }
        }

        public static string GetFilePath() => FilePath;

        public static void Warmup()
        {
            EnsureLoaded();
        }

        public static void WarmupAsync(Action onComplete = null)
        {
            if (loaded)
            {
                onComplete?.Invoke();
                return;
            }

            lock (warmupSync)
            {
                if (loaded)
                {
                    onComplete?.Invoke();
                    return;
                }

                if (onComplete != null)
                    pendingWarmupCallbacks.Add(onComplete);

                if (warmupInFlight) return;
                warmupInFlight = true;
            }

            var mainContext = SynchronizationContext.Current;

            Task.Run(() =>
            {
                Dictionary<string, string> loadedData = null;
                Exception error = null;
                try
                {
                    loadedData = LoadFromDisk();
                }
                catch (Exception e)
                {
                    error = e;
                }

                lock (Sync)
                {
                    if (!loaded)
                    {
                        data = loadedData ?? new Dictionary<string, string>();
                        loaded = true;
                    }
                }

                Action[] callbacks;
                lock (warmupSync)
                {
                    callbacks = pendingWarmupCallbacks.ToArray();
                    pendingWarmupCallbacks.Clear();
                    warmupInFlight = false;
                }

                if (error != null)
                    Debug.LogWarning($"[JsonFileStore] WarmupAsync load error: {error.Message}");

                if (callbacks.Length == 0) return;

                if (mainContext != null)
                {
                    mainContext.Post(_ =>
                    {
                        for (int i = 0; i < callbacks.Length; i++)
                        {
                            try { callbacks[i]?.Invoke(); }
                            catch (Exception e) { Debug.LogException(e); }
                        }
                    }, null);
                }
                else
                {
                    for (int i = 0; i < callbacks.Length; i++)
                    {
                        try { callbacks[i]?.Invoke(); }
                        catch (Exception e) { Debug.LogException(e); }
                    }
                }
            });
        }

        public static void Save()
        {
            lock (Sync)
            {
                if (!loaded || !dirty) return;
                FlushToDisk();
                dirty = false;
            }
        }

        public static void Reload()
        {
            lock (Sync)
            {
                loaded = false;
                dirty = false;
                data = null;
                EnsureLoaded();
            }
        }

        private static void Write(string key, string value)
        {
            if (string.IsNullOrEmpty(key)) return;
            EnsureLoaded();
            lock (Sync)
            {
                if (data.TryGetValue(key, out var existing) && existing == value) return;
                data[key] = value;
                dirty = true;
            }
        }

        private static bool TryRead(string key, out string value)
        {
            value = null;
            if (string.IsNullOrEmpty(key)) return false;
            EnsureLoaded();
            lock (Sync) return data.TryGetValue(key, out value);
        }

        private static void EnsureLoaded()
        {
            if (loaded) return;
            lock (Sync)
            {
                if (loaded) return;
                data = LoadFromDisk() ?? new Dictionary<string, string>();
                loaded = true;
            }
        }

        private enum LoadOutcome
        {
            Missing,
            Corrupt,
            Ok,
        }

        private static Dictionary<string, string> LoadFromDisk()
        {
            switch (TryLoadFile(FilePath, out var main))
            {
                case LoadOutcome.Ok:
                    diskCopyTrusted = true;
                    return main;

                case LoadOutcome.Missing:
                    if (TryLoadFile(BackupPath, out var fromBackup) == LoadOutcome.Ok)
                    {
                        Debug.LogWarning("[JsonFileStore] File chính không tồn tại — khôi phục từ .bak.");
                        diskCopyTrusted = true;
                        return fromBackup;
                    }
                    diskCopyTrusted = true;
                    return null;

                default:
                    Debug.LogError("[JsonFileStore] File chính không hợp lệ — thử .bak.");
                    if (TryLoadFile(BackupPath, out var rescue) == LoadOutcome.Ok)
                    {
                        diskCopyTrusted = false;
                        return rescue;
                    }
                    diskCopyTrusted = false;
                    return null;
            }
        }

        private static LoadOutcome TryLoadFile(string path, out Dictionary<string, string> result)
        {
            result = null;
            try
            {
                if (!File.Exists(path)) return LoadOutcome.Missing;

                var raw = File.ReadAllBytes(path);
                if (raw.Length == 0) return LoadOutcome.Missing;

                string json;

                if (VaultSecurityPort.Cipher.IsSealedBlob(raw))
                {
                    if (!VaultSecurityPort.Cipher.TryOpen(raw, CryptoAad, out var plain)) return LoadOutcome.Corrupt;
                    json = Encoding.UTF8.GetString(plain);
                }
                else if (raw[0] == (byte)'{')
                {
                    if (EncryptOnDisk)
                    {
                        Debug.LogError($"[JsonFileStore] Từ chối file JSON không mã hóa trong build: {path}");
                        return LoadOutcome.Corrupt;
                    }
                    json = Encoding.UTF8.GetString(raw);
                }
                else
                {
                    Debug.LogError($"[JsonFileStore] File không nhận dạng được (thiếu magic PXVT): {path}");
                    return LoadOutcome.Corrupt;
                }

                if (string.IsNullOrWhiteSpace(json)) return LoadOutcome.Corrupt;

                result = JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
                return result == null ? LoadOutcome.Corrupt : LoadOutcome.Ok;
            }
            catch (Exception e)
            {
                Debug.LogError($"[JsonFileStore] Đọc {path} lỗi: {e.Message}");
                return LoadOutcome.Corrupt;
            }
        }

        private static void FlushToDisk()
        {
            try
            {
                Directory.CreateDirectory(DataPath);

                string json = JsonConvert.SerializeObject(data);
                byte[] payload = EncryptOnDisk
                    ? VaultSecurityPort.Cipher.Seal(Encoding.UTF8.GetBytes(json), CryptoAad)
                    : Encoding.UTF8.GetBytes(json);

                File.WriteAllBytes(TempPath, payload);

                if (File.Exists(FilePath))
                {
                    if (diskCopyTrusted)
                    {
                        try { File.Copy(FilePath, BackupPath, true); }
                        catch {  }
                    }

                    File.Replace(TempPath, FilePath, null);
                }
                else
                {
                    File.Move(TempPath, FilePath);
                }

                diskCopyTrusted = true;
            }
            catch (Exception e)
            {
                Debug.LogError($"[JsonFileStore] Save failed: {e.Message}");
            }
        }
    }
}
