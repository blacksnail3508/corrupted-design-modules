using System;
using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json;
using Sirenix.OdinInspector;
using Sirenix.Utilities;
using UnityEngine;

namespace Pixon.Data
{
    public enum VaultBackend
    {
        Auto = 0,
        PlayerPrefs = 1,
        SecuredPrefs = 2,
        JsonFile = 3,
    }

    internal static class VaultSaveQueue
    {
        private const float FlushDelaySeconds = 0.05f;

        private static readonly Dictionary<string, Action> PendingWrites = new();
        private static bool needSavePlayerPrefs;
        private static bool needSaveJsonFile;

        private static Runner runner;
        private static Coroutine flushCoroutine;

        public static void Enqueue(string storageKey, Action writeAction, VaultBackend backend)
        {
            if (string.IsNullOrEmpty(storageKey) || writeAction == null) return;

            PendingWrites[storageKey] = writeAction;

            switch (backend)
            {
                case VaultBackend.PlayerPrefs:
                case VaultBackend.SecuredPrefs:
                    needSavePlayerPrefs = true;
                    break;
                case VaultBackend.JsonFile:
                    needSaveJsonFile = true;
                    break;
            }

            if (!Application.isPlaying)
            {
                FlushNow();
                return;
            }

            EnsureRunner();
            if (flushCoroutine == null)
                flushCoroutine = runner.StartCoroutine(FlushDeferred());
        }

        public static bool HasPending => PendingWrites.Count > 0;

        public static void FlushNow()
        {
            if (PendingWrites.Count == 0) return;

            var writes = new Action[PendingWrites.Count];
            PendingWrites.Values.CopyTo(writes, 0);
            PendingWrites.Clear();

            for (int i = 0; i < writes.Length; i++)
                writes[i]?.Invoke();

            if (needSavePlayerPrefs)
            {
                PlayerPrefs.Save();
                needSavePlayerPrefs = false;
            }
            if (needSaveJsonFile)
            {
                JsonFileStore.Save();
                needSaveJsonFile = false;
            }
        }

        private static IEnumerator FlushDeferred()
        {
            yield return new WaitForSecondsRealtime(FlushDelaySeconds);
            flushCoroutine = null;
            FlushNow();
        }

        private static void EnsureRunner()
        {
            if (runner != null) return;

            var go = new GameObject("VaultSaveQueue");
            UnityEngine.Object.DontDestroyOnLoad(go);
            runner = go.AddComponent<Runner>();
        }

        private sealed class Runner : MonoBehaviour
        {
            private void OnApplicationPause(bool pauseStatus)
            {
                if (pauseStatus) FlushNow();
            }

            private void OnApplicationQuit()
            {
                FlushNow();
            }
        }
    }

    [Serializable]
    public class Vault<T> : IVaultGuarded
    {
        private static readonly bool IsGuardedPrimitive =
            typeof(T) == typeof(int)   || typeof(T) == typeof(long) ||
            typeof(T) == typeof(float) || typeof(T) == typeof(bool) ||
            typeof(T).IsEnum;

        [SerializeField] [ReadOnly] private string key;
        [SerializeField] [ReadOnly] private T cachedValue;
        private ObscuredLong guardedValue;
        private T defaultValue;
        private bool initialized;

        private readonly VaultBackend backend;

        private VaultBackend ResolvedBackend =>
            backend == VaultBackend.Auto
                ? (Application.isEditor ? VaultBackend.PlayerPrefs : VaultBackend.SecuredPrefs)
                : backend;

        public Vault(string key, T defaultValue = default)
            : this(key, defaultValue, VaultBackend.Auto) { }

        public Vault(string key, T defaultValue, VaultBackend backend)
        {
            this.key = key;
            this.defaultValue = defaultValue;
            this.backend = backend;
        }

        public string GuardKey => key;

        private bool registered;

        private void EnsureRegistered()
        {
            if (registered || !IsGuardedPrimitive) return;
            registered = true;
            VaultWatch.Register(this);
        }

        public T Value
        {
            get
            {
                if (!initialized)
                {
                    SetCache(Read());
                    initialized = true;
                    EnsureRegistered();
                }
                return GetCache();
            }
            set => Save(value);
        }

        private T GetCache()
        {
            if (!IsGuardedPrimitive) return cachedValue;

            long bits = guardedValue.Get(key);

            if (typeof(T) == typeof(int))   return (T)(object)(int)bits;
            if (typeof(T) == typeof(long))  return (T)(object)bits;
            if (typeof(T) == typeof(bool))  return (T)(object)(bits != 0L);
            if (typeof(T) == typeof(float))
            {
                FloatBits fb = default;
                fb.AsInt = (int)bits;
                return (T)(object)fb.AsFloat;
            }
            return (T)Enum.ToObject(typeof(T), (int)bits);
        }

        private void SetCache(T value)
        {
            if (!IsGuardedPrimitive)
            {
                cachedValue = value;
                return;
            }

            long bits;
            if (typeof(T) == typeof(int))        bits = (int)(object)value;
            else if (typeof(T) == typeof(long))  bits = (long)(object)value;
            else if (typeof(T) == typeof(bool))  bits = (bool)(object)value ? 1L : 0L;
            else if (typeof(T) == typeof(float))
            {
                FloatBits fb = default;
                fb.AsFloat = (float)(object)value;
                bits = fb.AsInt;
            }
            else bits = Convert.ToInt32(value);

            guardedValue.Set(bits);
            cachedValue = default;
        }

        public bool VerifyIntegrity()
        {
            if (!initialized || !IsGuardedPrimitive) return true;
            if (guardedValue.IsIntact()) return true;

            VaultSecurity.Report(VaultTamperKind.ObscuredValue, key, "cache trong RAM bị sửa");
            return false;
        }

        public bool VerifyAgainstStorage()
        {
            if (!initialized) return true;

            if (VaultSaveQueue.HasPending) return true;

            var onDisk = Read();
            var inRam  = GetCache();

            if (Equals(onDisk, inRam)) return true;

            VaultSecurity.Report(VaultTamperKind.DiskMismatch, key,
                $"RAM='{inRam}' nhưng bản đã seal trên đĩa='{onDisk}'");
            return false;
        }

        public void ReloadFromStorage()
        {
            SetCache(Read());
            initialized = true;
        }

        public bool Exists
        {
            get
            {
                switch (ResolvedBackend)
                {
                    case VaultBackend.SecuredPrefs: return SecuredPrefs.HasKey(key);
                    case VaultBackend.JsonFile:     return JsonFileStore.HasKey(key);
                    default:                        return PlayerPrefs.HasKey(key);
                }
            }
        }

        public void Save(T newValue)
        {
            SetCache(newValue);
            initialized = true;
            EnsureRegistered();
            QueueWrite(newValue);
        }

        private T Read()
        {
            switch (ResolvedBackend)
            {
                case VaultBackend.PlayerPrefs:  return ReadFromPlayerPrefs();
                case VaultBackend.SecuredPrefs: return ReadFromSecuredPrefs();
                case VaultBackend.JsonFile:     return ReadFromJsonFile();
                default:                        return ReadFromPlayerPrefs();
            }
        }

        private T ReadFromPlayerPrefs()
        {
            if (typeof(T) == typeof(int))    return (T)(object)PlayerPrefs.GetInt(key, (int)(object)defaultValue);
            if (typeof(T) == typeof(float))  return (T)(object)PlayerPrefs.GetFloat(key, (float)(object)defaultValue);
            if (typeof(T) == typeof(string)) return (T)(object)PlayerPrefs.GetString(key, (string)(object)defaultValue);
            if (typeof(T) == typeof(bool))   return (T)(object)(PlayerPrefs.GetInt(key, (bool)(object)defaultValue ? 1 : 0) == 1);
            if (typeof(T).IsEnum)
            {
                var stored = PlayerPrefs.GetInt(key, Convert.ToInt32(defaultValue));
                return (T)Enum.ToObject(typeof(T), stored);
            }
            return ReadJson(() => PlayerPrefs.GetString(key));
        }

        private void WriteToPlayerPrefs(T value)
        {
            if (typeof(T) == typeof(int))         PlayerPrefs.SetInt(key, (int)(object)value);
            else if (typeof(T) == typeof(float))  PlayerPrefs.SetFloat(key, (float)(object)value);
            else if (typeof(T) == typeof(string)) PlayerPrefs.SetString(key, (string)(object)value);
            else if (typeof(T) == typeof(bool))   PlayerPrefs.SetInt(key, (bool)(object)value ? 1 : 0);
            else if (typeof(T).IsEnum)            PlayerPrefs.SetInt(key, Convert.ToInt32(value));
            else                                  PlayerPrefs.SetString(key, WriteJson(value));
        }

        private T ReadFromSecuredPrefs()
        {
            if (typeof(T) == typeof(int))    return (T)(object)SecuredPrefs.GetInt(key, (int)(object)defaultValue);
            if (typeof(T) == typeof(float))  return (T)(object)SecuredPrefs.GetFloat(key, (float)(object)defaultValue);
            if (typeof(T) == typeof(string)) return (T)(object)SecuredPrefs.GetString(key, (string)(object)defaultValue);
            if (typeof(T) == typeof(bool))   return (T)(object)SecuredPrefs.GetBool(key, (bool)(object)defaultValue);
            if (typeof(T).IsEnum)
            {
                var stored = SecuredPrefs.GetInt(key, Convert.ToInt32(defaultValue));
                return (T)Enum.ToObject(typeof(T), stored);
            }
            return ReadJson(() => SecuredPrefs.GetString(key));
        }

        private void WriteToSecuredPrefs(T value)
        {
            if (typeof(T) == typeof(int))         SecuredPrefs.SetInt(key, (int)(object)value);
            else if (typeof(T) == typeof(float))  SecuredPrefs.SetFloat(key, (float)(object)value);
            else if (typeof(T) == typeof(string)) SecuredPrefs.SetString(key, (string)(object)value);
            else if (typeof(T) == typeof(bool))   SecuredPrefs.SetBool(key, (bool)(object)value);
            else if (typeof(T).IsEnum)            SecuredPrefs.SetInt(key, Convert.ToInt32(value));
            else                                  SecuredPrefs.SetString(key, WriteJson(value));
        }

        private T ReadFromJsonFile()
        {
            if (typeof(T) == typeof(int))    return (T)(object)JsonFileStore.GetInt(key, (int)(object)defaultValue);
            if (typeof(T) == typeof(float))  return (T)(object)JsonFileStore.GetFloat(key, (float)(object)defaultValue);
            if (typeof(T) == typeof(string)) return (T)(object)JsonFileStore.GetString(key, (string)(object)defaultValue);
            if (typeof(T) == typeof(bool))   return (T)(object)JsonFileStore.GetBool(key, (bool)(object)defaultValue);
            if (typeof(T).IsEnum)
            {
                var stored = JsonFileStore.GetInt(key, Convert.ToInt32(defaultValue));
                return (T)Enum.ToObject(typeof(T), stored);
            }
            return ReadJson(() => JsonFileStore.GetString(key));
        }

        private void WriteToJsonFile(T value)
        {
            if (typeof(T) == typeof(int))         JsonFileStore.SetInt(key, (int)(object)value);
            else if (typeof(T) == typeof(float))  JsonFileStore.SetFloat(key, (float)(object)value);
            else if (typeof(T) == typeof(string)) JsonFileStore.SetString(key, (string)(object)value);
            else if (typeof(T) == typeof(bool))   JsonFileStore.SetBool(key, (bool)(object)value);
            else if (typeof(T).IsEnum)            JsonFileStore.SetInt(key, Convert.ToInt32(value));
            else                                  JsonFileStore.SetString(key, WriteJson(value));
        }

        private void QueueWrite(T value)
        {
            var b = ResolvedBackend;

            if (typeof(T) == typeof(int))
            {
                int snapshot = (int)(object)value;
                VaultSaveQueue.Enqueue(GetStorageKey(), () => WriteSnapshot((T)(object)snapshot), b);
                return;
            }

            if (typeof(T) == typeof(float))
            {
                float snapshot = (float)(object)value;
                VaultSaveQueue.Enqueue(GetStorageKey(), () => WriteSnapshot((T)(object)snapshot), b);
                return;
            }

            if (typeof(T) == typeof(string))
            {
                string snapshot = (string)(object)value;
                VaultSaveQueue.Enqueue(GetStorageKey(), () => WriteSnapshot((T)(object)snapshot), b);
                return;
            }

            if (typeof(T) == typeof(bool))
            {
                bool snapshot = (bool)(object)value;
                VaultSaveQueue.Enqueue(GetStorageKey(), () => WriteSnapshot((T)(object)snapshot), b);
                return;
            }

            if (typeof(T).IsEnum)
            {
                int snapshot = Convert.ToInt32(value);
                VaultSaveQueue.Enqueue(GetStorageKey(), () => WriteEnumSnapshot(snapshot), b);
                return;
            }

            string jsonSnapshot = WriteJson(value);
            VaultSaveQueue.Enqueue(GetStorageKey(), () => WriteJsonSnapshot(jsonSnapshot), b);
        }

        private string GetStorageKey()
        {
            return $"{ResolvedBackend}::{key}";
        }

        private void WriteSnapshot(T value)
        {
            switch (ResolvedBackend)
            {
                case VaultBackend.PlayerPrefs:  WriteToPlayerPrefs(value);  break;
                case VaultBackend.SecuredPrefs: WriteToSecuredPrefs(value); break;
                case VaultBackend.JsonFile:     WriteToJsonFile(value);     break;
            }
        }

        private void WriteEnumSnapshot(int enumValue)
        {
            switch (ResolvedBackend)
            {
                case VaultBackend.PlayerPrefs:  PlayerPrefs.SetInt(key, enumValue);    break;
                case VaultBackend.SecuredPrefs: SecuredPrefs.SetInt(key, enumValue);   break;
                case VaultBackend.JsonFile:     JsonFileStore.SetInt(key, enumValue);  break;
            }
        }

        private void WriteJsonSnapshot(string json)
        {
            switch (ResolvedBackend)
            {
                case VaultBackend.PlayerPrefs:  PlayerPrefs.SetString(key, json);   break;
                case VaultBackend.SecuredPrefs: SecuredPrefs.SetString(key, json);  break;
                case VaultBackend.JsonFile:     JsonFileStore.SetString(key, json); break;
            }
        }

        private T ReadJson(Func<string> readRaw)
        {
            try
            {
                var json = readRaw();
                if (json.IsNullOrWhitespace()) return defaultValue;
                return JsonConvert.DeserializeObject<T>(json);
            }
            catch
            {
                Bug.LogWarning($"[Vault] JSON parse failed for {typeof(T)}, using default.");
            }
            return defaultValue;
        }

        private string WriteJson(T value)
        {
            return JsonConvert.SerializeObject(value);
        }
    }
}
