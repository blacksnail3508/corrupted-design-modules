using Pixon.Observer;

public class CoinChange : GameEvent
{
    public int ChangeValue;
    public CoinChange(int changeValue)
    {
        ChangeValue = changeValue;
    }
}public class BoosterChanged : GameEvent
{
    public BoosterType ChangeType;
    public BoosterChanged(BoosterType changeType)
    {
        ChangeType = changeType;
    }
}

public class BoosterUsed : GameEvent
{
    public BoosterType ChangeType;
    public BoosterUsed(BoosterType changeType)
    {
        ChangeType = changeType;
    }
}
